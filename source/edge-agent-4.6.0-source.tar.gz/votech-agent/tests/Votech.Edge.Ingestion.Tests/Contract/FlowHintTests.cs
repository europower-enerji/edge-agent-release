using Google.Protobuf;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Interfaces;
using Votech.Edge.Mqtt;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Moq;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Tests.Contract;

/// <summary>The backend's flow hint (telemetry throughput B8): gentler only, within the agent's limits, until it expires.</summary>
public sealed class FlowHintTests
{
    private static readonly DateTimeOffset Now = new(2026, 11, 11, 10, 0, 0, TimeSpan.Zero);
    private readonly ManualTimeProvider _clock = new(Now);

    private static V2.FlowHint Hint(uint window, uint size, uint factor, TimeSpan validFor) => new()
    {
        BatchWindowMs = window,
        MaxBatchSize = size,
        BacklogReplayFactor = factor,
        ExpiresAtMs = (Now + validFor).ToUnixTimeMilliseconds(),
    };

    [Fact]
    public void AHint_OnlyMakesTheAgentGentler_WithinItsLimits()
    {
        var hints = new FlowHints(_clock);

        hints.Apply(Hint(5_000, 2_000, 2, TimeSpan.FromMinutes(15)));
        Assert.Equal((5_000, 2_000, 2), (hints.BatchWindowMs(2_000), hints.MaxBatchSize(500), hints.BacklogReplayFactor(10)));

        // Never shorter, smaller or faster than the agent's own, never beyond its limits
        hints.Apply(Hint(1_000, 100, 50, TimeSpan.FromMinutes(15)));
        Assert.Equal((2_000, 500, 10), (hints.BatchWindowMs(2_000), hints.MaxBatchSize(500), hints.BacklogReplayFactor(10)));
        hints.Apply(Hint(600_000, 1_000_000, 1, TimeSpan.FromMinutes(15)));
        Assert.Equal((EdgeAgentOptions.MaxBatchWindowMs, EdgeAgentOptions.MaxBatchSizeLimit, 1), (hints.BatchWindowMs(2_000), hints.MaxBatchSize(500), hints.BacklogReplayFactor(10)));
    }

    [Fact]
    public void AFieldOfZero_AClearedHint_AndAnExpiredHint_KeepTheAgentsOwnSettings()
    {
        var hints = new FlowHints(_clock);

        hints.Apply(Hint(0, 0, 0, TimeSpan.FromMinutes(15)));
        Assert.Equal((2_000, 500, 10), (hints.BatchWindowMs(2_000), hints.MaxBatchSize(500), hints.BacklogReplayFactor(10)));

        hints.Apply(Hint(5_000, 2_000, 2, TimeSpan.FromMinutes(15)));
        hints.Apply(null);
        Assert.Null(hints.Current);

        hints.Apply(Hint(5_000, 2_000, 2, TimeSpan.FromMinutes(15)));
        _clock.Now = Now.AddMinutes(15);
        Assert.Null(hints.Current);
        Assert.Equal(2_000, hints.BatchWindowMs(2_000));
    }

    [Fact]
    public async Task TheSubscriber_TakesTheRetainedHint_AndAnEmptyMessageClearsIt()
    {
        var hints = new FlowHints(_clock);
        var options = Options.Create(new EdgeAgentOptions { SiteId = TestConfigurations.SiteId.ToString(), AgentKey = "k", Mqtt = new MqttOptions { ClientId = "agent", BrokerHost = "localhost", TopicPrefix = "edge" } });
        using var subscriber = new V2CommandSubscriber(options, Mock.Of<IEdgeConfigurationSource>(), Mock.Of<IProbeHandler>(), Mock.Of<IMqttPublisher>(), hints, NullLogger<V2CommandSubscriber>.Instance);
        Assert.Equal($"edge/v2/commands/{TestConfigurations.SiteId}/flow", subscriber.FlowTopic);

        await subscriber.HandleAsync(subscriber.FlowTopic, Hint(5_000, 2_000, 2, TimeSpan.FromMinutes(15)).ToByteArray());
        Assert.Equal(5_000, hints.BatchWindowMs(2_000));

        await subscriber.HandleAsync(subscriber.FlowTopic, []);
        Assert.Null(hints.Current);
    }
}
