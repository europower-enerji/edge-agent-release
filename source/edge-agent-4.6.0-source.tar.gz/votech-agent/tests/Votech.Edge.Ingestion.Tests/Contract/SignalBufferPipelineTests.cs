using lib60870;
using lib60870.CS101;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Entities;
using Votech.Edge.Core.Interfaces;
using Votech.Edge.Core.Models;
using Votech.Edge.Ingestion.Iec104;
using Votech.Edge.Ingestion.Services;
using Votech.Edge.Mqtt;
using Votech.Edge.Storage;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Moq;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Tests.Contract;

/// <summary>The v2 path from the pollers to the broker: sink → SQLite buffer → publisher.</summary>
public sealed class SignalBufferPipelineTests : IDisposable
{
    private static readonly DateTime At = new(2026, 10, 19, 10, 0, 0, DateTimeKind.Utc);
    private readonly SqliteTestDatabase _db = new();
    private readonly SqliteSignalBuffer _buffer;
    private readonly Mock<IMqttPublisher> _mqtt = new();
    private readonly List<V2.SignalBatch> _published = [];

    public SignalBufferPipelineTests()
    {
        _buffer = new SqliteSignalBuffer(_db, NullLogger<SqliteSignalBuffer>.Instance);
        _mqtt.SetupGet(m => m.IsConnected).Returns(true);
        _mqtt.Setup(m => m.PublishSignalBatchAsync(It.IsAny<V2.SignalBatch>(), It.IsAny<CancellationToken>()))
            .Callback<V2.SignalBatch, CancellationToken>((batch, _) => _published.Add(batch.Clone()))
            .Returns(Task.CompletedTask);
    }

    public void Dispose()
    {
        _buffer.Dispose();
        _db.Dispose();
    }

    private static IOptions<EdgeAgentOptions> Options(int maxBatchSize = 500, int windowMs = 50) =>
        Microsoft.Extensions.Options.Options.Create(new EdgeAgentOptions
        {
            SiteId = TestConfigurations.SiteId.ToString(),
            MaxBatchSize = maxBatchSize,
            BatchWindowMs = windowMs,
            FlushIntervalMs = 100,
        });

    private static SignalReading Reading(Guid endpointId, double value, Guid? signalId = null) =>
        new(signalId ?? Guid.NewGuid(), endpointId, value, At.AddSeconds(value), CanonicalQualityStatus.Good, 0, SampleTimeSource.ReceiptUntimed);

    // The publisher's clock is the time the test batches are stored at, so they are live, not a backlog
    private readonly ManualTimeProvider _clock = new(new DateTimeOffset(At));

    private SignalBatchPublisher Publisher(IOptions<EdgeAgentOptions>? options = null) =>
        new(_buffer, _mqtt.Object, options ?? Options(), NullLogger<SignalBatchPublisher>.Instance, _clock);

    [Fact]
    public void Readings_AreBatchedPerConnection_WithinTheLargestBatch_AndCarryTheRevision()
    {
        Guid first = Guid.NewGuid(), second = Guid.NewGuid();
        var readings = Enumerable.Range(0, 5).Select(i => Reading(first, i)).Append(Reading(second, 9)).ToList();

        var batches = SignalSampleSink.ToBatches(readings, "rev-7", new DateTimeOffset(At), maxBatchSize: 2);

        Assert.Equal([(first, 2), (first, 2), (first, 1), (second, 1)], batches.Select(b => (EdgeIds.ToGuid(b.Batch.EndpointId), b.Batch.SampleCount)));
        Assert.All(batches, b => Assert.Equal("rev-7", b.Batch.ConfigRevision));
        Assert.Equal(4, batches.Select(b => Convert.ToHexString(b.Batch.BatchId)).Distinct().Count());
        Assert.All(batches, b => Assert.All(b.Samples, s => Assert.Equal(b.Batch.BatchId, s.BatchId)));
        Assert.Equal([0.0, 1, 2, 3, 4], batches.Take(3).SelectMany(b => b.Samples).Select(s => s.Value));
    }

    [Fact]
    public async Task TheSink_StoresWhatItCollected_WhenDrained()
    {
        var source = new Mock<IEdgeConfigurationSource>();
        source.SetupGet(s => s.Current).Returns(TestConfigurations.Iec104("rev-1"));
        var sink = new SignalSampleSink(_buffer, source.Object, Options(windowMs: 10_000), NullLogger<SignalSampleSink>.Instance);
        Guid first = Guid.NewGuid(), second = Guid.NewGuid();

        sink.Write(Reading(first, 1));
        sink.Write(Reading(first, 2));
        sink.Write(Reading(second, 3));
        await sink.DrainAsync();
        sink.Write(Reading(first, 4));

        await using var db = _db.CreateDbContext();
        Assert.Equal(2, await db.SignalBatches.CountAsync());
        Assert.Equal([1.0, 2, 3], (await db.SignalSamples.OrderBy(s => s.Id).ToListAsync()).Select(s => s.Value));
        Assert.All(await db.SignalBatches.ToListAsync(), b => Assert.Equal("rev-1", b.ConfigRevision));
    }

    /// <summary>A buffer that fails the first <paramref name="failures"/> stores, and records every attempt.</summary>
    private sealed class FailingBuffer(ISignalBuffer inner, int failures) : ISignalBuffer
    {
        private int _failures = failures;

        public List<IReadOnlyList<StoredSignalBatch>> Attempts { get; } = [];

        public Task SaveAsync(IReadOnlyList<StoredSignalBatch> batches, CancellationToken ct)
        {
            Attempts.Add(batches);
            return Interlocked.Decrement(ref _failures) >= 0 ? Task.FromException(new IOException("disk I/O error")) : inner.SaveAsync(batches, ct);
        }

        public Task<StoredSignalBatch?> NextUnpublishedAsync(long storedFromMs, CancellationToken ct) => inner.NextUnpublishedAsync(storedFromMs, ct);
        public Task<long> StoredSamplesSinceAsync(long sinceMs, CancellationToken ct) => inner.StoredSamplesSinceAsync(sinceMs, ct);
        public Task MarkPublishedAsync(byte[] batchId, CancellationToken ct) => inner.MarkPublishedAsync(batchId, ct);
        public Task WaitForBatchesAsync(TimeSpan timeout, CancellationToken ct) => inner.WaitForBatchesAsync(timeout, ct);
        public Task<SignalBufferStatus> GetStatusAsync(CancellationToken ct) => inner.GetStatusAsync(ct);
        public Task<int> PurgePublishedAsync(int retentionDays, CancellationToken ct) => inner.PurgePublishedAsync(retentionDays, ct);
        public Task EnforceStorageCapAsync(StorageOptions options, CancellationToken ct) => inner.EnforceStorageCapAsync(options, ct);
        public Task CheckpointDatabaseAsync(CancellationToken ct) => inner.CheckpointDatabaseAsync(ct);
        public bool IsEvicting => inner.IsEvicting;
        public long EvictedTotal => inner.EvictedTotal;
    }

    private SignalSampleSink Sink(ISignalBuffer buffer, IOptions<EdgeAgentOptions>? options = null)
    {
        var source = new Mock<IEdgeConfigurationSource>();
        source.SetupGet(s => s.Current).Returns(TestConfigurations.Iec104("rev-1"));
        return new SignalSampleSink(buffer, source.Object, options ?? Options(windowMs: 10_000), NullLogger<SignalSampleSink>.Instance)
        {
            StoreRetryFirstDelay = TimeSpan.FromMilliseconds(1),
        };
    }

    [Fact]
    public async Task AFailedStore_IsRetriedWithTheSameBatches()
    {
        var buffer = new FailingBuffer(_buffer, failures: 2);
        var sink = Sink(buffer);
        var endpoint = Guid.NewGuid();

        sink.Write(Reading(endpoint, 1));
        sink.Write(Reading(endpoint, 2));
        await sink.DrainAsync();

        Assert.Equal(3, buffer.Attempts.Count);
        Assert.Single(buffer.Attempts.Select(a => Convert.ToHexString(Assert.Single(a).Batch.BatchId)).Distinct());
        Assert.Equal(2, (await _buffer.GetStatusAsync(default)).UnpublishedSamples);
        Assert.Equal(0, sink.DroppedTotal);
    }

    [Fact]
    public async Task AStoreThatKeepsFailing_IsDroppedAndCounted()
    {
        var buffer = new FailingBuffer(_buffer, failures: int.MaxValue);
        var sink = Sink(buffer);

        sink.Write(Reading(Guid.NewGuid(), 1));
        sink.Write(Reading(Guid.NewGuid(), 2));
        await sink.DrainAsync();

        Assert.Equal(StorageConstants.StoreAttempts, buffer.Attempts.Count);
        Assert.Equal(2, sink.DroppedTotal);
    }

    /// <summary>The sink's log, kept for assertions.</summary>
    private sealed class SinkLog : ILogger<SignalSampleSink>
    {
        public ListLogger Inner { get; } = new() { MinimumLevel = LogLevel.Warning };
        public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;
        public bool IsEnabled(LogLevel logLevel) => Inner.IsEnabled(logLevel);
        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter) =>
            Inner.Log(logLevel, eventId, state, exception, formatter);
    }

    [Fact]
    public async Task NaNAndInfinity_AreDropped_WarnedOncePerSignal_AndTheOtherReadingsAreStored()
    {
        var source = new Mock<IEdgeConfigurationSource>();
        source.SetupGet(s => s.Current).Returns(TestConfigurations.Iec104("rev-1"));
        var log = new SinkLog();
        var sink = new SignalSampleSink(_buffer, source.Object, Options(windowMs: 10_000), log);
        Guid endpoint = Guid.NewGuid(), broken = Guid.NewGuid(), meter = Guid.NewGuid();

        sink.Write(Reading(endpoint, 1, meter));
        sink.Write(new SignalReading(broken, endpoint, double.NaN, At, CanonicalQualityStatus.Bad, 0x80, SampleTimeSource.ReceiptUntimed));
        sink.Write(new SignalReading(broken, endpoint, double.PositiveInfinity, At, CanonicalQualityStatus.Good, 0, SampleTimeSource.ReceiptUntimed));
        sink.Write(new SignalReading(meter, endpoint, double.NegativeInfinity, At, CanonicalQualityStatus.Good, 0, SampleTimeSource.ReceiptUntimed));
        sink.Write(Reading(endpoint, 2, meter));
        await sink.DrainAsync();

        await using var db = _db.CreateDbContext();
        Assert.Equal([1.0, 2], (await db.SignalSamples.OrderBy(s => s.Id).ToListAsync()).Select(s => s.Value));
        Assert.Equal(0, sink.DroppedTotal);
        // One warning per signal, however many such values it sends.
        Assert.Equal(2, log.Inner.Messages.Count(m => m.Contains("not a number")));
    }

    [Fact]
    public async Task AnIec104NaN_WithTheInvalidFlag_NeverReachesTheBuffer()
    {
        var station = Guid.NewGuid();
        var power = Guid.NewGuid();
        var connection = TestConfigurations.Iec104("rev-1", (station, 11, [(power, "1001", V2.DataType.Float32)])).Connections[0];
        var map = new Iec104PointMap(connection, NullLogger.Instance);
        var asdu = new ASDU(new ApplicationLayerParameters(), CauseOfTransmission.SPONTANEOUS, false, false, 0, 11, false);
        asdu.AddInformationObject(new MeasuredValueShort(1001, float.NaN, new QualityDescriptor { Invalid = true }));
        var bytes = asdu.AsByteArray();
        var sink = Sink(_buffer);

        var reading = Assert.Single(Iec104SignalMapper.Map(new ASDU(new ApplicationLayerParameters(), bytes, 0, bytes.Length), map, EdgeIds.ToGuid(connection.EndpointId), At, out _));
        sink.Write(reading);
        await sink.DrainAsync();

        Assert.True(double.IsNaN(reading.Value));
        Assert.Equal(0, (await _buffer.GetStatusAsync(default)).UnpublishedSamples);
    }

    [Fact]
    public async Task AQueueOverflow_IsCounted()
    {
        var options = Microsoft.Extensions.Options.Options.Create(new EdgeAgentOptions
        {
            SiteId = TestConfigurations.SiteId.ToString(),
            BatchWindowMs = 10_000,
            Storage = new StorageOptions { MaxPendingQueueSize = 100 },
        });
        var sink = Sink(_buffer, options);
        var endpoint = Guid.NewGuid();

        for (var i = 0; i < 150; i++)
        {
            sink.Write(Reading(endpoint, i));
        }

        await sink.DrainAsync();

        Assert.Equal(50, sink.DroppedTotal);
        Assert.Equal(100, (await _buffer.GetStatusAsync(default)).UnpublishedSamples);
    }

    [Fact]
    public async Task ThePublisher_SendsTheOldestBatchFirst_AndMarksItAfterTheAcknowledgement()
    {
        var endpoint = Guid.NewGuid();
        await _buffer.SaveAsync(SignalSampleSink.ToBatches([Reading(endpoint, 1), Reading(endpoint, 2)], "rev", new DateTimeOffset(At), 1), default);

        Assert.Equal(2, await Publisher().PublishPendingAsync(default));

        Assert.Equal([1.0, 2.0], _published.Select(b => b.Samples.Single().Value));
        var message = _published[0];
        Assert.Equal((TestConfigurations.SiteId, endpoint, "rev"), (EdgeIds.ToGuid(message.SiteId), EdgeIds.ToGuid(message.EndpointId), message.ConfigRevision));
        Assert.Equal((V2.Quality.Good, new DateTimeOffset(At.AddSeconds(1)).ToUnixTimeMilliseconds()), (message.Samples[0].Quality, message.Samples[0].TimestampMs));
        Assert.Null(await _buffer.NextUnpublishedAsync(0, default));
        Assert.Equal(0, (await _buffer.GetStatusAsync(default)).UnpublishedSamples);
    }

    /// <summary>Stores <paramref name="count"/> batches of <paramref name="samples"/> samples of one endpoint, stored at <paramref name="storedAt"/>.</summary>
    private async Task<List<double>> StoreBatchesAsync(DateTimeOffset storedAt, int count, int samples, double firstValue)
    {
        var endpoint = Guid.NewGuid();
        var values = Enumerable.Range(0, count * samples).Select(i => firstValue + i).ToList();
        await _buffer.SaveAsync(SignalSampleSink.ToBatches([.. values.Select(v => Reading(endpoint, v))], "rev", storedAt, samples), default);
        return values;
    }

    /// <summary>A3: after an outage, live readings go first and the backlog follows at the replay rate, oldest first.</summary>
    [Fact]
    public async Task AfterAnOutage_LiveReadingsGoFirst_AndTheBacklogFollowsAtTheReplayRate()
    {
        var now = new DateTimeOffset(At).AddHours(1);
        _clock.Now = now;
        // An hour-old backlog of 5 batches of 100, and 3 live batches of 100 stored within the last minute: the site
        // produces 300 samples a minute, so the backlog may send 10 × 5 = 50 samples/s, at least one full batch (100) a second
        var backlog = await StoreBatchesAsync(now.AddHours(-1), 5, 100, 0);
        var live = await StoreBatchesAsync(now.AddSeconds(-5), 3, 100, 10_000);
        var publisher = Publisher(Options(maxBatchSize: 100));

        Assert.Equal(3, await publisher.PublishPendingAsync(default));
        Assert.Equal(live, _published.SelectMany(b => b.Samples).Select(s => s.Value));
        Assert.True(publisher.HasBacklog);

        // One second later the budget holds one full batch: the oldest of the backlog goes, and a new live batch first
        _clock.Now = now.AddSeconds(1);
        var newer = await StoreBatchesAsync(_clock.Now, 1, 100, 20_000);
        _published.Clear();
        Assert.Equal(2, await publisher.PublishPendingAsync(default));
        Assert.Equal([.. newer, .. backlog.Take(100)], _published.SelectMany(b => b.Samples).Select(s => s.Value));

        // A long pause is not stored up into a flood: the budget holds one flush interval (at least one batch)
        _clock.Now = now.AddMinutes(10);
        _published.Clear();
        Assert.Equal(1, await publisher.PublishPendingAsync(default));
        Assert.Equal(backlog.Skip(100).Take(100), _published.SelectMany(b => b.Samples).Select(s => s.Value));

        for (var second = 11; publisher.HasBacklog && second < 20; second++)
        {
            _clock.Now = now.AddMinutes(second);
            await publisher.PublishPendingAsync(default);
        }

        Assert.False(publisher.HasBacklog);
        Assert.Null(await _buffer.NextUnpublishedAsync(0, default));
    }

    /// <summary>A3: what waits while the broker is down is a backlog when it is back, even during a catch-up.</summary>
    [Fact]
    public async Task WhatWaitedWhileTheBrokerWasDown_IsABacklog_WhenItIsBack()
    {
        var now = new DateTimeOffset(At).AddHours(1);
        _clock.Now = now;
        await StoreBatchesAsync(now.AddHours(-1), 2, 100, 0);
        var publisher = Publisher(Options(maxBatchSize: 100));
        Assert.Equal(0, await publisher.PublishPendingAsync(default));
        Assert.True(publisher.HasBacklog);

        // The broker goes down for a while; what is stored meanwhile is not live when it is back
        _mqtt.SetupGet(m => m.IsConnected).Returns(false);
        Assert.Equal(0, await publisher.PublishPendingAsync(default));
        Assert.False(publisher.HasBacklog);
        await StoreBatchesAsync(now.AddMinutes(1), 1, 100, 5_000);
        _clock.Now = now.AddMinutes(5);
        _mqtt.SetupGet(m => m.IsConnected).Returns(true);

        // Everything is a backlog now; its budget starts empty and the oldest batch goes first a second later
        Assert.Equal(0, await publisher.PublishPendingAsync(default));
        Assert.True(publisher.HasBacklog);
        _clock.Now = now.AddMinutes(5).AddSeconds(1);
        Assert.Equal(1, await publisher.PublishPendingAsync(default));
        Assert.Equal(0.0, _published.Single().Samples[0].Value);
    }

    /// <summary>A3: the live and rate queries read the index, without sorting the table.</summary>
    [Fact]
    public async Task TheLiveAndRateQueries_ReadTheIndex()
    {
        await StoreBatchesAsync(new DateTimeOffset(At), 2, 10, 0);
        _db.Commands.Clear();

        Assert.NotNull(await _buffer.NextUnpublishedAsync(new DateTimeOffset(At).ToUnixTimeMilliseconds(), default));
        Assert.Equal(20, await _buffer.StoredSamplesSinceAsync(new DateTimeOffset(At).AddMinutes(-1).ToUnixTimeMilliseconds(), default));

        var batchQueries = _db.Commands.Where(sql => sql.Contains("SignalBatches")).ToList();
        Assert.Equal(2, batchQueries.Count);
        Assert.All(batchQueries, sql =>
        {
            var plan = _db.QueryPlan(sql);
            Assert.Contains(plan, step => step.Contains("USING INDEX IX_SignalBatches_IsPublished_CreatedAt (is_published=? AND created_at>?)"));
            Assert.DoesNotContain(plan, step => step.Contains("TEMP B-TREE"));
        });
    }

    [Fact]
    public async Task ASamplesTimeSource_ReachesTheWire()
    {
        var endpoint = Guid.NewGuid();
        var skewed = new SignalReading(Guid.NewGuid(), endpoint, 1, At, CanonicalQualityStatus.Good, 0, SampleTimeSource.ReceiptClockSkew, DeviceTimestampMs: 1_613_079_540_000);
        var device = new SignalReading(Guid.NewGuid(), endpoint, 2, At.AddSeconds(-2), CanonicalQualityStatus.Good, 0, SampleTimeSource.Device, ReceiveLagMs: 2_000);
        await _buffer.SaveAsync(SignalSampleSink.ToBatches([skewed, device], "rev", new DateTimeOffset(At), 500), default);

        await Publisher().PublishPendingAsync(default);

        var samples = Assert.Single(_published).Samples;
        Assert.Equal(
            [(V2.TimeSource.ReceiptClockSkew, false, 1_613_079_540_000L, 0L), (V2.TimeSource.Device, true, 0L, 2_000L)],
            samples.Select(s => (s.TimeSource, s.DeviceTime, s.DeviceTimestampMs, s.ReceiveLagMs)));
    }

    [Fact]
    public async Task TheOutboxAndTheBufferStatus_ReadTheIndex_WithoutSortingTheTable()
    {
        var endpoint = Guid.NewGuid();
        await _buffer.SaveAsync(SignalSampleSink.ToBatches([Reading(endpoint, 1), Reading(endpoint, 2)], "rev", new DateTimeOffset(At), 1), default);
        _db.Commands.Clear();

        Assert.NotNull(await _buffer.NextUnpublishedAsync(0, default));
        Assert.Equal(new SignalBufferStatus(2, new DateTimeOffset(At).ToUnixTimeMilliseconds()), await _buffer.GetStatusAsync(default));

        var batchQueries = _db.Commands.Where(sql => sql.Contains("SignalBatches")).ToList();
        Assert.Equal(2, batchQueries.Count);
        Assert.All(batchQueries, sql =>
        {
            var plan = _db.QueryPlan(sql);
            Assert.Contains(plan, step => step.Contains("USING INDEX IX_SignalBatches_IsPublished_CreatedAt (is_published=?"));
            Assert.DoesNotContain(plan, step => step.Contains("TEMP B-TREE"));
        });
    }

    [Fact]
    public async Task ABatchThatWasNotAcknowledged_IsResentWithTheSameIdAndSamples()
    {
        var endpoint = Guid.NewGuid();
        await _buffer.SaveAsync(SignalSampleSink.ToBatches([Reading(endpoint, 1), Reading(endpoint, 2)], "rev", new DateTimeOffset(At), 500), default);
        var attempts = new List<V2.SignalBatch>();
        _mqtt.SetupSequence(m => m.PublishSignalBatchAsync(It.IsAny<V2.SignalBatch>(), It.IsAny<CancellationToken>()))
            .Throws(new TimeoutException("no PUBACK"))
            .Returns(Task.CompletedTask)
            .Returns(Task.CompletedTask);
        _mqtt.Invocations.Clear();

        Assert.Equal(0, await Publisher().PublishPendingAsync(default));
        // More samples arrive before the retry; they travel in a batch of their own.
        await _buffer.SaveAsync(SignalSampleSink.ToBatches([Reading(endpoint, 3)], "rev", new DateTimeOffset(At).AddSeconds(5), 500), default);
        Assert.Equal(2, await Publisher().PublishPendingAsync(default));

        var sent = _mqtt.Invocations.Where(i => i.Method.Name == nameof(IMqttPublisher.PublishSignalBatchAsync)).Select(i => (V2.SignalBatch)i.Arguments[0]).ToList();
        Assert.Equal(3, sent.Count);
        Assert.Equal(sent[0].BatchId, sent[1].BatchId);
        Assert.Equal(sent[0].Samples, sent[1].Samples);
        Assert.Equal([3.0], sent[2].Samples.Select(s => s.Value));
        Assert.NotEqual(sent[0].BatchId, sent[2].BatchId);
    }

    [Fact]
    public async Task NothingIsSentWhileTheBrokerIsDown()
    {
        _mqtt.SetupGet(m => m.IsConnected).Returns(false);
        await _buffer.SaveAsync(SignalSampleSink.ToBatches([Reading(Guid.NewGuid(), 1)], "rev", new DateTimeOffset(At), 500), default);

        Assert.Equal(0, await Publisher().PublishPendingAsync(default));
        Assert.Equal(1, (await _buffer.GetStatusAsync(default)).UnpublishedSamples);
    }

    /// <summary>10 batches of 10 samples; the 3 oldest are published.</summary>
    private async Task StoreTenBatchesThreePublishedAsync(SqliteSignalBuffer buffer)
    {
        var endpoint = Guid.NewGuid();
        for (var i = 0; i < 10; i++)
        {
            await buffer.SaveAsync(SignalSampleSink.ToBatches(Enumerable.Range(0, 10).Select(v => Reading(endpoint, v)).ToList(), "rev", new DateTimeOffset(At).AddSeconds(i), 500), default);
        }

        await using var db = _db.CreateDbContext();
        var published = await db.SignalBatches.OrderBy(b => b.CreatedAtMs).Take(3).Select(b => b.BatchId).ToListAsync();
        await db.SignalBatches.Where(b => published.Contains(b.BatchId)).ExecuteUpdateAsync(s => s.SetProperty(b => b.IsPublished, true));
    }

    [Fact]
    public async Task TheCap_DeletesWholePublishedBatches_AndKeepsUnpublishedOnes()
    {
        await StoreTenBatchesThreePublishedAsync(_buffer);

        await _buffer.EnforceStorageCapAsync(new StorageOptions { MaxRecordCapacity = 60, MinFreeDiskSpaceGb = 0, MinFreeDiskSpacePercent = 0 }, default);

        await using var check = _db.CreateDbContext();
        // 100 samples, 60 allowed: the 3 published batches go, the 7 unpublished stay until they are sent.
        Assert.Equal(70, await check.SignalSamples.CountAsync());
        Assert.Equal(0, await check.SignalBatches.CountAsync(b => b.IsPublished));
        Assert.Equal((false, 0L), (_buffer.IsEvicting, _buffer.EvictedTotal));
        Assert.Equal(await check.SignalBatches.SumAsync(b => b.SampleCount), await check.SignalSamples.CountAsync());
    }

    [Fact]
    public async Task TheDiskFloor_DeletesPublishedThenUnpublishedBatches_AndCountsThem()
    {
        var disk = new SqliteSignalBuffer.DiskSpace(AvailableBytes: 1L << 30, TotalBytes: 100L << 30); // 1 GB free of 100
        using var buffer = new SqliteSignalBuffer(_db, NullLogger<SqliteSignalBuffer>.Instance, _ => disk);
        await StoreTenBatchesThreePublishedAsync(buffer);

        await buffer.EnforceStorageCapAsync(new StorageOptions { MaxRecordCapacity = 60, MinFreeDiskSpaceGb = 2, MinFreeDiskSpacePercent = 0 }, default);

        await using var check = _db.CreateDbContext();
        // Below the 2 GB floor: back to 54 samples by deleting at least 46, as whole batches of 10.
        Assert.Equal(50, await check.SignalSamples.CountAsync());
        Assert.Equal(0, await check.SignalBatches.CountAsync(b => b.IsPublished));
        Assert.Equal((true, 20L), (buffer.IsEvicting, buffer.EvictedTotal));
        Assert.All(await check.SignalBatches.ToListAsync(), b => Assert.Equal(10, b.SampleCount));

        disk = disk with { AvailableBytes = 50L << 30 };
        await buffer.EnforceStorageCapAsync(new StorageOptions { MaxRecordCapacity = 1000, MinFreeDiskSpaceGb = 2, MinFreeDiskSpacePercent = 0 }, default);
        Assert.Equal((false, 20L), (buffer.IsEvicting, buffer.EvictedTotal));
    }

    [Fact]
    public async Task TheSizeCap_CountsThePagesInUse_NotTheFreePagesOfTheFile()
    {
        var endpoint = Guid.NewGuid();
        for (var i = 0; i < 20; i++)
        {
            await _buffer.SaveAsync(SignalSampleSink.ToBatches(Enumerable.Range(0, 1000).Select(v => Reading(endpoint, v)).ToList(), "rev", new DateTimeOffset(At).AddSeconds(i), 1000), default);
        }

        await using (var db = _db.CreateDbContext())
        {
            // Most samples were sent and purged: SQLite keeps their pages as free pages, the file does not shrink.
            var purged = await db.SignalBatches.OrderBy(b => b.CreatedAtMs).Take(19).Select(b => b.BatchId).ToListAsync();
            await db.SignalSamples.Where(s => purged.Contains(s.BatchId)).ExecuteDeleteAsync();
            await db.SignalBatches.Where(b => purged.Contains(b.BatchId)).ExecuteDeleteAsync();
            var freeBytes = await db.Database.SqlQueryRaw<long>("SELECT (SELECT freelist_count FROM pragma_freelist_count()) * (SELECT page_size FROM pragma_page_size()) AS Value").SingleAsync();
            Assert.True(freeBytes > 1024 * 1024, $"only {freeBytes} bytes of free pages");
        }

        await _buffer.EnforceStorageCapAsync(new StorageOptions { MaxDbSizeMb = 1, MinFreeDiskSpaceGb = 0, MinFreeDiskSpacePercent = 0 }, default);

        await using var check = _db.CreateDbContext();
        Assert.Equal(1000, await check.SignalSamples.CountAsync());
        Assert.False(_buffer.IsEvicting);
    }

    [Fact]
    public async Task OldPublishedBatches_ArePurged_AndUnpublishedOnesKept()
    {
        var endpoint = Guid.NewGuid();
        var old = DateTimeOffset.UtcNow.AddDays(-10);
        await _buffer.SaveAsync(SignalSampleSink.ToBatches([Reading(endpoint, 1)], "rev", old, 500), default);
        await _buffer.SaveAsync(SignalSampleSink.ToBatches([Reading(endpoint, 2)], "rev", old, 500), default);
        await _buffer.SaveAsync(SignalSampleSink.ToBatches([Reading(endpoint, 3)], "rev", DateTimeOffset.UtcNow, 500), default);
        var oldest = (await _buffer.NextUnpublishedAsync(0, default))!;
        await _buffer.MarkPublishedAsync(oldest.Batch.BatchId, default);

        Assert.Equal(1, await _buffer.PurgePublishedAsync(7, default));

        await using var db = _db.CreateDbContext();
        Assert.Equal([2.0, 3.0], (await db.SignalSamples.OrderBy(s => s.Id).ToListAsync()).Select(s => s.Value));
    }

    [Fact]
    public async Task StoringABatch_WakesThePublisher()
    {
        var wait = _buffer.WaitForBatchesAsync(TimeSpan.FromSeconds(10), default);
        Assert.False(wait.IsCompleted);

        await _buffer.SaveAsync(SignalSampleSink.ToBatches([Reading(Guid.NewGuid(), 1)], "rev", new DateTimeOffset(At), 500), default);

        Assert.Same(wait, await Task.WhenAny(wait, Task.Delay(5000)));
    }
}
