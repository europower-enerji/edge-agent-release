using Google.Protobuf;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Mqtt;

/// <summary>
/// The only path from the buffer to the broker (contract v2): sends unpublished batches as <c>SignalBatch</c> to
/// <c>{prefix}/v2/telemetry/{siteId}/{endpointId}</c>, marks each published after the broker's PUBACK, and repeats until
/// the buffer is empty. It wakes when batches are stored, and every <c>FlushIntervalMs</c>. A failed publish leaves the
/// batch in place; the next attempt sends the same samples under the same batch id, so the backend applies it once.
/// <para>
/// Live before backlog (telemetry throughput A3). When the broker is back after an outage, or the oldest unsent batch
/// waited longer than <see cref="LiveHorizon"/>, a cut is set: batches stored after it are live and go first, oldest
/// first; batches stored before it are the backlog and follow, oldest first, at up to <c>BacklogReplayFactor</c> times
/// the rate the site produces readings (measured over <see cref="RateWindow"/>), and at least one full batch per second.
/// A site of any size thus catches up about that many times faster than real time, its live readings never wait behind
/// its history, and a long catch-up does not flood the backend. The cut is cleared once the backlog is sent.
/// </para>
/// </summary>
public sealed class SignalBatchPublisher(
    ISignalBuffer buffer,
    IMqttPublisher publisher,
    IOptions<EdgeAgentOptions> options,
    ILogger<SignalBatchPublisher> logger,
    TimeProvider? timeProvider = null,
    FlowHints? flowHints = null
)
{
    private static readonly TimeSpan SummaryInterval = TimeSpan.FromMinutes(1);

    /// <summary>A batch that waited longer than this was not sent live: what waits is a backlog.</summary>
    public static readonly TimeSpan LiveHorizon = TimeSpan.FromSeconds(30);

    /// <summary>The window over which the site's own rate of readings is measured.</summary>
    public static readonly TimeSpan RateWindow = TimeSpan.FromMinutes(1);

    private readonly ISignalBuffer _buffer = buffer;
    private readonly IMqttPublisher _publisher = publisher;
    private readonly EdgeAgentOptions _options = options.Value;
    private readonly ILogger<SignalBatchPublisher> _logger = logger;
    private readonly TimeProvider _time = timeProvider ?? TimeProvider.System;
    private readonly FlowHints _flowHints = flowHints ?? new FlowHints(timeProvider);
    private readonly Guid _siteId = Guid.TryParse(options.Value.SiteId, out var siteId) ? siteId : Guid.Empty;
    private long _batches;
    private long _samples;
    private DateTimeOffset _summaryAt = (timeProvider ?? TimeProvider.System).GetUtcNow();

    // The backlog: batches stored before the cut, sent at the replay rate from a budget of samples
    private long? _backlogCutMs;
    private double _replayBudget;
    private DateTimeOffset _budgetAt;
    private DateTimeOffset _backlogStartedAt;
    private long _backlogSamples;

    /// <summary>True while a backlog is being sent behind the live readings.</summary>
    public bool HasBacklog => _backlogCutMs != null;

    public async Task RunAsync(CancellationToken ct)
    {
        var interval = TimeSpan.FromMilliseconds(_options.FlushIntervalMs);
        while (!ct.IsCancellationRequested)
        {
            try
            {
                await PublishPendingAsync(ct);
                await _buffer.WaitForBatchesAsync(interval, ct);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "[MQTT-V2] Publishing from the buffer failed; retrying.");
                await Task.Delay(interval, _time, ct);
            }
        }
    }

    /// <summary>
    /// Publishes the live batches, then the backlog as far as its replay budget allows, until the buffer is empty, the
    /// budget is spent or a publish fails; returns the number of batches sent. While the broker is down nothing is sent,
    /// and the cut is cleared, so everything that waits when it is back is a backlog.
    /// </summary>
    public async Task<int> PublishPendingAsync(CancellationToken ct)
    {
        if (!_publisher.IsConnected)
        {
            _backlogCutMs = null;
            return 0;
        }

        var now = _time.GetUtcNow();
        await FindBacklogAsync(now, ct);
        var replayRate = _backlogCutMs != null ? await ReplayRateAsync(now, ct) : 0;
        var sent = 0;
        while (_publisher.IsConnected)
        {
            var stored = await _buffer.NextUnpublishedAsync(_backlogCutMs ?? 0, ct);
            var fromBacklog = false;
            if (stored == null && _backlogCutMs != null)
            {
                stored = await _buffer.NextUnpublishedAsync(0, ct);
                if (stored == null)
                {
                    EndBacklog();
                    break;
                }

                if (!MayReplay(stored.Samples.Count, replayRate))
                {
                    break;
                }

                fromBacklog = true;
            }

            if (stored == null)
            {
                break;
            }

            var batch = ToMessage(stored, _siteId, _time.GetUtcNow());
            try
            {
                await _publisher.PublishSignalBatchAsync(batch, ct);
            }
            catch (Exception ex) when (ex is not OperationCanceledException || !ct.IsCancellationRequested)
            {
                _logger.LogWarning(
                    ex,
                    "[MQTT-V2] Batch {BatchId} ({Count} samples) was not acknowledged; it stays in the buffer.",
                    Convert.ToHexStringLower(stored.Batch.BatchId),
                    stored.Samples.Count
                );
                break;
            }

            await _buffer.MarkPublishedAsync(stored.Batch.BatchId, ct);
            sent++;
            _batches++;
            _samples += stored.Samples.Count;
            if (fromBacklog)
            {
                _replayBudget -= stored.Samples.Count;
                _backlogSamples += stored.Samples.Count;
            }
        }

        await LogSummaryAsync(ct);
        return sent;
    }

    /// <summary>Sets the cut when the oldest unsent batch waited longer than <see cref="LiveHorizon"/>.</summary>
    private async Task FindBacklogAsync(DateTimeOffset now, CancellationToken ct)
    {
        if (_backlogCutMs != null)
        {
            return;
        }

        var waiting = await _buffer.GetStatusAsync(ct);
        var cut = (now - LiveHorizon).ToUnixTimeMilliseconds();
        if (waiting.OldestUnpublishedMs == 0 || waiting.OldestUnpublishedMs >= cut)
        {
            return;
        }

        _backlogCutMs = cut;
        _replayBudget = 0;
        _budgetAt = now;
        _backlogStartedAt = now;
        _backlogSamples = 0;
        _logger.LogInformation(
            "[MQTT-V2] {Samples} samples waited since {Oldest:u}: live readings go first, and this backlog follows at up to {Factor} times the site's rate.",
            waiting.UnpublishedSamples,
            DateTimeOffset.FromUnixTimeMilliseconds(waiting.OldestUnpublishedMs),
            _options.BacklogReplayFactor
        );
    }

    /// <summary>
    /// Samples per second the backlog may send: <c>BacklogReplayFactor</c> (or the backend's smaller flow hint) times
    /// what the site stored over the last <see cref="RateWindow"/>, and at least one full batch per second.
    /// </summary>
    private async Task<double> ReplayRateAsync(DateTimeOffset now, CancellationToken ct)
    {
        var produced = await _buffer.StoredSamplesSinceAsync((now - RateWindow).ToUnixTimeMilliseconds(), ct);
        return Math.Max(_flowHints.BacklogReplayFactor(_options.BacklogReplayFactor) * produced / RateWindow.TotalSeconds, Math.Max(1, _options.MaxBatchSize));
    }

    /// <summary>
    /// Whether the backlog may send a batch of <paramref name="samples"/> now. The budget grows at the replay rate and
    /// holds at most one flush interval of it (and one full batch), so a pause of the publisher is made up for, never
    /// stored up into a flood.
    /// </summary>
    private bool MayReplay(int samples, double rate)
    {
        var now = _time.GetUtcNow();
        var ceiling = rate * Math.Max(1, _options.FlushIntervalMs / 1000.0);
        _replayBudget = Math.Min(Math.Max(ceiling, samples), _replayBudget + rate * (now - _budgetAt).TotalSeconds);
        _budgetAt = now;
        return _replayBudget >= samples;
    }

    private void EndBacklog()
    {
        _logger.LogInformation(
            "[MQTT-V2] The backlog is sent: {Samples} samples in {Seconds:0} s, behind the live readings.",
            _backlogSamples,
            (_time.GetUtcNow() - _backlogStartedAt).TotalSeconds
        );
        _backlogCutMs = null;
    }

    /// <summary>The wire form of a stored batch: its own id, endpoint and revision, and the samples in stored order.</summary>
    public static V2.SignalBatch ToMessage(StoredSignalBatch stored, Guid siteId, DateTimeOffset sentAt)
    {
        var batch = new V2.SignalBatch
        {
            BatchId = EdgeIds.ToByteString(stored.Batch.BatchId),
            SiteId = EdgeIds.ToByteString(siteId),
            EndpointId = EdgeIds.ToByteString(stored.Batch.EndpointId),
            ConfigRevision = stored.Batch.ConfigRevision,
            SentAtMs = sentAt.ToUnixTimeMilliseconds(),
        };
        batch.Samples.AddRange(stored.Samples.Select(s => new V2.SignalSample
        {
            SignalId = UnsafeByteOperations.UnsafeWrap(s.SignalId),
            Value = s.Value,
            TimestampMs = s.TimestampMs,
            Quality = (V2.Quality)s.QualityStatus,
            RawQuality = (uint)s.RawQuality,
            DeviceTime = s.DeviceTime,
            TimeSource = (V2.TimeSource)s.TimeSource,
            DeviceTimestampMs = s.DeviceTimestampMs,
            ReceiveLagMs = s.ReceiveLagMs,
        }));
        return batch;
    }

    private async Task LogSummaryAsync(CancellationToken ct)
    {
        var now = _time.GetUtcNow();
        if (now - _summaryAt < SummaryInterval || _batches == 0)
        {
            return;
        }

        var waiting = await _buffer.GetStatusAsync(ct);
        _logger.LogInformation(
            "[MQTT-V2] Sent {Batches} batches, {Samples} samples in {Seconds:0} s; {Waiting} waiting.",
            _batches,
            _samples,
            (now - _summaryAt).TotalSeconds,
            waiting.UnpublishedSamples
        );
        (_batches, _samples, _summaryAt) = (0, 0, now);
    }
}
