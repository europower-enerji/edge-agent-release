using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Core.Configuration;

/// <summary>
/// The backend's flow hint for this site (telemetry throughput B8, shared 3.1.0): while the backend is behind, it asks
/// for fewer, larger batches. The agent only ever becomes gentler with it: it takes the larger batch window and batch
/// size and the smaller backlog replay factor, always within its own limits, so a wrong or stale hint can never make it
/// send more often or faster. A field of 0 keeps the agent's own setting, and after the hint's expiry (or when it is
/// cleared) the agent's own settings apply again.
/// </summary>
public sealed class FlowHints(TimeProvider? time = null)
{
    private readonly TimeProvider _time = time ?? TimeProvider.System;
    private V2.FlowHint? _hint;

    /// <summary>The hint in force, or null when there is none or it expired.</summary>
    public V2.FlowHint? Current
    {
        get
        {
            var hint = Volatile.Read(ref _hint);
            return hint != null && hint.ExpiresAtMs > _time.GetUtcNow().ToUnixTimeMilliseconds() ? hint : null;
        }
    }

    /// <summary>Takes the backend's hint; null clears it.</summary>
    public void Apply(V2.FlowHint? hint) => Volatile.Write(ref _hint, hint);

    /// <summary>The batch window to use: the hint's when it is longer, up to the agent's limit.</summary>
    public int BatchWindowMs(int own) =>
        Current is { BatchWindowMs: > 0 } hint ? Math.Clamp((int)Math.Min(hint.BatchWindowMs, int.MaxValue), own, Math.Max(own, EdgeAgentOptions.MaxBatchWindowMs)) : own;

    /// <summary>The largest batch to use: the hint's when it is larger, up to the agent's limit.</summary>
    public int MaxBatchSize(int own) =>
        Current is { MaxBatchSize: > 0 } hint ? Math.Clamp((int)Math.Min(hint.MaxBatchSize, int.MaxValue), own, Math.Max(own, EdgeAgentOptions.MaxBatchSizeLimit)) : own;

    /// <summary>The backlog replay factor to use: the hint's when it is smaller, at least 1.</summary>
    public int BacklogReplayFactor(int own) =>
        Current is { BacklogReplayFactor: > 0 } hint ? Math.Clamp((int)Math.Min(hint.BacklogReplayFactor, int.MaxValue), 1, Math.Max(1, own)) : own;
}
