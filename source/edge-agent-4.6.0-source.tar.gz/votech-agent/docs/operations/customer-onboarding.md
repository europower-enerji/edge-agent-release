# Onboarding a customer's site connector (Votech internal)

How a customer's site connector (the edge agent) gets from "contract signed" to "live values on the site page, and
they stay live". The customer does the installation with the customer guide,
[`deploy/customer/README.md`](../../deploy/customer/README.md) (published to `edge-agent-release`). This document is
for us: who does what, where and when, what we check on our side, and what to do when something goes wrong
(EMS-275).

**Current values for the Votech dev platform (dev.votechpower.com):**

| Setting | Value |
| --- | --- |
| `API_BASE_URL` | `https://dev.votechpower.com` |
| `MQTT_HOST` | `mqtt.dev.votechpower.com`. Until the one-time section "Stable connections and the MQTT name" of the server RUNBOOK (`votech-backend/deploy/ems-test-votech/RUNBOOK.md`) is applied on our two servers, use `dev.votechpower.com`: before that, `mqtt.dev.votechpower.com` answers 404. |
| `MQTT_PORT` | `443` |
| `MQTT_USE_TLS` | `true` |
| `MQTT_WEBSOCKET_PATH` | `/mqtt` |
| `AGENT_KEY` | the connector's key from **Site connectors** (shown once) |

## Who

| Role | Who | Does |
| --- | --- | --- |
| Votech operator | Amin, or support | The site in Votech, the connector and its key, the values sheet, the checks on our side |
| Customer IT | named by the customer | The agent computer, its network (outbound 443, the device network), their firewall, their antivirus and any TLS inspection |
| Field engineer | us, when the contract includes the physical setup | Everything on the agent computer, and the device side with the customer's electricians |

## How the connection works, and why readings are not lost

- **The path:** the agent connects out to us; nothing connects in to the customer. It is MQTT inside HTTPS:
  `wss://<MQTT_HOST>/mqtt` on port 443. On our side that goes through the front proxy (SCADA-SERVER), scada-test's
  IIS and the edge broker, which checks the agent key with the backend; then the readings reach the backend. The
  customer opens no inbound port and needs only outbound 443 to our two names.
- **No loss on disconnects:** every reading is written to the agent's disk buffer first and stays there until the
  broker confirms it (QoS 1). A disconnect only delays readings. After an outage the agent sends live readings first
  and the stored ones behind them, about ten times faster than real time (agent 4.5 and later).
- **Real loss is possible in only two cases**, and both show up in the agent's status and in our `/health`:
  - the agent's disk reaches its free-space floor during a very long outage (`[CRITICAL-STORAGE-ALARM]`);
  - our broker's queue overflows, which the backend's flow hints prevent with agent 4.6 and later.
- **Stability:** a connection should stay up for days. Drops every 30 s mean the IIS proxy timeout on our side is at
  its default (EMS-271; the RUNBOOK section "Stable connections and the MQTT name"). Drops every few seconds mean two
  agents use the same key. Irregular drops with one agent mean TLS inspection at the customer (firewall or antivirus).

## The transport to offer

| Situation | Transport | What the customer must allow |
| --- | --- | --- |
| Default, any customer | MQTT over HTTPS, port 443 | Outbound 443 to `dev.votechpower.com` and `mqtt.dev.votechpower.com` |
| We set up the server ourselves, or the customer agrees to one firewall rule | MQTT over TLS, port 8883, once our dedicated broker endpoint exists (EMS-276) | Outbound TCP 8883 to our broker's IP only |
| The customer's policy requires a VPN for any vendor access | A site-to-site VPN, only on request | Their network team. Heavy and rarely needed: the agent connection is already encrypted, and outbound only |

Never ask a customer to open an inbound port, and never expose our internal broker (`ems-mosquitto`).

## Step by step

### Votech prepares the site and the connector (1 to 3 days before the installation)

1. **The site exists in Votech** with its communication endpoints: one per RTU or meter, with IP address, port and,
   for IEC 104, the common address. Its signals are imported (IO list). Check that the site page lists them.
2. **Site connectors: create the connector** and assign the site or sites it serves. Copy the key at once: it is
   shown only once. Keep it in the password manager.
3. **The values sheet:** the table at the top, and the device list (IP address and port of every RTU or meter).
   Send the key on its own, through a channel the customer agrees to, never in the same email as the host names.
4. **Send customer IT the customer guide** and point them at its first three steps: "Get your values from Votech",
   "Prepare the computer" and "Check the network from the agent computer". They need, in short:
   - a computer: Windows Server 2016 or later, or Windows 10/11, 64-bit (installed as a Windows service), or Linux
     with Docker; 2 cores, 2 GB of memory (4 GB with Docker Desktop), 6 GB free disk; the clock set automatically;
   - outbound 443 to `dev.votechpower.com` and `mqtt.dev.votechpower.com`, without TLS inspection (firewall or
     antivirus) for these two names, and without a proxy server;
   - a route from the agent computer to every device, and each device accepting the agent computer's IP address;
   - for the installation: local administrator rights, and access to `github.com`, or we bring the package.

### Customer IT checks the network on the agent computer (at least one working day before)

They run the checks of the guide's section "Check the network from the agent computer". On Windows they paste the
values block with `dev.votechpower.com` as `$ApiHost` and the `MQTT_HOST` of the values sheet as `$MqttHost`. Ask for
the output of every check. Expected:

| Check | Expected |
| --- | --- |
| The names are found | An IP address for both names (today `212.174.6.236`) |
| The ports are open | `TcpTestSucceeded : True` twice |
| The Votech API answers, and the clock is right | `Votech API: HTTP 200`, clock difference within 5 s |
| The certificates are Votech's own | Both `issued by` Let's Encrypt |
| The broker accepts a secure WebSocket | `Votech broker: Open` |
| The devices answer | `True` for every device |

What their results usually mean:

| Result | Meaning | Fix |
| --- | --- | --- |
| Port 443 blocked | Their firewall blocks outbound 443 to us | Customer IT allows the two names, or our public IP `212.174.6.236` |
| Certificate issued by their company, their firewall or their antivirus (for example `ESET SSL Filter CA`) | TLS inspection | They exclude our two names from inspection. With Docker the agent refuses the certificate; as a Windows service it may connect, but inspection cuts long connections |
| `Votech broker: ... (404) Not Found` with `mqtt.dev.votechpower.com` | The RUNBOOK section "Stable connections and the MQTT name" is not applied on our servers yet | Use `MQTT_HOST=dev.votechpower.com` for now |
| `Votech broker: ... (400)`, `(403)` or `(405)` | A web filter blocks WebSocket | They allow WebSocket to the broker name |
| The API answers only through their proxy | Internet only through an HTTP proxy | The agent has no proxy setting today: they allow direct outbound 443 to our two names. If that is impossible, tell Amin (agent change) |
| A device check fails | Wrong IP address or route, or the device accepts only certain IP addresses or connections | Customer IT or their electricians fix the route, or add the agent computer's IP address to the device |

### The installation (the customer with the guide, or our field engineer)

Always from the official release, never a file sent by email. The guide's "Install the agent" has three ways:

- **On Windows, as a Windows service** (recommended for every Windows computer). `install.ps1` installs the service
  `VotechEdgeAgent`, with its settings in `C:\ProgramData\EdgeAgent\.env`, and checks every value as it goes.
- **On Linux, with Docker** (`docker compose up -d` in `/opt/edge-agent`).
- **On Windows 10 or 11 with Docker Desktop**, only where Docker Desktop is already in use.

One agent per connector key. **Never two installations with the same key:** an old Docker agent next to a new Windows
service, a second computer, or a cloned virtual machine makes both reconnect every few seconds.

### First start: what the agent log must show, in this order

The guide's "Check that the agent works" lists them for the customer:

| Log line | Means |
| --- | --- |
| `[AGENT] Edge agent <version> with key eak_live_...` | The agent started, with this version |
| `[AGENT] Agent '...' serves N site(s) ...` | The key works and the sites are assigned (`serves 0 site(s)`: assign them on Site connectors) |
| `[SYNC-CONFIG] Running configuration revision … N connection(s) … N point(s)` | The site's configuration arrived |
| `[MQTT] Connecting to broker wss://<MQTT_HOST>:443/mqtt ...` | The right broker address |
| `[MQTT] Connected successfully` | The broker took the key |
| `[IEC104-STARTDT] Connection … confirmed STARTDT` (or `[MODBUS-CONN] … is open`), once per device | The devices answer |
| `[STATUS] Online: N/N endpoints connected.` | Every endpoint is connected |
| `[MQTT-V2] Sent N batches, N samples in 60 s; 0 waiting.` | Readings flow and nothing waits |

### Votech checks on our side (the same day, with the customer on the phone)

1. **Site connectors:** the connector shows Online, its version, its sites, and every endpoint connected.
2. **The site page:** live values change, and their time is now, not minutes ago.
3. **After 10 minutes:** the customer's connection-drop count is `0` (the guide's "Check after 10 minutes"). On
   scada-test the edge broker shows one connection per session, not a new one every 30 s:
   ```bash
   docker logs --since 10m votech-edge-broker 2>&1 | grep -c "New client connected"
   ```
   About 2 per site connector (data and commands); more means reconnects (see the table below).
4. **`/health`:** the service `Ingestion` is Healthy.
5. **The outage test** (the guide's "Test an outage", Windows service): the customer blocks our IP addresses for 5
   minutes. We see the connector go Offline, then Online again within a minute of the block's removal, and the 5
   minutes filled in on the site's charts.

### Handover (end of the installation day)

- Write down the agent computer's name and IP address, the installation way, the connector name, where the key is
  kept, and the customer's contact.
- **Next day:** check again that the connector stayed online, `0 waiting`, and no reconnect lines.
- Upgrades: the guide's "Upgrading to a new version". We tell the customer when a release matters for them.

## When something goes wrong

The guide's "Problems and solutions" covers what the customer sees. On our side:

| Symptom (agent log, or Votech) | Cause | Fix |
| --- | --- | --- |
| `Error while connecting with host 'Unspecified/127.0.0.1:…'` | `MQTT_HOST` points at the agent computer itself (copied from another installation) | The values sheet's `MQTT_HOST`, `MQTT_PORT` and `MQTT_WEBSOCKET_PATH`; restart |
| `[MQTT] Reconnect attempt #…` repeating, never connected | 443 blocked, a proxy in the way, or a typing error in the host | The network checks above; the host has no `https://` and no `:port` |
| `… status code '404' when status code '101' was expected` | A wrong `MQTT_WEBSOCKET_PATH`, or `mqtt.dev.votechpower.com` before the RUNBOOK section "Stable connections and the MQTT name" is applied | Path `/mqtt`; until that section is applied, `MQTT_HOST=dev.votechpower.com` |
| Certificate errors (`UntrustedRoot`, `The remote certificate is invalid`) | TLS inspection at the customer (firewall or antivirus) | They exclude our names from inspection |
| `not authorized` or `bad user name or password` | A wrong or revoked key, or the site is not assigned to this connector | Site connectors: check the assignment; give a new key if it was lost or revoked |
| `[AUTH] the backend refused agent key … (HTTP 401 EDGE_KEY_REVOKED)` | The key was replaced or revoked | The current key into `.env` (Windows: `install.ps1 -Action Config`), restart |
| `… FORBIDDEN_EDGE_SITE_MISMATCH` | The connector does not serve that site (any more) | Assign the site on Site connectors |
| `… TENANT_SUSPENDED` | The customer's organisation is suspended (licence) | Sales or licence; nothing to fix on the agent |
| Disconnects every ~30 s, and the connector flips between Online and Offline | Our IIS proxy timeout (EMS-271) | The RUNBOOK section "Stable connections and the MQTT name", on our two servers, not at the customer |
| Disconnects every few seconds; the edge broker log says `session taken over` | Two agents with the same key | Find and stop the second installation (an old Docker container, a second service, a cloned virtual machine) |
| Disconnects at irregular times, many per hour, one agent only | TLS inspection at the customer cuts long connections | The certificate check of the guide; they exclude our names |
| `[IEC104-CONN] Connection … is down … next attempt in … s` | The device cannot be reached, or refuses the agent's IP address | The device check, then the device's list of allowed IP addresses |
| Values arrive with old times, or a clock drift warning on the site | The agent computer's clock or the device's clock is wrong | NTP on the agent computer (the guide's "Prepare the computer"); the device clock with the customer |
| `[MQTT-V2] … N waiting` keeps growing | Readings cannot be sent fast enough: connection trouble, or our backend is behind | The connection lines first, then our `/health` (`Ingestion`) |
| `[FLOW] The backend is behind and asks for fewer batches …` | Our backend asked for fewer batches (agent 4.6 and later) | Nothing at the customer; watch our `/health` |
| `[CRITICAL-STORAGE-ALARM] The disk is at its free space floor` | A long outage filled the disk | Free disk space and restore the connection; at the floor the oldest unsent readings are deleted |
| `[SYNC-CONFIG] The server cannot be reached …` for days | No connection to our API; the agent stops after 72 h with an old configuration | Restore outbound 443 to `dev.votechpower.com` |
| The Windows service stops right after it starts | A setting is invalid | `install.ps1 -Action Status`; the log names the setting |
| The service does not start: `logon failure` | A domain policy controls "Log on as a service" | Customer IT adds `NT SERVICE\ALL SERVICES` to that policy |
| The agent version is older than 4.3 | No MQTT over HTTPS | Upgrade (the guide's "Upgrading to a new version") |

## When we set up the server ourselves (physical setup contract)

In addition to the steps above:

1. **The computer:**
   - Windows Server, updated, a local administrator account kept by us;
   - the clock from NTP (`w32tm /query /status` names a time server);
   - antivirus exclusions for `C:\Program Files\EdgeAgent` and `C:\ProgramData\EdgeAgent`, and the antivirus' TLS
     filtering off for our two names;
   - sleep and hibernation off;
   - it starts after a power cut (the BIOS setting "Restore on AC power loss: Power on"), behind a UPS.
2. **Network:** two network cards when the device network is separate (one to the devices, one to the internet),
   with no routing between them. Outbound 443 to our two names (or 8883 to our broker once EMS-276 exists).
3. **Remote support:** only through the customer's approved remote-access tool, written in the contract.
4. **Installation:** the guide's "On Windows: install the agent as a Windows service", with the values sheet, then
   "Check that the agent works" and "Confirm with Votech and test an outage".
5. **Before leaving the site:** the outage test passed, and the customer's contact knows where the guide's "Everyday
   operation" and "Getting help" are.
