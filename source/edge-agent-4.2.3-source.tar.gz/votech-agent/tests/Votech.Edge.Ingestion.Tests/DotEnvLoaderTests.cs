using System;
using System.IO;
using Votech.Edge.Core.Configuration;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace Votech.Edge.Ingestion.Tests;

public class DotEnvLoaderTests : IDisposable
{
    private readonly string _tempEnvFile;

    public DotEnvLoaderTests()
    {
        _tempEnvFile = Path.Combine(Path.GetTempPath(), $"test_{Guid.NewGuid():N}.env");
    }

    public void Dispose()
    {
        if (File.Exists(_tempEnvFile))
        {
            File.Delete(_tempEnvFile);
        }
    }

    [Fact]
    public void Load_MapsTheTenantGuard()
    {
        File.WriteAllText(_tempEnvFile, "TENANT_ID=1b2c3d4e-0000-4000-8000-000000000001\nAGENT_KEY=gpk_live_key\n");

        var config = DotEnvLoader.Load(_tempEnvFile);

        Assert.Equal("1b2c3d4e-0000-4000-8000-000000000001", config["EdgeAgent:TenantId"]);
        Assert.Equal("gpk_live_key", config["EdgeAgent:AgentKey"]);
    }

    [Fact]
    public void Load_ParsesSiteIdAndAgentKey_AndMapsToEdgeAgentConfig()
    {
        // Arrange
        var content = """
            # Test comment
            SITE_ID=site-uuid-1234
            AGENT_KEY="gpk_test_token_abc"
            API_BASE_URL='http://custom-api:9090'
            EdgeAgent__FlushIntervalMs=3500
            """;
        File.WriteAllText(_tempEnvFile, content);

        // Act
        var config = DotEnvLoader.Load(_tempEnvFile);

        // Assert
        Assert.Equal("site-uuid-1234", config["SITE_ID"]);
        Assert.Equal("site-uuid-1234", config["EdgeAgent:SiteId"]);
        Assert.Equal("gpk_test_token_abc", config["AGENT_KEY"]);
        Assert.Equal("gpk_test_token_abc", config["EdgeAgent:AgentKey"]);
        Assert.Equal("http://custom-api:9090", config["EdgeAgent:ApiBaseUrl"]);
        Assert.Equal("3500", config["EdgeAgent:FlushIntervalMs"]);

        // Verify System.Environment
        Assert.Equal("site-uuid-1234", Environment.GetEnvironmentVariable("SITE_ID"));
        Assert.Equal("gpk_test_token_abc", Environment.GetEnvironmentVariable("AGENT_KEY"));
    }

    [Fact]
    public void AddDotEnv_InjectsIntoConfigurationBuilder()
    {
        // Arrange
        var content = """
            SITE_ID=site-builder-test
            AGENT_KEY=gpk_builder_key
            """;
        File.WriteAllText(_tempEnvFile, content);

        var builder = new ConfigurationBuilder();

        // Act
        builder.AddDotEnv(_tempEnvFile);
        var configuration = builder.Build();

        // Assert
        Assert.Equal("site-builder-test", configuration["EdgeAgent:SiteId"]);
        Assert.Equal("gpk_builder_key", configuration["EdgeAgent:AgentKey"]);
    }
}
