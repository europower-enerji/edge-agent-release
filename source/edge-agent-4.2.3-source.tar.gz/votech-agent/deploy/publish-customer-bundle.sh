#!/usr/bin/env bash
# =============================================================================
# Publishes the customer files of a released agent version to the public
# repository, where customers download them without any account:
#
#   README.md                                 the installation guide
#   docker-compose.yml                        pinned to the version
#   env.example                               the settings template
#   source/edge-agent-<version>-source.tar.gz the complete source of the image
#                                             (GPL-3.0-only; same layout as the
#                                             source package of release.yml)
#
# The commit on main is tagged v<version>. A published version is never
# overwritten, and nothing is published until the image can be pulled without
# signing in.
#
# Run it after the "CI & Release" workflow pushed the image of the tag
#   git tag -a vX.Y.Z -m "Votech Edge Agent X.Y.Z" && git push origin vX.Y.Z
# from a checkout that can push to the public repository over SSH:
#   deploy/publish-customer-bundle.sh
# The version is <Version> in Votech.Edge.Service.csproj.
#
# Overrides:
#   PUBLIC_REPO=git@github.com:<owner>/<repo>.git
#   SHARED_DIR=<votech-shared checkout>
#   SHARED_REF=<the votech-shared ref the image was built from> (origin/main, the workflow's default)
# =============================================================================
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PUBLIC_REPO="${PUBLIC_REPO:-git@github.com:europower-enerji/edge-agent-release.git}"
SHARED_DIR="${SHARED_DIR:-$REPO_ROOT/../votech-shared}"
SHARED_REF="${SHARED_REF:-origin/main}"
IMAGE="ghcr.io/europower-enerji/edge-agent"
CSPROJ="$REPO_ROOT/src/Votech.Edge.Service/Votech.Edge.Service.csproj"

fail() { echo "ERROR: $*" >&2; exit 1; }

VERSION="$(sed -n 's:.*<Version>\(.*\)</Version>.*:\1:p' "$CSPROJ" | head -n1)"
[[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+(-[0-9A-Za-z.-]+)?$ ]] || fail "could not read a SemVer <Version> from $CSPROJ (got '$VERSION')."
TAG="v$VERSION"

# The image is built from the tag in origin, so the files come from that tag too
git -C "$REPO_ROOT" fetch -q origin "+refs/tags/$TAG:refs/tags/$TAG" 2>/dev/null \
  || fail "tag $TAG is not in origin. Push it first; the release workflow builds the image from it."
git -C "$SHARED_DIR" fetch -q origin || fail "could not fetch $SHARED_DIR (set SHARED_DIR to your votech-shared checkout)."
git -C "$SHARED_DIR" rev-parse -q --verify "$SHARED_REF^{commit}" >/dev/null || fail "$SHARED_REF is not a commit in $SHARED_DIR."

# Customers pull without signing in: the image must be public before its compose file is
repository="${IMAGE#ghcr.io/}"
token="$(curl -fsS "https://ghcr.io/token?scope=repository:${repository}:pull" 2>/dev/null | sed -n 's/.*"token":"\([^"]*\)".*/\1/p' || true)"
curl -fsS -o /dev/null \
  -H "Authorization: Bearer ${token}" \
  -H "Accept: application/vnd.oci.image.index.v1+json, application/vnd.docker.distribution.manifest.list.v2+json" \
  "https://ghcr.io/v2/${repository}/manifests/${VERSION}" 2>/dev/null \
  || fail "$IMAGE:$VERSION cannot be pulled without signing in. Wait for the release workflow, and make the package public (package settings, Change visibility)."

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
PUBLIC="$WORK/public"

git clone -q "$PUBLIC_REPO" "$PUBLIC" 2>/dev/null || fail "could not clone $PUBLIC_REPO."
if git -C "$PUBLIC" rev-parse -q --verify "refs/tags/$TAG" >/dev/null; then
  fail "$TAG is already published in $PUBLIC_REPO. Bump <Version> for a new release."
fi
# An empty repository has no branch yet: the first commit starts main
if git -C "$PUBLIC" rev-parse -q --verify HEAD >/dev/null; then
  git -C "$PUBLIC" checkout -q main
else
  git -C "$PUBLIC" symbolic-ref HEAD refs/heads/main
fi

git -C "$REPO_ROOT" show "$TAG:deploy/customer/docker-compose.yml" \
  | sed -E "s#^([[:space:]]*image: ${IMAGE}:).*#\1${VERSION}#" > "$PUBLIC/docker-compose.yml"
grep -q "image: ${IMAGE}:${VERSION}\$" "$PUBLIC/docker-compose.yml" || fail "the image line of docker-compose.yml was not pinned to $VERSION."
git -C "$REPO_ROOT" show "$TAG:deploy/customer/env.example" > "$PUBLIC/env.example"
git -C "$REPO_ROOT" show "$TAG:deploy/customer/README.md" > "$PUBLIC/README.md"

# Unpacks to votech-agent/ (the tag, without the export-ignore paths) and votech-shared/protobuf/ (the MIT contract)
mkdir -p "$PUBLIC/source"
package="$WORK/edge-agent-${VERSION}-source.tar"
git -C "$REPO_ROOT" archive --format=tar --prefix=votech-agent/ -o "$package" "$TAG"
git -C "$SHARED_DIR" archive --format=tar --prefix=votech-shared/ -o "$WORK/shared.tar" "$SHARED_REF" protobuf
tar --concatenate -f "$package" "$WORK/shared.tar"
gzip -9n -c "$package" > "$PUBLIC/source/edge-agent-${VERSION}-source.tar.gz"

git -C "$PUBLIC" add -A
git -C "$PUBLIC" commit -q -m "Votech Edge Agent $VERSION" -m "Image: $IMAGE:$VERSION (linux/amd64, linux/arm64). Source: source/edge-agent-${VERSION}-source.tar.gz (agent $(git -C "$REPO_ROOT" rev-parse --short "$TAG^{commit}"), votech-shared $(git -C "$SHARED_DIR" rev-parse --short "$SHARED_REF"))."
git -C "$PUBLIC" tag -a "$TAG" -m "Votech Edge Agent $VERSION"
git -C "$PUBLIC" push -q origin main "$TAG"

echo "Published Votech Edge Agent $VERSION to $PUBLIC_REPO:"
git -C "$PUBLIC" show --stat --format='  %h %s' HEAD | sed -n '2,$p'
