# Votech Edge Agent

The **Votech Edge Agent** is a .NET 10 background service deployed on physical site hardware (Raspberry Pi, industrial PC, etc.). It collects data from field devices via industrial protocols, stores it locally in SQLite, and reliably forwards it to the cloud via MQTT — even during network outages.

---

## 📐 Architecture

```
┌──────────────────────────────────────────────────────────────────────┐
│                        Votech.Edge.Service                        │
│  (Composition Root: DI, Serilog, Worker BackgroundService)           │
└──────┬──────────────────────────┬──────────────────────────┬─────────┘
       │                          │                          │
       ▼                          ▼                          ▼
┌─────────────┐         ┌──────────────────┐      ┌──────────────────┐
│  Ingestion  │         │     Storage      │      │      Mqtt        │
│ (IEC104,    │──Save─▶│ (SQLite Buffer)  │──▶───│  (Publisher)     │──▶ Cloud
│  Modbus)    │         │                  │      │                  │
└─────────────┘         └──────────────────┘      └──────────────────┘
       │                          │                          │
       └──────────────────────────┴──────────────────────────┘
                                  │
                    ┌─────────────▼──────────────┐
                    │      Votech.Edge.Core    │
                    │  (Interfaces & Entities)    │
                    └─────────────────────────────┘
                                  │
                    ┌─────────────▼──────────────┐
                    │     Votech.Edge.Models   │
                    │  (Auto-generated DTOs from  │
                    │    votech-shared)         │
                    └─────────────────────────────┘
```

**Key Design: Store-and-Forward**
Every reading from a device is first saved to a local SQLite database. A background flush loop then tries to publish it to MQTT. If the network is down, the data stays in SQLite and is published automatically when connectivity is restored.

---

## 📁 Project Structure

```
/votech-agent
├── Votech.Edge.sln
├── /src
│   ├── Votech.Edge.Models        → C# compiled from votech-shared protobuf/v2 at build time
│   ├── Votech.Edge.Core          → Contracts & entities (IConnectionPoller, ISignalSink, ISignalBuffer, AcquiredPoint)
│   ├── Votech.Edge.Ingestion     → v2 configuration source, connection manager, IEC 104 and Modbus pollers, sample sink, probes
│   ├── Votech.Edge.Storage       → SQLite buffer (EF Core): SignalBatches/SignalSamples, configuration cache, migrations
│   ├── Votech.Edge.Mqtt          → MQTT publisher, batch publisher, agent status, v2 command subscriber (MQTTnet)
│   └── Votech.Edge.Service       → Program.cs (DI) + Worker.cs (BackgroundService)
├── /tests
│   ├── Votech.Edge.Ingestion.Tests
│   └── Votech.Edge.Storage.Tests
└── /deploy
    ├── Dockerfile
    ├── docker-compose.yml
    └── mosquitto.conf
```

---

## 🚀 Prerequisites

| Tool           | Version | Link                               |
| -------------- | ------- | ---------------------------------- |
| .NET SDK       | 10.0+   | https://dot.net                    |
| Docker         | 24.0+   | https://docs.docker.com/get-docker |
| Docker Compose | v2      | included with Docker Desktop       |

---

## 🛠️ Running Locally (Development)

### Option A — Direct (no Docker)

```bash
# 1. Clone the repo
git clone https://github.com/europower-enerji/votech-agent.git
cd votech-agent

# 2. Build the solution
dotnet build

# 3. Run the service (uses appsettings.Development.json automatically)
dotnet run --project src/Votech.Edge.Service
```

> A file called `edge-dev.db` will be created in the project directory as the local SQLite buffer.

### Option B — Docker Compose (recommended for full-stack testing)

```bash
# From the /deploy directory
cd deploy
docker-compose up --build
```

This starts:

- The **Edge Agent** container
- A local **Mosquitto MQTT broker** on port `1883`

You can connect an MQTT client (e.g., MQTT Explorer) to `localhost:1883` to watch telemetry flow in real time.

---

## 🧪 Running Tests

```bash
dotnet test
```

All tests use in-memory databases — no physical device or network connection required.

---

## 🔁 How Data Flows (edge contract v2, agent 3.x)

The contract is ADR-002 in the backend and `protobuf/v2` in `votech-shared`.

0. `AgentSupervisor` asks `GET api/v1/edge/agent` which sites this agent key serves (one site, the sites of one
   organisation, or, for a platform agent, sites of many organisations), every 60 s, and runs each site in its own
   `SiteRuntime`: its own services, SQLite file, MQTT sessions and log tag. Everything below happens per site.
1. `EdgeConfigurationSource` fetches `GET api/v1/edge/sites/{siteId}/configuration` (protobuf `EdgeConfiguration`)
   with `If-None-Match`, caches it in SQLite, and reloads on `{prefix}/v2/commands/{siteId}/reload` or every 60 s.
2. `ConnectionManager` runs one `IConnectionPoller` per connection, keyed by the root endpoint. A changed connection
   setting reopens the link; changed stations or points are swapped in on the open link.
3. `Iec104ConnectionPoller` (GI per station common address, routing by CA and IOA) and `ModbusConnectionPoller`
   (address grammar, block reads, typed decoding, poll groups) write every value as a `SignalReading`. There is no
   deadband on the edge: the backend applies it.
4. `SignalSampleSink` stores the readings as batches per connection in `SignalBatches`/`SignalSamples`.
5. `SignalBatchPublisher` sends the oldest batch to `{prefix}/v2/telemetry/{siteId}/{endpointId}` and marks it after
   the broker's PUBACK; a resend carries the same batch id.
6. `AgentStatusReporter` publishes the retained `AgentStatus` (every endpoint, revision, buffer) on
   `{prefix}/v2/status/{siteId}/{clientId}`; the Last Will is the same status as OFFLINE.
7. `V2CommandSubscriber` answers `ProbeCommand`s for configured endpoints only (`EndpointProbeService`).

---

## ➕ How to Add a New Protocol

1. Add the protocol to `protobuf/v2/edge_config.proto` in `votech-shared` (a `Protocol` value and a settings
   message in `Connection.settings`), and to the backend compiler.
2. Implement `IConnectionPoller` in `src/Votech.Edge.Ingestion/<Protocol>/`: read the connection's stations and
   points, write each value to the `ISignalSink` as a `SignalReading`, report `Health` for the root and every
   station, and send one Offline sample per signal when the link drops.
3. Create it in `ConnectionPollerFactory` and add the protocol to `AgentCapabilities.SupportedProtocols`.

---

## 🔄 How the Shared Contract Is Used

`Votech.Edge.Models` compiles `votech-shared/protobuf/v2/*.proto` at build time (Grpc.Tools), from a
`votech-shared` checkout next to this repository. There is nothing to generate or copy: a contract change in
`votech-shared` is picked up by the next build. The release workflow builds against the `SHARED_REF` repository
variable (a tag, branch or commit of `votech-shared`).

---

## ⚙️ Configuration Reference

All settings live in `src/Votech.Edge.Service/appsettings.json`. Use environment variables to override in production (Docker):

| Setting       | Env Variable                                 | Default               | Description                         |
| ------------- | -------------------------------------------- | --------------------- | ----------------------------------- |
| SQLite path   | `EdgeAgent__Storage__SqliteConnectionString` | `Data Source=edge.db` | Path to the local buffer database   |
| MQTT host     | `EdgeAgent__Mqtt__BrokerHost`                | `localhost`           | Cloud MQTT broker hostname          |
| MQTT port     | `EdgeAgent__Mqtt__BrokerPort`                | `8883`                | MQTT broker port                    |
| MQTT TLS      | `EdgeAgent__Mqtt__UseTls`                    | `true`                | Enable TLS for MQTT connection      |
| API base URL  | `EdgeAgent__ApiBaseUrl`                      | `http://localhost:5050` | Must be `https://` outside Development |
| Batch window  | `EdgeAgent__BatchWindowMs`                   | `2000`                | How long readings are collected into one batch |
| Batch size    | `EdgeAgent__MaxBatchSize`                    | `500`                 | Largest number of samples in one batch |
| Flush interval | `EdgeAgent__FlushIntervalMs`                | `5000`                | Publisher wake-up when no batch arrives |
| Buffer samples | `EdgeAgent__Storage__MaxRecordCapacity`     | `25000000`            | Buffered samples before the oldest are deleted |
| Buffer size   | `EdgeAgent__Storage__MaxDbSizeMb`            | `2048`                | Largest buffer in MB (pages in use) |
| Retention     | `EdgeAgent__Storage__RetentionDays`          | `1`                   | Days published batches are kept     |
| Clock policy  | `EdgeAgent__Iec104__ClockPolicy`             | `Observe`             | `Observe` measures each RTU clock; `Enforce` stamps the values of an RTU whose clock is off on receipt |
| Clock tolerance | `EdgeAgent__Iec104__ClockSkewToleranceSec` | `60`                  | How far an RTU clock may be off before `Enforce` stops trusting it |
| Console colors | `ConsoleLogging__EnableAnsiColors`         | `true`                | Colored console lines, as the backend's; `false` for a log viewer that shows the escape codes |

Outside `DOTNET_ENVIRONMENT=Development` the agent refuses to start with an `http://` API address or with
`UseTls=false`. `dotnet run` uses the Development profile; the local `deploy/docker-compose.yml` stack runs
Production without TLS and needs `DOTNET_ENVIRONMENT=Development` to start 2.x.

---

## 📦 Deployment to a Physical Device

Sites run the published multi-arch image `ghcr.io/europower-enerji/edge-agent` (`linux/amd64`, `linux/arm64`). No source checkout is needed on the device. Customers download `docker-compose.yml`, `env.example` and the installation guide (Windows with Docker Desktop, and Linux) from the public repository <https://github.com/europower-enerji/edge-agent-release>, without any account; it also holds the source package of every published version (GPL-3.0-only). [deploy/publish-customer-bundle.sh](deploy/publish-customer-bundle.sh) updates it after the image is published.

```bash
# In an empty folder on the device, next to docker-compose.yml
# and a .env created from env.example:
docker compose up -d
```

To upgrade, change the image tag in `docker-compose.yml` and run `docker compose up -d` again. Logs are written to `/var/log/edge-agent/` inside the container (mounted as a Docker volume) and are also available via `docker compose logs`.

- Customer installation guide (shipped with every release): [deploy/customer/README.md](deploy/customer/README.md)
- Release process (GHCR, GitHub Actions, releases repository): `agent/RELEASING.md` in the private `platform-ops` repository

---

## 🧑‍💻 NuGet Packages To Add When Implementing Protocols

| Layer       | Package    | Purpose                          |
| ----------- | ---------- | -------------------------------- |
| `Ingestion` | `NModbus`  | Modbus TCP/RTU polling           |
| `Ingestion` | `lib60870` | IEC 60870-5-104 client           |
| `Mqtt`      | `MQTTnet`  | MQTT client with QoS 1/2 support |

Add them to the relevant `.csproj` file and then implement the `TODO` blocks in the placeholder files.

---

## ⚖️ License

Copyright (C) 2026 Europower Enerji.

The Votech Edge Agent is free software: you can redistribute it and/or modify it under the terms of the GNU General
Public License, version 3 only (GPL-3.0-only), as published by the Free Software Foundation. It is distributed in the
hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See [LICENSE](LICENSE).

The agent links lib60870.NET (GPL-3.0-only). The licences of every third-party package are in
[THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md). Every release carries a source package with the complete source of
its image, including the shared message-format (protobuf) files, which are MIT-licensed.
