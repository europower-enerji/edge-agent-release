using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Interfaces;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Protocol;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Mqtt;

/// <summary>
/// Receives the v2 commands of the agent's site (ADR-002 2.1) on its own MQTT session (clean, so commands queued while
/// the agent was offline are not replayed):
/// <list type="bullet">
/// <item><c>{prefix}/v2/commands/{siteId}/reload</c> <c>ReloadConfig</c>: fetches the configuration unless the revision
/// is the running one.</item>
/// <item><c>{prefix}/v2/commands/{siteId}/probe</c> <c>ProbeCommand</c>: answered with a <c>CommandAck</c> on
/// <c>{prefix}/v2/ack/{siteId}/{endpointId}</c>.</item>
/// </list>
/// </summary>
public sealed class V2CommandSubscriber : BackgroundService
{
    private readonly MqttOptions _options;
    private readonly Guid _siteId;
    private readonly string _agentKey;
    private readonly string _username;
    private readonly IEdgeConfigurationSource _configuration;
    private readonly IProbeHandler _probes;
    private readonly IMqttPublisher _publisher;
    private readonly ILogger<V2CommandSubscriber> _logger;
    private readonly IMqttClient _client;
    private readonly MqttTopicBuilder _topics;
    private int _isReconnecting;
    private CancellationToken _stoppingToken;

    public V2CommandSubscriber(
        IOptions<EdgeAgentOptions> options,
        IEdgeConfigurationSource configuration,
        IProbeHandler probes,
        IMqttPublisher publisher,
        ILogger<V2CommandSubscriber> logger
    )
    {
        _options = options.Value.Mqtt;
        _siteId = Guid.TryParse(options.Value.SiteId, out var siteId) ? siteId : Guid.Empty;
        _agentKey = options.Value.AgentKey;
        _username = options.Value.BrokerUsername;
        _configuration = configuration;
        _probes = probes;
        _publisher = publisher;
        _logger = logger;
        _topics = new MqttTopicBuilder(options.Value.Mqtt);
        _client = new MqttFactory().CreateMqttClient();
        _client.ApplicationMessageReceivedAsync += e => HandleAsync(e.ApplicationMessage.Topic, e.ApplicationMessage.PayloadSegment.ToArray());
        _client.DisconnectedAsync += OnDisconnectedAsync;
    }

    public string ReloadTopic => _topics.V2Command(_siteId, EdgeContractConstants.TopicReload);

    public string ProbeTopic => _topics.V2Command(_siteId, EdgeContractConstants.TopicProbe);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _stoppingToken = stoppingToken;
        try
        {
            await ConnectAsync(stoppingToken);
        }
        catch (Exception ex) when (!stoppingToken.IsCancellationRequested)
        {
            _logger.LogWarning(ex, "[COMMANDS] The first connection to the broker failed; retrying.");
            _ = OnDisconnectedAsync(new MqttClientDisconnectedEventArgs(false, null, MqttClientDisconnectReason.UnspecifiedError, ex.Message, [], ex));
        }

        try
        {
            await Task.Delay(Timeout.Infinite, stoppingToken);
        }
        catch (OperationCanceledException)
        {
            // Shutdown
        }
    }

    private async Task ConnectAsync(CancellationToken ct)
    {
        var builder = new MqttClientOptionsBuilder()
            .WithClientId($"{_options.ClientId}-cmd")
            .WithTcpServer(_options.BrokerHost, _options.BrokerPort)
            .WithCleanSession(true);
        if (_options.UseTls)
        {
            builder.WithTlsOptions(MqttTlsOptionsFactory.BuildTlsOptions(_options, _logger));
        }

        if (!string.IsNullOrEmpty(_options.Username))
        {
            builder.WithCredentials(_options.Username, !string.IsNullOrEmpty(_options.Password) ? _options.Password : _agentKey);
        }
        else if (!string.IsNullOrEmpty(_agentKey))
        {
            builder.WithCredentials(_username, _agentKey);
        }

        await _client.ConnectAsync(builder.Build(), ct);
        await _client.SubscribeAsync(ReloadTopic, MqttQualityOfServiceLevel.AtLeastOnce, ct);
        await _client.SubscribeAsync(ProbeTopic, MqttQualityOfServiceLevel.AtLeastOnce, ct);
        _logger.LogInformation("[COMMANDS] Subscribed to {ReloadTopic} and {ProbeTopic}.", ReloadTopic, ProbeTopic);
    }

    /// <summary>Handles one command message; malformed payloads are logged and dropped.</summary>
    internal async Task HandleAsync(string topic, byte[] payload)
    {
        try
        {
            if (topic == ReloadTopic)
            {
                var reload = V2.ReloadConfig.Parser.ParseFrom(payload);
                _logger.LogInformation("[COMMANDS] Reload command for revision {Revision}.", reload.Revision);
                await _configuration.ReloadAsync(reload.Revision, _stoppingToken);
            }
            else if (topic == ProbeTopic)
            {
                var probe = V2.ProbeCommand.Parser.ParseFrom(payload);
                var ack = await _probes.ProbeAsync(probe, DateTimeOffset.UtcNow, _stoppingToken);
                await _publisher.PublishCommandAckAsync(_siteId, ack, _stoppingToken);
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException || !_stoppingToken.IsCancellationRequested)
        {
            _logger.LogWarning(ex, "[COMMANDS] The command on {Topic} could not be handled.", topic);
        }
    }

    private async Task OnDisconnectedAsync(MqttClientDisconnectedEventArgs args)
    {
        if (_stoppingToken.IsCancellationRequested || Interlocked.CompareExchange(ref _isReconnecting, 1, 0) != 0)
        {
            return;
        }

        try
        {
            var delayMs = _options.ReconnectBaseDelayMs;
            var attempt = 0;
            while (!_stoppingToken.IsCancellationRequested)
            {
                attempt++;
                if (_options.ReconnectAttemptsExhausted(attempt))
                {
                    _logger.LogCritical("[COMMANDS] Reconnection aborted after {MaxAttempts} failed attempts.", _options.MaxReconnectAttempts);
                    return;
                }

                try
                {
                    await Task.Delay(delayMs, _stoppingToken);
                    await ConnectAsync(_stoppingToken);
                    return;
                }
                catch (OperationCanceledException)
                {
                    return;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "[COMMANDS] Reconnect attempt #{Attempt} failed.", attempt);
                    delayMs = Math.Min(delayMs * 2, _options.ReconnectMaxDelayMs);
                }
            }
        }
        finally
        {
            Interlocked.Exchange(ref _isReconnecting, 0);
        }
    }

    public override void Dispose()
    {
        _client.DisconnectedAsync -= OnDisconnectedAsync;
        _client.Dispose();
        base.Dispose();
    }
}
