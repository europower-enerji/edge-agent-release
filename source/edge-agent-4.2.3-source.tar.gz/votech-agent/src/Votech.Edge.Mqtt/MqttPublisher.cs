using Google.Protobuf;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Interfaces;
using Microsoft.Extensions.Logging;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Protocol;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Mqtt;

/// <summary>
/// Full MQTT publisher implementation using MQTTnet v4.
///
/// Features:
///   - QoS 1 (at-least-once) for all telemetry
///   - CleanSession = false — broker retains session state across reconnects
///   - Will Message: v2 AgentStatus OFFLINE on abrupt disconnect (retained)
///   - mTLS client certificate support (production) or username/password (dev)
///   - Exponential backoff reconnect
///   - Contract v2: signal batches, agent status and command acknowledgements
/// </summary>
public sealed class MqttPublisher : IMqttPublisher, IAsyncDisposable
{
    private readonly MqttOptions _options;
    private readonly string _siteId;
    private readonly string? _agentKey;
    private readonly string? _username;
    private readonly MqttTopicBuilder _topics;
    private readonly ILogger<MqttPublisher> _logger;
    private readonly IMqttClient _client;
    private readonly MqttClientOptions _clientOptions;
    private readonly CancellationTokenSource _cts = new();
    private int _isReconnecting = 0;

    public bool IsConnected => _client.IsConnected;

    public MqttPublisher(
        MqttOptions options,
        string siteId,
        ILogger<MqttPublisher> logger,
        string? agentKey = null,
        string? username = null
    )
    {
        _options = options;
        _siteId = siteId;
        _agentKey = agentKey;
        _username = username;
        _logger = logger;
        _topics = new MqttTopicBuilder(options);

        var factory = new MqttFactory();
        _client = factory.CreateMqttClient();

        _clientOptions = BuildClientOptions();

        // Reconnect handler with exponential backoff
        _client.DisconnectedAsync += OnDisconnectedAsync;
    }

    // ─── IMqttPublisher ───────────────────────────────────────────────────────

    public async Task ConnectAsync(CancellationToken ct)
    {
        _logger.LogInformation(
            "[MQTT] Connecting to broker {Host}:{Port} (TLS={Tls}, ClientId={ClientId})...",
            _options.BrokerHost,
            _options.BrokerPort,
            _options.UseTls,
            _options.ClientId
        );

        var result = await _client.ConnectAsync(_clientOptions, ct);

        if (result.ResultCode != MqttClientConnectResultCode.Success)
        {
            if (
                result.ResultCode == MqttClientConnectResultCode.NotAuthorized
                || result.ResultCode == MqttClientConnectResultCode.BadUserNameOrPassword
            )
            {
                _logger.LogCritical(
                    "[MQTT-AUTH] MQTT broker rejected credentials (Result: {ResultCode}, Reason: {Reason}). Verify AgentKey / MQTT credentials.",
                    result.ResultCode,
                    result.ReasonString
                );
            }

            throw new InvalidOperationException(
                $"MQTT connection failed: {result.ResultCode} — {result.ReasonString}"
            );
        }

        _logger.LogInformation(
            "[MQTT] Connected successfully (SessionPresent={Present}).",
            result.IsSessionPresent
        );
    }

    public async Task PublishSignalBatchAsync(V2.SignalBatch batch, CancellationToken ct)
    {
        var topic = _topics.V2Telemetry(EdgeIds.ToGuid(batch.SiteId), EdgeIds.ToGuid(batch.EndpointId));
        var message = new MqttApplicationMessageBuilder()
            .WithTopic(topic)
            .WithPayload(batch.ToByteArray())
            .WithQualityOfServiceLevel(MqttQualityOfServiceLevel.AtLeastOnce)
            .WithRetainFlag(false)
            .Build();

        var result = await _client.PublishAsync(message, ct);
        if (result.ReasonCode is not (MqttClientPublishReasonCode.Success or MqttClientPublishReasonCode.NoMatchingSubscribers))
        {
            throw new InvalidOperationException($"The broker refused the batch on {topic}: {result.ReasonCode} {result.ReasonString}");
        }

        _logger.LogTrace("[MQTT-V2] Sent batch {BatchId} ({Count} samples).", Convert.ToHexStringLower(batch.BatchId.Span), batch.Samples.Count);
    }

    public async Task PublishAgentStatusAsync(V2.AgentStatus status, CancellationToken ct)
    {
        var topic = _topics.V2Status(EdgeIds.ToGuid(status.SiteId));
        var message = new MqttApplicationMessageBuilder()
            .WithTopic(topic)
            .WithPayload(status.ToByteArray())
            .WithQualityOfServiceLevel(MqttQualityOfServiceLevel.AtLeastOnce)
            .WithRetainFlag(true) // The backend reads the latest status when it subscribes
            .Build();

        await _client.PublishAsync(message, ct);
        _logger.LogTrace("[MQTT-V2] Sent status {State} ({Count} endpoints).", status.State, status.Endpoints.Count);
    }

    public async Task PublishCommandAckAsync(Guid siteId, V2.CommandAck ack, CancellationToken ct)
    {
        var topic = _topics.V2Ack(siteId, EdgeIds.ToGuid(ack.EndpointId));
        var message = new MqttApplicationMessageBuilder()
            .WithTopic(topic)
            .WithPayload(ack.ToByteArray())
            .WithQualityOfServiceLevel(MqttQualityOfServiceLevel.AtLeastOnce)
            .Build();

        await _client.PublishAsync(message, ct);
        _logger.LogInformation(
            "[MQTT-V2] Acknowledged command {CommandId} for endpoint {EndpointId}: success={Success} {Response} {Error}",
            EdgeIds.ToGuid(ack.CommandId),
            EdgeIds.ToGuid(ack.EndpointId),
            ack.Success,
            ack.ProtocolResponse,
            ack.Error
        );
    }

    // ─── Private helpers ──────────────────────────────────────────────────────

    private MqttClientOptions BuildClientOptions()
    {
        // The broker publishes this retained v2 status when the agent drops off without a clean shutdown
        var siteId = Guid.TryParse(_siteId, out var parsed) ? parsed : Guid.Empty;
        var willStatus = new V2.AgentStatus
        {
            ClientId = _options.ClientId,
            SiteId = EdgeIds.ToByteString(siteId),
            AgentVersion = AgentCapabilities.AgentVersion,
            State = V2.AgentState.Offline,
            TimestampMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
        };
        willStatus.SupportedProtocols.AddRange(AgentCapabilities.SupportedProtocols);
        var willPayloadBytes = willStatus.ToByteArray();

        var builder = new MqttClientOptionsBuilder()
            .WithClientId(_options.ClientId)
            .WithTcpServer(_options.BrokerHost, _options.BrokerPort)
            .WithCleanSession(false) // Session state persisted across reconnects
            .WithWillTopic(_topics.V2Status(siteId)) // Will Retained
            .WithWillPayload(willPayloadBytes)
            .WithWillQualityOfServiceLevel(MqttQualityOfServiceLevel.AtLeastOnce)
            .WithWillRetain(true);

        if (_options.UseTls)
        {
            builder.WithTlsOptions(MqttTlsOptionsFactory.BuildTlsOptions(_options, _logger));
        }

        if (!string.IsNullOrEmpty(_options.Username))
        {
            var pwd = !string.IsNullOrEmpty(_options.Password) ? _options.Password : _agentKey;
            builder.WithCredentials(_options.Username, pwd);
        }
        else if (!string.IsNullOrEmpty(_agentKey))
        {
            // The key id of the tenant agent key; the broker's ACL allows the key's own sites only
            builder.WithCredentials(_username ?? _siteId, _agentKey);
        }

        return builder.Build();
    }

    private async Task OnDisconnectedAsync(MqttClientDisconnectedEventArgs args)
    {
        if (Interlocked.CompareExchange(ref _isReconnecting, 1, 0) != 0)
        {
            _logger.LogDebug(
                "[MQTT] Reconnect loop is already running. Skipping duplicate trigger."
            );
            return;
        }

        try
        {
            _logger.LogWarning(
                "[MQTT] Disconnected (reason: {Reason}). Starting reconnect with backoff...",
                args.Reason
            );

            var delayMs = _options.ReconnectBaseDelayMs;
            var attempt = 0;

            while (!_cts.Token.IsCancellationRequested)
            {
                attempt++;
                if (_options.ReconnectAttemptsExhausted(attempt))
                {
                    _logger.LogCritical(
                        "[MQTT] Reconnection aborted after {MaxAttempts} failed attempts. Manual intervention or service restart required.",
                        _options.MaxReconnectAttempts
                    );
                    break;
                }

                _logger.LogInformation(
                    "[MQTT] Reconnect attempt #{Attempt}/{MaxAttempts} in {Delay}ms...",
                    attempt,
                    _options.ReconnectAttemptLimitText,
                    delayMs
                );

                try
                {
                    await Task.Delay(delayMs, _cts.Token);
                    await _client.ConnectAsync(_clientOptions, _cts.Token);
                    _logger.LogInformation(
                        "[MQTT] Reconnected successfully on attempt #{Attempt}.",
                        attempt
                    );
                    return;
                }
                catch (OperationCanceledException)
                {
                    _logger.LogInformation("[MQTT] Reconnection canceled.");
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "[MQTT] Reconnect attempt #{Attempt} failed.", attempt);
                    delayMs = Math.Min(delayMs * 2, _options.ReconnectMaxDelayMs);
                }
            }
        }
        finally
        {
            Interlocked.Exchange(ref _isReconnecting, 0);
        }
    }

    public async ValueTask DisposeAsync()
    {
        _client.DisconnectedAsync -= OnDisconnectedAsync;
        try
        {
            _cts.Cancel();
        }
        catch (ObjectDisposedException) { }

        if (_client.IsConnected)
        {
            try
            {
                await _client.DisconnectAsync();
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Error disconnecting MQTT client during dispose.");
            }
        }
        _client.Dispose();
        _cts.Dispose();
    }
}
