using Votech.Edge.Core.Configuration;
using Votech.Edge.Ingestion.Services;
using Votech.Edge.Service;
using Microsoft.Extensions.Options;
using Serilog;

// ─────────────────────────────────────────────────────────────────────────────
// Bootstrap Serilog early so startup exceptions are captured
// ─────────────────────────────────────────────────────────────────────────────
// Colored like the backend unless ConsoleLogging__EnableAnsiColors=false; configuration is not read yet
Log.Logger = new LoggerConfiguration()
    .WriteTo.Console(new CleanConsoleFormatter(CleanConsoleFormatter.AnsiColorsEnabled(Environment.GetEnvironmentVariable("ConsoleLogging__EnableAnsiColors"))))
    .CreateBootstrapLogger();

try
{
    Log.Information("Starting the edge agent...");

    // Initialize SQLCipher native provider
    SQLitePCL.Batteries.Init();

    // ─── Load .env Early ──────────────────────────────────────────────────────
    var dotEnvValues = DotEnvLoader.Load();

    var builder = Host.CreateApplicationBuilder(args);

    if (dotEnvValues.Count > 0)
    {
        builder.Configuration.AddInMemoryCollection(dotEnvValues);
    }

    // ─── Serilog ─────────────────────────────────────────────────────────────
    // The console sink is here, not in appsettings.json, for its formatter (CleanConsoleFormatter); the file sink is configured
    var consoleColors = CleanConsoleFormatter.AnsiColorsEnabled(builder.Configuration["ConsoleLogging:EnableAnsiColors"]);
    builder.Services.AddSerilog(
        (_, cfg) =>
            cfg.ReadFrom.Configuration(builder.Configuration)
                .Enrich.With<SiteTagEnricher>()
                .WriteTo.Console(new CleanConsoleFormatter(consoleColors))
    );

    // ─── Mandatory AgentKey Startup Gate ──────────────────────────────────────
    var agentKey =
        builder.Configuration.GetSection("EdgeAgent:AgentKey").Value
        ?? builder.Configuration.GetSection("EdgeAgent:ApiKey").Value;

    if (string.IsNullOrWhiteSpace(agentKey))
    {
        Log.Fatal("================================================================================");
        Log.Fatal("FATAL CONFIGURATION ERROR: the edge agent did not start.");
        Log.Fatal("Missing required configuration: 'AgentKey' (AGENT_KEY).");
        Log.Fatal("The agent key identifies this installed agent. Issue it on the Site connectors page,");
        Log.Fatal("where you also choose the sites this agent serves; the agent asks the server for them.");
        Log.Fatal("Please configure it in .env (AGENT_KEY=...), appsettings.json or an environment variable:");
        Log.Fatal("  - JSON: EdgeAgent:AgentKey");
        Log.Fatal("  - Environment variable: EdgeAgent__AgentKey");
        Log.Fatal("Optional: TENANT_ID (EdgeAgent:TenantId) refuses a key of another organisation.");
        Log.Fatal("================================================================================");
        await Log.CloseAndFlushAsync();
        return 1;
    }

    // Since agent 3.3 the client ids come from the key (X-03); a value from agent 3.2 or older is not used
    if (!string.IsNullOrWhiteSpace(builder.Configuration["EdgeAgent:Mqtt:ClientId"]))
    {
        Log.Warning(
            "EdgeAgent:Mqtt:ClientId (MQTT_CLIENT_ID) is not used since agent 3.3: each site connects as edge-<key id>-<site id>, the only client ids the broker accepts for this key. Remove the setting."
        );
    }

    // ─── Options Pattern (IOptions<T>) ───────────────────────────────────────
    // The agent's own settings; each site runtime binds its own copy with its site (SiteRuntime).
    builder
        .Services.AddOptions<EdgeAgentOptions>()
        .Bind(builder.Configuration.GetSection("EdgeAgent"))
        .ValidateDataAnnotations()
        .ValidateOnStart();
    // https and MQTT over TLS outside Development; an agent key and no configured site
    builder.Services.AddSingleton<IValidateOptions<EdgeAgentOptions>>(new EdgeAgentOptionsValidator(builder.Environment.EnvironmentName));
    builder.Services.AddSingleton<IValidateOptions<EdgeAgentOptions>>(new AgentKeyValidator(builder.Environment.EnvironmentName));

    // ─── Agent assignment: the sites this agent serves ───────────────────────
    const string EdgeApiHttpClient = "edge-api";
    builder
        .Services.AddHttpClient(
            EdgeApiHttpClient,
            (sp, client) =>
            {
                var opts = sp.GetRequiredService<IOptions<EdgeAgentOptions>>().Value;
                client.BaseAddress = new Uri(opts.ApiBaseUrl.TrimEnd('/') + "/");
            }
        )
        // The client lives as long as the agent; the handler recycles connections and checks a private CA
        .ConfigurePrimaryHttpMessageHandler(sp =>
            EdgeApiHttpHandler.Create(sp.GetRequiredService<IOptions<EdgeAgentOptions>>().Value, sp.GetRequiredService<ILoggerFactory>().CreateLogger("Votech.Edge.Api")))
        .SetHandlerLifetime(Timeout.InfiniteTimeSpan);

    builder.Services.AddSingleton(sp =>
        new AgentAssignmentSource(
            sp.GetRequiredService<IHttpClientFactory>().CreateClient(EdgeApiHttpClient),
            sp.GetRequiredService<IOptions<EdgeAgentOptions>>(),
            sp.GetRequiredService<ILogger<AgentAssignmentSource>>(),
            AssignmentCacheFile(sp.GetRequiredService<IOptions<EdgeAgentOptions>>().Value.Storage.SqliteConnectionString)
        )
    );

    // ─── Health checks ───────────────────────────────────────────────────────
    builder.Services.AddHealthChecks();

    // ─── The sites, each in its own runtime ──────────────────────────────────
    builder.Services.AddHostedService<AgentSupervisor>();

    var host = builder.Build();
    await host.RunAsync();
}
catch (Exception ex)
{
    Log.Fatal(ex, "Edge Agent terminated unexpectedly.");
    return 1;
}
finally
{
    await Log.CloseAndFlushAsync();
}

return 0;

// The agent's sites are kept next to the site databases, so it restarts them without the backend.
static string? AssignmentCacheFile(string sqliteConnectionString)
{
    var dataSource = new Microsoft.Data.Sqlite.SqliteConnectionStringBuilder(sqliteConnectionString).DataSource;
    return string.IsNullOrEmpty(dataSource) || dataSource.Equals(":memory:", StringComparison.OrdinalIgnoreCase)
        ? null
        : Path.Combine(Path.GetDirectoryName(Path.GetFullPath(dataSource))!, "agent-assignment.pb");
}
