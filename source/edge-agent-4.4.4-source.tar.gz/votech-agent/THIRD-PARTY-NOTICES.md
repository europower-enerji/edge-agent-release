# Third-party notices

The site connector is licensed under the GNU General Public License version 3 only (GPL-3.0-only, see `LICENSE`),
because it links lib60870.NET, which is GPL-3.0-only. It uses the packages below at run time; each keeps its own
licence. Build-only tools (Grpc.Tools, Microsoft.EntityFrameworkCore.Design) are not part of the published image or the Windows package.

| Package | Version | Licence | Copyright / authors | Source |
|---|---|---|---|---|
| lib60870.NET | 2.3.0 | GPL-3.0-only | MZ Automation GmbH (Michael Zillgith) | https://github.com/mz-automation/lib60870.NET |
| NModbus, NModbus.Serial | 3.0.81 | MIT | Scott Alexander, Dmitry Turin and contributors | https://github.com/NModbus/NModbus |
| MQTTnet | 4.3.7.1207 | MIT | The contributors of MQTTnet | https://github.com/dotnet/MQTTnet |
| Google.Protobuf | 3.29.0 | BSD-3-Clause | Google Inc. | https://github.com/protocolbuffers/protobuf |
| SQLitePCLRaw.bundle_e_sqlcipher | 2.1.8 | Apache-2.0 | Eric Sink | https://github.com/ericsink/SQLitePCL.raw |
| SQLCipher (native, inside the bundle above) | – | BSD-3-Clause | Zetetic LLC | https://github.com/sqlcipher/sqlcipher |
| SQLite (native, inside SQLCipher) | – | Public domain | – | https://sqlite.org |
| Microsoft.EntityFrameworkCore, .Sqlite.Core | 10.0.9 | MIT | Microsoft | https://github.com/dotnet/efcore |
| Microsoft.Extensions.* (Configuration, Hosting, Hosting.WindowsServices, Http, Logging, Options, Diagnostics.HealthChecks) | 10.0.9 | MIT | Microsoft | https://github.com/dotnet/runtime |
| System.ServiceProcess.ServiceController, System.Diagnostics.EventLog (with Hosting.WindowsServices) | 10.0.9 | MIT | Microsoft | https://github.com/dotnet/runtime |
| System.IO.Ports | 9.0.2 | MIT | Microsoft | https://github.com/dotnet/runtime |
| Serilog.Extensions.Hosting, .Settings.Configuration, .Sinks.Console, .Sinks.File | 8.0.0, 8.0.4, 6.0.0, 6.0.0 | Apache-2.0 | Serilog contributors | https://github.com/serilog |
| .NET runtime (base image `mcr.microsoft.com/dotnet/runtime`; inside the Windows package, which is self-contained) | 10.0 | MIT | Microsoft | https://github.com/dotnet/runtime |

The message-format files the connector is built from (`votech-shared/protobuf/v2/*.proto`) are MIT-licensed by
Europower Enerji, so the server side can use the same files. The source package attached to every release contains
them next to the connector's source.

Every new run-time package must be GPLv3-compatible and must be added to this table (`IMPLEMENTATION_CHECKLIST.md`).
