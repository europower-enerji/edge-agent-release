# Votech Edge Agent: Engineering & Operations Guide

This guide covers the Votech edge agent (`votech-agent`) on the edge contract v2 (ADR-002): how it is identified, how it gets its configuration, how values reach the backend, the commands it answers, and how to run and debug it locally. The customer installation guide is `deploy/customer/README.md`.

---

## 1. System Architecture: 1 Backend to N Edge Agents

```
 ┌────────────────────────────────────────────────────────┐
 │            Votech Backend (.NET 10)                  │
 │     REST: http://localhost:5050 | MQTT: localhost:1883 │
 └───────────────────────▲────────────────────────────────┘
                         │
     ┌───────────────────┼───────────────────┐
     │ (REST / MQTT)     │ (REST / MQTT)     │ (REST / MQTT)
     ▼                   ▼                   ▼
┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│  Edge Agent  │   │  Edge Agent  │   │  Edge Agent  │
│  (Site A)    │   │  (Site B)    │   │  (Site C)    │
└──────┬───────┘   └──────┬───────┘   └──────┬───────┘
       │ IEC 104          │ Modbus TCP       │ Modbus RTU
 ┌─────▼───────┐   ┌──────▼───────┐   ┌──────▼───────┐
 │ RTU and the │   │ Inverters,   │   │ Meters on a  │
 │ stations    │   │ meters       │   │ serial line  │
 │ behind it   │   │              │   │              │
 └─────────────┘   └──────────────┘   └──────────────┘
```

- **One agent per site.** It reads the site's communication endpoints (an RTU or gateway and the stations behind it, or a device with its own connection) and their signals.
- **Identity.** Everything is keyed by the backend's ids:
  - every sample by its signal id;
  - every batch by its endpoint id;
  - every status report by the site and the MQTT client id.

  Ids travel as 16-byte big-endian GUIDs in the protobuf messages (`votech-shared/protobuf/v2`).
- **Protocols:** IEC 60870-5-104, Modbus TCP and Modbus RTU.

---

## 2. Authentication & Site Identification

Since agent 3.0 a key belongs to an installed agent, not to a site. The key comes from the Votech **Edge agents** page, where a TenantAdmin (Organization Admin) registers agents for the organisation's sites, and a system administrator registers platform agents that serve sites of several organisations (the main server). There each agent is assigned its sites; a site is served by one agent at most. `.env` holds `AGENT_KEY` and, optionally, `TENANT_ID`, which refuses a key of another organisation (leave it empty for a platform agent).

1. **Agent assignment** (`AgentAssignmentSource`, `AgentSupervisor`).
   - `GET api/v1/edge/agent` (protobuf `AgentAssignment`) says which sites the agent serves, of any organisation. It runs at start and every 60 s, and is kept in `agent-assignment.pb` for restarts without the backend.
   - Every site runs in its own runtime (`SiteRuntime`) with its own container, SQLite file (`{data folder}/{tenantId}/{siteId}.db`, locked against a second agent), MQTT sessions and Last Will; log lines carry the site name.
   - A newly assigned site starts within a minute, a removed one stops; a site that stops by itself starts again after 1 min, doubling to 30 min. The other sites keep running.
   - A refusal (401/403) never stops the process (agent 3.2, X-01). The running sites keep running, those of `agent-assignment.pb` start, and the agent asks again after 1 min, doubling to 15 min (`[AUTH]`). The refusal's `code` says why (votech-shared `edge_config.proto`, "Refusals").
   - Only a key refusal (401 `EDGE_KEY_INVALID`, `EDGE_KEY_REVOKED` or `EDGE_KEY_TENANT_MISMATCH`) that comes 3 times in a row over at least 10 min stops every site (`[AUTH-FATAL]`, `KeyRefusalPolicy`). The agent keeps asking and starts the sites again when the backend accepts the key. A 503 (`EDGE_AUTH_UNAVAILABLE`: the backend could not check the key) counts as "backend not reachable".
2. **REST configuration channel.**
   - Per site: `GET api/v1/edge/sites/{siteId}/configuration` with `X-Edge-Api-Key: <agent key>` (and `X-Edge-Tenant-Id` when `TENANT_ID` is set).
   - A 403 `ERRORS.FORBIDDEN_EDGE_SITE_MISMATCH` (the agent does not serve the site any more) stops that site only. Any other 401 or 403 keeps the site on its cached configuration.
3. **MQTT.**
   - Username = the key id (`eak_live_<key id>_<secret>`, or `gpk_live_…` for a key issued before backend 5.18.0), password = the key; client id = `edge-<key id>-<site id, 32 hex digits>`, and the same with `-cmd` for the commands (agent 3.3). Votech accepts an agent key under its own client ids only, and closes them when the key is revoked or rotated or the site is taken away (X-03). `EdgeAgent:Mqtt:ClientId` (`MQTT_CLIENT_ID`) is ignored with a warning.
   - The broker lets the agent publish and subscribe only under `{prefix}/v2/.../{siteId}/...` of its sites.
3. **Transport security.** Outside `DOTNET_ENVIRONMENT=Development`, the API address must be `https://` and `Mqtt:UseTls` must be true; otherwise the agent does not start.
   - **Private CA** (agent 3.4, A-02): `EdgeAgent:Mqtt:CaCertificatePath` (`MQTT_CA_CERT`) and `EdgeAgent:ApiCaCertificatePath` (`API_CA_CERT`). With one set, that connection trusts only the CA file (PEM, DER or a bundle; custom root trust, no revocation check), and the certificate must name the host. A file that cannot be read stops the agent at startup in every environment (`PrivateCaTrust`, `EdgeAgentOptionsValidator`). Refusals log `[MqttTls]` or `[API-TLS]`.

---

## 3. Data Pipeline & Store-and-Forward

1. **Configuration** (`EdgeConfigurationSource`).
   - Fetches the protobuf `EdgeConfiguration` with `If-None-Match`; a 304 keeps the running revision.
   - Fetches at startup, on a `reload` command, and every 60 s as a fallback.
   - The last good configuration is cached in SQLite (`EdgeConfigurationCache`). Offline, the agent runs on it for up to `MaxOfflineCacheHours`.
2. **Acquisition** (`ConnectionManager`).
   - One `IConnectionPoller` runs per connection, keyed by the root endpoint.
   - A changed link setting reopens the link; changed stations or points are swapped in on the open link.
   - `Iec104ConnectionPoller`:
     - sends a general interrogation per station common address;
     - routes values by CA and IOA;
     - judges each device time by the offset of the connection's clock (`EdgeAgent:Iec104:ClockPolicy`: `Observe` measures and logs it, `Enforce` stamps every value of a connection whose clock is off by more than `ClockSkewToleranceSec` on receipt), and says in each sample where its time comes from;
     - sets a station clock only when the connection's `clock_sync` asks for it, and logs every set.
   - `ModbusConnectionPoller` reads blocks per unit and decodes typed values.
   - Every value is written as a sample. There is no deadband on the edge; the backend applies it.
3. **Store-and-forward buffer** (`SignalSampleSink`, `SqliteSignalBuffer`).
   - Samples are collected for `BatchWindowMs` and stored as batches of at most `MaxBatchSize` in `SignalBatches` / `SignalSamples`.
   - The database is SQLite in WAL mode, encrypted with SQLCipher when a database password is set.
   - Nothing is lost while the broker or the internet is down.
   - The buffer is capped (`Storage:MaxRecordCapacity`, `Storage:MaxDbSizeMb` counted as the pages in use). The caps delete whole published batches only; unsent batches are deleted only at the free disk floor, and counted (`evicted_total` in the status).
   - A window that cannot be stored is tried 5 times; readings that never reach the buffer are counted (`dropped_total` in the status).
4. **Publishing** (`SignalBatchPublisher`).
   - The oldest batch goes to `{prefix}/v2/telemetry/{siteId}/{endpointId}` at QoS 1.
   - It is marked published after the broker's PUBACK.
   - A resend carries the same batch id and samples, so the backend applies it once.
   - Published batches are purged after `Storage:RetentionDays` (1 day).
5. **Status** (`AgentStatusReporter`).
   - The retained `AgentStatus` goes to `{prefix}/v2/status/{siteId}/{clientId}`: every endpoint's health, the running revision, the supported protocols and the buffer.
   - It is sent every `HeartbeatIntervalSec`, and at once when an endpoint connects or disconnects.
   - The MQTT Last Will is the same status as OFFLINE.

---

## 4. Downlink Commands

The agent subscribes to `{prefix}/v2/commands/{siteId}/+` (`V2CommandSubscriber`).

- **`reload`** (`ReloadConfig`): fetches the configuration again, unless the announced revision is the one already running.
- **`probe`** (`ProbeCommand`): tests the connection of one endpoint of the running configuration and answers a `CommandAck` on `{prefix}/v2/ack/{siteId}/{endpointId}`.
  - A connected endpoint answers from its live health without a second socket.
  - An endpoint without a running poller gets one probe with its configured settings.
  - An endpoint that is not configured is refused (`ENDPOINT_NOT_CONFIGURED`), so the agent never probes arbitrary addresses.

---

## 5. Quick Start: How to Build & Run Locally

### Prerequisites

- [.NET 10 SDK](https://dotnet.microsoft.com/download/dotnet/10.0)
- The Votech backend on `http://localhost:5050` and its Mosquitto broker on `localhost:1883`
- `votech-shared` checked out next to this repository (the protos are compiled at build time)
- An agent registered on the Votech Edge agents page with its sites; put its `AGENT_KEY` (and optionally `TENANT_ID`) in `.env` (see `.env.example`)
- For IEC 104 without a real RTU: a simulator listening on port 2404

### Build & Run

```bash
dotnet build Votech.Edge.sln
dotnet test Votech.Edge.sln
dotnet run --project src/Votech.Edge.Service/Votech.Edge.Service.csproj
```

`dotnet run` uses the Development profile (`appsettings.Development.json`): plain HTTP and MQTT, a local `edge-dev.db`, and Debug logs.

---

## 6. Log Cheat Sheet

| Log tag               | Source                                   | What it reports                                           |
| --------------------- | ---------------------------------------- | --------------------------------------------------------- |
| `[SYNC-CONFIG]`       | `EdgeConfigurationSource`                | Configuration fetched, cached or kept; the running revision |
| `[CONNECTIONS]`       | `ConnectionManager`                      | Pollers started, swapped or stopped                       |
| `[IEC104-CONN]`       | `Iec104ConnectionPoller`                 | Link opened, lost or not confirmed                        |
| `[IEC104-STARTDT]`    | `Iec104ConnectionPoller`                 | STARTDT confirmed by the RTU                              |
| `[IEC104-GI]`         | `Iec104ConnectionPoller`                 | General interrogation per station: sent, confirmed, and done with its counts (objects, read, not configured, points that did not answer) |
| `[IEC104-CA]`         | `Iec104ConnectionPoller`                 | The RTU refused a common address (COT 46), naming the address it sends |
| `[IEC104-CONFIG]`     | `Iec104ConnectionPoller`, `Iec104PointMap` | No points, an unknown common address, an address that is not an IOA or is ambiguous, IOAs arriving with reversed octets |
| `[IEC104-CLOCK]`      | `Iec104ConnectionPoller`                 | Every hour: the offset of the RTU clock and how many device times were used or stamped on receipt. Once per link: an RTU clock off by more than the tolerance (a past year, ahead, or local time instead of UTC). Every clock the agent sets. |
| `[IEC104-STATS]`      | `Iec104ConnectionPoller`                 | Traffic summary per connection every `EdgeAgent:Iec104:StatsIntervalMinutes` (5) |
| `[IEC104-FRAME]`      | `Iec104ConnectionPoller`                 | Every frame decoded at Debug, with `EdgeAgent:Iec104:LogRawFrames` and the Debug level; `[IEC104-HEX]` gives the bytes at Verbose |
| `[MODBUS-CONN]`       | `ModbusConnectionPoller`                 | Link opened or lost, station down                         |
| `[SINK]`              | `SignalSampleSink`                       | Readings dropped (queue full), a store retried or dropped, drained on shutdown |
| `[STATUS]`            | `AgentStatusReporter`                    | Endpoint connected count when it changes                  |
| `[MQTT]`              | `MqttPublisher`                          | Broker connection and reconnects                          |
| `[MQTT-V2]`           | `SignalBatchPublisher`, `MqttPublisher`  | Batches sent per minute; acknowledgements                 |
| `[COMMANDS]`          | `V2CommandSubscriber`                    | Commands received or refused                              |
| `[PROBE]`             | `EndpointProbeService`                   | Probe results                                             |
| `[STORAGE]`           | `SqliteSignalBuffer`, `EdgeDatabaseMigrator` | Buffer cap reached, published batches deleted, unsent ones kept; database copied and migrated |
| `[CRITICAL-STORAGE-ALARM]` | `SqliteSignalBuffer`                | The disk is at its free space floor: the oldest unsent batches were deleted |
| `[AUTH]`              | `AgentSupervisor`                        | The backend refused the agent; the sites keep running and it asks less often |
| `[AUTH-FATAL]`        | `AgentSupervisor`                        | The key was refused for 10 min; every site stops, the agent keeps asking |

---

## 7. Troubleshooting

- **No data, `[SYNC-CONFIG]` shows 0 connections.** The site's endpoints are inactive, or the agent runs for another site. Activate the RTU (and its stations) in the Communication Explorer; the agent loads the change within a minute.
- **IEC 104 link opens but `STARTDT_NOT_CONFIRMED`.** The RTU accepts TCP but not this master: another master holds its only connection, or the agent's address is not an allowed master. Each attempt's socket is closed before the next; the delay grows 5 s, 10 s, 20 s, 40 s, then 60 s (±20 %), and starts over only after a link that stayed up a minute. `ss -tnoi dst <rtu-ip>` on the agent host shows whether this agent holds more than one socket.
- **`Another agent is running on …`.** The agent holds `<database>-lock` (with its process id) while it runs, so a second agent on the same database, such as a second `dotnet watch`, stops at startup instead of competing for the RTUs.
- **SQLite database locked.** The agent sets `busy_timeout` and WAL mode. Make sure no SQLite browser holds `edge.db` open.
- **Upgrading from 1.8.x.** Go through 2.0.2 first: it sends what 1.8.x had not sent. 2.1 and later drop the 1.8.x tables, keeping them only in the `edge.db.bak-<version>` copy.
