# Votech Edge Agent — AI Agent & Developer Implementation Checklist

> **Purpose**: This is the mandatory pre-flight + execution checklist for every task delegated to developers or AI agents on the `votech-agent` .NET 10 codebase. No task is considered complete until every applicable section is verified. Read this **in full** before writing a single line of code.
>
> The agent runs on the edge contract v2 (ADR-002, `votech-shared/protobuf/v2`): it reads communication endpoints and signals from the backend and sends every sample keyed by its signal id. The v1 device/tag contract is gone (agent 2.1).

---

## 0. Codebase DNA (Read-Only Reference — Never Deviate)

### Tech Stack

| Layer            | Technology                                                                                  | Version / Lib |
| ---------------- | ------------------------------------------------------------------------------------------- | ------------- |
| Runtime          | .NET 10 / C# 14                                                                             | .NET 10.0     |
| Host             | .NET Generic Host (`IHostedService` / `BackgroundService`)                                  | 10.0          |
| ORM / Buffer DB  | Entity Framework Core 10 (SQLite provider)                                                  | 10.0          |
| DB Engine        | SQLite 3 (WAL mode), SQLCipher encryption at rest (`SQLitePCLRaw.bundle_e_sqlcipher`)       | 3.x / 2.1.x   |
| IEC 104 Protocol | `lib60870.NET` (pure C#, MZ Automation)                                                     | 2.3.x         |
| Modbus Protocol  | `NModbus` and `NModbus.Serial` (TCP and RTU)                                                | 3.0.x         |
| MQTT Publisher   | `MQTTnet` (v4.x)                                                                            | 4.3.x         |
| Contract         | `Google.Protobuf` + `Grpc.Tools`, compiled from `votech-shared/protobuf/v2` at build time | 3.29 / 2.67   |
| Logging          | Serilog (Console + File sinks)                                                              | 4.x           |
| Testing          | xUnit + Moq; SQLite files in the temp folder; a lib60870 loopback server for IEC 104        | —             |
| Container        | Docker (multi-stage, `mcr.microsoft.com/dotnet/runtime:10.0`, multi-arch)                   | 24.0+         |
| Package Manager  | dotnet CLI / NuGet                                                                          | —             |

### Project Conventions You MUST Follow

- **Store-and-Forward First**: Every sample read from the field is stored in SQLite (`SignalBatches` / `SignalSamples`) BEFORE any MQTT publish attempt. Data safety is the top priority.
- **Interface-Driven Design**: Every protocol implements `IConnectionPoller` and is created by `ConnectionPollerFactory`. Never instantiate a protocol client directly in `Worker.cs` or `Program.cs`.
- **The Backend Owns the Point List**: Endpoints, stations, points, addresses and scaling come from the v2 configuration (`GET api/v1/edge/sites/{siteId}/configuration`). Never configure points in `appsettings.json`.
- **Options Pattern Mandatory**: Use `IOptions<T>`, `IOptionsSnapshot<T>`, or `IOptionsMonitor<T>` for all agent settings. Zero calls to `IConfiguration["raw:key"]` inside services or protocol clients.
- **Constants in `Votech.Edge.Core/Constants/`**: Every protocol constant (port numbers, timeouts, frame counts, quality descriptor bytes, ASDU TypeIDs, etc.) MUST be defined in a named constant in `ProtocolConstants.cs` or `EdgeContractConstants.cs`. Hard-coding a port number or timeout inline — even as an Options class default — is **forbidden**. Options class default values must reference the constants.
- **Strict Nullability**: `<Nullable>enable</Nullable>` is ON for all projects. No null-forgiving operators (`!`) without an explanatory comment.
- **No Business Logic in Worker**: `Worker.cs` is the orchestrator only. Protocol logic lives in `Ingestion`, storage logic in `Storage`, transport logic in `Mqtt`.
- **Decouple Library Threads**: Protocol callbacks (e.g. lib60870 ASDU handlers) run on the library's threads. They only write a `SignalReading` to `ISignalSink`, which queues it (bounded) and stores batches on its own task.
- **EF Core Migrations**: Use `dotnet ef migrations add` (the tool is pinned in `.config/dotnet-tools.json`) for schema changes. Never modify generated migration files after they shipped. `EdgeDatabaseMigrator` copies an existing database to `<file>.bak-<version>` before it migrates. Never call `EnsureCreatedAsync()` in production.
- **Batch Writes**: Never insert samples one at a time. A batch and its samples are written in one transaction.
- **Open Source (GPLv3)**: The connector links lib60870.NET (GPL-3.0-only) and is published under GPLv3 (`LICENSE`, `THIRD-PARTY-NOTICES.md`). Every dependency must be GPLv3-compatible (MIT, BSD, Apache-2.0, LGPL or GPL); never add a proprietary or source-unavailable package, and list each new runtime package in `THIRD-PARTY-NOTICES.md`. Connector code is never copied into the backend, web, mobile or license platform. LFDCC/IEC60870 and Jeprotec/IEC-60870 are GPL code relabelled "MIT": never use them. `PackageLicenseTests` fails on any other licence and on those packages (EMS-173).
- **Public Repository**: Never put customer or site names, real site or tenant ids, addresses of customer devices, keys, passwords or incident details in any file, tests and `.trace` records included. Use neutral names ("North Solar Plant") and documentation addresses (192.0.2.x, 198.51.100.x, 203.0.113.x). `PublicAddressInRepositoryTests` fails on a public address with a port. Business logic (plans, prices, licence checks) lives in the backend only.

### 0.1 Strict Vibe-Trace & Automatic Versioning Protocol

Whenever completing a task (implementing a feature, fixing a bug, or performing refactoring/maintenance), AI agents and developers MUST:

1. Increment the `<Version>` string in `Votech.Edge.Service.csproj` following standard SemVer rules (Patch for fixes/tweaks, Minor for features/drivers, Major for breaking changes).
2. Create a trace record in `.trace/` named `YYYY-MM-DD-HH-MM-short-description.md` detailing context, architectural shifts, and app version.

---

## 1. Pre-Implementation Checklist (Before Writing Code)

### 1.0 AI Engineering & Anti-Hallucination Inventory (STRICT)

- [ ] **Hard Halt on Missing Protocol Definitions**: If a feature requires ASDU types, IOA addresses, or Protobuf fields not present in the constants or the v2 messages, halt immediately and emit: `STATUS: DATA_NOT_FOUND`.
- [ ] **Ground Truth Inventory First**: Search `Votech.Edge.Core`, `Votech.Edge.Ingestion`, `Votech.Edge.Storage` and `Votech.Edge.Mqtt` to reuse existing pollers, mappers and buffer stores.
- [ ] **Zero Hardcoded Protocol Values**: Ensure all IP addresses, ports, and ASDU TypeIDs come from the configuration or constants.

### 1.1 Understand Scope

- [ ] Read the task description completely. Clarify any ambiguity before touching any file.
- [ ] Identify which **projects** are affected (`Models`, `Core`, `Ingestion`, `Storage`, `Mqtt`, `Service`).
- [ ] Identify if entity changes are required and whether a new **EF Core migration** is needed.
- [ ] Identify if agent settings change — update `appsettings.json`, `appsettings.Development.json`, `deploy/customer/env.example` and the README configuration table together.
- [ ] Identify the specific **ASDU TypeIDs** (IEC 104) or **Modbus tables and data types** the implementation must handle.
- [ ] Check the v2 contract in `votech-shared/protobuf/v2`. If the task needs a new message or field, it is added in `votech-shared` first, and in the backend's configuration compiler or ingestion, before the agent uses it.
- [ ] Verify any new numeric constant (port, timeout, TypeID, quality byte) is placed in `Votech.Edge.Core/Constants/` BEFORE using it anywhere.

### 1.2 Check Existing Patterns First

- [ ] Locate the existing pollers (`Iec104ConnectionPoller`, `ModbusConnectionPoller`) and their helpers (`Iec104PointMap`, `Iec104SignalMapper`, `ModbusAddressParser`, `ModbusBlockPlanner`, `ModbusValueDecoder`) before creating new ones.
- [ ] Reuse `EdgeConfigurationDiff` and `ConnectionManager` for configuration changes; do not restart the host for a new configuration.

---

## 2. Data Model Checklist

### Samples and Batches

- [ ] A reading carries the **signal id** (from the configuration), the value after transform and scaling, the timestamp, the canonical quality (`Good`, `Uncertain`, `Bad`, `Offline`), the raw quality bits, where its time comes from (`SampleTimeSource`), the device time when it was not used, and the receive lag.
- [ ] A batch carries its id (UUID v7), the **endpoint id** of its connection and the running configuration revision. It is sent, marked and evicted whole.
- [ ] Quality: IEC 104 `IV`, `NT`, `SB` and `BL` give Bad, `OV` gives Uncertain, and the raw bits are kept. Never invent a custom quality scale.
- [ ] `Timestamp` is always **UTC**. Never store local time.
- [ ] A CP56Time2a time is used unless its own IV bit is set (`ReceiptTimeInvalid`). With `ClockPolicy` Observe (default) a time more than 5 minutes ahead or older than `MaxDeviceTimeAgeHours` falls back to the receive time; with Enforce, every value of a connection whose clock offset (`DeviceClock`) is beyond `ClockSkewToleranceSec` does. A replaced time is kept (`ReceiptClockSkew`, `device_timestamp_ms`).
- [ ] When a link drops, a station stops answering or a poller stops, every signal already read gets one Offline sample with its last value, stamped on the clock its value came from and after that value.

---

## 3. Protocol Adapter Checklist

### General

- [ ] The poller implements `IConnectionPoller`, is created in `ConnectionPollerFactory`, and its protocol is listed in `AgentCapabilities.SupportedProtocols`.
- [ ] It reports `Health` for the root endpoint and every station behind it, with a reason code (`DeviceDiagnosticReason`) when down.
- [ ] Connection errors are caught, logged, and retried with **exponential backoff**. The poller NEVER crashes the host process.
- [ ] Stations and points can be swapped in on an open link (`UpdatePoints`); only link setting changes reopen the connection.
- [ ] It logs: connection established, connection lost (with the reason), reconnection attempts, and reconnection successful.

### IEC 104 Specific

- [ ] `APCIParameters` (`k`, `w`, `t0`–`t3`) and the originator address come from the connection settings.
- [ ] After STARTDT_CON, a General Interrogation (`C_IC_NA_1`) goes to every station common address, once per link (lib60870 can report STARTDT_CON twice), and again every `gi_interval_s`.
- [ ] A station clock is set (`C_CS_NA_1`) only as the connection's `clock_sync` says (OFF, ON_CONNECT, PERIODIC; UNSPECIFIED = every `clock_sync_interval_s` when set), in the station's `time_zone` (with SU while summer time applies; never when that zone is not known on the machine), and every sync is logged with the station's answer (confirmed, refused, or none within 30 s). Device times (CP56Time2a) are read in the same zone. Setting a clock writes to a device other masters may share.
- [ ] A missing STARTDT_CON ends the attempt after t1 with `STARTDT_NOT_CONFIRMED` (lib60870 does not time it out).
- [ ] Every attempt's socket is closed before the next. The delay grows from 5 s to 60 s with ±20 % jitter, and starts over only after a link that stayed up a minute.
- [ ] A one-shot probe never overlaps a running, starting or stopping poller of the same connection (`IConnectionManager.ProbeIfIdleAsync`).
- [ ] One agent per database: a second one stops at startup (`AgentInstanceLock`, `<database>-lock`).
- [ ] Values are routed by (common address, IOA) through a pre-compiled map. Never use LINQ in the hot ASDU handler path.
- [ ] An unknown common address is logged once; unknown IOAs are skipped.

### Modbus Specific

- [ ] Addresses follow the backend's grammar (`SignalAddressRules`) with the connection's address base.
- [ ] Points are grouped by poll interval; block reads cover touching ranges up to `max_block_registers` (125) or 2000 bits; gaps are never read.
- [ ] Timeouts and retries come from the connection's polling settings (NModbus's default of 3 retries is replaced).
- [ ] A Modbus exception fails only its block. A unit that times out, or a gateway exception 0x0A/0x0B, marks that station down.

---

## 4. SQLite Storage Checklist

### Schema & EF Core

- [ ] EF Core migrations are used. `EdgeDatabaseMigrator` applies them at startup after copying an existing database to `<file>.bak-<version>`.
- [ ] `SignalBatches` has an index on `(is_published, created_at)` — the publisher's query path. `SignalSamples` is indexed by batch id.
- [ ] The configuration cache is one row (`EdgeConfigurationCache`).

### SQLite WAL & Performance

- [ ] WAL mode and `busy_timeout` are set on the connection.
- [ ] The WAL is checkpointed periodically (`StorageMaintenanceService` → `ISignalBuffer.CheckpointDatabaseAsync`), with a warning when the WAL stays large.
- [ ] **Purge and cap**: published batches are purged after `RetentionDays`. `EnforceStorageCapAsync` keeps the buffer within `MaxRecordCapacity` and `MaxDbSizeMb` (pages in use, not the file size) by deleting whole published batches; unpublished ones are deleted only at the free disk floor, where free pages count as free space (`IsEvicting`, `EvictedTotal`, reported in the status).

### SQLite Encryption-At-Rest

- [ ] SQLCipher encryption is enabled when a database password is set (`Microsoft.EntityFrameworkCore.Sqlite.Core` + `SQLitePCLRaw.bundle_e_sqlcipher`).
- [ ] `SQLitePCL.Batteries.Init()` runs before any DbContext factory operation.
- [ ] The password is read from the environment and never logged.

### Concurrency

- [ ] There is exactly ONE write path for samples: `ISignalSink` → `ISignalBuffer`. Pollers never write to SQLite directly.
- [ ] The sink drops a reading whose value is not a number (NaN, ±Infinity), whatever the protocol or scaling: warned once per signal, counted per window at Debug. It never reaches the buffer or the backend.
- [ ] `IDbContextFactory<EdgeDbContext>` is used (NOT `AddDbContext<>`), so every operation gets a short-lived context.

---

## 5. MQTT Publisher Checklist

### Connection & Reliability

- [ ] `CleanSession = false` (MQTT 3.1.1) or `CleanStart = false` (MQTT 5.0) preserves session state across reconnects.
- [ ] QoS 1 (`AtLeastOnce`) for every publish. The backend deduplicates by batch id and by `(timestamp, signal id)`.
- [ ] TLS is configured when `UseTls = true`; outside Development the agent refuses to start without it (`EdgeAgentOptionsValidator`).
- [ ] The Will Message is the v2 `AgentStatus` with state OFFLINE, retained, on `{prefix}/v2/status/{siteId}/{clientId}`.
- [ ] Disconnects reconnect with exponential backoff and never give up.

### Publish Behavior

- [ ] `SignalBatchPublisher` is the only path to the broker. It sends the oldest batch to `{prefix}/v2/telemetry/{siteId}/{endpointId}`, marks it published after the broker's PUBACK, and stops at the first failure.
- [ ] A resend carries the same batch id and the same samples.
- [ ] `AgentStatusReporter` publishes the retained status every `HeartbeatIntervalSec`, at once when an endpoint connects or disconnects, and OFFLINE on a clean stop.
- [ ] Payloads are protobuf messages of the v2 contract only. No JSON on the wire.
- [ ] Each site connects as `edge-{keyId}-{siteId:N}` (data) and `…-cmd` (commands), derived from the agent key (agent 3.3, X-03). The broker accepts no other client id for the key; a configured `EdgeAgent:Mqtt:ClientId` is ignored with a warning.

---

## 6. Configuration System Checklist

- [ ] Every agent setting has a strongly-typed Options class in `Votech.Edge.Core/Configuration/`, validated at startup (data annotations or `IValidateOptions<T>`).
- [ ] `appsettings.Development.json` overrides production values for local development (plain HTTP and MQTT, local SQLite file, Debug logs).
- [ ] `appsettings.json` NEVER contains credentials. The site id, agent key, broker credentials and database password come from environment variables (`.env` locally).
- [ ] Any new setting is documented in `README.md`'s configuration table and in `deploy/customer/env.example` when customers may change it.

---

## 7. Security Checklist

- [ ] **No Secrets in Git**: MQTT passwords, TLS certificates, agent keys and database passwords MUST NOT be committed.
- [ ] **TLS in Production**: `https://` API and MQTT over TLS outside Development (enforced at startup).
- [ ] **Private CA**: with `MQTT_CA_CERT` / `API_CA_CERT`, only that CA is trusted and the certificate must name the host; an unreadable CA file stops the agent (A-02).
- [ ] **Agent Key**: the configuration request carries `X-Edge-Api-Key`. A refusal never stops the process; only a key code (401 `EDGE_KEY_*`) refused 3 times over at least 10 min stops the sites (`[AUTH-FATAL]`), and the agent keeps asking (X-01).
- [ ] **Commands**: only v2 commands on `{prefix}/v2/commands/{siteId}/…` for this site are handled; unknown or expired commands are refused and logged.
- [ ] **Probes**: only endpoints of the running configuration are probed, so a command can never make the agent open a socket to an arbitrary address.
- [ ] **Controls**: the agent does not execute control commands yet. When it does, every command MUST be checked for site, authorization and expiry before anything touches a physical device.
- [ ] **No Logging of Sensitive Values**: passwords, keys and control set-points are never logged at `Information` or higher.
- [ ] **Denial-of-Service Guard**: the sink queue is bounded (`MaxPendingQueueSize`, drop oldest, counted in `dropped_total` and logged). This prevents OOM crashes when a device floods.

---

## 8. Background Service & Reliability Checklist

### Worker Lifecycle

- [ ] `Worker` connects MQTT (non-blocking), starts the pollers through `ConnectionManager`, and runs the publisher and the purge job.
- [ ] On shutdown the pollers stop first (marking their signals Offline), the sink stores what it holds, and the publisher sends what the broker can still take within 5 seconds. The rest stays in the buffer.
- [ ] A poller handles link errors itself and reconnects with backoff. An exception that still escapes `RunAsync` is logged by `ConnectionManager` (`[CONNECTIONS] … stopped with an error`); the host process does NOT crash.

### Publisher Loop

- [ ] The publisher wakes when batches are stored and every `FlushIntervalMs`. It uses `Task.Delay(…, ct)` — NOT `Thread.Sleep`.
- [ ] It logs a summary once a minute (`[MQTT-V2] Sent N batches, N samples in 60 s; N waiting.`).

### Health

- [ ] The agent has no HTTP endpoint. Its health reaches the backend as the retained `AgentStatus`: per-endpoint health, the running revision, and the buffer (unsent samples, oldest unsent, eviction, dropped and evicted counters). The agent version names its commit (`3.1.0+abc1234`).

---

## 9. Testing Checklist

### Unit Tests (`Votech.Edge.Ingestion.Tests`)

- [ ] IEC 104: every supported ASDU TypeID, quality mapping, CP56Time2a handling, routing by (CA, IOA), and the loopback test against a lib60870 server (GI per CA, Offline on link loss).
- [ ] Modbus: table-driven tests for the address parser, the decoder and the block planner, plus pollers with a fake link.
- [ ] Configuration source, connection manager and diff, sink, buffer and publisher (same batch id on resend, whole-batch eviction), status, probes and the command subscriber.

### Unit Tests (`Votech.Edge.Storage.Tests`)

- [ ] `EdgeDatabaseMigrator`: a database of an older agent is copied, then migrated; a new database gets no copy.
- [ ] The SQLite database: WAL checkpoint, SQLCipher encryption.
- [ ] `Worker`: start order and shutdown order.
- [ ] `CleanConsoleFormatter`: the console line as the backend's (colors, site and component badges, `ConsoleLogging:EnableAnsiColors`).
- [ ] Storage tests use real SQLite files in the temp directory. No mocking of EF Core.

### End-to-End Smoke Test

- [ ] Run the agent against a local backend and broker with a site whose RTU (or a simulator) is active.
- [ ] `[SYNC-CONFIG]` shows the expected connections, stations and points; `[STATUS]` shows them connected.
- [ ] Stop the broker — samples accumulate in SQLite. Start it — they are sent and the backend shows them.
- [ ] Stop the RTU or simulator — the agent reconnects with backoff and the endpoints show as down.

---

## 10. Code Quality Red Lines (Non-Negotiable)

- ❌ **No direct `IConfiguration["path"]` access** inside services, pollers, or publishers. Use `IOptions<T>`.
- ❌ **No inline numeric literals for protocol constants**: port numbers, timeouts, TypeIDs, quality bytes, K/W APCI values, and frame counts MUST be referenced from the constants files.
- ❌ **No `Thread.Sleep()`** anywhere in the codebase. Use `await Task.Delay(ms, cancellationToken)`.
- ❌ **No synchronous blocking calls** (`.Result`, `.Wait()`, `.GetAwaiter().GetResult()`) on `Task`. Always `await`.
- ❌ **No single-sample inserts** to SQLite — always batch.
- ❌ **No swallowing of `OperationCanceledException`** during shutdown — let it end the loop.
- ❌ **No hardcoded IP addresses, port numbers, or credentials** in source code.
- ❌ **No local time** in samples. Always UTC, or the device time converted to UTC.
- ❌ **No raw exception throws without logging** — catch, log, then re-throw or handle.
- ❌ **No partial batch marking**: a batch is marked published whole, after the broker's acknowledgement, or not at all.
- ❌ **No command executed without checks** — site, authorization and expiry, before anything touches a physical device.
- ❌ **No GPLv3 code referenced from `Votech.Edge.Service`** or the libraries it uses.
- ❌ **No `EnsureCreatedAsync()` in production code** — migrations only.
- ❌ **No null-forgiving operators (`!`)** without a comment explaining why the reference is guaranteed non-null.

---

## 11. Deployment Checklist

### Docker Image

- [ ] `deploy/Dockerfile` uses a multi-stage build: `sdk:10.0` for build, `runtime:10.0` for the final image; the contract comes from the `shared` build context (`protobuf/v2`).
- [ ] Only the publish output and the required native libraries (SQLCipher, serial port) are copied.
- [ ] A non-root user (`edgeuser`) is set before `ENTRYPOINT`.
- [ ] `ENTRYPOINT` uses the array form: `ENTRYPOINT ["dotnet", "Votech.Edge.Service.dll"]`.

### Docker Compose (Customer)

- [ ] `restart: unless-stopped` is set for the edge-agent service.
- [ ] The data volume holds the SQLite database and its `.bak-<version>` copies; the logs volume holds the log files.
- [ ] All secrets are injected via `.env`, NOT hardcoded in `docker-compose.yml`.

### Physical Device (Raspberry Pi / Industrial PC)

- [ ] Docker and Docker Compose v2 are installed and verified.
- [ ] The device's clock is synchronized via NTP (needed for clock sync and timestamps).
- [ ] The RTUs, meters and inverters are reachable from the device (TCP 2404 for IEC 104, 502 for Modbus TCP, or the serial port for Modbus RTU).
- [ ] The backend API (443) and the broker (8883, MQTT over TLS) are reachable.

---

## 12. Protocol Standards Reference (Do Not Deviate)

### IEC 60870-5-104 (TCP/IP Companion Standard)

- Port: **2404** (IANA registered)
- Default APCI parameters: `k=12`, `w=8`, `t0=30s`, `t1=15s`, `t2=10s`, `t3=20s`
- General Interrogation: TypeID `100`, qualifier `20` (station interrogation)
- Clock sync: TypeID `103`, CP56Time2a of current UTC time
- Quality bits (§7.2.6.3): `IV=128` (invalid), `NT=64` (non-topical), `SB=32` (substituted), `BL=16` (blocked), `OV=1` (overflow)
- Cause of Transmission (CoT): `3=Spontaneous`, `5=Request`, `20=Interrogated by station`, `10=Act`, `11=ActCon`, `13=ActTerm`

### Modbus (TCP and RTU)

- Port: **502** (TCP)
- Function codes: `1` coils, `2` discrete inputs, `3` holding registers, `4` input registers
- At most **125** registers or **2000** bits per read
- Gateway exceptions `0x0A` (path unavailable) and `0x0B` (target failed to respond) mean the station behind the gateway is down

### MQTT (Edge-to-Cloud Transport, contract v2)

- Standard: MQTT 3.1.1 (minimum) or MQTT 5.0
- QoS for telemetry, status and acknowledgements: **QoS 1** (at-least-once)
- Topics: `{prefix}/v2/telemetry/{siteId}/{endpointId}` and `{prefix}/v2/status/{siteId}/{clientId}` (publish), `{prefix}/v2/ack/{siteId}/{endpointId}` (publish), `{prefix}/v2/commands/{siteId}/{command}` (subscribe)
- TLS: **TLS 1.2+**

---

## 13. Vibe-Trace Protocol (Meta-Level Engineering Audit)

Every developer or AI agent session MUST conclude by recording a concise summary in the `.trace/` directory.

- **Rule**: Create a new `.md` file in `.trace/` named `YYYY-MM-DD-HH-MM-short-description.md`.
- **Content**:
  - **Date and Location**: Date, time, location, timezone.
  - **Agent**: Developer's name + AI Tool — AI Model.
  - **Context**: Brief bullet points of the task.
  - **Protocols Touched**: List the pollers, ASDU types, or Modbus tables modified.
  - **Architectural Shift**: Did you change how a module works? Document it here.
  - **Vibes**: A short, informal note on progress or blockers.
- **Gate**: No task is closed until the `.trace` entry is committed and verified.

---

> _"In power systems, reliability is not a feature — it is the foundation. Write every line of this edge agent as if the grid depends on it. Because it does."_
