using Serilog.Core;
using Serilog.Events;
using Serilog.Formatting;
using Serilog.Formatting.Display;

namespace Votech.Edge.Service;

/// <summary>
/// The console format of the backend's <c>CleanConsoleFormatter</c>: a muted timestamp, an ANSI colored level badge,
/// the site of a site runtime, a component badge (<c>[IEC104]</c>, <c>[Modbus]</c>, <c>[MQTT]</c>, <c>[Storage]</c>,
/// <c>[Agent]</c>, …) and an indented red exception:
/// <c>[13:31:02] [INF] [Plant A] [IEC104] [IEC104-CONN] Connected to …</c>.
/// Colors are on unless <c>ConsoleLogging:EnableAnsiColors</c> is false (<see cref="AnsiColorsEnabled"/>). The file
/// log keeps its own template and the full <c>SourceContext</c>.
/// </summary>
public sealed class CleanConsoleFormatter(bool enableAnsiColors = true) : ITextFormatter
{
    private const string Reset = "\u001b[0m";
    private const string MutedGray = "\u001b[90m";
    private const string Green = "\u001b[32m";
    private const string Yellow = "\u001b[33m";
    private const string Red = "\u001b[31m";
    private const string BoldRed = "\u001b[1;31m";
    private const string Cyan = "\u001b[36m";
    private const string Purple = "\u001b[35m";

    // The agent's messages are written for {Message:lj}: strings without quotes, structures as JSON
    private static readonly MessageTemplateTextFormatter MessageFormatter = new("{Message:lj}");

    // The component badge of a class, first match on its name wins
    private static readonly (string Fragment, string Badge)[] ClassBadges =
    [
        ("Iec104", "IEC104"),
        ("Modbus", "Modbus"),
        ("Command", "Commands"),
        ("StatusReporter", "Status"),
        ("Mqtt", "MQTT"),
        ("Publisher", "MQTT"),
        ("Sink", "Sink"),
        ("Probe", "Probe"),
        ("Configuration", "Config"),
        ("Connection", "Connections"),
        ("Sqlite", "Storage"),
        ("Storage", "Storage"),
        ("Database", "Storage"),
        ("Agent", "Agent"),
        ("SiteRuntime", "Agent"),
    ];

    /// <summary>
    /// Colors are on unless <paramref name="setting"/> (<c>ConsoleLogging:EnableAnsiColors</c>) is <c>false</c>; a
    /// value that is not a boolean keeps them on rather than stopping the agent.
    /// </summary>
    public static bool AnsiColorsEnabled(string? setting) => !bool.TryParse(setting, out var enabled) || enabled;

    public void Format(LogEvent logEvent, TextWriter output)
    {
        ArgumentNullException.ThrowIfNull(logEvent);
        ArgumentNullException.ThrowIfNull(output);

        WriteBadge(output, logEvent.Timestamp.ToString("HH:mm:ss"), MutedGray);

        var (levelText, levelColor) = GetLevelInfo(logEvent.Level);
        WriteBadge(output, levelText, levelColor);

        if (logEvent.Properties.TryGetValue("Site", out var siteValue) && siteValue is ScalarValue { Value: string site } && !string.IsNullOrWhiteSpace(site))
        {
            WriteBadge(output, site, Purple);
        }

        WriteBadge(output, ResolveSourceBadge(GetSourceContext(logEvent)), Cyan);

        MessageFormatter.Format(logEvent, output);
        output.WriteLine();

        if (logEvent.Exception != null)
        {
            if (enableAnsiColors)
            {
                output.Write(Red);
            }
            output.Write("  --> ");
            output.Write(logEvent.Exception.ToString());
            if (enableAnsiColors)
            {
                output.Write(Reset);
            }
            output.WriteLine();
        }
    }

    /// <summary>
    /// The component badge of a Serilog <c>SourceContext</c>: framework categories by namespace, the agent's classes by
    /// <see cref="ClassBadges"/>, otherwise the class name. Lines without one (bootstrap, startup gate) are the agent's.
    /// </summary>
    public static string ResolveSourceBadge(string? sourceContext)
    {
        if (string.IsNullOrWhiteSpace(sourceContext))
        {
            return "Agent";
        }

        if (sourceContext.StartsWith("Microsoft.EntityFrameworkCore", StringComparison.Ordinal))
        {
            return "Storage";
        }

        if (sourceContext.StartsWith("System.Net.Http", StringComparison.Ordinal))
        {
            return "HTTP";
        }

        if (sourceContext.StartsWith("Microsoft.", StringComparison.Ordinal) || sourceContext.StartsWith("System.", StringComparison.Ordinal))
        {
            return "Host";
        }

        // EdgeApiHttpHandler logs under this category (Program.cs)
        if (sourceContext == "Votech.Edge.Api")
        {
            return "API";
        }

        // Without generic arity and namespace: Votech.Edge.Ingestion.Iec104.Iec104ConnectionPoller -> Iec104ConnectionPoller
        var typeName = sourceContext;
        var tickIndex = typeName.IndexOf('`');
        if (tickIndex > 0)
        {
            typeName = typeName[..tickIndex];
        }
        var shortName = typeName[(typeName.LastIndexOf('.') + 1)..];

        foreach (var (fragment, badge) in ClassBadges)
        {
            if (shortName.Contains(fragment, StringComparison.OrdinalIgnoreCase))
            {
                return badge;
            }
        }

        return shortName;
    }

    private void WriteBadge(TextWriter output, string text, string color)
    {
        if (enableAnsiColors)
        {
            output.Write(color);
        }
        output.Write('[');
        output.Write(text);
        output.Write(']');
        if (enableAnsiColors)
        {
            output.Write(Reset);
        }
        output.Write(' ');
    }

    private static string? GetSourceContext(LogEvent logEvent) =>
        logEvent.Properties.TryGetValue(Constants.SourceContextPropertyName, out var value) && value is ScalarValue { Value: string context }
            ? context
            : null;

    private static (string Text, string Color) GetLevelInfo(LogEventLevel level) =>
        level switch
        {
            LogEventLevel.Verbose => ("TRC", MutedGray),
            LogEventLevel.Debug => ("DBG", Cyan),
            LogEventLevel.Information => ("INF", Green),
            LogEventLevel.Warning => ("WRN", Yellow),
            LogEventLevel.Error => ("ERR", Red),
            LogEventLevel.Fatal => ("FTL", BoldRed),
            _ => ("INF", Green),
        };
}
