using Serilog.Core;
using Serilog.Events;

namespace Votech.Edge.Service;

/// <summary>
/// Adds <c>SiteTag</c> for the file log template: <c>"[site name] "</c> for lines of a site runtime and empty for the
/// agent's own. The console shows the site and a component badge itself (<see cref="CleanConsoleFormatter"/>).
/// </summary>
public sealed class SiteTagEnricher : ILogEventEnricher
{
    public void Enrich(LogEvent logEvent, ILogEventPropertyFactory propertyFactory)
    {
        var site = logEvent.Properties.TryGetValue("Site", out var siteValue) && siteValue is ScalarValue { Value: string name } ? $"[{name}] " : string.Empty;
        logEvent.AddPropertyIfAbsent(propertyFactory.CreateProperty("SiteTag", site));
    }
}
