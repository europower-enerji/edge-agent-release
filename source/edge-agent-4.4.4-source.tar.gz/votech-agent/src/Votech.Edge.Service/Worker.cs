using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Interfaces;
using Votech.Edge.Mqtt;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Votech.Edge.Service;

/// <summary>
/// The agent's main loop on the v2 contract (ADR-002):
///   1. Connect to MQTT (non-blocking: samples are buffered until the broker is reachable).
///   2. Start one poller per connection of the configuration (<see cref="IConnectionManager"/>).
///   3. Publish the buffered batches (<see cref="SignalBatchPublisher"/>, the only path to the broker).
///   4. Purge published samples older than <c>Storage.RetentionDays</c>.
/// On shutdown the pollers stop first (marking their signals Offline), the sink stores what it holds, and whatever
/// the broker can still take is sent.
/// </summary>
public sealed class Worker(
    ILogger<Worker> logger,
    IConnectionManager connections,
    ISignalSink sink,
    ISignalBuffer buffer,
    IMqttPublisher mqttPublisher,
    SignalBatchPublisher publisher,
    IOptions<EdgeAgentOptions> options
) : BackgroundService
{
    private static readonly TimeSpan ShutdownPublishTimeout = TimeSpan.FromSeconds(5);

    private readonly ILogger<Worker> _logger = logger;
    private readonly EdgeAgentOptions _options = options.Value;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation(
            "Edge Worker {Version} starting on contract v2. Site={SiteId}.",
            AgentCapabilities.AgentVersion,
            _options.SiteId
        );

        await TryConnectMqttAsync(stoppingToken);
        await connections.StartAsync(stoppingToken);

        try
        {
            await Task.WhenAll(
                publisher.RunAsync(stoppingToken),
                RunPurgeJobAsync(stoppingToken)
            );
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            // Shutdown
        }
        finally
        {
            await connections.StopAsync(CancellationToken.None);
            try
            {
                await sink.DrainAsync(CancellationToken.None);
                using var timeout = new CancellationTokenSource(ShutdownPublishTimeout);
                await publisher.PublishPendingAsync(timeout.Token);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Storing or sending the last samples on shutdown failed; they stay in the buffer.");
            }

            _logger.LogInformation("Edge Worker stopped cleanly.");
        }
    }

    private async Task RunPurgeJobAsync(CancellationToken ct)
    {
        var interval = TimeSpan.FromHours(_options.Storage.PurgeIntervalHours);
        while (!ct.IsCancellationRequested)
        {
            await Task.Delay(interval, ct);
            try
            {
                var samples = await buffer.PurgePublishedAsync(_options.Storage.RetentionDays, ct);
                _logger.LogInformation(
                    "Purge job complete: deleted {Samples} sample(s) (retention={Days} days).",
                    samples,
                    _options.Storage.RetentionDays
                );
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Purge job failed.");
            }
        }
    }

    private async Task TryConnectMqttAsync(CancellationToken ct)
    {
        try
        {
            await mqttPublisher.ConnectAsync(ct);
            _logger.LogInformation("MQTT connected to {Broker}.", _options.Mqtt.BrokerAddress);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "MQTT connection failed. Operating in offline-buffer mode.");
        }
    }
}
