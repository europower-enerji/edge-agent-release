using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Interfaces;
using Votech.Edge.Ingestion.Services;
using Votech.Edge.Mqtt;
using Votech.Edge.Storage;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace Votech.Edge.Service;

/// <summary>
/// The services of one site runtime (<see cref="SiteRuntime"/>): its configuration source, pollers, SQLite buffer and
/// MQTT sessions. Every runtime has its own container, so nothing a site holds is shared with another.
/// </summary>
public static class SiteServices
{
    private const string EdgeApiHttpClient = "edge-api";

    public static IServiceCollection AddSiteServices(this IServiceCollection services, IConfiguration configuration, string environmentName, string sqliteConnectionString)
    {
        services
            .AddOptions<EdgeAgentOptions>()
            .Bind(configuration.GetSection("EdgeAgent"))
            .ValidateDataAnnotations()
            .ValidateOnStart();
        // https and MQTT over TLS outside Development
        services.AddSingleton<IValidateOptions<EdgeAgentOptions>>(new EdgeAgentOptionsValidator(environmentName));

        services.AddDbContextFactory<EdgeDbContext>(options => options.UseSqlite(sqliteConnectionString));

        services.AddSingleton<IMqttPublisher>(sp =>
        {
            var opts = sp.GetRequiredService<IOptions<EdgeAgentOptions>>().Value;
            return new MqttPublisher(opts.Mqtt, opts.SiteId, sp.GetRequiredService<ILogger<MqttPublisher>>(), opts.AgentKey, opts.BrokerUsername);
        });

        // ─── Contract v2 (ADR-002): configuration, acquisition, buffer and publishing ─
        // The configuration source is one instance: the connection manager listens to its changes, the command
        // subscriber triggers its reloads, and it runs its own fallback poll as a hosted service.
        services
            .AddHttpClient(
                EdgeApiHttpClient,
                (sp, client) =>
                {
                    var opts = sp.GetRequiredService<IOptions<EdgeAgentOptions>>().Value;
                    client.BaseAddress = new Uri(opts.ApiBaseUrl.TrimEnd('/') + "/");
                }
            )
            // The client lives as long as the runtime; the handler recycles connections and checks a private CA
            .ConfigurePrimaryHttpMessageHandler(sp =>
                EdgeApiHttpHandler.Create(sp.GetRequiredService<IOptions<EdgeAgentOptions>>().Value, sp.GetRequiredService<ILoggerFactory>().CreateLogger("Votech.Edge.Api")))
            .SetHandlerLifetime(Timeout.InfiniteTimeSpan);

        services.AddSingleton(sp =>
            ActivatorUtilities.CreateInstance<EdgeConfigurationSource>(sp, sp.GetRequiredService<IHttpClientFactory>().CreateClient(EdgeApiHttpClient))
        );
        services.AddSingleton<IEdgeConfigurationSource>(sp => sp.GetRequiredService<EdgeConfigurationSource>());

        services.AddSingleton<ISignalBuffer, SqliteSignalBuffer>();
        services.AddSingleton<ISignalSink, SignalSampleSink>();
        services.AddSingleton<IConnectionPollerFactory, ConnectionPollerFactory>();
        // Consumers read IConnectionManager.Connections when they need it: the pollers change with the configuration.
        services.AddSingleton<IConnectionManager, ConnectionManager>();
        services.AddSingleton<IProbeHandler, EndpointProbeService>();
        services.AddSingleton<SignalBatchPublisher>();

        // ─── Hosted services (started in this order) ─────────────────────────────
        services.AddHostedService(sp => sp.GetRequiredService<EdgeConfigurationSource>());
        services.AddHostedService<Worker>();
        services.AddHostedService<V2CommandSubscriber>();
        services.AddHostedService<AgentStatusReporter>();
        services.AddHostedService<StorageMaintenanceService>();
        return services;
    }
}
