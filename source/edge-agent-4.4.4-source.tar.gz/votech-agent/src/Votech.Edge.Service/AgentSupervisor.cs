using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Ingestion.Services;
using Microsoft.Extensions.Options;

namespace Votech.Edge.Service;

/// <summary>
/// Runs the sites assigned to this agent (agent 3.0): asks the backend for them at start and every
/// <see cref="EdgeContractConstants.FallbackPollSeconds"/> seconds (<see cref="AgentAssignmentSource"/>), starts a
/// <see cref="SiteRuntime"/> for each new site, stops the runtime of a site that is no longer assigned, and starts a
/// site that stopped by itself again after 1 minute, doubling to 30 minutes while it keeps stopping. One agent can so run
/// one site, the sites of one organisation, or (a platform agent) sites of many organisations, without a restart when
/// the assignment changes. A refusal never stops the process: the <see cref="KeyRefusalPolicy"/> keeps the sites
/// running and asks less often, and stops every site only when the key itself keeps being refused (X-01).
/// </summary>
public sealed class AgentSupervisor(
    AgentAssignmentSource assignments,
    IConfiguration configuration,
    IHostEnvironment environment,
    IOptions<EdgeAgentOptions> options,
    ILogger<AgentSupervisor> logger,
    TimeProvider? timeProvider = null
) : BackgroundService
{
    private readonly IConfiguration _configuration = configuration;
    private readonly IHostEnvironment _environment = environment;
    private readonly ILogger<AgentSupervisor> _logger = logger;
    private readonly Dictionary<Guid, Supervision> _sites = [];
    private readonly KeyRefusalPolicy _refusals = new();
    private readonly TimeProvider _time = timeProvider ?? TimeProvider.System;
    private string _lastReason = string.Empty;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var agent = options.Value;
        _logger.LogInformation(
            "[AGENT] Edge agent {Version} with key {KeyPrefix}{TenantGuard}: asking {ApiBaseUrl} which sites it serves.",
            AgentCapabilities.AgentVersion,
            EdgeAgentKey.Prefix(agent.AgentKey),
            string.IsNullOrEmpty(agent.TenantId) ? string.Empty : $" of organisation {agent.TenantId}",
            agent.ApiBaseUrl
        );

        try
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                var result = await assignments.FetchAsync(stoppingToken);
                var decision = _refusals.Next(result, _time.GetUtcNow());
                Report(result, decision);

                if (decision.Action == KeyRefusalPolicy.Action.StopAll)
                {
                    await StopAllAsync();
                }
                else if (decision.Action == KeyRefusalPolicy.Action.Apply)
                {
                    await ApplyAsync(result.Assignment!.Name, result.Sites, stoppingToken);
                }

                await Task.Delay(decision.Delay, _time, stoppingToken);
            }
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            // Shutdown
        }
        finally
        {
            await Task.WhenAll(_sites.Values.Select(s => s.StopAsync()));
            _sites.Clear();
            _logger.LogInformation("[AGENT] Every site stopped.");
        }
    }

    /// <summary>Logs what the answer means for the sites, once per distinct message.</summary>
    private void Report(AgentAssignmentSource.Result result, KeyRefusalPolicy.Decision decision)
    {
        var next = decision.Delay.TotalMinutes >= 1 ? $"{decision.Delay.TotalMinutes:F0} min" : $"{decision.Delay.TotalSeconds:F0} s";
        var running = _sites.Count == 0 ? "No site runs" : $"{_sites.Count} site(s) keep running";
        switch (result.Outcome)
        {
            case AgentAssignmentSource.Outcome.Refused when decision.Action == KeyRefusalPolicy.Action.StopAll:
                LogOnce(
                    LogLevel.Critical,
                    $"[AUTH-FATAL] {result.Reason}. The key was refused for at least {AgentConstants.KeyRefusedStopMinutes} min, so every site stops. The agent keeps asking every {next} and starts the sites again once the key is accepted. Enter the current key from the Site connectors page, then run \"docker compose up -d\".");
                break;
            case AgentAssignmentSource.Outcome.Refused:
                LogOnce(
                    LogLevel.Warning,
                    $"[AUTH] {result.Reason}. {(_refusals.Stopped ? "The sites stay stopped" : running)}; asking again in {next}.{(result.KeyRefused && !_refusals.Stopped ? $" The sites stop only if the key keeps being refused for {AgentConstants.KeyRefusedStopMinutes} min." : string.Empty)}");
                break;
            case AgentAssignmentSource.Outcome.Unavailable:
                LogOnce(LogLevel.Warning, $"[AGENT] The agent's sites are not known yet: {result.Reason}. {running}; asking again in {next}.");
                break;
            case AgentAssignmentSource.Outcome.Cached:
                LogOnce(LogLevel.Warning, $"[AGENT] {result.Reason}.{(_refusals.Stopped ? " The sites stay stopped until the backend accepts the key." : string.Empty)}");
                break;
            default:
                if (_lastReason.Length > 0)
                {
                    _logger.LogInformation("[AGENT] The backend answers again.");
                }

                _lastReason = string.Empty;
                break;
        }
    }

    private async Task StopAllAsync()
    {
        if (_sites.Count == 0)
        {
            return;
        }

        await Task.WhenAll(_sites.Values.Select(s => s.StopAsync()));
        _sites.Clear();
        _logger.LogWarning("[AGENT] Every site stopped; the agent keeps asking the backend.");
    }

    /// <summary>The sites to start and to stop for an assignment, given those running.</summary>
    public static (IReadOnlyList<AgentSite> Start, IReadOnlyList<Guid> Stop) Diff(IReadOnlyCollection<Guid> running, IReadOnlyList<AgentSite> assigned)
    {
        var wanted = assigned.Select(s => s.SiteId).ToHashSet();
        return (assigned.Where(s => !running.Contains(s.SiteId)).ToList(), running.Where(id => !wanted.Contains(id)).ToList());
    }

    private async Task ApplyAsync(string agentName, IReadOnlyList<AgentSite> assigned, CancellationToken ct)
    {
        var (start, stop) = Diff(_sites.Keys, assigned);
        if (start.Count == 0 && stop.Count == 0)
        {
            return;
        }

        _logger.LogInformation(
            "[AGENT] Agent '{AgentName}' serves {Count} site(s) of {Organisations} organisation(s): {Sites}.",
            agentName,
            assigned.Count,
            assigned.Select(s => s.TenantId).Distinct().Count(),
            assigned.Count == 0 ? "none (assign sites on the Site connectors page)" : string.Join(", ", assigned.Select(s => $"{s.Label} ({s.TenantName})"))
        );

        foreach (var siteId in stop)
        {
            _logger.LogInformation("[AGENT] Site {Site} is no longer assigned to this agent; stopping it.", _sites[siteId].Site.Label);
            await _sites[siteId].StopAsync();
            _sites.Remove(siteId);
        }

        foreach (var site in start)
        {
            _sites[site.SiteId] = Supervision.Start(site, this, ct);
        }
    }

    private void LogOnce(LogLevel level, string message)
    {
        if (message != _lastReason)
        {
            _lastReason = message;
            _logger.Log(level, "{Message}", message);
        }
    }

    /// <summary>One site: its runtime, started again with a growing delay while it keeps stopping by itself.</summary>
    private sealed class Supervision
    {
        private readonly CancellationTokenSource _stop;
        private Task _loop = Task.CompletedTask;

        private Supervision(AgentSite site, CancellationToken agentStopping)
        {
            Site = site;
            _stop = CancellationTokenSource.CreateLinkedTokenSource(agentStopping);
        }

        public AgentSite Site { get; }

        public static Supervision Start(AgentSite site, AgentSupervisor supervisor, CancellationToken agentStopping)
        {
            var supervision = new Supervision(site, agentStopping);
            supervision._loop = Task.Run(() => supervision.RunAsync(supervisor), CancellationToken.None);
            return supervision;
        }

        public async Task StopAsync()
        {
            await _stop.CancelAsync();
            await _loop;
            _stop.Dispose();
        }

        private async Task RunAsync(AgentSupervisor supervisor)
        {
            var ct = _stop.Token;
            var delay = TimeSpan.FromSeconds(AgentConstants.SiteRestartMinDelaySec);
            while (!ct.IsCancellationRequested)
            {
                var startedAt = supervisor._time.GetUtcNow();
                try
                {
                    await using var runtime = await SiteRuntime.StartAsync(Site, supervisor._configuration, supervisor._environment, ct);
                    supervisor._logger.LogInformation(
                        "[AGENT] Site {Site} ({SiteId}) of {Organisation} started.",
                        Site.Label,
                        Site.SiteId,
                        string.IsNullOrEmpty(Site.TenantName) ? Site.TenantId.ToString() : Site.TenantName
                    );
                    await runtime.WaitForStopAsync(ct);
                }
                catch (OperationCanceledException) when (ct.IsCancellationRequested)
                {
                    break;
                }
                catch (Exception ex)
                {
                    supervisor._logger.LogError(ex, "[AGENT] Site {Site} ({SiteId}) failed: {Reason}", Site.Label, Site.SiteId, ex.Message);
                }

                if (ct.IsCancellationRequested)
                {
                    break;
                }

                if (supervisor._time.GetUtcNow() - startedAt >= TimeSpan.FromMinutes(AgentConstants.SiteStableRunMinutes))
                {
                    delay = TimeSpan.FromSeconds(AgentConstants.SiteRestartMinDelaySec);
                }

                supervisor._logger.LogWarning(
                    "[AGENT] Site {Site} stopped; it starts again in {Minutes:F0} min. The agent's other sites keep running.",
                    Site.Label,
                    delay.TotalMinutes
                );
                try
                {
                    await Task.Delay(delay, supervisor._time, ct);
                }
                catch (OperationCanceledException)
                {
                    break;
                }

                delay = TimeSpan.FromSeconds(Math.Min(delay.TotalSeconds * 2, AgentConstants.SiteRestartMaxDelaySec));
            }
        }
    }
}
