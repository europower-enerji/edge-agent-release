using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Storage;
using Microsoft.EntityFrameworkCore;
using Serilog;
using Serilog.Extensions.Logging;

namespace Votech.Edge.Service;

/// <summary>
/// One assigned site, run as its own host (<see cref="SiteServices"/>): its configuration, pollers, SQLite buffer
/// (<see cref="SiteDatabase"/>, locked against a second agent), MQTT sessions with their own Last Will, and log lines
/// tagged with the site. A site that stops (a refused key, an expired offline window, a crash) stops alone.
/// </summary>
public sealed class SiteRuntime : IAsyncDisposable
{
    private readonly IHost _host;
    private readonly AgentInstanceLock? _lock;

    private SiteRuntime(AgentSite site, IHost host, AgentInstanceLock? instanceLock)
    {
        Site = site;
        _host = host;
        _lock = instanceLock;
    }

    public AgentSite Site { get; }

    public static async Task<SiteRuntime> StartAsync(AgentSite site, IConfiguration agentConfiguration, IHostEnvironment environment, CancellationToken ct)
    {
        var siteLog = Log.Logger.ForContext("Site", site.Label);
        var logger = new SerilogLoggerFactory(siteLog).CreateLogger<SiteRuntime>();
        var connectionString = SiteDatabase.ConnectionStringFor(
            site,
            agentConfiguration["EdgeAgent:Storage:SqliteConnectionString"] ?? "Data Source=edge.db",
            agentConfiguration["EdgeAgent:Storage:DbPassword"],
            logger
        );
        var agentKey = agentConfiguration["EdgeAgent:AgentKey"] ?? agentConfiguration["EdgeAgent:ApiKey"];

        var builder = Host.CreateEmptyApplicationBuilder(
            new HostApplicationBuilderSettings
            {
                EnvironmentName = environment.EnvironmentName,
                ApplicationName = environment.ApplicationName,
                ContentRootPath = environment.ContentRootPath,
            }
        );
        builder.Configuration.AddConfiguration(agentConfiguration);
        builder.Configuration.AddInMemoryCollection(
            new Dictionary<string, string?>
            {
                ["EdgeAgent:SiteId"] = site.SiteId.ToString(),
                ["EdgeAgent:SiteTenantId"] = site.TenantId.ToString(),
                ["EdgeAgent:Storage:SqliteConnectionString"] = connectionString,
                // One broker session per site and kind, under the client ids the broker accepts for this key only
                // (X-03): every client id is unique, every site has its own Last Will
                ["EdgeAgent:Mqtt:ClientId"] = EdgeAgentKey.ClientIdFor(agentKey, site.SiteId),
            }
        );
        builder.Services.AddSerilog(siteLog, dispose: false);
        builder.Services.AddSiteServices(builder.Configuration, environment.EnvironmentName, connectionString);
        var host = builder.Build();

        AgentInstanceLock? instanceLock = null;
        try
        {
            // A second agent on this site would connect to the same RTUs, and most RTUs serve one master.
            instanceLock = AgentInstanceLock.Acquire(SiteDatabase.DataSourceOf(connectionString), TimeSpan.FromSeconds(AgentConstants.SiteLockWaitSec));
            await SiteDatabase.PrepareAsync(
                host.Services.GetRequiredService<IDbContextFactory<EdgeDbContext>>(),
                AgentCapabilities.AgentRelease,
                logger,
                ct
            );
            await host.StartAsync(ct);
            return new SiteRuntime(site, host, instanceLock);
        }
        catch
        {
            host.Dispose();
            instanceLock?.Dispose();
            throw;
        }
    }

    /// <summary>Completes when the site stops by itself (its host stopping) or <paramref name="ct"/> is cancelled.</summary>
    public async Task WaitForStopAsync(CancellationToken ct)
    {
        var stopping = _host.Services.GetRequiredService<IHostApplicationLifetime>().ApplicationStopping;
        using var either = CancellationTokenSource.CreateLinkedTokenSource(ct, stopping);
        try
        {
            await Task.Delay(Timeout.Infinite, either.Token);
        }
        catch (OperationCanceledException)
        {
            // Stopping
        }
    }

    /// <summary>True when the site's host stopped by itself rather than being stopped by the agent.</summary>
    public bool StoppedBySite => _host.Services.GetRequiredService<IHostApplicationLifetime>().ApplicationStopping.IsCancellationRequested;

    /// <summary>Stops the pollers (signals go Offline), stores and sends what the site holds, and releases its database.</summary>
    public async ValueTask DisposeAsync()
    {
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(AgentConstants.SiteStopTimeoutSec));
        try
        {
            await _host.StopAsync(timeout.Token);
        }
        finally
        {
            _host.Dispose();
            _lock?.Dispose();
        }
    }
}
