using Votech.Edge.Core.Configuration;

namespace Votech.Edge.Service;

/// <summary>
/// The connection handler of the API clients (discovery and each site's configuration). It recycles pooled
/// connections, so DNS changes of the API are seen. With <see cref="EdgeAgentOptions.ApiCaCertificatePath"/> it trusts
/// only that private CA and only a certificate naming the API host (<see cref="PrivateCaTrust"/>, A-02).
/// </summary>
public static class EdgeApiHttpHandler
{
    public static SocketsHttpHandler Create(EdgeAgentOptions options, ILogger logger)
    {
        var handler = new SocketsHttpHandler { PooledConnectionLifetime = TimeSpan.FromMinutes(5) };
        if (string.IsNullOrEmpty(options.ApiCaCertificatePath))
        {
            return handler;
        }

        var roots = PrivateCaTrust.Load(options.ApiCaCertificatePath);
        handler.SslOptions.RemoteCertificateValidationCallback = (_, certificate, chain, errors) =>
        {
            if (PrivateCaTrust.Validate(certificate, chain, errors, roots, out var reason))
            {
                return true;
            }

            logger.LogError(
                "[API-TLS] Refused the certificate of {ApiBaseUrl}: {Reason}. Only the CA in {Path} is trusted.",
                options.ApiBaseUrl,
                reason,
                options.ApiCaCertificatePath
            );
            return false;
        };
        return handler;
    }
}
