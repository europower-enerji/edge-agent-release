using System.Collections.Concurrent;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Models;
using lib60870;
using lib60870.CS101;
using lib60870.CS104;
using Microsoft.Extensions.Logging;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Iec104;

/// <summary>
/// Reads one IEC 104 connection of the v2 configuration (ADR-002 2.2):
/// <list type="bullet">
/// <item>The link timers and windows (t0-t3, k, w) and the originator address come from the connection's settings;
/// 0 means the standard default.</item>
/// <item>After STARTDT, and every <c>gi_interval_s</c>, a general interrogation goes to each station's common
/// address. The station clocks are set only as the connection's <c>clock_sync</c> says (<see cref="ClockSyncPlan"/>):
/// setting a clock writes to a device whose clock other masters may share. Every clock set is logged.</item>
/// <item>An attempt waits for STARTDT until <see cref="Iec104AgentOptions.StartDtTimeoutSec"/> (default t3 + t1 + 2 s,
/// so the library's link test runs first, as in agent 1.x); the error says whether the station answered that test.</item>
/// <item>Values are routed by (common address, IOA) to signal ids and sent without a deadband. An IOA may be written in
/// decimal or as octets (<see cref="Iec104Address"/>).</item>
/// <item>A station whose common address the RTU refuses (negative GI confirmation) or that stays silent is reported as
/// <c>CONFIGURATION_MISMATCH</c> naming the addresses the RTU does send, also when the RTU is its own only station.
/// Points that never arrive while their IOA with reversed octets does are named in the log.</item>
/// <item>A device time older than <see cref="Iec104AgentOptions.MaxDeviceTimeAgeHours"/> (24 h) or more than 5 minutes
/// ahead is replaced by the time of receipt. The offset of the connection's clock is measured (<see cref="DeviceClock"/>)
/// and logged every hour, and once per link when it is beyond <see cref="Iec104AgentOptions.ClockSkewToleranceSec"/>;
/// with <see cref="Iec104AgentOptions.ClockPolicy"/> Enforce it decides whether the device times are used.</item>
/// <item>The log tells what happens: each interrogation with its counts, a traffic summary every
/// <see cref="Iec104AgentOptions.StatsIntervalMinutes"/>, and with <see cref="Iec104AgentOptions.LogRawFrames"/> every
/// frame decoded at Debug (the hex at Verbose); nothing is decoded while Debug is off.</item>
/// <item>When the link drops, or the poller stops, every signal read so far gets one Offline sample with its last
/// value, so live screens never show a frozen value as live. It is stamped on the clock the value came from
/// (<see cref="OfflineTime"/>), so the next value of an RTU whose clock is behind is not older than the Offline
/// sample.</item>
/// <item>Every failed attempt closes its socket before the next one, which waits 5 s doubling to 60 s with ±20 % jitter;
/// only a link that stayed up a minute starts the delay over (an RTU held by another master is not hammered).</item>
/// </list>
/// </summary>
public sealed class Iec104ConnectionPoller : IConnectionPoller
{
    private static readonly TimeSpan StableLink = TimeSpan.FromMinutes(1);

    /// <summary>Unknown (CA, IOA) pairs remembered per link for the reversed-octet check.</summary>
    private const int MaxTrackedUnknown = 4_096;

    /// <summary>Examples named in one log line.</summary>
    private const int MaxExamples = 5;

    private readonly V2.Iec104Settings _settings;
    private readonly ISignalSink _sink;
    private readonly ILogger _logger;
    private readonly TimeProvider _time;
    private readonly string _code;
    private readonly ConcurrentDictionary<Guid, LastSample> _lastValues = new();
    private readonly ConcurrentDictionary<int, DateTime> _lastSeenByCa = new();
    private readonly ConcurrentDictionary<int, byte> _reportedUnknownCas = new();

    // What the RTU did since the link came up (cleared on STARTDT).
    private readonly ConcurrentDictionary<int, CauseOfTransmission> _rejectedCas = new();
    private readonly ConcurrentDictionary<(int Ca, int Ioa), byte> _unknownIoas = new();
    private readonly ConcurrentDictionary<Guid, byte> _seenSinceLinkUp = new();
    private readonly ConcurrentDictionary<int, GiProgress> _interrogations = new();
    // Clock syncs sent and not yet confirmed or refused, by common address: the time and what was sent.
    private readonly ConcurrentDictionary<int, (DateTime SentAt, string Set)> _pendingClockSyncs = new();
    private readonly ConcurrentDictionary<(int Ca, int Ioa), byte> _reportedReversed = new();
    private readonly DeviceClock _clock = new();
    private readonly TrafficStats _stats = new();
    private readonly List<int> _unknownBuffer = [];
    private readonly Iec104SignalMapper.TimePolicy _timePolicy;
    private readonly (bool OnConnect, TimeSpan? Every) _clockSync;
    private volatile bool _clockReported;
    private volatile bool _clockSyncRefused;
    private ApplicationLayerParameters _alp = new();
    private Iec104PointMap _map;
    private Connection? _connection;
    private CancellationTokenSource? _session;
    private volatile bool _linkUp;
    private DateTime? _linkUpAt;
    private DateTime? _lastSeenAt;
    private string? _lastError;
    private string _reasonCode = DeviceDiagnosticReason.Connecting;
    private DateTime? _tcpOpenedAt;
    private int _t1Seconds = Iec104Constants.T1TimeoutSec;
    private int _t3Seconds = Iec104Constants.T3TimeoutSec;
    private int _startDtTimeoutSeconds;
    private int _attempt;
    private readonly Iec104AgentOptions _agentOptions;

    // What the station sent during the current attempt, seen by the library's receive thread.
    private volatile bool _testFrAnswered;
    private int _framesReceived;

    public Iec104ConnectionPoller(
        V2.Connection connection,
        ISignalSink sink,
        ILogger logger,
        TimeProvider? timeProvider = null,
        Iec104AgentOptions? agentOptions = null
    )
    {
        EndpointId = EdgeIds.ToGuid(connection.EndpointId);
        _settings = connection.Iec104 ?? throw new ArgumentException("The connection has no IEC 104 settings.", nameof(connection));
        _code = connection.Code;
        _sink = sink;
        _logger = logger;
        _time = timeProvider ?? TimeProvider.System;
        _agentOptions = agentOptions ?? new Iec104AgentOptions();
        var zoneKnown = StationTime.TryResolve(_settings.TimeZone, out var zone);
        _timePolicy = Iec104SignalMapper.TimePolicy.From(_agentOptions) with { Zone = zone };
        _clockSync = ClockSyncPlan(_settings, zoneKnown);
        _map = new Iec104PointMap(connection, logger);
        WarnWhenEmpty(_map);
        if (!zoneKnown)
        {
            _logger.LogWarning(
                "[IEC104-CLOCK] Connection {Code}: the station time zone {TimeZone} is not known on this machine. Its times are read as UTC and its clock is not set.",
                _code,
                _settings.TimeZone
            );
        }
        else if (zone is not null)
        {
            _logger.LogInformation(
                "[IEC104-CLOCK] Connection {Code}: the station clock runs in {TimeZone}; its times are read {Set}in that zone.",
                _code,
                zone.Id,
                _clockSync.OnConnect || _clockSync.Every.HasValue ? "and its clock is set " : string.Empty
            );
        }
    }

    /// <summary>
    /// When the station clocks are set (<c>clock_sync</c>): after each STARTDT confirmation, and how often.
    /// <list type="bullet">
    /// <item>OFF: never. ON_CONNECT: after STARTDT. PERIODIC: after STARTDT and every <c>clock_sync_interval_s</c>
    /// (0 = 3600 s).</item>
    /// <item>UNSPECIFIED (a backend before shared 2.2.0): as agent 3.0, every <c>clock_sync_interval_s</c> when above 0,
    /// not after connect.</item>
    /// <item>A station clock runs in its <c>time_zone</c> and is set in it (<see cref="StationTime"/>). When that zone
    /// is not known on this machine (<paramref name="zoneKnown"/> false), the clock is never set: UTC would be wrong.</item>
    /// </list>
    /// </summary>
    internal static (bool OnConnect, TimeSpan? Every) ClockSyncPlan(V2.Iec104Settings settings, bool zoneKnown = true)
    {
        if (!zoneKnown)
        {
            return (false, null);
        }

        var interval = settings.ClockSyncIntervalS > 0 ? TimeSpan.FromSeconds(settings.ClockSyncIntervalS) : (TimeSpan?)null;
        return settings.ClockSync switch
        {
            V2.ClockSyncMode.OnConnect => (true, null),
            V2.ClockSyncMode.Periodic => (true, interval ?? TimeSpan.FromSeconds(Iec104Constants.DefaultClockSyncIntervalSec)),
            V2.ClockSyncMode.Unspecified => (false, interval),
            _ => (false, null),
        };
    }

    public Guid EndpointId { get; }

    public V2.Protocol Protocol => V2.Protocol.Iec104;

    public bool IsConnected => _linkUp;

    public string Host => _settings.Host;

    public int Port => _settings.Port > 0 ? (int)_settings.Port : Iec104Constants.DefaultPort;

    private TimeSpan GiInterval => TimeSpan.FromSeconds(_settings.GiIntervalS > 0 ? _settings.GiIntervalS : Iec104Constants.DefaultGiIntervalSec);

    public IReadOnlyList<EndpointHealth> Health
    {
        get
        {
            var map = Volatile.Read(ref _map);
            var now = _time.GetUtcNow().UtcDateTime;

            // The RTU itself is a station when its own points (or nothing behind it) are read: its health is then the
            // station's, so an RTU answering on the wrong common address does not show as healthy.
            var root = map.Stations.Where(s => s.EndpointId == EndpointId).Select(s => (int?)s.Ca).FirstOrDefault();
            var health = new List<EndpointHealth>
            {
                _linkUp && root is { } rootCa
                    ? StationHealth(EndpointId, rootCa, _lastSeenAt, now)
                    : new(EndpointId, _linkUp, _lastSeenAt, _linkUp ? DeviceDiagnosticReason.ConnectedHealthy : _reasonCode, _linkUp ? null : _lastError),
            };
            foreach (var (endpointId, ca) in map.Stations.Where(s => s.EndpointId != EndpointId))
            {
                DateTime? seen = _lastSeenByCa.TryGetValue(ca, out var at) ? at : null;
                health.Add(StationHealth(endpointId, ca, seen, now));
            }

            return health;
        }
    }

    /// <summary>
    /// A station is connected while the link is up and it has answered since, or while it still has one interrogation
    /// period (plus t1) to answer. One whose common address the RTU refused is not, at once.
    /// </summary>
    private EndpointHealth StationHealth(Guid endpointId, int ca, DateTime? seen, DateTime now)
    {
        if (!_linkUp)
        {
            return new(endpointId, false, seen, _reasonCode, _lastError);
        }

        if (_rejectedCas.TryGetValue(ca, out var cause))
        {
            return new(
                endpointId,
                false,
                seen,
                DeviceDiagnosticReason.ConfigurationMismatch,
                $"The RTU refused the general interrogation of common address {ca}: {Iec104FrameText.Cause(cause)}.{ForeignAddressHint()}"
            );
        }

        var answered = _lastSeenByCa.TryGetValue(ca, out var at) && at >= _linkUpAt;
        var grace = _linkUpAt.HasValue && now - _linkUpAt.Value < GiInterval + TimeSpan.FromSeconds(Iec104Constants.T1TimeoutSec);
        return answered || grace
            ? new(endpointId, true, seen, DeviceDiagnosticReason.ConnectedHealthy, null)
            : new(endpointId, false, seen, DeviceDiagnosticReason.ConfigurationMismatch, $"No data from common address {ca} since the link came up.{ForeignAddressHint()}");
    }

    /// <summary>" The RTU sends common address 7: set it as the station's common address.", or nothing.</summary>
    private string ForeignAddressHint()
    {
        var configured = Volatile.Read(ref _map).CommonAddresses;
        var foreign = _lastSeenByCa.Where(e => e.Value >= _linkUpAt && !configured.Contains(e.Key)).Select(e => e.Key).Order().ToList();
        return foreign.Count switch
        {
            0 => string.Empty,
            1 => $" The RTU sends common address {foreign[0]}: set it as the station's common address.",
            _ => $" The RTU sends common addresses {string.Join(", ", foreign)}.",
        };
    }

    private void WarnWhenEmpty(Iec104PointMap map)
    {
        if (map.Count == 0)
        {
            _logger.LogWarning(
                "[IEC104-CONFIG] Connection {Code} has no point with an IEC 104 address: nothing it sends is read. Give its signals their IOAs (signal address or IO list import).",
                _code
            );
        }
    }

    public void UpdatePoints(V2.Connection connection)
    {
        var map = new Iec104PointMap(connection, _logger);
        var added = map.CommonAddresses.Except(Volatile.Read(ref _map).CommonAddresses).ToList();
        Volatile.Write(ref _map, map);
        var kept = map.Points.Select(p => p.SignalId).ToHashSet();
        foreach (var signalId in _lastValues.Keys.Where(id => !kept.Contains(id)))
        {
            _lastValues.TryRemove(signalId, out _);
        }

        // Judge the new map afresh: warnings about unknown addresses and refused common addresses start over.
        _reportedUnknownCas.Clear();
        _reportedReversed.Clear();
        foreach (var ca in _rejectedCas.Keys.Where(ca => !map.CommonAddresses.Contains(ca) || added.Contains(ca)))
        {
            _rejectedCas.TryRemove(ca, out _);
        }

        WarnWhenEmpty(map);

        _logger.LogInformation(
            "[IEC104-CONFIG] Connection {Code}: point map updated on the open link ({Points} points, {Stations} common addresses).",
            _code,
            map.Count,
            map.CommonAddresses.Count
        );

        if (_linkUp)
        {
            foreach (var ca in added)
            {
                SendInterrogation(ca);
            }
        }
    }

    public async Task RunAsync(CancellationToken ct)
    {
        int? delayMs = null;
        while (!ct.IsCancellationRequested)
        {
            using var session = CancellationTokenSource.CreateLinkedTokenSource(ct);
            Volatile.Write(ref _session, session);
            TimeSpan? upFor = null;
            try
            {
                _tcpOpenedAt = null;
                Connect();
                await RunTimersAsync(session.Token);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                break;
            }
            catch (OperationCanceledException)
            {
                // The link closed; reconnect below.
            }
            catch (Exception ex)
            {
                var detail = ex.InnerException != null ? $"{ex.Message} ({ex.InnerException.Message})" : ex.Message;
                var unreachable = ex is System.Net.Sockets.SocketException || ex.InnerException is System.Net.Sockets.SocketException
                    || ex.Message.Contains("refused", StringComparison.OrdinalIgnoreCase)
                    || ex.Message.Contains("timed out", StringComparison.OrdinalIgnoreCase)
                    || ex.Message.Contains("connect", StringComparison.OrdinalIgnoreCase);
                _lastError = unreachable && _tcpOpenedAt == null ? $"TCP connection to {Host}:{Port} failed: {detail}" : detail;
                _reasonCode = unreachable ? DeviceDiagnosticReason.UnreachablePhysicalDevice : DeviceDiagnosticReason.ConfigurationMismatch;
            }
            finally
            {
                Volatile.Write(ref _session, null);
                upFor = _linkUp && _linkUpAt.HasValue ? _time.GetUtcNow().UtcDateTime - _linkUpAt.Value : null;
                Close();
                LinkLost();
            }

            if (ct.IsCancellationRequested)
            {
                break;
            }

            delayMs = NextDelayMs(delayMs, upFor);
            var wait = WithJitter(delayMs.Value, Random.Shared.NextDouble());
            _logger.LogWarning(
                "[IEC104-CONN] Connection {Code} ({Host}:{Port}) is down ({ReasonCode}: {Error}). Socket closed; next attempt in {Delay} s.",
                _code,
                Host,
                Port,
                _reasonCode,
                _lastError,
                (int)Math.Round(wait.TotalSeconds)
            );
            await Task.Delay(wait, _time, ct).ConfigureAwait(false);
        }
    }

    /// <summary>
    /// The delay before the next attempt: 5 s after the first failure, then doubled up to 60 s. Only a link that stayed up
    /// a minute starts it over, so a station that confirms STARTDT and drops at once is not retried every 5 s.
    /// </summary>
    internal static int NextDelayMs(int? previousMs, TimeSpan? upFor) =>
        previousMs is not { } previous || upFor >= StableLink
            ? Iec104Constants.DefaultReconnectDelayMs
            : Math.Min(previous * 2, Iec104Constants.MaxReconnectDelayMs);

    /// <summary>±20 % (<paramref name="unit"/> in [0, 1)), so connections that dropped together (a site switch restart) do not reconnect in step.</summary>
    internal static TimeSpan WithJitter(int delayMs, double unit) => TimeSpan.FromMilliseconds(delayMs * (0.8 + 0.4 * unit));

    private void Connect()
    {
        var apci = new APCIParameters
        {
            K = _settings.K > 0 ? (int)_settings.K : Iec104Constants.DefaultK,
            W = _settings.W > 0 ? (int)_settings.W : Iec104Constants.DefaultW,
            T0 = _settings.T0S > 0 ? (int)_settings.T0S : Iec104Constants.T0TimeoutSec,
            T1 = _settings.T1S > 0 ? (int)_settings.T1S : Iec104Constants.T1TimeoutSec,
            T2 = _settings.T2S > 0 ? (int)_settings.T2S : Iec104Constants.T2TimeoutSec,
            T3 = _settings.T3S > 0 ? (int)_settings.T3S : Iec104Constants.T3TimeoutSec,
        };
        var alp = new ApplicationLayerParameters { OA = (int)Math.Min(_settings.OriginatorAddress, byte.MaxValue) };
        _alp = alp;

        _t1Seconds = apci.T1;
        _t3Seconds = apci.T3;
        _startDtTimeoutSeconds = _agentOptions.StartDtTimeoutSec > 0 ? _agentOptions.StartDtTimeoutSec : apci.T3 + apci.T1 + 2;
        _testFrAnswered = false;
        Volatile.Write(ref _framesReceived, 0);
        _attempt++;
        var attempt = _attempt == 1 && _reasonCode == DeviceDiagnosticReason.Connecting ? "first attempt" : $"attempt {_attempt} after {_reasonCode}";

        var connection = new Connection(Host, Port, apci, alp);
        connection.SetConnectTimeout(apci.T0 * 1000);
        connection.SetASDUReceivedHandler(OnAsduReceived, null);
        connection.SetConnectionHandler(OnConnectionEvent, null);
        connection.SetReceivedRawMessageHandler(OnRawReceived, null);
        connection.SetSentRawMessageHandler(OnRawSent, null);

        _connection = connection;

        _logger.LogInformation(
            "[IEC104-CONN] Connecting {Code} to {Host}:{Port} ({Attempt}; k={K}, w={W}, t0-t3={T0}/{T1}/{T2}/{T3} s, STARTDT wait {StartDt} s, common addresses {CommonAddresses})...",
            _code,
            Host,
            Port,
            attempt,
            apci.K,
            apci.W,
            apci.T0,
            apci.T1,
            apci.T2,
            apci.T3,
            _startDtTimeoutSeconds,
            string.Join(", ", Volatile.Read(ref _map).CommonAddresses)
        );
        connection.Connect();
    }

    /// <summary>
    /// Interrogates and synchronises the clock on schedule until the link closes. The library does not time out a
    /// missing STARTDT confirmation: it sends a link test (TESTFR) at t3 and closes when that is not answered within t1,
    /// but keeps a station that answers TESTFR forever. An attempt without STARTDT is therefore ended here, after
    /// the STARTDT wait.
    /// </summary>
    private async Task RunTimersAsync(CancellationToken ct)
    {
        var syncEvery = _clockSync.Every;
        var statsEvery = _agentOptions.StatsIntervalMinutes > 0 ? TimeSpan.FromMinutes(_agentOptions.StatsIntervalMinutes) : (TimeSpan?)null;
        var clockEvery = TimeSpan.FromMinutes(Iec104Constants.ClockLogIntervalMinutes);
        var nextGi = _time.GetUtcNow() + GiInterval;
        var nextSync = syncEvery.HasValue ? _time.GetUtcNow() + syncEvery.Value : DateTimeOffset.MaxValue;
        var nextStats = statsEvery.HasValue ? _time.GetUtcNow() + statsEvery.Value : DateTimeOffset.MaxValue;
        var nextClock = _time.GetUtcNow() + clockEvery;
        var startDtDeadline = _time.GetUtcNow() + TimeSpan.FromSeconds(_startDtTimeoutSeconds);
        _stats.Take();
        while (true)
        {
            var next = nextGi < nextSync ? nextGi : nextSync;
            next = nextStats < next ? nextStats : next;
            next = nextClock < next ? nextClock : next;
            if (!_linkUp && startDtDeadline < next)
            {
                next = startDtDeadline;
            }

            var wait = next - _time.GetUtcNow();
            if (wait > TimeSpan.Zero)
            {
                await Task.Delay(wait, _time, ct).ConfigureAwait(false);
            }

            ct.ThrowIfCancellationRequested();
            var now = _time.GetUtcNow();
            if (!_linkUp && now >= startDtDeadline)
            {
                (_reasonCode, _lastError) = StartDtNotConfirmed(_startDtTimeoutSeconds);
                return;
            }
            // Checked on every timer, so at the latest with the next interrogation or the hourly clock log.
            ReportUnansweredClockSyncs(now.UtcDateTime);
            if (now >= nextGi)
            {
                if (_linkUp)
                {
                    InterrogateAll();
                }

                nextGi = now + GiInterval;
            }

            if (syncEvery.HasValue && now >= nextSync)
            {
                if (_linkUp)
                {
                    SyncClocks("periodic");
                }

                nextSync = now + syncEvery.Value;
            }

            if (statsEvery.HasValue && now >= nextStats)
            {
                if (_linkUp)
                {
                    LogStats(statsEvery.Value);
                }

                nextStats = now + statsEvery.Value;
            }

            if (now >= nextClock)
            {
                if (_linkUp)
                {
                    LogClock(clockEvery);
                }

                nextClock = now + clockEvery;
            }
        }
    }

    private void OnConnectionEvent(object? parameter, ConnectionEvent connectionEvent)
    {
        switch (connectionEvent)
        {
            case ConnectionEvent.STARTDT_CON_RECEIVED:
                // The library can report one confirmation twice; interrogate once per link.
                if (_linkUp)
                {
                    break;
                }

                _rejectedCas.Clear();
                _unknownIoas.Clear();
                _seenSinceLinkUp.Clear();
                _interrogations.Clear();
                _clockReported = false;
                _clock.Take();
                _linkUpAt = _time.GetUtcNow().UtcDateTime;
                _linkUp = true;
                _lastError = null;
                _reasonCode = DeviceDiagnosticReason.ConnectedHealthy;
                _logger.LogInformation(
                    "[IEC104-STARTDT] Connection {Code} ({Host}:{Port}) confirmed STARTDT on attempt {Attempt}. Interrogating common addresses {CommonAddresses}.",
                    _code,
                    Host,
                    Port,
                    _attempt,
                    string.Join(", ", Volatile.Read(ref _map).CommonAddresses)
                );
                _attempt = 0;
                InterrogateAll();
                if (_clockSync.OnConnect)
                {
                    SyncClocks("after STARTDT");
                }

                break;

            case ConnectionEvent.OPENED:
                _tcpOpenedAt = _time.GetUtcNow().UtcDateTime;
                break;

            case ConnectionEvent.CLOSED:
            case ConnectionEvent.CONNECT_FAILED:
                // A close the poller caused itself (stop, reconnect) arrives after the session is gone: keep the reason.
                var session = Volatile.Read(ref _session);
                if (session == null || session.IsCancellationRequested)
                {
                    break;
                }

                (_reasonCode, _lastError) = DiagnoseClose(connectionEvent);
                session.Cancel();
                break;

            case ConnectionEvent.STOPDT_CON_RECEIVED:
                _lastError = $"{Host}:{Port} confirmed STOPDT: the station stopped sending data.";
                _reasonCode = DeviceDiagnosticReason.ConfigurationMismatch;
                Volatile.Read(ref _session)?.Cancel();
                break;
        }
    }

    /// <summary>
    /// Why the link went down, from how far the attempt got: no TCP connection, TCP without a STARTDT confirmation (the
    /// station serves another master, or only configured master addresses), or a link that was up.
    /// </summary>
    private (string ReasonCode, string Error) DiagnoseClose(ConnectionEvent connectionEvent)
    {
        var now = _time.GetUtcNow().UtcDateTime;
        if (_linkUp && _linkUpAt.HasValue)
        {
            return (DeviceDiagnosticReason.UnreachablePhysicalDevice, $"The IEC 104 link to {Host}:{Port} closed after {Describe(now - _linkUpAt.Value)} up.");
        }

        if (_tcpOpenedAt.HasValue && connectionEvent == ConnectionEvent.CLOSED)
        {
            var open = now - _tcpOpenedAt.Value;

            // The library closes by itself when its link test (sent at t3) is not answered within t1.
            if (!_testFrAnswered && open >= TimeSpan.FromSeconds(_t3Seconds + _t1Seconds - 1))
            {
                return StartDtNotConfirmed((int)Math.Round(open.TotalSeconds));
            }

            return (
                DeviceDiagnosticReason.StartDtNotConfirmed,
                $"{Host}:{Port} closed the connection {Describe(open)} after accepting it, without confirming STARTDT. Another master may hold the station's session, or the station only serves configured master addresses."
            );
        }

        return (DeviceDiagnosticReason.UnreachablePhysicalDevice, $"TCP connection to {Host}:{Port} failed.");
    }

    /// <summary>
    /// STARTDT was not confirmed. A station that answers the link test (TESTFR) runs an IEC 104 server that does not
    /// start data transfer for this master; one that answers nothing does not serve IEC 104 to this master at all.
    /// </summary>
    private (string ReasonCode, string Error) StartDtNotConfirmed(int waitedSeconds)
    {
        var frames = Volatile.Read(ref _framesReceived);
        var error = _testFrAnswered
            ? $"{Host}:{Port} accepted the TCP connection and answers the link test (TESTFR), but did not confirm STARTDT within {waitedSeconds} s. Its IEC 104 server runs but does not start data transfer for this master: another master may hold the session, or this host is not an allowed master for this port."
            : $"{Host}:{Port} accepted the TCP connection but answered neither STARTDT nor the link test (TESTFR) within {waitedSeconds} s. Nothing on this port serves IEC 104 to this master: the station may only accept configured master addresses, or hold the session of another master.";
        if (frames > 0 && !_testFrAnswered)
        {
            error += $" It sent {frames} other frame(s); set EdgeAgent:Iec104:LogRawFrames and the Debug log level to see them.";
        }

        return (DeviceDiagnosticReason.StartDtNotConfirmed, error);
    }

    /// <summary>Notes what the station sends before STARTDT and counts the link tests; logs every frame when asked to.</summary>
    private bool OnRawReceived(object? parameter, byte[] message, int messageSize)
    {
        Interlocked.Increment(ref _framesReceived);
        if (messageSize >= 3 && message[0] == 0x68 && message[2] == 0x83)
        {
            _testFrAnswered = true;
            _stats.LinkTestAnswered();
        }

        LogFrame("RX", message, messageSize);
        return true;
    }

    private bool OnRawSent(object? parameter, byte[] message, int messageSize)
    {
        if (messageSize >= 3 && message[0] == 0x68 && message[2] == 0x43)
        {
            _stats.LinkTestSent();
        }

        LogFrame("TX", message, messageSize);
        return true;
    }

    /// <summary>
    /// With <see cref="Iec104AgentOptions.LogRawFrames"/>: the frame decoded at Debug, its bytes at Verbose. Runs on the
    /// library's receive thread, so nothing is decoded unless Debug is on.
    /// </summary>
    private void LogFrame(string direction, byte[] message, int messageSize)
    {
        if (!_agentOptions.LogRawFrames || !_logger.IsEnabled(LogLevel.Debug))
        {
            return;
        }

        _logger.LogDebug(
            "[IEC104-FRAME] {Code} {Direction} {Frame}",
            _code,
            direction,
            Iec104FrameText.Describe(message, messageSize, _alp, Volatile.Read(ref _map))
        );
        if (_logger.IsEnabled(LogLevel.Trace))
        {
            _logger.LogTrace("[IEC104-HEX] {Code} {Direction} {Hex}", _code, direction, Convert.ToHexString(message, 0, messageSize));
        }
    }

    /// <summary>"5.6 years", "3.2 days", "3.0 h", "14 min", "12 s".</summary>
    internal static string Describe(TimeSpan span) =>
        span.TotalDays >= 365 ? $"{span.TotalDays / 365.25:F1} years"
        : span.TotalDays >= 2 ? $"{span.TotalDays:F1} days"
        : span.TotalHours >= 1 ? $"{span.TotalHours:F1} h"
        : span.TotalMinutes >= 1 ? $"{span.TotalMinutes:F0} min"
        : $"{span.TotalSeconds:F0} s";

    private bool OnAsduReceived(object? parameter, ASDU asdu)
    {
        // lib60870's receive thread: map and queue only.
        if (!Iec104SignalMapper.IsMonitoringType(asdu.TypeId))
        {
            OnControlAsdu(asdu);
            return true;
        }

        var now = _time.GetUtcNow().UtcDateTime;
        _lastSeenAt = now;
        _lastSeenByCa[asdu.Ca] = now;
        var map = Volatile.Read(ref _map);
        _unknownBuffer.Clear();
        var readings = Iec104SignalMapper.Map(asdu, map, EndpointId, now, out var unknown, _timePolicy, _unknownBuffer, _clock);
        foreach (var reading in readings)
        {
            _lastValues[reading.SignalId] = new LastSample(reading.Value, reading.Timestamp, reading.DeviceTime);
            _seenSinceLinkUp.TryAdd(reading.SignalId, 0);
            _stats.Updated(reading.SignalId);
            _sink.Write(reading);
        }

        _stats.Count(asdu.Cot, asdu.NumberOfElements, readings.Count, unknown);
        if (asdu.Cot == CauseOfTransmission.INTERROGATED_BY_STATION && _interrogations.TryGetValue(asdu.Ca, out var interrogation))
        {
            interrogation.Add(asdu.NumberOfElements, readings.Count, unknown, unknown > 0 ? _unknownBuffer[0] : null);
        }

        if (unknown > 0)
        {
            _stats.Unknown(asdu.Ca, _unknownBuffer[0]);
            foreach (var ioa in _unknownBuffer)
            {
                if (_unknownIoas.Count >= MaxTrackedUnknown)
                {
                    break;
                }

                _unknownIoas.TryAdd((asdu.Ca, ioa), 0);
            }
        }

        if (unknown > 0 && !map.CommonAddresses.Contains(asdu.Ca) && _reportedUnknownCas.TryAdd(asdu.Ca, 0))
        {
            _logger.LogWarning(
                "[IEC104-CONFIG] Connection {Code} receives common address {CommonAddress}, which is no configured station ({Configured}); its values are not read. If {CommonAddress} is the RTU's address, set it as the station's common address.",
                _code,
                asdu.Ca,
                string.Join(", ", map.CommonAddresses),
                asdu.Ca
            );
        }

        if (!_clockReported)
        {
            ReportClock(now);
        }

        return true;
    }

    /// <summary>Confirmations of the agent's commands: a refused common address, and the progress of each interrogation.</summary>
    private void OnControlAsdu(ASDU asdu)
    {
        if (asdu.TypeId == TypeID.C_CS_NA_1)
        {
            ClockSyncAnswered(asdu);
            return;
        }

        if (asdu.TypeId != TypeID.C_IC_NA_1)
        {
            if (asdu.IsNegative)
            {
                _logger.LogWarning(
                    "[IEC104-RX] Connection {Code}: the RTU refused {TypeId} for common address {CommonAddress}: {Cause}.",
                    _code,
                    asdu.TypeId,
                    asdu.Ca,
                    Iec104FrameText.Cause(asdu.Cot)
                );
            }

            return;
        }

        if (asdu.IsNegative)
        {
            _rejectedCas[asdu.Ca] = asdu.Cot;
            _interrogations.TryRemove(asdu.Ca, out _);
            _logger.LogWarning(
                "[IEC104-CA] Connection {Code}: the RTU refused the general interrogation of common address {CommonAddress}: {Cause}.{Hint}",
                _code,
                asdu.Ca,
                Iec104FrameText.Cause(asdu.Cot),
                ForeignAddressHint()
            );
            return;
        }

        if (asdu.Cot == CauseOfTransmission.ACTIVATION_CON)
        {
            _rejectedCas.TryRemove(asdu.Ca, out _);
            _logger.LogDebug("[IEC104-GI] Connection {Code}: common address {CommonAddress} confirmed the general interrogation.", _code, asdu.Ca);
        }
        else if (asdu.Cot == CauseOfTransmission.ACTIVATION_TERMINATION && _interrogations.TryRemove(asdu.Ca, out var interrogation))
        {
            InterrogationDone(asdu.Ca, interrogation);
        }
    }

    /// <summary>
    /// Logs what an interrogation returned, names the configured points that did not answer, and those whose IOA arrives
    /// with its octets reversed (a point list written low.mid.high).
    /// </summary>
    private void InterrogationDone(int ca, GiProgress interrogation)
    {
        var now = _time.GetUtcNow().UtcDateTime;
        var missing = new List<string>();
        var reversed = new List<string>();
        var missingCount = 0;
        foreach (var (key, point) in Volatile.Read(ref _map).Entries)
        {
            if (key.Ca != ca || _seenSinceLinkUp.ContainsKey(point.SignalId))
            {
                continue;
            }

            missingCount++;
            if (missing.Count < MaxExamples)
            {
                missing.Add($"{point.Code} {Iec104Address.Describe(key.Ioa)}");
            }

            var swapped = Iec104Address.Reverse(key.Ioa);
            if (swapped != key.Ioa && _unknownIoas.ContainsKey((ca, swapped)) && _reportedReversed.TryAdd(key, 0))
            {
                reversed.Add($"{point.Code} {Iec104Address.Describe(key.Ioa)} arrives as {Iec104Address.Describe(swapped)}");
            }
        }

        _logger.LogInformation(
            "[IEC104-GI] Connection {Code}: general interrogation of common address {CommonAddress} done in {Seconds:F1} s: {Objects} objects, {Mapped} read, {Unknown} not configured{UnknownExample}; {Missing} configured point(s) did not answer{MissingExamples}.",
            _code,
            ca,
            (now - interrogation.SentAt).TotalSeconds,
            interrogation.Objects,
            interrogation.Mapped,
            interrogation.Unknown,
            interrogation.FirstUnknown is { } ioa ? $" (e.g. {Iec104Address.Describe(ioa)})" : string.Empty,
            missingCount,
            missing.Count > 0 ? $" (e.g. {string.Join(", ", missing)})" : string.Empty
        );

        if (reversed.Count > 0)
        {
            _logger.LogWarning(
                "[IEC104-CONFIG] Connection {Code}: {Count} point(s) of common address {CommonAddress} never arrive, but the IOA with their octets reversed does: {Examples}. The point list may write the octets in the other order (the grammar reads high.mid.low).",
                _code,
                reversed.Count,
                ca,
                string.Join("; ", reversed.Take(MaxExamples))
            );
        }
    }

    /// <summary>
    /// Once per link: says when the RTU clock is off by more than the tolerance, what happens to its device times, and
    /// whether it looks like local time instead of UTC.
    /// </summary>
    private void ReportClock(DateTime now)
    {
        if (_clock.Offset is not { } skew || skew.Duration() <= _timePolicy.Tolerance)
        {
            return;
        }

        _clockReported = true;
        var hours = Math.Round(skew.TotalHours);
        var localTime = Math.Abs(hours) is >= 1 and <= 14 && Math.Abs(skew.TotalHours - hours) * 60 < 20
            ? _timePolicy.Zone is null
                ? $" It looks like local time (UTC{hours:+0;-0}) instead of UTC: set the endpoint's station time zone."
                : $" It looks like another zone than {_timePolicy.Zone.Id} (off by {hours:+0;-0} h): check the endpoint's station time zone."
            : string.Empty;
        var outcome = _timePolicy.Mode == Iec104ClockPolicy.Enforce
            ? "its values are stamped with the time of receipt, and the device time is kept beside them"
            : skew > Iec104SignalMapper.FutureTolerance || -skew > _timePolicy.MaxDeviceAge
                ? "its values are stamped with the time of receipt (ClockPolicy Observe)"
                : "its device times are still used (ClockPolicy Observe; Enforce would stamp them on receipt)";
        _logger.LogWarning(
            "[IEC104-CLOCK] Connection {Code}: the RTU clock says {DeviceTime:yyyy-MM-dd HH:mm:ss} UTC, {Skew} {Direction} the agent; {Outcome}.{LocalTime} {Setting}",
            _code,
            now + skew,
            Describe(skew.Duration()),
            skew > TimeSpan.Zero ? "ahead of" : "behind",
            outcome,
            localTime,
            !(_clockSync.OnConnect || _clockSync.Every.HasValue)
                ? "The RTU clock is not set from here (clock_sync is off: other masters may share it)."
                : _clockSyncRefused
                    ? $"The station did not accept the agent's clock sync (clock_sync {_settings.ClockSync}), so its clock stays off."
                    : $"The agent sets the RTU clock (clock_sync {_settings.ClockSync})."
        );
    }

    /// <summary>The offset of the connection's clock, as a short text: "in step (+0.4 s)", "3.0 h ahead", "5.5 years behind".</summary>
    private string ClockOffsetText() =>
        _clock.Offset is not { } offset ? "no offset yet"
        : offset.Duration() <= _timePolicy.Tolerance ? $"in step ({offset.TotalSeconds:+0.0;-0.0} s)"
        : $"{Describe(offset.Duration())} {(offset > TimeSpan.Zero ? "ahead" : "behind")}";

    /// <summary>Every hour: the offset of the connection's clock and what happened to its device times.</summary>
    private void LogClock(TimeSpan window)
    {
        var (used, late, replaced) = _clock.TakeHour();
        _logger.LogInformation(
            "[IEC104-CLOCK] Connection {Code}, last {Minutes:F0} min: device clock {Offset}; {Used} device time(s) used ({Late} more than {Tolerance} s old), {Replaced} stamped on receipt; ClockPolicy {Policy}.",
            _code,
            window.TotalMinutes,
            ClockOffsetText(),
            used,
            late,
            _timePolicy.Tolerance.TotalSeconds,
            replaced,
            _timePolicy.Mode
        );
    }

    /// <summary>What the connection received since the last summary.</summary>
    private void LogStats(TimeSpan window)
    {
        var s = _stats.Take();
        var (newest, trusted, untrusted) = _clock.Take();
        var clock = newest is { } device
            ? $"device clock {device:yyyy-MM-dd HH:mm:ss} UTC at newest ({ClockOffsetText()}), {trusted} value(s) with device time, {untrusted} stamped on receipt"
            : "no device time";
        _logger.LogInformation(
            "[IEC104-STATS] Connection {Code} ({Host}:{Port}), last {Minutes:F0} min: {Objects} objects in {Asdus} ASDUs (spont {Spontaneous}, GI {Interrogated}, other {Other}); {Mapped} values to {Signals} signals; {Unknown} not configured{UnknownExample}; link tests {Answered}/{Sent} answered; {Clock}.",
            _code,
            Host,
            Port,
            window.TotalMinutes,
            s.Objects,
            s.Asdus,
            s.Spontaneous,
            s.Interrogated,
            s.Other,
            s.Mapped,
            s.Signals,
            s.Unknown,
            s.FirstUnknown is { } unknown ? $" (CA {unknown.Ca}, e.g. {Iec104Address.Describe(unknown.Ioa)})" : string.Empty,
            s.LinkTestsAnswered,
            s.LinkTestsSent,
            clock
        );
    }

    private void InterrogateAll()
    {
        foreach (var ca in Volatile.Read(ref _map).CommonAddresses)
        {
            SendInterrogation(ca);
        }
    }

    private void SendInterrogation(int ca)
    {
        try
        {
            _interrogations[ca] = new GiProgress(_time.GetUtcNow().UtcDateTime);
            _connection?.SendInterrogationCommand(CauseOfTransmission.ACTIVATION, ca, Iec104Constants.StationInterrogationQualifier);
            _logger.LogDebug("[IEC104-GI] Connection {Code}: general interrogation sent to common address {CommonAddress}.", _code, ca);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "[IEC104-GI] Connection {Code}: interrogating common address {CommonAddress} failed.", _code, ca);
        }
    }

    /// <summary>Sets the clock of every station of the connection to the agent's time in the station's zone, and logs it.</summary>
    private void SyncClocks(string reason)
    {
        foreach (var ca in Volatile.Read(ref _map).CommonAddresses)
        {
            try
            {
                var now = _time.GetUtcNow().UtcDateTime;
                var set = $"{now:yyyy-MM-dd HH:mm:ss.fff} UTC in {StationTime.Describe(_timePolicy.Zone)}";
                _pendingClockSyncs[ca] = (now, set);
                _connection?.SendClockSyncCommand(ca, StationTime.ToCp56(now, _timePolicy.Zone));
                _logger.LogInformation(
                    "[IEC104-CLOCK] Connection {Code}: clock sync sent to common address {CommonAddress}: {Set} ({Reason}, clock_sync {Mode}).",
                    _code,
                    ca,
                    set,
                    reason,
                    _settings.ClockSync
                );
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "[IEC104-CLOCK] Connection {Code}: clock synchronisation of common address {CommonAddress} failed.", _code, ca);
            }
        }
    }

    /// <summary>
    /// The station's answer to a clock sync: confirmed (the clock is set), refused, or rejected with COT 44-47, which a
    /// station without clock sync sends back instead of a negative confirmation (in both cases the clock is not set).
    /// An answer to a sync this agent did not send (another master's) is only logged at Debug.
    /// </summary>
    private void ClockSyncAnswered(ASDU asdu)
    {
        var rejected = asdu.Cot is CauseOfTransmission.UNKNOWN_TYPE_ID
            or CauseOfTransmission.UNKNOWN_CAUSE_OF_TRANSMISSION
            or CauseOfTransmission.UNKNOWN_COMMON_ADDRESS_OF_ASDU
            or CauseOfTransmission.UNKNOWN_INFORMATION_OBJECT_ADDRESS;
        if ((asdu.Cot != CauseOfTransmission.ACTIVATION_CON && !rejected) || !_pendingClockSyncs.TryRemove(asdu.Ca, out var sync))
        {
            _logger.LogDebug("[IEC104-CLOCK] Connection {Code}: clock sync answer from common address {CommonAddress} ({Cause}).", _code, asdu.Ca, Iec104FrameText.Cause(asdu.Cot));
            return;
        }

        _clockSyncRefused = rejected || asdu.IsNegative;
        if (rejected)
        {
            _logger.LogWarning(
                "[IEC104-CLOCK] Connection {Code}: common address {CommonAddress} rejected the clock sync ({Set}) as {Cause}; its clock is not set. The station may not support clock sync; set the endpoint's clock sync to Never.",
                _code,
                asdu.Ca,
                sync.Set,
                Iec104FrameText.Cause(asdu.Cot)
            );
            return;
        }

        if (asdu.IsNegative)
        {
            _logger.LogWarning(
                "[IEC104-CLOCK] Connection {Code}: common address {CommonAddress} refused the clock sync ({Set}); its clock is not set. Check that the station accepts C_CS_NA_1 from originator address {Originator}.",
                _code,
                asdu.Ca,
                sync.Set,
                _settings.OriginatorAddress
            );
            return;
        }

        _logger.LogInformation(
            "[IEC104-CLOCK] Connection {Code}: common address {CommonAddress} confirmed the clock sync ({Set}).",
            _code,
            asdu.Ca,
            sync.Set
        );

        // The offset measured before the sync is no longer true: measure again and report the new one once.
        _clock.Restart();
        _clockReported = false;
    }

    /// <summary>Warns about the clock syncs no station answered in time; each is reported once.</summary>
    private void ReportUnansweredClockSyncs(DateTime now)
    {
        foreach (var (ca, sync) in _pendingClockSyncs)
        {
            if (now - sync.SentAt < TimeSpan.FromSeconds(Iec104Constants.ClockSyncConfirmTimeoutSec) || !_pendingClockSyncs.TryRemove(ca, out _))
            {
                continue;
            }

            _logger.LogWarning(
                "[IEC104-CLOCK] Connection {Code}: common address {CommonAddress} did not confirm the clock sync ({Set}) within {Timeout} s; its clock may not be set.",
                _code,
                ca,
                sync.Set,
                Iec104Constants.ClockSyncConfirmTimeoutSec
            );
        }
    }

    /// <summary>Marks the link down; the first time after it was up, sends one Offline sample per signal read.</summary>
    private void LinkLost()
    {
        if (!_linkUp)
        {
            return;
        }

        _linkUp = false;
        // A sync sent on the lost link is answered on no link: not reported as unanswered.
        _pendingClockSyncs.Clear();
        var now = _time.GetUtcNow().UtcDateTime;
        var offset = _clock.Offset;
        var newest = _clock.Newest;
        // The same limit the mapper trusts device times by: with Enforce, the connection's tolerance.
        var maxAhead = _timePolicy.Mode == Iec104ClockPolicy.Enforce ? _timePolicy.Tolerance : Iec104SignalMapper.FutureTolerance;
        foreach (var (signalId, last) in _lastValues)
        {
            var at = OfflineTime(last, now, offset, newest, maxAhead);
            _sink.Write(new SignalReading(
                signalId,
                EndpointId,
                last.Value,
                at,
                CanonicalQualityStatus.Offline,
                0,
                last.DeviceTimed ? SampleTimeSource.Device : SampleTimeSource.ReceiptUntimed,
                ReceiveLagMs: (long)(now - at).TotalMilliseconds
            ));
        }

        _logger.LogWarning(
            "[IEC104-CONN] Connection {Code} lost; {Count} signal(s) marked Offline.",
            _code,
            _lastValues.Count
        );
    }

    /// <summary>A signal's last value, its time, and whether that time came from the device.</summary>
    internal readonly record struct LastSample(double Value, DateTime Timestamp, bool DeviceTimed);

    /// <summary>
    /// When a signal's Offline sample is stamped, always after its last value (by at least 1 ms, so the backend never
    /// overwrites that value with it):
    /// <list type="bullet">
    /// <item>A value stamped with the device time: the RTU's clock at the link loss, the agent's time plus the offset of
    /// the RTU clock (else the newest device time seen). The RTU's next values are later than that, even when its clock is
    /// behind, so the Offline sample never hides them.</item>
    /// <item>A value stamped on receipt: the agent's time.</item>
    /// <item>An RTU clock further ahead than <paramref name="maxAhead"/> (default <see cref="Iec104SignalMapper.FutureTolerance"/>):
    /// its device times are replaced by the time of receipt, so its next values come at the agent's time. The Offline
    /// sample then takes the agent's time too; stamped at the RTU's clock it would be newer than every value until that
    /// clock is reached and pin the signal Offline (a device clock hours ahead kept assets degraded for hours).</item>
    /// </list>
    /// </summary>
    internal static DateTime OfflineTime(LastSample last, DateTime now, TimeSpan? clockOffset, DateTime? newestDeviceTime, TimeSpan? maxAhead = null)
    {
        var after = last.Timestamp.AddMilliseconds(1);
        var device = clockOffset is { } offset ? now + offset : newestDeviceTime ?? after;
        if (device > now + (maxAhead ?? Iec104SignalMapper.FutureTolerance))
        {
            device = now;
        }

        var clock = last.DeviceTimed ? device : now;
        return clock > after ? clock : after;
    }

    private void Close()
    {
        var connection = Interlocked.Exchange(ref _connection, null);
        try
        {
            connection?.Cancel();
            connection?.Close();
        }
        catch (Exception ex)
        {
            // Best effort on a broken link.
            _logger.LogDebug(ex, "[IEC104-CONN] Connection {Code}: closing the socket to {Host}:{Port} failed.", _code, Host, Port);
        }
    }

    public ValueTask DisposeAsync()
    {
        Volatile.Read(ref _session)?.Cancel();
        Close();
        return ValueTask.CompletedTask;
    }

    /// <summary>One general interrogation of a common address, from the command to its termination.</summary>
    private sealed class GiProgress(DateTime sentAt)
    {
        private int _objects;
        private int _mapped;
        private int _unknown;
        private int _firstUnknown = -1;

        public DateTime SentAt { get; } = sentAt;

        public int Objects => Volatile.Read(ref _objects);

        public int Mapped => Volatile.Read(ref _mapped);

        public int Unknown => Volatile.Read(ref _unknown);

        public int? FirstUnknown => Volatile.Read(ref _firstUnknown) is >= 0 and var ioa ? ioa : null;

        public void Add(int objects, int mapped, int unknown, int? firstUnknown)
        {
            Interlocked.Add(ref _objects, objects);
            Interlocked.Add(ref _mapped, mapped);
            Interlocked.Add(ref _unknown, unknown);
            if (firstUnknown is { } ioa)
            {
                Interlocked.CompareExchange(ref _firstUnknown, ioa, -1);
            }
        }
    }

    /// <summary>Traffic counters between two summaries; written by the receive thread, taken by the timers.</summary>
    private sealed class TrafficStats
    {
        private long _asdus, _objects, _spontaneous, _interrogated, _other, _mapped, _unknown, _testsSent, _testsAnswered;
        private ConcurrentDictionary<Guid, byte> _signals = new();

        // The first unknown (CA, IOA) of the window packed as CA << 24 | IOA, so it is read and written at once; -1 = none.
        private long _firstUnknown = -1;

        public readonly record struct Snapshot(
            long Asdus, long Objects, long Spontaneous, long Interrogated, long Other, long Mapped, int Signals, long Unknown,
            (int Ca, int Ioa)? FirstUnknown, long LinkTestsSent, long LinkTestsAnswered);

        public void Count(CauseOfTransmission cause, int objects, int mapped, int unknown)
        {
            Interlocked.Increment(ref _asdus);
            Interlocked.Add(ref _objects, objects);
            Interlocked.Add(ref _mapped, mapped);
            Interlocked.Add(ref _unknown, unknown);
            if (cause == CauseOfTransmission.SPONTANEOUS)
            {
                Interlocked.Add(ref _spontaneous, objects);
            }
            else if (cause == CauseOfTransmission.INTERROGATED_BY_STATION)
            {
                Interlocked.Add(ref _interrogated, objects);
            }
            else
            {
                Interlocked.Add(ref _other, objects);
            }
        }

        public void Updated(Guid signalId) => Volatile.Read(ref _signals).TryAdd(signalId, 0);

        public void Unknown(int ca, int ioa) => Interlocked.CompareExchange(ref _firstUnknown, ((long)ca << 24) | (uint)ioa, -1);

        public void LinkTestSent() => Interlocked.Increment(ref _testsSent);

        public void LinkTestAnswered() => Interlocked.Increment(ref _testsAnswered);

        public Snapshot Take()
        {
            var signals = Interlocked.Exchange(ref _signals, new ConcurrentDictionary<Guid, byte>());
            var packed = Interlocked.Exchange(ref _firstUnknown, -1);
            (int Ca, int Ioa)? first = packed >= 0 ? ((int)(packed >> 24), (int)(packed & 0xFFFFFF)) : null;
            return new Snapshot(
                Interlocked.Exchange(ref _asdus, 0),
                Interlocked.Exchange(ref _objects, 0),
                Interlocked.Exchange(ref _spontaneous, 0),
                Interlocked.Exchange(ref _interrogated, 0),
                Interlocked.Exchange(ref _other, 0),
                Interlocked.Exchange(ref _mapped, 0),
                signals.Count,
                Interlocked.Exchange(ref _unknown, 0),
                first,
                Interlocked.Exchange(ref _testsSent, 0),
                Interlocked.Exchange(ref _testsAnswered, 0)
            );
        }
    }
}
