using System.Globalization;
using System.Text;
using lib60870;
using lib60870.CS101;

namespace Votech.Edge.Ingestion.Iec104;

/// <summary>
/// One APDU as a line a field engineer can read (<c>LogRawFrames</c>): the frame kind and sequence numbers, and for an
/// I-frame the type, cause, common address and every object with its IOA (decimal and octets), value, quality, device
/// time and, when configured, the point it feeds:
/// <code>I(ns=231 nr=2) M_ME_TF_1 spont CA 7, 1 object: 1772813 (27.13.13) = 993.8 good @2021-02-11 22:58:53.660 → TM3_SUNG13.VDC1</code>
/// </summary>
public static class Iec104FrameText
{
    /// <summary>Objects listed per frame; the rest are counted.</summary>
    private const int MaxObjects = 8;

    public static string Describe(byte[] message, int size, ApplicationLayerParameters parameters, Iec104PointMap? map)
    {
        if (size < 6 || message[0] != 0x68)
        {
            return $"not an APDU ({size} bytes)";
        }

        var control = message[2];
        if ((control & 0x01) == 0)
        {
            var sent = (message[2] | (message[3] << 8)) >> 1;
            var received = (message[4] | (message[5] << 8)) >> 1;
            return $"I(ns={sent} nr={received}) {DescribeAsdu(message, size, parameters, map)}";
        }

        if ((control & 0x03) == 0x01)
        {
            return $"S ack nr={(message[4] | (message[5] << 8)) >> 1}";
        }

        return control switch
        {
            0x07 => "U STARTDT act",
            0x0B => "U STARTDT con",
            0x13 => "U STOPDT act",
            0x23 => "U STOPDT con",
            0x43 => "U TESTFR act (link test)",
            0x83 => "U TESTFR con (link test answered)",
            _ => $"U 0x{control:X2}",
        };
    }

    private static string DescribeAsdu(byte[] message, int size, ApplicationLayerParameters parameters, Iec104PointMap? map)
    {
        ASDU asdu;
        try
        {
            var bytes = message.AsSpan(6, size - 6).ToArray();
            asdu = new ASDU(parameters, bytes, 0, bytes.Length);
        }
        catch (Exception ex)
        {
            return $"undecodable ASDU ({ex.Message})";
        }

        var text = new StringBuilder();
        text.Append(asdu.TypeId).Append(' ').Append(Cause(asdu.Cot));
        if (asdu.IsNegative)
        {
            text.Append(" NEGATIVE");
        }

        if (asdu.IsTest)
        {
            text.Append(" TEST");
        }

        var count = asdu.NumberOfElements;
        text.Append(" CA ").Append(asdu.Ca).Append(", ").Append(count).Append(count == 1 ? " object" : " objects");
        for (var i = 0; i < Math.Min(count, MaxObjects); i++)
        {
            text.Append(i == 0 ? ": " : "; ");
            try
            {
                var io = asdu.GetElement(i);
                text.Append(Iec104Address.Describe(io.ObjectAddress)).Append(' ').Append(Value(io));
                if (map != null && map.TryGet(asdu.Ca, io.ObjectAddress, out var point))
                {
                    text.Append(" → ").Append(point.Code);
                }
            }
            catch (Exception ex)
            {
                text.Append("undecodable object (").Append(ex.Message).Append(')');
            }
        }

        if (count > MaxObjects)
        {
            text.Append("; … ").Append(count - MaxObjects).Append(" more");
        }

        return text.ToString();
    }

    /// <summary>The cause of transmission in a word: spont, GI, act, act-con, act-term, unknown-CA…</summary>
    public static string Cause(CauseOfTransmission cot) =>
        cot switch
        {
            CauseOfTransmission.PERIODIC => "periodic",
            CauseOfTransmission.BACKGROUND_SCAN => "background",
            CauseOfTransmission.SPONTANEOUS => "spont",
            CauseOfTransmission.INITIALIZED => "init",
            CauseOfTransmission.REQUEST => "request",
            CauseOfTransmission.ACTIVATION => "act",
            CauseOfTransmission.ACTIVATION_CON => "act-con",
            CauseOfTransmission.DEACTIVATION => "deact",
            CauseOfTransmission.DEACTIVATION_CON => "deact-con",
            CauseOfTransmission.ACTIVATION_TERMINATION => "act-term",
            CauseOfTransmission.INTERROGATED_BY_STATION => "GI",
            CauseOfTransmission.UNKNOWN_TYPE_ID => "unknown type (COT 44)",
            CauseOfTransmission.UNKNOWN_CAUSE_OF_TRANSMISSION => "unknown cause (COT 45)",
            CauseOfTransmission.UNKNOWN_COMMON_ADDRESS_OF_ASDU => "unknown common address (COT 46)",
            CauseOfTransmission.UNKNOWN_INFORMATION_OBJECT_ADDRESS => "unknown IOA (COT 47)",
            _ => $"COT {(int)cot}",
        };

    private static string Value(InformationObject io) =>
        io switch
        {
            SinglePointWithCP56Time2a sp => $"= {(sp.Value ? "on" : "off")} {Quality(sp.Quality)}{Time(sp.Timestamp)}",
            SinglePointInformation sp => $"= {(sp.Value ? "on" : "off")} {Quality(sp.Quality)}",
            DoublePointWithCP56Time2a dp => $"= {DoublePoint(dp.Value)} {Quality(dp.Quality)}{Time(dp.Timestamp)}",
            DoublePointInformation dp => $"= {DoublePoint(dp.Value)} {Quality(dp.Quality)}",
            StepPositionWithCP56Time2a st => $"= step {st.Value} {Quality(st.Quality)}{Time(st.Timestamp)}",
            StepPositionInformation st => $"= step {st.Value} {Quality(st.Quality)}",
            Bitstring32WithCP56Time2a bo => $"= 0x{bo.Value:X8} {Quality(bo.Quality)}{Time(bo.Timestamp)}",
            Bitstring32 bo => $"= 0x{bo.Value:X8} {Quality(bo.Quality)}",
            MeasuredValueNormalizedWithCP56Time2a me => $"= {Number(me.NormalizedValue)} {Quality(me.Quality)}{Time(me.Timestamp)}",
            MeasuredValueNormalized me => $"= {Number(me.NormalizedValue)} {Quality(me.Quality)}",
            MeasuredValueNormalizedWithoutQuality me => $"= {Number(me.NormalizedValue)}",
            MeasuredValueScaledWithCP56Time2a me => $"= {me.ScaledValue.Value} {Quality(me.Quality)}{Time(me.Timestamp)}",
            MeasuredValueScaled me => $"= {me.ScaledValue.Value} {Quality(me.Quality)}",
            MeasuredValueShortWithCP56Time2a me => $"= {Number(me.Value)} {Quality(me.Quality)}{Time(me.Timestamp)}",
            MeasuredValueShort me => $"= {Number(me.Value)} {Quality(me.Quality)}",
            IntegratedTotalsWithCP56Time2a it => $"= {it.BCR.Value} {Counter(it.BCR)}{Time(it.Timestamp)}",
            IntegratedTotals it => $"= {it.BCR.Value} {Counter(it.BCR)}",
            InterrogationCommand gi => $"QOI {gi.QOI}{(gi.QOI == 20 ? " (station)" : string.Empty)}",
            ClockSynchronizationCommand cs => $"set clock{Time(cs.NewTime)}",
            _ => io.GetType().Name,
        };

    private static string Number(double value) => value.ToString("G7", CultureInfo.InvariantCulture);

    private static string DoublePoint(DoublePointValue value) =>
        value switch
        {
            DoublePointValue.OFF => "off (1)",
            DoublePointValue.ON => "on (2)",
            DoublePointValue.INTERMEDIATE => "intermediate (0)",
            _ => "faulty (3)",
        };

    /// <summary>"good", or the set bits: IV NT SB BL OV.</summary>
    public static string Quality(QualityDescriptor quality)
    {
        var bits = quality.EncodedValue;
        if ((bits & 0xF1) == 0)
        {
            return "good";
        }

        var flags = new List<string>(5);
        if ((bits & 0x80) != 0) flags.Add("IV");
        if ((bits & 0x40) != 0) flags.Add("NT");
        if ((bits & 0x20) != 0) flags.Add("SB");
        if ((bits & 0x10) != 0) flags.Add("BL");
        if ((bits & 0x01) != 0) flags.Add("OV");
        return string.Join(' ', flags);
    }

    private static string Counter(BinaryCounterReading bcr) =>
        bcr.Invalid ? "IV" : bcr.Carry ? "carry" : bcr.Adjusted ? "adjusted" : "good";

    private static string Time(CP56Time2a? time)
    {
        if (time is null)
        {
            return string.Empty;
        }

        var stamp = $" @20{time.Year:D2}-{time.Month:D2}-{time.DayOfMonth:D2} {time.Hour:D2}:{time.Minute:D2}:{time.Second:D2}.{time.Millisecond:D3}";
        return time.Invalid ? stamp + " (time invalid)" : stamp;
    }
}
