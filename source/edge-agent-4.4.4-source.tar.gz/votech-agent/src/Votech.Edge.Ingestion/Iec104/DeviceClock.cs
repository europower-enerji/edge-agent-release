using Votech.Edge.Core.Constants;

namespace Votech.Edge.Ingestion.Iec104;

/// <summary>
/// What the device times (CP56Time2a) of one connection say: the newest one and how many were used or replaced since the
/// last <see cref="Take"/>, the same counts per hour (<see cref="TakeHour"/>), and the <see cref="Offset"/> of the
/// device clock.
/// <list type="bullet">
/// <item>The offset is the newest device time of a window (<see cref="Iec104Constants.ClockEstimateWindowSec"/>) minus
/// the time it was received. A backlog of old events, which an RTU sends after a link loss, is never the newest, so it
/// does not move the offset.</item>
/// <item>A window whose newest device time is not newer than every one before is skipped, unless that happens
/// <see cref="Iec104Constants.ClockStaleWindowsBeforeReset"/> times in a row (the device clock was set back).</item>
/// <item>The first offset comes when the first window closes. It lives as long as the poller, so it survives
/// reconnects.</item>
/// </list>
/// Observed on lib60870's receive thread, read by the poller's timers.
/// </summary>
public sealed class DeviceClock(TimeSpan? window = null)
{
    private readonly TimeSpan _window = window ?? TimeSpan.FromSeconds(Iec104Constants.ClockEstimateWindowSec);
    private readonly Lock _gate = new();
    private long _newestTicks;
    private int _trusted;
    private int _untrusted;
    private int _hourUsed;
    private int _hourLate;
    private int _hourReplaced;

    // The window being collected and the offset taken from the last one (under _gate).
    private DateTime? _windowStart;
    private DateTime? _windowNewest;
    private TimeSpan _windowOffset;
    private DateTime? _highWater;
    private int _staleWindows;
    private TimeSpan? _offset;

    /// <summary>
    /// Records a device time received at <paramref name="receivedAt"/>, whether it was used (<paramref name="trusted"/>),
    /// and whether it was used although older than the tolerance (<paramref name="late"/>: a buffered or late event).
    /// </summary>
    public void Observe(DateTime deviceTime, DateTime receivedAt, bool trusted, bool late = false)
    {
        if (deviceTime.Ticks > Volatile.Read(ref _newestTicks))
        {
            Volatile.Write(ref _newestTicks, deviceTime.Ticks);
        }

        if (trusted)
        {
            Interlocked.Increment(ref _trusted);
            Interlocked.Increment(ref _hourUsed);
        }
        else
        {
            Interlocked.Increment(ref _untrusted);
            Interlocked.Increment(ref _hourReplaced);
        }

        if (late)
        {
            Interlocked.Increment(ref _hourLate);
        }

        lock (_gate)
        {
            if (_windowStart is { } start && receivedAt - start >= _window)
            {
                CloseWindow();
            }

            _windowStart ??= receivedAt;
            if (_windowNewest is not { } newest || deviceTime > newest)
            {
                _windowNewest = deviceTime;
                _windowOffset = deviceTime - receivedAt;
            }
        }
    }

    /// <summary>Device time minus receipt time of the connection's clock; null until the first window closed.</summary>
    public TimeSpan? Offset
    {
        get
        {
            lock (_gate)
            {
                return _offset;
            }
        }
    }

    /// <summary>The newest device time and the counts since the last call; starts over.</summary>
    public (DateTime? Newest, int Trusted, int Untrusted) Take()
    {
        var ticks = Interlocked.Exchange(ref _newestTicks, 0);
        return (ticks > 0 ? new DateTime(ticks, DateTimeKind.Utc) : null, Interlocked.Exchange(ref _trusted, 0), Interlocked.Exchange(ref _untrusted, 0));
    }

    /// <summary>Device times used (of them late) and replaced since the last call; starts over.</summary>
    public (int Used, int Late, int Replaced) TakeHour() =>
        (Interlocked.Exchange(ref _hourUsed, 0), Interlocked.Exchange(ref _hourLate, 0), Interlocked.Exchange(ref _hourReplaced, 0));

    /// <summary>The newest device time since the last <see cref="Take"/>, without starting over.</summary>
    public DateTime? Newest => Volatile.Read(ref _newestTicks) is > 0 and var ticks ? new DateTime(ticks, DateTimeKind.Utc) : null;

    /// <summary>
    /// The device clock was just set (a confirmed clock sync): the offset and the window are dropped, so the next window
    /// measures the set clock instead of waiting <see cref="Iec104Constants.ClockStaleWindowsBeforeReset"/> windows when
    /// it was set back. The counts are kept.
    /// </summary>
    public void Restart()
    {
        lock (_gate)
        {
            _windowStart = null;
            _windowNewest = null;
            _highWater = null;
            _staleWindows = 0;
            _offset = null;
        }
    }

    private void CloseWindow()
    {
        if (_windowNewest is { } newest)
        {
            if (_highWater is not { } highWater || newest > highWater || ++_staleWindows >= Iec104Constants.ClockStaleWindowsBeforeReset)
            {
                _offset = _windowOffset;
                _highWater = newest;
                _staleWindows = 0;
            }
        }

        _windowStart = null;
        _windowNewest = null;
    }
}
