using lib60870;

namespace Votech.Edge.Ingestion.Iec104;

/// <summary>
/// The wall clock of an IEC 104 station that runs in a time zone (<c>Iec104Settings.time_zone</c>, IANA). CP56Time2a
/// carries no offset, only the summer time bit (SU), so a station on local time sends its local wall time.
/// <list type="bullet">
/// <item>Reading: the wall time is taken in the zone. In the hour a summer time change repeats, SU picks the summer
/// offset; in the hour it skips (no such wall time), the offset before the change is used.</item>
/// <item>Setting the clock: the agent's UTC time converted to the zone, with SU set while summer time applies.</item>
/// <item>No zone (null): UTC, as before.</item>
/// </list>
/// </summary>
public static class StationTime
{
    /// <summary>The zone of <paramref name="timeZone"/>; null for empty (UTC). False when the id is not known here.</summary>
    public static bool TryResolve(string? timeZone, out TimeZoneInfo? zone)
    {
        zone = null;
        if (string.IsNullOrWhiteSpace(timeZone))
        {
            return true;
        }

        return TimeZoneInfo.TryFindSystemTimeZoneById(timeZone, out zone);
    }

    /// <summary>The UTC instant of the station wall time <paramref name="wallTime"/> (kind ignored).</summary>
    public static DateTime ToUtc(DateTime wallTime, bool summerTime, TimeZoneInfo? zone)
    {
        var wall = DateTime.SpecifyKind(wallTime, DateTimeKind.Unspecified);
        if (zone is null)
        {
            return DateTime.SpecifyKind(wall, DateTimeKind.Utc);
        }

        TimeSpan offset;
        if (zone.IsAmbiguousTime(wall))
        {
            var offsets = zone.GetAmbiguousTimeOffsets(wall);
            offset = summerTime ? offsets.Max() : offsets.Min();
        }
        else if (zone.IsInvalidTime(wall))
        {
            // The skipped hour of a change to summer time: read it with the offset in force just before.
            offset = zone.GetUtcOffset(wall.AddHours(-1));
        }
        else
        {
            offset = zone.GetUtcOffset(wall);
        }

        return DateTime.SpecifyKind(wall - offset, DateTimeKind.Utc);
    }

    /// <summary>The CP56Time2a that sets a station clock running in <paramref name="zone"/> to <paramref name="utc"/>.</summary>
    public static CP56Time2a ToCp56(DateTime utc, TimeZoneInfo? zone)
    {
        var instant = DateTime.SpecifyKind(utc, DateTimeKind.Utc);
        if (zone is null)
        {
            return new CP56Time2a(instant);
        }

        var wall = DateTime.SpecifyKind(TimeZoneInfo.ConvertTimeFromUtc(instant, zone), DateTimeKind.Unspecified);
        return new CP56Time2a(wall) { SummerTime = zone.IsDaylightSavingTime(instant) };
    }

    /// <summary>The zone's name for logs: its id, or "UTC".</summary>
    public static string Describe(TimeZoneInfo? zone) => zone?.Id ?? "UTC";
}
