using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Models;
using lib60870;
using lib60870.CS101;

namespace Votech.Edge.Ingestion.Iec104;

/// <summary>
/// Turns the information objects of a monitoring ASDU into <see cref="SignalReading"/>s, routed by the ASDU's common
/// address and each object's IOA (<see cref="Iec104PointMap"/>). Every value is sent: the backend applies the deadband.
/// <list type="bullet">
/// <item>Types: single and double points, step positions, 32-bit strings, normalized, scaled and short floating
/// measurements, and integrated totals (energy counters), each with or without CP56Time2a.</item>
/// <item>Quality (IEC 60870-5-101 7.2.6.3): IV, NT, SB or BL make the value Bad, OV makes it Uncertain. Integrated
/// totals: IV is Bad, a carry Uncertain. The bits go out unchanged as the raw quality.</item>
/// <item>Time: the CP56Time2a of the object, unless its own invalid bit is set, it lies more than
/// <see cref="FutureTolerance"/> ahead of the agent's clock, or it is older than the maximum age (24 h unless
/// configured: an RTU clock left in a past year); then the time of receipt. With <see cref="Iec104ClockPolicy.Enforce"/>
/// the connection's clock is judged instead (<see cref="TimePolicy"/>). Every reading says where its time comes from
/// (<see cref="SampleTimeSource"/>), keeps a device time that was not used, and carries how long after its time the
/// agent received it. A <see cref="DeviceClock"/> records what the device said and the offset of its clock.</item>
/// </list>
/// </summary>
public static class Iec104SignalMapper
{
    /// <summary>A device time further ahead than this is not trusted.</summary>
    public static readonly TimeSpan FutureTolerance = TimeSpan.FromMinutes(Iec104Constants.DeviceTimeFutureToleranceMinutes);

    /// <summary>A device time older than this is not trusted, unless the connection sets its own maximum age.</summary>
    public static readonly TimeSpan DefaultMaxDeviceAge = TimeSpan.FromHours(Iec104Constants.DefaultMaxDeviceTimeAgeHours);

    /// <summary>Raw quality bit of an integrated total's carry (the BCR sequence octet).</summary>
    private const uint CounterCarry = 0x20;

    /// <summary>Raw quality bit of an adjusted integrated total.</summary>
    private const uint CounterAdjusted = 0x40;

    /// <summary>How device times are judged: the maximum age, the policy and the tolerance of a connection's clock.</summary>
    /// <summary>
    /// How device times are judged, and the <paramref name="Zone"/> the station clock runs in (null = UTC; see
    /// <see cref="StationTime"/>).
    /// </summary>
    public readonly record struct TimePolicy(TimeSpan MaxDeviceAge, Iec104ClockPolicy Mode, TimeSpan Tolerance, TimeZoneInfo? Zone = null)
    {
        /// <summary>24 h, <see cref="Iec104ClockPolicy.Observe"/>, 60 s.</summary>
        public static TimePolicy Default { get; } = new(DefaultMaxDeviceAge, Iec104ClockPolicy.Observe, TimeSpan.FromSeconds(Iec104Constants.DefaultClockSkewToleranceSec));

        /// <summary>The policy of the agent's IEC 104 options (0 = the default maximum age).</summary>
        public static TimePolicy From(Iec104AgentOptions options) => new(
            options.MaxDeviceTimeAgeHours > 0 ? TimeSpan.FromHours(options.MaxDeviceTimeAgeHours) : DefaultMaxDeviceAge,
            options.ClockPolicy,
            TimeSpan.FromSeconds(options.ClockSkewToleranceSec));
    }

    /// <summary>
    /// Maps the elements of <paramref name="asdu"/> that the map knows; returns the number of elements with an unknown
    /// address in <paramref name="unknown"/>, and adds their IOAs to <paramref name="unknownIoas"/> when given. Device
    /// times are judged by <paramref name="policy"/> (default <see cref="TimePolicy.Default"/>); <paramref name="clock"/>
    /// records every device time seen and gives the offset of the connection's clock.
    /// </summary>
    public static List<SignalReading> Map(
        ASDU asdu,
        Iec104PointMap map,
        Guid connectionId,
        DateTime receivedAt,
        out int unknown,
        TimePolicy? policy = null,
        List<int>? unknownIoas = null,
        DeviceClock? clock = null
    )
    {
        var readings = new List<SignalReading>(asdu.NumberOfElements);
        var time = new TimeContext(receivedAt, policy ?? TimePolicy.Default, clock);
        unknown = 0;
        for (var i = 0; i < asdu.NumberOfElements; i++)
        {
            var element = Read(asdu.TypeId, asdu.GetElement(i), time);
            if (element is not { } value)
            {
                continue;
            }

            if (!map.TryGet(asdu.Ca, value.Ioa, out var point))
            {
                unknown++;
                unknownIoas?.Add(value.Ioa);
                continue;
            }

            readings.Add(new SignalReading(
                point.SignalId,
                connectionId,
                point.ToEngineering(value.Raw),
                value.Time.Timestamp,
                value.Quality,
                value.RawQuality,
                value.Time.Source,
                value.Time.DeviceTimestampMs,
                value.Time.ReceiveLagMs
            ));
        }

        return readings;
    }

    /// <summary>True for the type ids <see cref="Map"/> reads.</summary>
    public static bool IsMonitoringType(TypeID typeId) =>
        typeId is TypeID.M_SP_NA_1 or TypeID.M_SP_TB_1 or TypeID.M_DP_NA_1 or TypeID.M_DP_TB_1
            or TypeID.M_ST_NA_1 or TypeID.M_ST_TB_1 or TypeID.M_BO_NA_1 or TypeID.M_BO_TB_1
            or TypeID.M_ME_NA_1 or TypeID.M_ME_TD_1 or TypeID.M_ME_ND_1 or TypeID.M_ME_NB_1 or TypeID.M_ME_TE_1
            or TypeID.M_ME_NC_1 or TypeID.M_ME_TF_1 or TypeID.M_IT_NA_1 or TypeID.M_IT_TB_1;

    /// <summary>A sample's time, where it comes from, the device time when it was not used, and the receive lag.</summary>
    public readonly record struct SampleTime(DateTime Timestamp, SampleTimeSource Source, long DeviceTimestampMs, long ReceiveLagMs)
    {
        /// <summary>The time of receipt, for a value without a time.</summary>
        public static SampleTime Receipt(DateTime receivedAt) => new(receivedAt, SampleTimeSource.ReceiptUntimed, 0, 0);
    }

    private readonly record struct Element(int Ioa, double Raw, CanonicalQualityStatus Quality, uint RawQuality, SampleTime Time);

    private readonly record struct TimeContext(DateTime ReceivedAt, TimePolicy Policy, DeviceClock? Clock);

    private static Element? Read(TypeID typeId, InformationObject io, TimeContext time) =>
        (typeId, io) switch
        {
            (TypeID.M_SP_TB_1, SinglePointWithCP56Time2a sp) => Timed(sp.ObjectAddress, sp.Value ? 1 : 0, sp.Quality, sp.Timestamp, time),
            (TypeID.M_SP_NA_1, SinglePointInformation sp) => Untimed(sp.ObjectAddress, sp.Value ? 1 : 0, sp.Quality, time),
            (TypeID.M_DP_TB_1, DoublePointWithCP56Time2a dp) => Timed(dp.ObjectAddress, (int)dp.Value, dp.Quality, dp.Timestamp, time),
            (TypeID.M_DP_NA_1, DoublePointInformation dp) => Untimed(dp.ObjectAddress, (int)dp.Value, dp.Quality, time),
            (TypeID.M_ST_TB_1, StepPositionWithCP56Time2a st) => Timed(st.ObjectAddress, st.Value, st.Quality, st.Timestamp, time),
            (TypeID.M_ST_NA_1, StepPositionInformation st) => Untimed(st.ObjectAddress, st.Value, st.Quality, time),
            (TypeID.M_BO_TB_1, Bitstring32WithCP56Time2a bo) => Timed(bo.ObjectAddress, bo.Value, bo.Quality, bo.Timestamp, time),
            (TypeID.M_BO_NA_1, Bitstring32 bo) => Untimed(bo.ObjectAddress, bo.Value, bo.Quality, time),
            (TypeID.M_ME_TD_1, MeasuredValueNormalizedWithCP56Time2a me) => Timed(me.ObjectAddress, me.NormalizedValue, me.Quality, me.Timestamp, time),
            (TypeID.M_ME_NA_1, MeasuredValueNormalized me) => Untimed(me.ObjectAddress, me.NormalizedValue, me.Quality, time),
            (TypeID.M_ME_ND_1, MeasuredValueNormalizedWithoutQuality me) => new Element(me.ObjectAddress, me.NormalizedValue, CanonicalQualityStatus.Good, 0, SampleTime.Receipt(time.ReceivedAt)),
            (TypeID.M_ME_TE_1, MeasuredValueScaledWithCP56Time2a me) => Timed(me.ObjectAddress, me.ScaledValue.Value, me.Quality, me.Timestamp, time),
            (TypeID.M_ME_NB_1, MeasuredValueScaled me) => Untimed(me.ObjectAddress, me.ScaledValue.Value, me.Quality, time),
            (TypeID.M_ME_TF_1, MeasuredValueShortWithCP56Time2a me) => Timed(me.ObjectAddress, me.Value, me.Quality, me.Timestamp, time),
            (TypeID.M_ME_NC_1, MeasuredValueShort me) => Untimed(me.ObjectAddress, me.Value, me.Quality, time),
            (TypeID.M_IT_TB_1, IntegratedTotalsWithCP56Time2a it) => Counter(it.ObjectAddress, it.BCR, it.Timestamp, time),
            (TypeID.M_IT_NA_1, IntegratedTotals it) => Counter(it.ObjectAddress, it.BCR, null, time),
            _ => null,
        };

    private static Element Untimed(int ioa, double raw, QualityDescriptor quality, TimeContext time) =>
        new(ioa, raw, ToQuality(quality), quality.EncodedValue, SampleTime.Receipt(time.ReceivedAt));

    private static Element Timed(int ioa, double raw, QualityDescriptor quality, CP56Time2a? cp56, TimeContext time) =>
        new(ioa, raw, ToQuality(quality), quality.EncodedValue, ResolveTime(cp56, time.ReceivedAt, time.Policy, time.Clock));

    private static Element Counter(int ioa, BinaryCounterReading bcr, CP56Time2a? cp56, TimeContext time)
    {
        var sampleTime = ResolveTime(cp56, time.ReceivedAt, time.Policy, time.Clock);
        var raw = (uint)(bcr.SequenceNumber & 0x1F)
            | (bcr.Carry ? CounterCarry : 0)
            | (bcr.Adjusted ? CounterAdjusted : 0)
            | (bcr.Invalid ? Iec104Constants.QualityInvalid : 0u);
        var quality = bcr.Invalid ? CanonicalQualityStatus.Bad
            : bcr.Carry ? CanonicalQualityStatus.Uncertain
            : CanonicalQualityStatus.Good;
        return new Element(ioa, bcr.Value, quality, raw, sampleTime);
    }

    /// <summary>IV, NT, SB or BL: Bad; OV: Uncertain; otherwise Good.</summary>
    public static CanonicalQualityStatus ToQuality(QualityDescriptor quality)
    {
        const byte bad = Iec104Constants.QualityInvalid | Iec104Constants.QualityNonTopical
            | Iec104Constants.QualitySubstituted | Iec104Constants.QualityBlocked;
        var bits = quality.EncodedValue;
        return (bits & bad) != 0 ? CanonicalQualityStatus.Bad
            : (bits & Iec104Constants.QualityOverflow) != 0 ? CanonicalQualityStatus.Uncertain
            : CanonicalQualityStatus.Good;
    }

    /// <summary>
    /// The CP56Time2a, read in the station's zone (<see cref="TimePolicy.Zone"/>) and turned into UTC, when it is trusted (<see cref="SampleTimeSource.Device"/>); otherwise the time of receipt:
    /// <see cref="SampleTimeSource.ReceiptUntimed"/> without a time, <see cref="SampleTimeSource.ReceiptTimeInvalid"/> when
    /// its invalid bit is set or it is no date, and <see cref="SampleTimeSource.ReceiptClockSkew"/> when it is not trusted.
    /// A device time that is not used is kept when it is a date.
    /// <list type="bullet">
    /// <item><see cref="Iec104ClockPolicy.Observe"/>, and <see cref="Iec104ClockPolicy.Enforce"/> before the clock's first
    /// offset: trusted within [receipt - maximum age, receipt + 5 min].</item>
    /// <item><see cref="Iec104ClockPolicy.Enforce"/>: never trusted while the connection's clock is off by more than the
    /// tolerance; otherwise trusted within [receipt - maximum age, receipt + tolerance], so the events an RTU buffered
    /// during a link loss keep their own times.</item>
    /// </list>
    /// </summary>
    public static SampleTime ResolveTime(CP56Time2a? time, DateTime receivedAt) =>
        ResolveTime(time, receivedAt, TimePolicy.Default, null);

    /// <inheritdoc cref="ResolveTime(CP56Time2a?, DateTime)"/>
    public static SampleTime ResolveTime(CP56Time2a? time, DateTime receivedAt, TimePolicy policy, DeviceClock? clock)
    {
        if (time is null)
        {
            return SampleTime.Receipt(receivedAt);
        }

        DateTime device;
        try
        {
            device = StationTime.ToUtc(
                new DateTime(time.Year + 2000, time.Month, time.DayOfMonth, time.Hour, time.Minute, time.Second, time.Millisecond),
                time.SummerTime,
                policy.Zone);
        }
        catch (ArgumentOutOfRangeException)
        {
            return new SampleTime(receivedAt, SampleTimeSource.ReceiptTimeInvalid, 0, 0);
        }

        var deviceMs = new DateTimeOffset(device).ToUnixTimeMilliseconds();
        if (time.Invalid)
        {
            return new SampleTime(receivedAt, SampleTimeSource.ReceiptTimeInvalid, deviceMs, 0);
        }

        var trusted = policy.Mode == Iec104ClockPolicy.Enforce && clock?.Offset is { } offset
            ? offset.Duration() <= policy.Tolerance && device <= receivedAt + policy.Tolerance && device >= receivedAt - policy.MaxDeviceAge
            : device <= receivedAt + FutureTolerance && device >= receivedAt - policy.MaxDeviceAge;
        clock?.Observe(device, receivedAt, trusted, trusted && device < receivedAt - policy.Tolerance);
        return trusted
            ? new SampleTime(device, SampleTimeSource.Device, 0, (long)(receivedAt - device).TotalMilliseconds)
            : new SampleTime(receivedAt, SampleTimeSource.ReceiptClockSkew, deviceMs, 0);
    }
}
