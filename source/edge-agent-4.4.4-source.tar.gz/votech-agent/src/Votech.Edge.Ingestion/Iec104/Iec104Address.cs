using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using Votech.Edge.Core.Constants;

namespace Votech.Edge.Ingestion.Iec104;

/// <summary>
/// The IEC 104 address grammar of the shared contract (votech-shared <c>protobuf/v2/iec104_address_vectors.json</c>,
/// tested against the same vectors as the backend and the web):
/// <list type="bullet">
/// <item>decimal, optionally after <c>IOA</c>, <c>IOA:</c> or <c>IOA=</c>: <c>1835306</c>, <c>IOA:1835306</c>;</item>
/// <item>three octets high.mid.low separated by <c>.</c> <c>-</c> <c>/</c> <c>_</c> or a space: <c>28.1.42</c> = 1835306;</item>
/// <item>decimal with thousands separators <c>.</c> <c>,</c> <c>'</c> or a space when that is the only valid reading:
/// <c>1.835.306</c>.</item>
/// </list>
/// Two different valid readings (<c>1.100.200</c>) are refused as ambiguous rather than guessed, and what Excel makes of
/// <c>28.1.42</c> (a date) is refused as such. The backend sends the decimal form; the other forms are read for addresses
/// stored before backend 5.0.0 normalised them.
/// </summary>
public static partial class Iec104Address
{
    public enum Outcome
    {
        Valid,
        Ambiguous,
        Invalid,
    }

    /// <summary>
    /// The result of <see cref="Parse"/>. <see cref="Ioa"/> is set when valid; <see cref="Thousands"/> and
    /// <see cref="Octets"/> are the two readings of an ambiguous address; <see cref="Reason"/> is set when invalid:
    /// <c>empty</c>, <c>out_of_range</c>, <c>date_like</c>, <c>malformed</c>, <c>mixed_separators</c> or
    /// <c>octet_out_of_range</c>.
    /// </summary>
    public readonly record struct Result(Outcome Outcome, int Ioa = 0, int Thousands = 0, int Octets = 0, string? Reason = null)
    {
        public static Result Invalid(string reason) => new(Outcome.Invalid, Reason: reason);
    }

    private const string OctetSeparators = ".-/_ ";
    private const string ThousandsSeparators = ".,' ";
    private const string AllSeparators = ".-/_ ,'";

    public static bool TryParse(string? text, out int ioa)
    {
        var result = Parse(text);
        ioa = result.Ioa;
        return result.Outcome == Outcome.Valid;
    }

    public static Result Parse(string? text)
    {
        var s = Whitespace().Replace((text ?? string.Empty).Normalize(NormalizationForm.FormKC).Trim(), " ");
        var prefix = Prefix().Match(s);
        if (prefix.Success)
        {
            s = s[prefix.Length..];
        }

        if (s.Length == 0)
        {
            return Result.Invalid("empty");
        }

        if (Digits().IsMatch(s))
        {
            return s.Length <= 8 && int.Parse(s, CultureInfo.InvariantCulture) is var value && value is >= 1 and <= Iec104Constants.MaxIoa
                ? new Result(Outcome.Valid, value)
                : Result.Invalid("out_of_range");
        }

        if (DateLike().IsMatch(s))
        {
            return Result.Invalid("date_like");
        }

        s = SpacedSeparator().Replace(s, "$1");
        if (s.Any(c => c is not (>= '0' and <= '9') && !AllSeparators.Contains(c)))
        {
            return Result.Invalid("malformed");
        }

        var separators = s.Where(c => c is not (>= '0' and <= '9')).Distinct().ToList();
        if (separators.Count > 1)
        {
            return Result.Invalid("mixed_separators");
        }

        var sep = separators[0];
        var groups = s.Split(sep);
        if (groups.Any(g => g.Length == 0))
        {
            return Result.Invalid("malformed");
        }

        var octetShaped = OctetSeparators.Contains(sep) && groups.Length == 3 && groups.All(g => g.Length <= 3);
        int? octets = null;
        if (octetShaped)
        {
            var (high, mid, low) = (int.Parse(groups[0], CultureInfo.InvariantCulture), int.Parse(groups[1], CultureInfo.InvariantCulture), int.Parse(groups[2], CultureInfo.InvariantCulture));
            if (high <= 255 && mid <= 255 && low <= 255)
            {
                octets = (high << 16) | (mid << 8) | low;
            }
        }

        long? thousands = null;
        if (ThousandsSeparators.Contains(sep) && groups.Length >= 2 && groups[0].Length <= 3 && groups.Skip(1).All(g => g.Length == 3))
        {
            thousands = long.Parse(string.Concat(groups), CultureInfo.InvariantCulture);
        }

        var octetValid = octets is >= 1 and <= Iec104Constants.MaxIoa;
        var thousandsValid = thousands is >= 1 and <= Iec104Constants.MaxIoa;
        if (octetValid && thousandsValid && octets != thousands)
        {
            return new Result(Outcome.Ambiguous, Thousands: (int)thousands!.Value, Octets: octets!.Value);
        }

        if (octetValid || thousandsValid)
        {
            return new Result(Outcome.Valid, octetValid ? octets!.Value : (int)thousands!.Value);
        }

        if (octetShaped && octets is null)
        {
            return Result.Invalid("octet_out_of_range");
        }

        return octets is not null || thousands is not null ? Result.Invalid("out_of_range") : Result.Invalid("malformed");
    }

    /// <summary>The octet form high.mid.low of an IOA: 1835306 → "28.1.42".</summary>
    public static string ToOctets(int ioa) => $"{(ioa >> 16) & 0xFF}.{(ioa >> 8) & 0xFF}.{ioa & 0xFF}";

    /// <summary>The IOA with its octets in reverse order, what a list written low.mid.high would give: 28.1.42 → 42.1.28.</summary>
    public static int Reverse(int ioa) => ((ioa & 0xFF) << 16) | (ioa & 0xFF00) | ((ioa >> 16) & 0xFF);

    /// <summary>"1835306 (28.1.42)", as addresses appear in the log.</summary>
    public static string Describe(int ioa) => $"{ioa} ({ToOctets(ioa)})";

    [GeneratedRegex(@"\s+")]
    private static partial Regex Whitespace();

    [GeneratedRegex(@"^ioa\s*[:=]?\s*", RegexOptions.IgnoreCase)]
    private static partial Regex Prefix();

    [GeneratedRegex(@"^[0-9]+$")]
    private static partial Regex Digits();

    [GeneratedRegex(@"^([0-9]{4}[-./][0-9]{1,2}[-./][0-9]{1,2}|[0-9]{1,2}[-./][0-9]{1,2}[-./][0-9]{4})$")]
    private static partial Regex DateLike();

    [GeneratedRegex(@"\s*([.\-/_,'])\s*")]
    private static partial Regex SpacedSeparator();
}
