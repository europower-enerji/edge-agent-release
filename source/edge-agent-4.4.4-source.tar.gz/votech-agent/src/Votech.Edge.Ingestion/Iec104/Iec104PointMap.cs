using Votech.Edge.Core.Acquisition;
using Microsoft.Extensions.Logging;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Iec104;

/// <summary>
/// The points of one IEC 104 connection, routed by (common address, information object address). Every station
/// carries its own common address, so stations behind a gateway that reuse the same IOAs never mix (gap B10).
/// Immutable: a configuration change builds a new map, which the poller swaps in.
/// </summary>
public sealed class Iec104PointMap
{
    private readonly Dictionary<(int Ca, int Ioa), AcquiredPoint> _points = [];

    public Iec104PointMap(V2.Connection connection, ILogger logger)
    {
        var stations = new List<(Guid EndpointId, int Ca)>();
        foreach (var station in connection.Stations)
        {
            var ca = (int)station.StationAddress;
            var endpointId = EdgeIds.ToGuid(station.EndpointId);
            stations.Add((endpointId, ca));
            foreach (var point in station.Points)
            {
                var address = Iec104Address.Parse(point.Address);
                if (address.Outcome == Iec104Address.Outcome.Ambiguous)
                {
                    logger.LogWarning(
                        "[IEC104-CONFIG] Point {Code} has address '{Address}', which reads as IOA {Thousands} or as octets {Octets}; it is not read until the address is written unambiguously.",
                        point.Code,
                        point.Address,
                        address.Thousands,
                        Iec104Address.Describe(address.Octets)
                    );
                    continue;
                }

                if (address.Outcome == Iec104Address.Outcome.Invalid)
                {
                    logger.LogWarning(
                        "[IEC104-CONFIG] Point {Code} has address '{Address}', which is not an IOA ({Reason}); it is not read.",
                        point.Code,
                        point.Address,
                        address.Reason
                    );
                    continue;
                }

                var ioa = address.Ioa;

                if (!_points.TryAdd((ca, ioa), new AcquiredPoint(point, endpointId, station.StationAddress)))
                {
                    logger.LogWarning(
                        "[IEC104-CONFIG] Point {Code} repeats CA {CommonAddress} IOA {Ioa} on connection {Connection}; only the first point is read.",
                        point.Code,
                        ca,
                        ioa,
                        connection.Code
                    );
                }
            }
        }

        Stations = stations;
        CommonAddresses = stations.Select(s => s.Ca).Distinct().Order().ToList();
    }

    /// <summary>Every station of the connection with its common address.</summary>
    public IReadOnlyList<(Guid EndpointId, int Ca)> Stations { get; }

    /// <summary>The distinct common addresses, each interrogated on its own.</summary>
    public IReadOnlyList<int> CommonAddresses { get; }

    public int Count => _points.Count;

    public IEnumerable<AcquiredPoint> Points => _points.Values;

    /// <summary>Every point with the (common address, IOA) it is routed by.</summary>
    public IEnumerable<KeyValuePair<(int Ca, int Ioa), AcquiredPoint>> Entries => _points;

    public bool TryGet(int commonAddress, int ioa, out AcquiredPoint point) =>
        _points.TryGetValue((commonAddress, ioa), out point!);

    /// <summary>An IOA in any form of the shared grammar (<see cref="Iec104Address"/>): "1001", "IOA:1001", "28.1.42".</summary>
    public static bool TryParseIoa(string address, out int ioa) => Iec104Address.TryParse(address, out ioa);
}
