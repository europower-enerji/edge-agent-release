using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Ingestion.Iec104;
using Votech.Edge.Ingestion.Modbus;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Services;

/// <summary>Creates the poller of each protocol this agent reads (<see cref="AgentCapabilities.SupportedProtocols"/>).</summary>
public sealed class ConnectionPollerFactory(ILoggerFactory loggerFactory, IOptions<EdgeAgentOptions>? options = null) : IConnectionPollerFactory
{
    private readonly ILoggerFactory _loggerFactory = loggerFactory;
    private readonly ILogger _logger = loggerFactory.CreateLogger<ConnectionPollerFactory>();
    private readonly Iec104AgentOptions _iec104 = options?.Value.Iec104 ?? new Iec104AgentOptions();

    public IConnectionPoller? Create(V2.Connection connection, ISignalSink sink)
    {
        switch (connection.SettingsCase)
        {
            case V2.Connection.SettingsOneofCase.Iec104 when connection.Protocol == V2.Protocol.Iec104:
                return new Iec104ConnectionPoller(connection, sink, _loggerFactory.CreateLogger<Iec104ConnectionPoller>(), agentOptions: _iec104);

            case V2.Connection.SettingsOneofCase.ModbusTcp when connection.Protocol == V2.Protocol.ModbusTcp:
            case V2.Connection.SettingsOneofCase.ModbusRtu when connection.Protocol == V2.Protocol.ModbusRtu:
                return new ModbusConnectionPoller(connection, sink, _loggerFactory.CreateLogger<ModbusConnectionPoller>());

            default:
                _logger.LogWarning(
                    "[CONNECTIONS] Connection {Code} ({EndpointId}) uses {Protocol} with {Settings} settings, which this agent cannot read; it is skipped.",
                    connection.Code,
                    EdgeIds.ToGuid(connection.EndpointId),
                    connection.Protocol,
                    connection.SettingsCase
                );
                return null;
        }
    }
}
