using System.Globalization;
using System.Net;
using System.Net.Http.Headers;
using Google.Protobuf;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Entities;
using Votech.Edge.Core.Interfaces;
using Votech.Edge.Storage;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Services;

/// <summary>
/// Fetches the v2 configuration of one site (<c>GET api/v1/edge/sites/{siteId}/configuration</c>, protobuf, with the
/// agent key, and <c>X-Edge-Tenant-Id</c> when <c>TENANT_ID</c> is set) and keeps the site's runtime on the last good
/// one:
/// <list type="bullet">
/// <item>The running revision goes out as <c>If-None-Match</c>; 304 keeps the configuration and counts as contact
/// with the backend.</item>
/// <item>A body that is not a configuration of this site, its organisation and schema version is logged and never
/// replaces the running one.</item>
/// <item>Without the backend, the cached configuration is used while it is younger than
/// <c>MaxOfflineCacheHours</c> and the clock has not gone back; otherwise the agent stops, because an outdated
/// configuration may no longer match the field.</item>
/// <item>A 403 saying the agent does not serve the site (<c>ERRORS.FORBIDDEN_EDGE_SITE_MISMATCH</c>) stops the site's
/// runtime; the agent's other sites keep running. Any other 401 or 403 keeps the site on its cached configuration: the
/// agent's <c>KeyRefusalPolicy</c> decides whether a refused key stops the sites (X-01).</item>
/// <item>A reload command for the running revision is skipped; the configuration is also fetched every
/// <see cref="EdgeContractConstants.FallbackPollSeconds"/> seconds.</item>
/// </list>
/// </summary>
public sealed class EdgeConfigurationSource(
    HttpClient httpClient,
    IDbContextFactory<EdgeDbContext> contextFactory,
    IOptions<EdgeAgentOptions> options,
    ILogger<EdgeConfigurationSource> logger,
    IHostApplicationLifetime? appLifetime = null,
    TimeProvider? timeProvider = null
) : BackgroundService, IEdgeConfigurationSource
{
    private readonly HttpClient _httpClient = httpClient;
    private readonly IDbContextFactory<EdgeDbContext> _contextFactory = contextFactory;
    private readonly EdgeAgentOptions _options = options.Value;
    private readonly ILogger<EdgeConfigurationSource> _logger = logger;
    private readonly IHostApplicationLifetime? _appLifetime = appLifetime;
    private readonly TimeProvider _time = timeProvider ?? TimeProvider.System;
    private readonly SemaphoreSlim _syncLock = new(1, 1);
    private V2.EdgeConfiguration? _current;

    public V2.EdgeConfiguration? Current => Volatile.Read(ref _current);

    public event EventHandler<V2.EdgeConfiguration>? ConfigurationChanged;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(EdgeContractConstants.FallbackPollSeconds), _time);
        do
        {
            try
            {
                await SyncAsync(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                return;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "[SYNC-CONFIG] Configuration sync failed; retrying on the next poll.");
            }
        } while (await timer.WaitForNextTickAsync(stoppingToken).ConfigureAwait(false));
    }

    public async Task ReloadAsync(string? revision, CancellationToken ct = default)
    {
        if (!string.IsNullOrEmpty(revision) && revision == Current?.Revision)
        {
            _logger.LogInformation(
                "[SYNC-CONFIG] Reload command for revision {Revision} skipped: it is the running configuration.",
                Short(revision)
            );
            return;
        }

        await SyncAsync(ct);
    }

    public async Task SyncAsync(CancellationToken ct = default)
    {
        await _syncLock.WaitAsync(ct);
        try
        {
            await FetchAsync(ct);
        }
        finally
        {
            _syncLock.Release();
        }
    }

    private async Task FetchAsync(CancellationToken ct)
    {
        var path = string.Format(CultureInfo.InvariantCulture, EdgeContractConstants.ConfigurationPathFormat, _options.SiteId);
        using var request = new HttpRequestMessage(HttpMethod.Get, path);
        request.Headers.TryAddWithoutValidation(EdgeContractConstants.AgentKeyHeader, _options.AgentKey);
        if (!string.IsNullOrEmpty(_options.TenantId))
        {
            request.Headers.TryAddWithoutValidation(EdgeContractConstants.TenantIdHeader, _options.TenantId);
        }
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(EdgeContractConstants.ProtobufContentType));
        var known = Current?.Revision ?? (await ReadCacheAsync(ct))?.Revision;
        if (!string.IsNullOrEmpty(known))
        {
            request.Headers.IfNoneMatch.Add(new EntityTagHeaderValue($"\"{known}\""));
        }

        HttpResponseMessage response;
        try
        {
            response = await _httpClient.SendAsync(request, ct);
        }
        catch (Exception ex) when (!ct.IsCancellationRequested)
        {
            _logger.LogWarning(
                ex,
                "[SYNC-CONFIG] The backend at {BaseAddress} cannot be reached. Running on the cached configuration.",
                _httpClient.BaseAddress
            );
            await UseCacheAsync(ct);
            return;
        }

        using (response)
        {
            if (response.StatusCode == HttpStatusCode.NotModified)
            {
                await TouchCacheAsync(ct);
                if (Current == null)
                {
                    await UseCacheAsync(ct);
                }

                _logger.LogDebug("[SYNC-CONFIG] Configuration unchanged (revision {Revision}).", Short(known));
                return;
            }

            if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
            {
                var code = await EdgeRefusal.ReadCodeAsync(response, ct);
                if (response.StatusCode == HttpStatusCode.Forbidden && code == EdgeContractConstants.SiteNotServedCode)
                {
                    _logger.LogWarning(
                        "[SYNC-CONFIG] The backend says agent key {KeyPrefix} does not serve site {SiteId} (any more; see the Site connectors page). This site stops; the agent's other sites keep running.",
                        EdgeAgentKey.Prefix(_options.AgentKey),
                        _options.SiteId
                    );
                    _appLifetime?.StopApplication();
                    return;
                }

                _logger.LogWarning(
                    "[SYNC-CONFIG] The backend refused the configuration of site {SiteId} for agent key {KeyPrefix} (HTTP {StatusCode} {Code}). Running on the cached configuration; [AUTH] lines say what happens to the key.",
                    _options.SiteId,
                    EdgeAgentKey.Prefix(_options.AgentKey),
                    (int)response.StatusCode,
                    code ?? "without a code"
                );
                await UseCacheAsync(ct);
                return;
            }

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogWarning(
                    "[SYNC-CONFIG] The backend answered HTTP {StatusCode} for the configuration. Running on the cached configuration.",
                    (int)response.StatusCode
                );
                await UseCacheAsync(ct);
                return;
            }

            var payload = await response.Content.ReadAsByteArrayAsync(ct);
            var contentType = response.Content.Headers.ContentType?.MediaType;
            if (!string.Equals(contentType, EdgeContractConstants.ProtobufContentType, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogError(
                    "[SYNC-CONFIG] The configuration response has content type {ContentType}, not {Expected}. Keeping the last good configuration.",
                    contentType,
                    EdgeContractConstants.ProtobufContentType
                );
                await UseCacheAsync(ct);
                return;
            }

            if (!TryRead(payload, out var configuration, out var reason))
            {
                _logger.LogError(
                    "[SYNC-CONFIG] The configuration response cannot be used ({Reason}). Keeping the last good configuration.",
                    reason
                );
                await UseCacheAsync(ct);
                return;
            }

            await SaveCacheAsync(configuration, payload, ct);
            Apply(configuration, "the backend");
        }
    }

    /// <summary>
    /// Reads a configuration and checks that this agent can run it: protobuf, schema version
    /// <see cref="EdgeContractConstants.SchemaVersion"/>, the agent's site and a revision.
    /// </summary>
    internal bool TryRead(byte[] payload, out V2.EdgeConfiguration configuration, out string reason)
    {
        try
        {
            configuration = V2.EdgeConfiguration.Parser.ParseFrom(payload);
        }
        catch (InvalidProtocolBufferException ex)
        {
            configuration = new V2.EdgeConfiguration();
            reason = $"not a protobuf EdgeConfiguration: {ex.Message}";
            return false;
        }

        if (configuration.SchemaVersion != EdgeContractConstants.SchemaVersion)
        {
            reason = $"schema version {configuration.SchemaVersion}, this agent reads {EdgeContractConstants.SchemaVersion}";
            return false;
        }

        if (!Guid.TryParse(_options.SiteId, out var siteId) || EdgeIds.ToGuid(configuration.SiteId) != siteId)
        {
            reason = $"site {EdgeIds.ToGuid(configuration.SiteId)} is not the agent's site {_options.SiteId}";
            return false;
        }

        if (Guid.TryParse(_options.SiteTenantId, out var tenantId) && EdgeIds.ToGuid(configuration.TenantId) != tenantId)
        {
            reason = $"organisation {EdgeIds.ToGuid(configuration.TenantId)} is not the site's organisation {_options.SiteTenantId}";
            return false;
        }

        if (string.IsNullOrEmpty(configuration.Revision))
        {
            reason = "no revision";
            return false;
        }

        reason = string.Empty;
        return true;
    }

    private void Apply(V2.EdgeConfiguration configuration, string source)
    {
        var previous = Interlocked.Exchange(ref _current, configuration);
        if (previous?.Revision == configuration.Revision)
        {
            return;
        }

        var stations = configuration.Connections.Sum(c => c.Stations.Count);
        var points = configuration.Connections.Sum(c => c.Stations.Sum(s => s.Points.Count));
        _logger.LogInformation(
            "[SYNC-CONFIG] Running configuration revision {Revision} from {Source}: {Connections} connection(s), {Stations} station(s), {Points} point(s), {Unsupported} endpoint(s) not acquired.",
            Short(configuration.Revision),
            source,
            configuration.Connections.Count,
            stations,
            points,
            configuration.Unsupported.Count
        );
        foreach (var unsupported in configuration.Unsupported)
        {
            _logger.LogWarning(
                "[SYNC-CONFIG] Endpoint {Code} ({Protocol}) is not acquired: {Reason}.",
                unsupported.Code,
                unsupported.Protocol,
                unsupported.Reason
            );
        }

        ConfigurationChanged?.Invoke(this, configuration);
    }

    /// <summary>
    /// Runs on the cached configuration when nothing better is available. The cache is refused, and the agent stopped,
    /// when the clock went back past the last contact (it would stretch the offline window) or the last contact is
    /// older than <c>MaxOfflineCacheHours</c>.
    /// </summary>
    private async Task UseCacheAsync(CancellationToken ct)
    {
        var cached = await ReadCacheAsync(ct);
        if (cached == null)
        {
            if (Current == null)
            {
                _logger.LogWarning(
                    "[SYNC-CONFIG] No cached configuration for site {SiteId}; nothing is read until the backend answers.",
                    _options.SiteId
                );
            }

            return;
        }

        // An outdated configuration (or one dated in the future: the clock went back) may no longer match the field, so
        // the agent stops instead of reading with it.
        var now = _time.GetUtcNow().UtcDateTime;
        var fetchedAt = DateTime.SpecifyKind(cached.FetchedAt, DateTimeKind.Utc);
        var age = now - fetchedAt;
        if (age < TimeSpan.Zero || age > TimeSpan.FromHours(_options.MaxOfflineCacheHours))
        {
            _logger.LogCritical(
                "[SYNC-CONFIG] The server cannot be reached and the cached configuration was fetched at {FetchedAtUtc} ({CacheAgeHours:F1} h ago, {MaxHours} h allowed). It may no longer match the field, so the agent stops. Check the connection to the server, and the computer clock.",
                fetchedAt,
                age.TotalHours,
                _options.MaxOfflineCacheHours
            );
            _appLifetime?.StopApplication();
            return;
        }

        if (Current != null)
        {
            return;
        }

        if (!TryRead(cached.Payload, out var configuration, out var reason))
        {
            _logger.LogError("[SYNC-CONFIG] The cached configuration cannot be used ({Reason}).", reason);
            return;
        }

        Apply(configuration, $"the local cache ({age.TotalHours:F1} h old, {_options.MaxOfflineCacheHours} h allowed)");
    }

    private async Task<CachedEdgeConfiguration?> ReadCacheAsync(CancellationToken ct)
    {
        try
        {
            await using var db = await _contextFactory.CreateDbContextAsync(ct);
            return await db.EdgeConfigurationCache.AsNoTracking().FirstOrDefaultAsync(c => c.Id == CachedEdgeConfiguration.SingletonId, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogWarning(ex, "[SYNC-CONFIG] The cached configuration cannot be read.");
            return null;
        }
    }

    private async Task SaveCacheAsync(V2.EdgeConfiguration configuration, byte[] payload, CancellationToken ct)
    {
        try
        {
            await using var db = await _contextFactory.CreateDbContextAsync(ct);
            var cached = await db.EdgeConfigurationCache.FirstOrDefaultAsync(c => c.Id == CachedEdgeConfiguration.SingletonId, ct);
            if (cached == null)
            {
                cached = new CachedEdgeConfiguration();
                db.EdgeConfigurationCache.Add(cached);
            }

            cached.Revision = configuration.Revision;
            cached.SchemaVersion = (int)configuration.SchemaVersion;
            cached.Payload = payload;
            cached.FetchedAt = _time.GetUtcNow().UtcDateTime;
            await db.SaveChangesAsync(ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogWarning(ex, "[SYNC-CONFIG] The configuration could not be cached; it is used anyway.");
        }
    }

    private async Task TouchCacheAsync(CancellationToken ct)
    {
        try
        {
            await using var db = await _contextFactory.CreateDbContextAsync(ct);
            var now = _time.GetUtcNow().UtcDateTime;
            await db.EdgeConfigurationCache
                .Where(c => c.Id == CachedEdgeConfiguration.SingletonId)
                .ExecuteUpdateAsync(setters => setters.SetProperty(c => c.FetchedAt, now), ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            _logger.LogWarning(ex, "[SYNC-CONFIG] The time of the last configuration check could not be stored.");
        }
    }

    private static string Short(string? revision) =>
        string.IsNullOrEmpty(revision) ? "(none)" : revision.Length > 12 ? revision[..12] : revision;

    public override void Dispose()
    {
        _syncLock.Dispose();
        base.Dispose();
    }
}
