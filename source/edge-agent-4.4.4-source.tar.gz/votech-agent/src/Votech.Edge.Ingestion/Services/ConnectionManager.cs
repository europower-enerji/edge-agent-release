using System.Collections.Concurrent;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Interfaces;
using Microsoft.Extensions.Logging;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Services;

/// <summary>
/// Runs one <see cref="IConnectionPoller"/> per connection of the running v2 configuration, keyed by the connection's
/// root endpoint id. A new revision is applied per connection (<see cref="EdgeConfigurationDiff"/>): a changed
/// protocol or connection setting reopens the link, a change of stations or points is swapped in on the open link, and
/// untouched connections keep running. Revisions are applied one at a time, in the order they arrive, and never while a
/// one-shot probe holds a socket, so each station sees one connection from this agent at a time.
/// </summary>
public sealed class ConnectionManager(
    IEdgeConfigurationSource configurationSource,
    IConnectionPollerFactory pollerFactory,
    ISignalSink sink,
    ILogger<ConnectionManager> logger
) : IConnectionManager, IAsyncDisposable
{
    private static readonly TimeSpan StopTimeout = TimeSpan.FromSeconds(3);

    private readonly IEdgeConfigurationSource _configurationSource = configurationSource;
    private readonly IConnectionPollerFactory _pollerFactory = pollerFactory;
    private readonly ISignalSink _sink = sink;
    private readonly ILogger<ConnectionManager> _logger = logger;
    private readonly ConcurrentDictionary<Guid, Session> _sessions = new();
    private readonly SemaphoreSlim _applyLock = new(1, 1);
    private V2.EdgeConfiguration? _running;
    private bool _stopped;

    private sealed record Session(IConnectionPoller Poller, CancellationTokenSource Cts, Task Task);

    public IReadOnlyCollection<IConnectionPoller> Connections => _sessions.Values.Select(s => s.Poller).ToList();

    public string RunningRevision => Volatile.Read(ref _running)?.Revision ?? string.Empty;

    public async Task StartAsync(CancellationToken ct = default)
    {
        _configurationSource.ConfigurationChanged += OnConfigurationChanged;
        if (_configurationSource.Current is { } current)
        {
            await ApplyAsync(current);
        }
    }

    public async Task StopAsync(CancellationToken ct = default)
    {
        _configurationSource.ConfigurationChanged -= OnConfigurationChanged;
        await _applyLock.WaitAsync(CancellationToken.None);
        try
        {
            _stopped = true;
            await Task.WhenAll(_sessions.Keys.ToList().Select(StopSessionAsync));
        }
        finally
        {
            _applyLock.Release();
        }
    }

    public async Task<T?> ProbeIfIdleAsync<T>(Guid rootEndpointId, Func<CancellationToken, Task<T>> probe, CancellationToken ct)
        where T : class
    {
        await _applyLock.WaitAsync(ct);
        try
        {
            return _sessions.ContainsKey(rootEndpointId) ? null : await probe(ct);
        }
        finally
        {
            _applyLock.Release();
        }
    }

    private void OnConfigurationChanged(object? sender, V2.EdgeConfiguration configuration) =>
        _ = ApplyAsync(configuration);

    /// <summary>Brings the running pollers to <paramref name="target"/>.</summary>
    internal async Task ApplyAsync(V2.EdgeConfiguration target)
    {
        await _applyLock.WaitAsync(CancellationToken.None);
        try
        {
            if (_stopped || _running?.Revision == target.Revision)
            {
                return;
            }

            var diff = EdgeConfigurationDiff.Between(_running, target);
            await Task.WhenAll(diff.Removed.Concat(diff.Reconnect.Select(c => EdgeIds.ToGuid(c.EndpointId))).Select(StopSessionAsync));
            foreach (var connection in diff.Reconnect.Concat(diff.Added))
            {
                StartSession(connection);
            }

            foreach (var connection in diff.Repoint)
            {
                if (_sessions.TryGetValue(EdgeIds.ToGuid(connection.EndpointId), out var session))
                {
                    session.Poller.UpdatePoints(connection);
                }
                else
                {
                    StartSession(connection);
                }
            }

            Volatile.Write(ref _running, target);
            _logger.LogInformation(
                "[CONNECTIONS] Revision {Revision} applied: {Added} started, {Removed} stopped, {Reconnected} reconnected, {Repointed} updated on the open link; {Running} running.",
                target.Revision.Length > 12 ? target.Revision[..12] : target.Revision,
                diff.Added.Count,
                diff.Removed.Count,
                diff.Reconnect.Count,
                diff.Repoint.Count,
                _sessions.Count
            );
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "[CONNECTIONS] Applying configuration revision {Revision} failed.", target.Revision);
        }
        finally
        {
            _applyLock.Release();
        }
    }

    private void StartSession(V2.Connection connection)
    {
        var poller = _pollerFactory.Create(connection, _sink);
        if (poller == null)
        {
            return;
        }

        var cts = new CancellationTokenSource();
        var task = Task.Run(async () =>
        {
            try
            {
                await poller.RunAsync(cts.Token);
            }
            catch (OperationCanceledException) when (cts.IsCancellationRequested)
            {
                // Stopped
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "[CONNECTIONS] The poller of connection {Code} ({EndpointId}) stopped with an error.", connection.Code, poller.EndpointId);
            }
        });
        _sessions[poller.EndpointId] = new Session(poller, cts, task);
        _logger.LogInformation(
            "[CONNECTIONS] Started {Protocol} connection {Code} ({EndpointId}): {Stations} station(s), {Points} point(s).",
            connection.Protocol,
            connection.Code,
            poller.EndpointId,
            connection.Stations.Count,
            connection.Stations.Sum(s => s.Points.Count)
        );
    }

    private async Task StopSessionAsync(Guid endpointId)
    {
        if (!_sessions.TryRemove(endpointId, out var session))
        {
            return;
        }

        try
        {
            await session.Cts.CancelAsync();
            await Task.WhenAny(session.Task, Task.Delay(StopTimeout));
            await session.Poller.DisposeAsync();
            _logger.LogInformation("[CONNECTIONS] Stopped connection {EndpointId}.", endpointId);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "[CONNECTIONS] Stopping connection {EndpointId} failed.", endpointId);
        }
        finally
        {
            session.Cts.Dispose();
        }
    }

    public async ValueTask DisposeAsync()
    {
        await StopAsync();
        _applyLock.Dispose();
    }
}
