using System.Net;
using System.Text.Json;
using System.Text.RegularExpressions;
using Votech.Edge.Core.Constants;

namespace Votech.Edge.Ingestion.Services;

/// <summary>
/// Reads why the backend refused an edge request: the <c>code</c> of its problem+json body (votech-shared
/// <c>protobuf/v2/edge_config.proto</c>, "Refusals"). Only the three key codes of a 401 say that the agent key is wrong
/// (X-01); a refusal without a code may come from a proxy or an older backend.
/// </summary>
public static partial class EdgeRefusal
{
    private const int MaxBodyLength = 16_384;

    /// <summary>The refusal's code, or null when the body has none (or one that is not a plain code, so it is never logged).</summary>
    public static async Task<string?> ReadCodeAsync(HttpResponseMessage response, CancellationToken ct)
    {
        try
        {
            var body = await response.Content.ReadAsStringAsync(ct);
            if (body.Length == 0 || body.Length > MaxBodyLength)
            {
                return null;
            }

            using var document = JsonDocument.Parse(body);
            return document.RootElement.ValueKind == JsonValueKind.Object
                && document.RootElement.TryGetProperty("code", out var code)
                && code.ValueKind == JsonValueKind.String
                && CodeFormat().IsMatch(code.GetString()!)
                    ? code.GetString()
                    : null;
        }
        catch (JsonException)
        {
            return null;
        }
    }

    /// <summary>True for a 401 that says the key itself is wrong; only such refusals can stop the agent's sites.</summary>
    public static bool IsKeyRefusal(HttpStatusCode status, string? code) =>
        status == HttpStatusCode.Unauthorized
        && code is EdgeContractConstants.KeyInvalidCode or EdgeContractConstants.KeyRevokedCode or EdgeContractConstants.KeyTenantMismatchCode;

    [GeneratedRegex("^[A-Z0-9_.]{1,64}$", RegexOptions.CultureInvariant)]
    private static partial Regex CodeFormat();
}
