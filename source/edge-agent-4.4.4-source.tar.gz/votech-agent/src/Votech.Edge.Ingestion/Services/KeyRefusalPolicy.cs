using Votech.Edge.Core.Constants;

namespace Votech.Edge.Ingestion.Services;

/// <summary>
/// What the agent does with its sites after each answer about them (X-01, decision Q3: the agent never stops collecting
/// on one error).
/// <list type="bullet">
/// <item>A fresh or a cached assignment is run; without either the running sites keep running.</item>
/// <item>A refusal (401/403) keeps the running sites, starts those of the local copy, and asks again after 1 minute,
/// doubling to 15 minutes.</item>
/// <item>Only a key refusal (a 401 with a key code) that keeps coming <see cref="AgentConstants.KeyRefusedStopCount"/>
/// times in a row, over at least <see cref="AgentConstants.KeyRefusedStopMinutes"/> minutes, stops every site. The
/// process keeps running and asking, so Docker does not restart it into the RTUs again. The sites start again only on
/// a fresh assignment from the backend.</item>
/// </list>
/// </summary>
public sealed class KeyRefusalPolicy
{
    public enum Action
    {
        /// <summary>Run the result's assignment: start new sites, stop those no longer assigned.</summary>
        Apply,

        /// <summary>Change nothing: the running sites keep running, and stopped ones stay stopped.</summary>
        Keep,

        /// <summary>Stop every site: the key was refused for long enough.</summary>
        StopAll,
    }

    /// <param name="Action">What to do with the sites.</param>
    /// <param name="Delay">When to ask the backend again.</param>
    /// <param name="Refusals">Refusals in a row so far (0 after any other answer).</param>
    public readonly record struct Decision(Action Action, TimeSpan Delay, int Refusals);

    private static readonly TimeSpan Poll = TimeSpan.FromSeconds(EdgeContractConstants.FallbackPollSeconds);
    private static readonly TimeSpan StopAfter = TimeSpan.FromMinutes(AgentConstants.KeyRefusedStopMinutes);

    private int _refusals;
    private int _keyRefusals;
    private DateTimeOffset _keyRefusedSince;

    /// <summary>The sites were stopped for a refused key and stay stopped until the backend accepts it again.</summary>
    public bool Stopped { get; private set; }

    public Decision Next(AgentAssignmentSource.Result result, DateTimeOffset now)
    {
        if (result.Outcome != AgentAssignmentSource.Outcome.Refused)
        {
            _refusals = 0;
            _keyRefusals = 0;
            if (result.Outcome == AgentAssignmentSource.Outcome.Fresh)
            {
                Stopped = false;
            }

            var run = !Stopped && result.Assignment != null;
            return new Decision(run ? Action.Apply : Action.Keep, Poll, 0);
        }

        _refusals++;
        var delay = TimeSpan.FromSeconds(Math.Min(
            AgentConstants.RefusedRetryMinDelaySec * Math.Pow(2, Math.Min(_refusals - 1, 16)),
            AgentConstants.RefusedRetryMaxDelaySec));

        if (result.KeyRefused)
        {
            if (_keyRefusals++ == 0)
            {
                _keyRefusedSince = now;
            }

            if (Stopped || (_keyRefusals >= AgentConstants.KeyRefusedStopCount && now - _keyRefusedSince >= StopAfter))
            {
                Stopped = true;
                return new Decision(Action.StopAll, delay, _refusals);
            }
        }
        else
        {
            _keyRefusals = 0;
        }

        return new Decision(!Stopped && result.Assignment != null ? Action.Apply : Action.Keep, delay, _refusals);
    }
}
