using System.Diagnostics;
using System.IO.Ports;
using System.Net.Sockets;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Interfaces;
using Votech.Edge.Ingestion.Modbus;
using Microsoft.Extensions.Logging;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Services;

/// <summary>The answer to a probe, before it becomes a <c>CommandAck</c>.</summary>
public sealed record ProbeOutcome(bool Success, string ProtocolResponse, string? Error);

/// <summary>
/// Answers v2 <c>ProbeCommand</c>s for configured endpoints only, so a probe can never be used to reach another address
/// on the plant network:
/// <list type="bullet">
/// <item>An endpoint that is not a connection or station of the running configuration is refused
/// (<see cref="NotConfigured"/>), and so is an expired command.</item>
/// <item>An endpoint whose connection is being read is answered from that connection's health; no second socket is
/// opened (many RTUs accept a single master).</item>
/// <item>Otherwise one short probe uses the connection's configured settings: STARTDT for IEC 104, one register read
/// for Modbus TCP, opening the serial port for Modbus RTU. It waits for a revision being applied, and is answered from
/// the poller instead when that revision started one (<see cref="IConnectionManager.ProbeIfIdleAsync{T}"/>).</item>
/// </list>
/// </summary>
public sealed class EndpointProbeService(
    IEdgeConfigurationSource configuration,
    IConnectionManager connections,
    ILogger<EndpointProbeService> logger,
    Func<V2.Connection, V2.Station?, CancellationToken, Task<ProbeOutcome>>? oneShot = null
) : IProbeHandler
{
    public const string NotConfigured = "ENDPOINT_NOT_CONFIGURED";
    public const string Expired = "COMMAND_EXPIRED";

    private static readonly TimeSpan OneShotTimeout = TimeSpan.FromMilliseconds(ModbusConstants.DefaultTimeoutMs);

    private readonly IEdgeConfigurationSource _configuration = configuration;
    private readonly IConnectionManager _connections = connections;
    private readonly ILogger<EndpointProbeService> _logger = logger;
    private readonly Func<V2.Connection, V2.Station?, CancellationToken, Task<ProbeOutcome>> _oneShot = oneShot ?? ProbeOnceAsync;

    public async Task<V2.CommandAck> ProbeAsync(V2.ProbeCommand command, DateTimeOffset now, CancellationToken ct)
    {
        var endpointId = EdgeIds.ToGuid(command.EndpointId);
        var outcome = await AnswerAsync(command, endpointId, now, ct);
        return new V2.CommandAck
        {
            CommandId = command.CommandId,
            EndpointId = command.EndpointId,
            Success = outcome.Success,
            ProtocolResponse = outcome.ProtocolResponse,
            Error = outcome.Error ?? string.Empty,
            TimestampMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds(),
        };
    }

    private async Task<ProbeOutcome> AnswerAsync(V2.ProbeCommand command, Guid endpointId, DateTimeOffset now, CancellationToken ct)
    {
        if (command.ExpiresAtMs > 0 && now.ToUnixTimeMilliseconds() > command.ExpiresAtMs)
        {
            _logger.LogWarning("[PROBE] Probe of endpoint {EndpointId} expired before it arrived; ignored.", endpointId);
            return new ProbeOutcome(false, Expired, "The probe command expired.");
        }

        var connection = _configuration.Current?.Connections.FirstOrDefault(c =>
            EdgeIds.ToGuid(c.EndpointId) == endpointId || c.Stations.Any(s => EdgeIds.ToGuid(s.EndpointId) == endpointId));
        if (connection == null)
        {
            _logger.LogWarning(
                "[PROBE] Refused a probe of endpoint {EndpointId}: it is not in the running configuration, and the agent only contacts configured endpoints.",
                endpointId
            );
            return new ProbeOutcome(false, NotConfigured, "The endpoint is not in the agent's configuration.");
        }

        var rootId = EdgeIds.ToGuid(connection.EndpointId);
        if (FromRunningConnection(connection, rootId, endpointId) is { } running)
        {
            return running;
        }

        var station = connection.Stations.FirstOrDefault(s => EdgeIds.ToGuid(s.EndpointId) == endpointId)
            ?? connection.Stations.FirstOrDefault();
        var watch = Stopwatch.StartNew();
        ProbeOutcome result;
        try
        {
            var oneShot = await _connections.ProbeIfIdleAsync(rootId, token => _oneShot(connection, station, token), ct);
            if (oneShot == null)
            {
                // A revision started the connection while the probe waited: no second socket.
                return FromRunningConnection(connection, rootId, endpointId)
                    ?? new ProbeOutcome(false, DeviceDiagnosticReason.Connecting, "The connection is being restarted.");
            }

            result = oneShot;
        }
        catch (Exception ex) when (ex is not OperationCanceledException || !ct.IsCancellationRequested)
        {
            result = new ProbeOutcome(false, DeviceDiagnosticReason.UnreachablePhysicalDevice, ex is OperationCanceledException ? "The probe timed out." : ex.Message);
        }

        _logger.LogInformation(
            "[PROBE] One-shot probe of {Code} ({EndpointId}) with its configured settings: success={Success} {Response} in {Elapsed} ms {Error}",
            connection.Code,
            endpointId,
            result.Success,
            result.ProtocolResponse,
            watch.ElapsedMilliseconds,
            result.Error
        );
        return result;
    }

    /// <summary>The health of <paramref name="endpointId"/> from the poller of its connection; null when none runs.</summary>
    private ProbeOutcome? FromRunningConnection(V2.Connection connection, Guid rootId, Guid endpointId)
    {
        var poller = _connections.Connections.FirstOrDefault(p => p.EndpointId == rootId);
        if (poller == null)
        {
            return null;
        }

        var health = poller.Health.FirstOrDefault(h => h.EndpointId == endpointId)
            ?? new EndpointHealth(endpointId, poller.IsConnected, null, poller.IsConnected ? DeviceDiagnosticReason.ConnectedHealthy : DeviceDiagnosticReason.UnreachablePhysicalDevice, null);
        _logger.LogInformation(
            "[PROBE] Endpoint {EndpointId} answered from its running connection {Code}: connected={Connected} ({Reason}).",
            endpointId,
            connection.Code,
            health.Connected,
            health.ReasonCode
        );
        return new ProbeOutcome(health.Connected, health.ReasonCode, health.Connected ? null : health.Error ?? health.ReasonCode);
    }

    /// <summary>One short probe of a configured connection that is not being read.</summary>
    internal static async Task<ProbeOutcome> ProbeOnceAsync(V2.Connection connection, V2.Station? station, CancellationToken ct)
    {
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        switch (connection.SettingsCase)
        {
            case V2.Connection.SettingsOneofCase.Iec104:
            {
                timeout.CancelAfter(OneShotTimeout);
                var port = connection.Iec104.Port > 0 ? (int)connection.Iec104.Port : Iec104Constants.DefaultPort;
                using var client = new TcpClient();
                await client.ConnectAsync(connection.Iec104.Host, port, timeout.Token);
                var stream = client.GetStream();
                byte[] startDtAct = [0x68, 0x04, 0x07, 0x00, 0x00, 0x00];
                await stream.WriteAsync(startDtAct, timeout.Token);
                var answer = new byte[6];
                var read = await stream.ReadAsync(answer, timeout.Token);
                return read == 6 && answer[0] == 0x68 && (answer[2] & 0x0B) == 0x0B
                    ? new ProbeOutcome(true, "STARTDT_CON", null)
                    : new ProbeOutcome(false, DeviceDiagnosticReason.ConfigurationMismatch, $"No STARTDT confirmation ({read} bytes).");
            }

            case V2.Connection.SettingsOneofCase.ModbusTcp:
            {
                var settings = connection.ModbusTcp;
                timeout.CancelAfter(ModbusPolling.TimeoutMs(settings.Polling));
                using var link = await new ModbusTcpLinkFactory(settings).OpenAsync(timeout.Token);
                var unit = (byte)Math.Min(station?.StationAddress ?? 1, byte.MaxValue);
                await link.ReadRegistersAsync(unit, ModbusTable.HoldingRegister, 0, 1).WaitAsync(timeout.Token);
                return new ProbeOutcome(true, "FC03 OK", null);
            }

            case V2.Connection.SettingsOneofCase.ModbusRtu:
            {
                var settings = connection.ModbusRtu;
                if (!SerialPort.GetPortNames().Contains(settings.SerialPort, StringComparer.OrdinalIgnoreCase))
                {
                    return new ProbeOutcome(false, DeviceDiagnosticReason.ConfigurationMismatch, $"Serial port '{settings.SerialPort}' does not exist on this host.");
                }

                using var link = await new ModbusRtuLinkFactory(settings).OpenAsync(timeout.Token);
                return new ProbeOutcome(true, "SERIAL_PORT_OPEN", null);
            }

            default:
                return new ProbeOutcome(false, DeviceDiagnosticReason.ConfigurationMismatch, $"{connection.Protocol} cannot be probed by this agent.");
        }
    }
}
