using System.Net;
using System.Net.Http.Headers;
using Google.Protobuf;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Services;

/// <summary>
/// Asks the backend which sites this agent serves (<c>GET api/v1/edge/agent</c>, protobuf <c>AgentAssignment</c>, with
/// the agent key and, when <c>TENANT_ID</c> is set, <c>X-Edge-Tenant-Id</c>). The answer is kept in
/// <c>agent-assignment.pb</c> next to the site databases, so the agent restarts its sites without the backend for up to
/// <c>MaxOfflineCacheHours</c>. A refusal (401/403) comes with that local copy too and its <c>code</c>: whether it ends
/// the agent's sites is the <see cref="KeyRefusalPolicy"/>'s decision (X-01).
/// </summary>
public sealed class AgentAssignmentSource(
    HttpClient httpClient,
    IOptions<EdgeAgentOptions> options,
    ILogger<AgentAssignmentSource> logger,
    string? cacheFile,
    TimeProvider? timeProvider = null
)
{
    public enum Outcome
    {
        /// <summary>From the backend.</summary>
        Fresh,

        /// <summary>From the local copy: the backend cannot be reached.</summary>
        Cached,

        /// <summary>
        /// The backend refused the agent (401/403); <see cref="Result.Reason"/> and <see cref="Result.Code"/> say why, and
        /// <see cref="Result.Assignment"/> is the local copy when there is a usable one.
        /// </summary>
        Refused,

        /// <summary>Neither the backend nor a usable local copy; <see cref="Result.Reason"/> says why.</summary>
        Unavailable,
    }

    /// <param name="Code">The <c>code</c> of a refusal (votech-shared <c>edge_config.proto</c>, "Refusals"); null without one.</param>
    /// <param name="KeyRefused">The refusal is a 401 with a key code: the key itself is wrong, not the backend.</param>
    public sealed record Result(Outcome Outcome, V2.AgentAssignment? Assignment, string? Reason, string? Code = null, bool KeyRefused = false)
    {
        public IReadOnlyList<AgentSite> Sites => Assignment is null ? [] : SitesOf(Assignment);
    }

    private readonly EdgeAgentOptions _options = options.Value;
    private readonly TimeProvider _time = timeProvider ?? TimeProvider.System;

    public async Task<Result> FetchAsync(CancellationToken ct)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, EdgeContractConstants.AgentAssignmentPath);
        request.Headers.TryAddWithoutValidation(EdgeContractConstants.AgentKeyHeader, _options.AgentKey);
        if (!string.IsNullOrEmpty(_options.TenantId))
        {
            request.Headers.TryAddWithoutValidation(EdgeContractConstants.TenantIdHeader, _options.TenantId);
        }

        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue(EdgeContractConstants.ProtobufContentType));
        HttpResponseMessage response;
        try
        {
            response = await httpClient.SendAsync(request, ct);
        }
        catch (Exception ex) when (!ct.IsCancellationRequested)
        {
            return FromCache($"the backend at {httpClient.BaseAddress} cannot be reached ({ex.Message})");
        }

        using (response)
        {
            if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
            {
                var code = await EdgeRefusal.ReadCodeAsync(response, ct);
                return FromCache(RefusalReason(response.StatusCode, code), Outcome.Refused) with
                {
                    Code = code,
                    KeyRefused = EdgeRefusal.IsKeyRefusal(response.StatusCode, code),
                };
            }

            if (!response.IsSuccessStatusCode)
            {
                return FromCache($"the backend answered HTTP {(int)response.StatusCode}");
            }

            var payload = await response.Content.ReadAsByteArrayAsync(ct);
            if (!string.Equals(response.Content.Headers.ContentType?.MediaType, EdgeContractConstants.ProtobufContentType, StringComparison.OrdinalIgnoreCase)
                || !TryRead(payload, out var assignment, out var reason))
            {
                return FromCache($"the answer is not an agent assignment ({response.Content.Headers.ContentType?.MediaType})");
            }

            if (reason != null)
            {
                return new Result(Outcome.Unavailable, null, reason);
            }

            Save(assignment, payload);
            return new Result(Outcome.Fresh, assignment, null);
        }
    }

    /// <summary>True when <paramref name="kept"/> is the same assignment as <paramref name="assignment"/>, apart from when it was built.</summary>
    private static bool SameSites(byte[] kept, V2.AgentAssignment assignment)
    {
        try
        {
            var old = V2.AgentAssignment.Parser.ParseFrom(kept);
            var fresh = assignment.Clone();
            old.GeneratedAtMs = 0;
            fresh.GeneratedAtMs = 0;
            return old.Equals(fresh);
        }
        catch (InvalidProtocolBufferException)
        {
            return false;
        }
    }

    /// <summary>The sites of an assignment, each with its organisation; entries without a valid id are left out.</summary>
    public static IReadOnlyList<AgentSite> SitesOf(V2.AgentAssignment assignment) =>
        assignment.Sites
            .Where(s => s.SiteId.Length == 16 && s.TenantId.Length == 16)
            .Select(s => new AgentSite(EdgeIds.ToGuid(s.TenantId), EdgeIds.ToGuid(s.SiteId), s.Name, s.TenantName))
            .DistinctBy(s => s.SiteId)
            .ToList();

    /// <summary>Parses an assignment; <paramref name="reason"/> is set when it cannot be run (another organisation than TENANT_ID).</summary>
    private bool TryRead(byte[] payload, out V2.AgentAssignment assignment, out string? reason)
    {
        reason = null;
        try
        {
            assignment = V2.AgentAssignment.Parser.ParseFrom(payload);
        }
        catch (InvalidProtocolBufferException)
        {
            assignment = new V2.AgentAssignment();
            return false;
        }

        if (Guid.TryParse(_options.TenantId, out var tenantId) && (assignment.TenantId.Length != 16 || EdgeIds.ToGuid(assignment.TenantId) != tenantId))
        {
            reason = $"the agent key is not an agent of organisation {_options.TenantId} (TENANT_ID)";
        }

        return true;
    }

    /// <summary>Why the backend refused the agent, with the key's safe prefix and never the key.</summary>
    private string RefusalReason(HttpStatusCode status, string? code)
    {
        var why = code switch
        {
            EdgeContractConstants.KeyInvalidCode => "the key is unknown: it was rotated, or it was entered wrong",
            EdgeContractConstants.KeyRevokedCode => "the key was revoked",
            EdgeContractConstants.KeyTenantMismatchCode => $"the key is not an agent of organisation {_options.TenantId} (TENANT_ID)",
            EdgeContractConstants.TenantSuspendedCode => "the agent's organisation is suspended",
            null => "no reason given (a proxy may have answered, or a backend older than 5.14)",
            _ => "a reason this agent does not know",
        };
        return $"the backend refused agent key {EdgeAgentKey.Prefix(_options.AgentKey)} (HTTP {(int)status}{(code is null ? string.Empty : $" {code}")}): {why}";
    }

    /// <summary>
    /// The local copy of the agent's sites, as <paramref name="outcome"/> (<see cref="Outcome.Cached"/> without the
    /// backend). Without a usable copy the result has no assignment and is <see cref="Outcome.Unavailable"/>, or stays
    /// <see cref="Outcome.Refused"/>.
    /// </summary>
    private Result FromCache(string reason, Outcome outcome = Outcome.Cached)
    {
        var none = outcome == Outcome.Refused ? Outcome.Refused : Outcome.Unavailable;
        if (string.IsNullOrEmpty(cacheFile) || !File.Exists(cacheFile))
        {
            return new Result(none, null, $"{reason}, and there is no local copy of the agent's sites");
        }

        try
        {
            var age = _time.GetUtcNow().UtcDateTime - File.GetLastWriteTimeUtc(cacheFile);
            if (age < TimeSpan.Zero || age > TimeSpan.FromHours(_options.MaxOfflineCacheHours))
            {
                return new Result(none, null, $"{reason}, and the local copy of the agent's sites is {age.TotalHours:F0} h old ({_options.MaxOfflineCacheHours} h allowed)");
            }

            if (!TryRead(File.ReadAllBytes(cacheFile), out var assignment, out var refused) || refused != null)
            {
                return new Result(none, null, $"{reason}, and the local copy of the agent's sites cannot be used");
            }

            return new Result(outcome, assignment, $"{reason}; using the local copy ({age.TotalHours:F1} h old)");
        }
        catch (IOException ex)
        {
            return new Result(none, null, $"{reason}, and the local copy cannot be read ({ex.Message})");
        }
    }

    /// <summary>
    /// Keeps the assignment. An unchanged one (only <c>generated_at_ms</c> differs) is not written again: its file time is
    /// moved on, which is what the offline window counts from.
    /// </summary>
    private void Save(V2.AgentAssignment assignment, byte[] payload)
    {
        if (string.IsNullOrEmpty(cacheFile))
        {
            return;
        }

        try
        {
            if (File.Exists(cacheFile) && SameSites(File.ReadAllBytes(cacheFile), assignment))
            {
                File.SetLastWriteTimeUtc(cacheFile, DateTime.UtcNow);
                return;
            }

            Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(cacheFile))!);
            var temporary = cacheFile + ".tmp";
            File.WriteAllBytes(temporary, payload);
            File.Move(temporary, cacheFile, overwrite: true);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            logger.LogWarning(ex, "[AGENT] The agent's sites could not be kept in {File}; they are used anyway.", cacheFile);
        }
    }
}
