using System.Collections.Concurrent;
using System.Threading.Channels;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Entities;
using Votech.Edge.Core.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Votech.Edge.Ingestion.Services;

/// <summary>
/// Collects the readings of every poller for <c>BatchWindowMs</c> (or until <c>MaxBatchSize</c> are waiting) and
/// stores them as batches per connection of at most <c>MaxBatchSize</c> samples. Each batch gets its id when it is
/// stored, with the configuration revision running then; the publisher sends it from the buffer. Readings wait in
/// memory in a queue of <c>Storage.MaxPendingQueueSize</c>; when the buffer cannot keep up, the oldest are dropped and
/// counted. A window that cannot be stored is tried <see cref="StorageConstants.StoreAttempts"/> times (the same batches,
/// so the same ids) while new readings keep queuing; then it is dropped and counted. <see cref="DroppedTotal"/> goes
/// out in the agent status. A reading whose value is not a number (NaN, ±Infinity), which an RTU can send for an invalid
/// measurement or a scaling can produce, is dropped before it is queued: warned once per signal, counted per window at
/// Debug (EMS-146).
/// </summary>
public sealed class SignalSampleSink : ISignalSink, IAsyncDisposable
{
    private readonly ISignalBuffer _buffer;
    private readonly IEdgeConfigurationSource _configuration;
    private readonly EdgeAgentOptions _options;
    private readonly ILogger<SignalSampleSink> _logger;
    private readonly TimeProvider _time;
    private readonly Channel<SignalReading> _channel;
    private readonly Task _loop;
    private int _waiting;
    private long _dropped;
    private long _droppedTotal;
    private long _nonFinite;
    private readonly ConcurrentDictionary<Guid, byte> _reportedNonFinite = new();
    private int _drained;
    private volatile bool _completing;

    public SignalSampleSink(
        ISignalBuffer buffer,
        IEdgeConfigurationSource configuration,
        IOptions<EdgeAgentOptions> options,
        ILogger<SignalSampleSink> logger,
        TimeProvider? timeProvider = null
    )
    {
        _buffer = buffer;
        _configuration = configuration;
        _options = options.Value;
        _logger = logger;
        _time = timeProvider ?? TimeProvider.System;
        _channel = Channel.CreateBounded<SignalReading>(
            new BoundedChannelOptions(_options.Storage.MaxPendingQueueSize)
            {
                FullMode = BoundedChannelFullMode.DropOldest,
                SingleReader = true,
                SingleWriter = false,
            },
            _ =>
            {
                Interlocked.Increment(ref _dropped);
                Interlocked.Increment(ref _droppedTotal);
                Interlocked.Decrement(ref _waiting);
            }
        );
        _loop = Task.Run(RunAsync);
    }

    public void Write(in SignalReading reading)
    {
        if (!double.IsFinite(reading.Value))
        {
            Interlocked.Increment(ref _nonFinite);
            if (_reportedNonFinite.TryAdd(reading.SignalId, 0))
            {
                _logger.LogWarning(
                    "[SINK] Signal {SignalId} of connection {EndpointId} sent a value that is not a number ({Value}, quality {Quality}); such values are dropped.",
                    reading.SignalId,
                    reading.EndpointId,
                    reading.Value,
                    reading.Quality
                );
            }

            return;
        }

        if (_channel.Writer.TryWrite(reading))
        {
            Interlocked.Increment(ref _waiting);
        }
        else
        {
            Interlocked.Increment(ref _dropped);
            Interlocked.Increment(ref _droppedTotal);
        }
    }

    public long DroppedTotal => Interlocked.Read(ref _droppedTotal);

    /// <summary>The wait after the first failed store; it doubles after each (tests shorten it).</summary>
    internal TimeSpan StoreRetryFirstDelay { get; init; } = TimeSpan.FromMilliseconds(StorageConstants.StoreRetryFirstDelayMs);

    private async Task RunAsync()
    {
        var window = TimeSpan.FromMilliseconds(Math.Max(50, _options.BatchWindowMs));
        var reader = _channel.Reader;
        while (await reader.WaitToReadAsync().ConfigureAwait(false))
        {
            // Collect for one window, or less when a full batch is already waiting.
            var deadline = _time.GetUtcNow() + window;
            while (Volatile.Read(ref _waiting) < _options.MaxBatchSize && _time.GetUtcNow() < deadline && !_completing)
            {
                await Task.Delay(TimeSpan.FromMilliseconds(Math.Min(50, window.TotalMilliseconds)), _time).ConfigureAwait(false);
            }

            await StoreWaitingAsync().ConfigureAwait(false);
        }

        await StoreWaitingAsync().ConfigureAwait(false);
    }

    private async Task StoreWaitingAsync()
    {
        var readings = new List<SignalReading>();
        while (_channel.Reader.TryRead(out var reading))
        {
            Interlocked.Decrement(ref _waiting);
            readings.Add(reading);
        }

        var nonFinite = Interlocked.Exchange(ref _nonFinite, 0);
        if (nonFinite > 0)
        {
            _logger.LogDebug("[SINK] {Count} reading(s) that were not a number (NaN or ±Infinity) were dropped.", nonFinite);
        }

        var dropped = Interlocked.Exchange(ref _dropped, 0);
        if (dropped > 0)
        {
            _logger.LogWarning(
                "[SINK] {Count} reading(s) were dropped: more than {Max} waited to be stored.",
                dropped,
                _options.Storage.MaxPendingQueueSize
            );
        }

        if (readings.Count == 0)
        {
            return;
        }

        var batches = ToBatches(readings, _configuration.Current?.Revision ?? string.Empty, _time.GetUtcNow(), Math.Max(1, _options.MaxBatchSize));
        var delay = StoreRetryFirstDelay;
        for (var attempt = 1; ; attempt++)
        {
            try
            {
                await _buffer.SaveAsync(batches, CancellationToken.None).ConfigureAwait(false);
                return;
            }
            catch (Exception ex) when (attempt < StorageConstants.StoreAttempts)
            {
                _logger.LogWarning(ex, "[SINK] Storing {Count} reading(s) in the local buffer failed (attempt {Attempt}); retrying in {Delay} ms.", readings.Count, attempt, delay.TotalMilliseconds);
                await Task.Delay(delay, _time).ConfigureAwait(false);
                delay *= 2;
            }
            catch (Exception ex)
            {
                Interlocked.Add(ref _droppedTotal, readings.Count);
                _logger.LogError(ex, "[SINK] Storing {Count} reading(s) in the local buffer failed {Attempts} times; they are dropped.", readings.Count, attempt);
                return;
            }
        }
    }

    /// <summary>Batches per connection of at most <paramref name="maxBatchSize"/> samples, in arrival order.</summary>
    internal static List<StoredSignalBatch> ToBatches(IReadOnlyList<SignalReading> readings, string revision, DateTimeOffset now, int maxBatchSize)
    {
        var batches = new List<StoredSignalBatch>();
        var createdAt = now.ToUnixTimeMilliseconds();
        foreach (var connection in readings.GroupBy(r => r.EndpointId))
        {
            foreach (var chunk in connection.Chunk(maxBatchSize))
            {
                var batchId = EdgeIds.ToBytes(Guid.CreateVersion7(now));
                var samples = chunk.Select(r => new BufferedSignalSample
                {
                    BatchId = batchId,
                    SignalId = EdgeIds.ToBytes(r.SignalId),
                    Value = r.Value,
                    TimestampMs = new DateTimeOffset(DateTime.SpecifyKind(r.Timestamp, DateTimeKind.Utc)).ToUnixTimeMilliseconds(),
                    QualityStatus = (byte)r.Quality,
                    RawQuality = (int)r.RawQuality,
                    DeviceTime = r.DeviceTime,
                    TimeSource = (byte)r.TimeSource,
                    DeviceTimestampMs = r.DeviceTimestampMs,
                    ReceiveLagMs = r.ReceiveLagMs,
                }).ToList();
                batches.Add(new StoredSignalBatch(
                    new BufferedSignalBatch
                    {
                        BatchId = batchId,
                        EndpointId = EdgeIds.ToBytes(connection.Key),
                        ConfigRevision = revision,
                        CreatedAtMs = createdAt++,
                        SampleCount = samples.Count,
                    },
                    samples
                ));
            }
        }

        return batches;
    }

    public async Task DrainAsync(CancellationToken ct = default)
    {
        if (Interlocked.Exchange(ref _drained, 1) == 1)
        {
            return;
        }

        _completing = true;
        _channel.Writer.TryComplete();
        await _loop.WaitAsync(ct).ConfigureAwait(false);
        _logger.LogInformation("[SINK] Signal sink drained for shutdown.");
    }

    public async ValueTask DisposeAsync() => await DrainAsync();
}
