using Votech.Edge.Core.Acquisition;

namespace Votech.Edge.Ingestion.Modbus;

/// <summary>A point with its parsed address and the number of registers (or bits) it takes.</summary>
public sealed record ModbusPoint(AcquiredPoint Point, ModbusAddress Address, int Length);

/// <summary>One read request: a contiguous range of one table of one unit.</summary>
public sealed record ModbusBlock(byte Unit, ModbusTable Table, ushort Start, ushort Count, IReadOnlyList<ModbusPoint> Points)
{
    public int End => Start + Count;
}

/// <summary>
/// Groups points into as few read requests as possible: per unit and table, points whose ranges touch or overlap are
/// read together while the request stays within the largest block (registers) or
/// <see cref="MaxBitsPerRead"/> (coils and discrete inputs). Gaps are never read, so unmapped registers cannot fail
/// a request.
/// </summary>
public static class ModbusBlockPlanner
{
    /// <summary>The Modbus limit for one coil or discrete input read.</summary>
    public const int MaxBitsPerRead = 2000;

    /// <summary>The Modbus limit for one register read.</summary>
    public const int MaxRegistersPerRead = 125;

    public static IReadOnlyList<ModbusBlock> Plan(byte unit, IEnumerable<ModbusPoint> points, int maxBlockRegisters)
    {
        var maxRegisters = maxBlockRegisters is > 0 and <= MaxRegistersPerRead ? maxBlockRegisters : MaxRegistersPerRead;
        var blocks = new List<ModbusBlock>();
        foreach (var table in points.GroupBy(p => p.Address.Table))
        {
            var max = table.Key is ModbusTable.Coil or ModbusTable.DiscreteInput ? MaxBitsPerRead : maxRegisters;
            var current = new List<ModbusPoint>();
            int start = 0, end = 0;
            foreach (var point in table.OrderBy(p => p.Address.Offset).ThenBy(p => p.Length))
            {
                var pointEnd = point.Address.Offset + point.Length;
                if (current.Count > 0 && point.Address.Offset <= end && Math.Max(end, pointEnd) - start <= max)
                {
                    current.Add(point);
                    end = Math.Max(end, pointEnd);
                    continue;
                }

                Flush();
                current = [point];
                start = point.Address.Offset;
                end = pointEnd;
            }

            Flush();

            void Flush()
            {
                if (current.Count > 0)
                {
                    blocks.Add(new ModbusBlock(unit, table.Key, (ushort)start, (ushort)(end - start), current));
                }
            }
        }

        return blocks;
    }
}
