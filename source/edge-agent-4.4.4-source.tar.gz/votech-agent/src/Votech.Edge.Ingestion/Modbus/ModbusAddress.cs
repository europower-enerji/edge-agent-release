using System.Globalization;
using System.Text.RegularExpressions;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Modbus;

/// <summary>The four Modbus data tables.</summary>
public enum ModbusTable
{
    Coil,
    DiscreteInput,
    InputRegister,
    HoldingRegister,
}

/// <summary>
/// A parsed Modbus signal address (the grammar the backend checks, <c>SignalAddressRules</c>).
/// </summary>
/// <param name="Table">The data table.</param>
/// <param name="Offset">Zero-based offset in the table, as sent on the wire.</param>
/// <param name="Bit">A bit of a register (0-15), or null.</param>
/// <param name="Width">The value width named by a suffix (":F32"), or null.</param>
public readonly record struct ModbusAddress(ModbusTable Table, ushort Offset, int? Bit, V2.DataType? Width)
{
    public bool IsRegister => Table is ModbusTable.InputRegister or ModbusTable.HoldingRegister;
}

/// <summary>
/// Parses Modbus addresses:
/// <list type="bullet">
/// <item>Modicon: "00001"-"09999" coil, "10001"-"19999" discrete input, "30001"-"39999" input register,
/// "40001"-"49999" holding register, and the 6-digit forms ("400001"). The leading digit names the table; the
/// connection's address base says whether the rest counts from 1 (40001 = offset 0) or from 0 (40000 = offset 0).</item>
/// <item>Explicit and always zero-based: "CO:0", "DI:0", "IR:0", "HR:0".</item>
/// <item>A register may name a bit ("40001.3", 0-15) or a value width ("40001:F32"; I16, U16, I32, U32, F32, I64,
/// F64), not both.</item>
/// </list>
/// </summary>
public static partial class ModbusAddressParser
{
    [GeneratedRegex(
        @"^(?:(?<modicon>[0134]\d{4,5})|(?<table>CO|DI|IR|HR):(?<offset>\d{1,5}))(?:\.(?<bit>\d{1,2}))?(?::(?<width>I16|U16|I32|U32|F32|I64|F64))?$",
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant
    )]
    private static partial Regex Grammar();

    public static bool TryParse(string address, V2.AddressBase addressBase, out ModbusAddress parsed, out string error)
    {
        parsed = default;
        var match = Grammar().Match(address.Trim());
        if (!match.Success)
        {
            error = "not a Modbus address (40001, 40001.3, 40001:F32, HR:0)";
            return false;
        }

        ModbusTable table;
        int offset;
        if (match.Groups["modicon"].Success)
        {
            var modicon = match.Groups["modicon"].Value;
            table = modicon[0] switch
            {
                '0' => ModbusTable.Coil,
                '1' => ModbusTable.DiscreteInput,
                '3' => ModbusTable.InputRegister,
                _ => ModbusTable.HoldingRegister,
            };
            var number = int.Parse(modicon.AsSpan(1), NumberStyles.None, CultureInfo.InvariantCulture);
            offset = addressBase == V2.AddressBase.ZeroBased ? number : number - 1;
        }
        else
        {
            table = match.Groups["table"].Value.ToUpperInvariant() switch
            {
                "CO" => ModbusTable.Coil,
                "DI" => ModbusTable.DiscreteInput,
                "IR" => ModbusTable.InputRegister,
                _ => ModbusTable.HoldingRegister,
            };
            offset = int.Parse(match.Groups["offset"].Value, NumberStyles.None, CultureInfo.InvariantCulture);
        }

        if (offset is < 0 or > ushort.MaxValue)
        {
            error = addressBase == V2.AddressBase.Modicon && offset < 0
                ? "offset 0 does not exist when addresses count from 1"
                : "offset beyond 65535";
            return false;
        }

        int? bit = match.Groups["bit"].Success ? int.Parse(match.Groups["bit"].Value, CultureInfo.InvariantCulture) : null;
        V2.DataType? width = match.Groups["width"].Success
            ? match.Groups["width"].Value.ToUpperInvariant() switch
            {
                "I16" => V2.DataType.Int16,
                "U16" => V2.DataType.Uint16,
                "I32" => V2.DataType.Int32,
                "U32" => V2.DataType.Uint32,
                "F32" => V2.DataType.Float32,
                "I64" => V2.DataType.Int64,
                _ => V2.DataType.Float64,
            }
            : null;

        var isRegister = table is ModbusTable.InputRegister or ModbusTable.HoldingRegister;
        if (!isRegister && (bit.HasValue || width.HasValue))
        {
            error = "a coil or discrete input has no bit or width";
            return false;
        }

        if (bit.HasValue && (width.HasValue || bit > 15))
        {
            error = "a bit is 0-15 and excludes a width";
            return false;
        }

        parsed = new ModbusAddress(table, (ushort)offset, bit, width);
        error = string.Empty;
        return true;
    }
}
