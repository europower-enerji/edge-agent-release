using System.Buffers.Binary;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Modbus;

/// <summary>
/// Decodes register values: 16-bit values from one register, 32-bit from two and 64-bit from four, with the
/// connection's byte order (inside a register) and word order (of the registers). A bit address reads one bit of the
/// register.
/// </summary>
public static class ModbusValueDecoder
{
    /// <summary>The number of registers a value of <paramref name="dataType"/> takes.</summary>
    public static int RegisterCount(V2.DataType dataType) =>
        dataType switch
        {
            V2.DataType.Int32 or V2.DataType.Uint32 or V2.DataType.Float32 => 2,
            V2.DataType.Int64 or V2.DataType.Float64 => 4,
            _ => 1,
        };

    public static double Decode(
        ReadOnlySpan<ushort> registers,
        V2.DataType dataType,
        V2.ByteOrder byteOrder,
        V2.WordOrder wordOrder,
        int? bit = null
    )
    {
        var count = bit.HasValue ? 1 : RegisterCount(dataType);
        if (registers.Length < count)
        {
            throw new ArgumentException($"{dataType} needs {count} register(s), {registers.Length} given.", nameof(registers));
        }

        Span<ushort> words = stackalloc ushort[count];
        for (var i = 0; i < count; i++)
        {
            var word = registers[wordOrder == V2.WordOrder.LowFirst ? count - 1 - i : i];
            words[i] = byteOrder == V2.ByteOrder.LittleEndian ? BinaryPrimitives.ReverseEndianness(word) : word;
        }

        if (bit.HasValue)
        {
            return (words[0] >> bit.Value) & 1;
        }

        ulong raw = 0;
        foreach (var word in words)
        {
            raw = (raw << 16) | word;
        }

        return dataType switch
        {
            V2.DataType.Boolean => raw != 0 ? 1 : 0,
            V2.DataType.DoublePoint => raw & 0x3,
            V2.DataType.Int16 => (short)raw,
            V2.DataType.Int32 => (int)raw,
            V2.DataType.Uint32 => (uint)raw,
            V2.DataType.Float32 => BitConverter.Int32BitsToSingle((int)raw),
            V2.DataType.Int64 => (long)raw,
            V2.DataType.Float64 => BitConverter.Int64BitsToDouble((long)raw),
            _ => (ushort)raw,
        };
    }
}
