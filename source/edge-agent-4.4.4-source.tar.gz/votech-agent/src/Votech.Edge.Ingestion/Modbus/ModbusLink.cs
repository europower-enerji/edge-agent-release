using System.IO.Ports;
using System.Net.Sockets;
using Votech.Edge.Core.Constants;
using NModbus;
using NModbus.Serial;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Modbus;

/// <summary>An open Modbus master link (a TCP socket or a serial port).</summary>
public interface IModbusLink : IDisposable
{
    Task<bool[]> ReadBitsAsync(byte unit, ModbusTable table, ushort start, ushort count);

    Task<ushort[]> ReadRegistersAsync(byte unit, ModbusTable table, ushort start, ushort count);
}

/// <summary>Opens the link of one connection.</summary>
public interface IModbusLinkFactory
{
    /// <summary>For log lines: "host:port" or the serial port and format.</summary>
    string Target { get; }

    Task<IModbusLink> OpenAsync(CancellationToken ct);
}

/// <summary>An NModbus master with the transport it owns.</summary>
internal sealed class NModbusLink(IModbusMaster master, IDisposable transport) : IModbusLink
{
    public Task<bool[]> ReadBitsAsync(byte unit, ModbusTable table, ushort start, ushort count) =>
        table == ModbusTable.Coil
            ? master.ReadCoilsAsync(unit, start, count)
            : master.ReadInputsAsync(unit, start, count);

    public Task<ushort[]> ReadRegistersAsync(byte unit, ModbusTable table, ushort start, ushort count) =>
        table == ModbusTable.HoldingRegister
            ? master.ReadHoldingRegistersAsync(unit, start, count)
            : master.ReadInputRegistersAsync(unit, start, count);

    public void Dispose()
    {
        master.Dispose();
        transport.Dispose();
    }
}

/// <summary>Modbus TCP: host and port from the connection's settings; timeout and retries from its polling settings.</summary>
public sealed class ModbusTcpLinkFactory(V2.ModbusTcpSettings settings) : IModbusLinkFactory
{
    private int Port => settings.Port > 0 ? (int)settings.Port : ModbusConstants.DefaultTcpPort;

    public string Target => $"{settings.Host}:{Port}";

    public async Task<IModbusLink> OpenAsync(CancellationToken ct)
    {
        var timeoutMs = ModbusPolling.TimeoutMs(settings.Polling);
        var client = new TcpClient();
        try
        {
            using var connect = CancellationTokenSource.CreateLinkedTokenSource(ct);
            connect.CancelAfter(timeoutMs);
            await client.ConnectAsync(settings.Host, Port, connect.Token);
            var master = new ModbusFactory().CreateMaster(client);
            ModbusPolling.Apply(master, settings.Polling);
            return new NModbusLink(master, client);
        }
        catch
        {
            client.Dispose();
            throw;
        }
    }
}

/// <summary>
/// Modbus RTU: the serial port and its format (baud rate, data bits, parity, stop bits) from the typed settings of the
/// connection.
/// </summary>
public sealed class ModbusRtuLinkFactory(V2.ModbusRtuSettings settings) : IModbusLinkFactory
{
    private int BaudRate => settings.BaudRate > 0 ? (int)settings.BaudRate : ModbusConstants.DefaultBaudRate;
    private int DataBits => settings.DataBits > 0 ? (int)settings.DataBits : ModbusConstants.DefaultDataBits;

    private Parity Parity => settings.Parity switch
    {
        V2.Parity.Even => Parity.Even,
        V2.Parity.Odd => Parity.Odd,
        _ => Parity.None,
    };

    private StopBits StopBits => settings.StopBits == V2.StopBits.Two ? StopBits.Two : StopBits.One;

    public string Target => $"{settings.SerialPort} {BaudRate} {DataBits}{Parity.ToString()[0]}{(StopBits == StopBits.Two ? 2 : 1)}";

    public Task<IModbusLink> OpenAsync(CancellationToken ct)
    {
        var timeoutMs = ModbusPolling.TimeoutMs(settings.Polling);
        var port = new SerialPort(settings.SerialPort, BaudRate, Parity, DataBits, StopBits)
        {
            ReadTimeout = timeoutMs,
            WriteTimeout = timeoutMs,
        };
        try
        {
            port.Open();
            var master = new ModbusFactory().CreateRtuMaster(new SerialPortAdapter(port));
            ModbusPolling.Apply(master, settings.Polling);
            return Task.FromResult<IModbusLink>(new NModbusLink(master, port));
        }
        catch
        {
            port.Dispose();
            throw;
        }
    }
}

/// <summary>The polling settings of a connection, with the contract's defaults for 0.</summary>
public static class ModbusPolling
{
    public static int IntervalMs(V2.PollingSettings? polling) =>
        polling?.PollIntervalMs > 0 ? (int)polling.PollIntervalMs : ModbusConstants.DefaultPollingIntervalMs;

    public static int TimeoutMs(V2.PollingSettings? polling) =>
        polling?.TimeoutMs > 0 ? (int)polling.TimeoutMs : ModbusConstants.DefaultTimeoutMs;

    /// <summary>Retries of a failed request; 0 = none (NModbus would otherwise retry 3 times).</summary>
    public static int Retries(V2.PollingSettings? polling) => (int)(polling?.Retries ?? 0);

    internal static void Apply(IModbusMaster master, V2.PollingSettings? polling)
    {
        master.Transport.ReadTimeout = TimeoutMs(polling);
        master.Transport.WriteTimeout = TimeoutMs(polling);
        master.Transport.Retries = Retries(polling);
    }
}
