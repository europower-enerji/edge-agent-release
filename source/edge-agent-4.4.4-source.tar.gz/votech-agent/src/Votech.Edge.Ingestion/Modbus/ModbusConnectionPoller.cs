using System.Collections.Concurrent;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Models;
using Microsoft.Extensions.Logging;
using NModbus;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Modbus;

/// <summary>
/// Reads one Modbus TCP or RTU connection of the v2 configuration (ADR-002 2.2):
/// <list type="bullet">
/// <item>Each point's address is parsed with the connection's address base (<see cref="ModbusAddressParser"/>); its
/// data type sets the register count, decoded with the connection's byte and word order
/// (<see cref="ModbusValueDecoder"/>).</item>
/// <item>Points are grouped by poll interval (the point's, else the station's, else the connection's, else 1 s), and
/// each group is read in as few block requests as possible per station unit id (<see cref="ModbusBlockPlanner"/>).</item>
/// <item>A Modbus exception fails only its block. A station that stops answering is marked down and its signals get
/// one Offline sample; a broken link marks every signal Offline and is reopened with a growing delay.</item>
/// </list>
/// </summary>
public sealed class ModbusConnectionPoller : IConnectionPoller
{
    private const int ReconnectDelayMs = 1_000;
    private const int MaxReconnectDelayMs = 60_000;

    // Modbus exception codes of a gateway whose target unit does not answer.
    private const byte GatewayPathUnavailable = 0x0A;
    private const byte GatewayTargetFailedToRespond = 0x0B;

    private readonly IModbusLinkFactory _linkFactory;
    private readonly ISignalSink _sink;
    private readonly ILogger _logger;
    private readonly string _code;
    private readonly V2.ModbusEncoding _encoding;
    private readonly V2.PollingSettings? _polling;
    private readonly ConcurrentDictionary<Guid, double> _lastValues = new();
    private readonly ConcurrentDictionary<Guid, StationState> _stations = new();
    private readonly ConcurrentDictionary<string, byte> _reportedBlockErrors = new();
    private Plan _plan;
    private volatile bool _linkUp;
    private DateTime? _lastSeenAt;
    private string? _lastError;
    private string _reasonCode = DeviceDiagnosticReason.Connecting;
    private CancellationTokenSource? _replan;

    private sealed class StationState(Guid endpointId, byte unit)
    {
        public Guid EndpointId { get; } = endpointId;
        public byte Unit { get; } = unit;
        public bool Answering { get; set; } = true;
        public DateTime? LastSeenAt { get; set; }
        public string? Error { get; set; }
    }

    /// <summary>The read schedule: blocks per poll interval, and the stations.</summary>
    private sealed record Plan(IReadOnlyList<(TimeSpan Interval, IReadOnlyList<ModbusBlock> Blocks)> Groups, IReadOnlyList<(Guid EndpointId, byte Unit)> Stations);

    public ModbusConnectionPoller(V2.Connection connection, ISignalSink sink, ILogger logger, IModbusLinkFactory? linkFactory = null)
    {
        EndpointId = EdgeIds.ToGuid(connection.EndpointId);
        Protocol = connection.Protocol;
        _code = connection.Code;
        _sink = sink;
        _logger = logger;
        (_encoding, _polling, _linkFactory) = connection.SettingsCase switch
        {
            V2.Connection.SettingsOneofCase.ModbusTcp => (connection.ModbusTcp.Encoding ?? new V2.ModbusEncoding(), connection.ModbusTcp.Polling, linkFactory ?? new ModbusTcpLinkFactory(connection.ModbusTcp)),
            V2.Connection.SettingsOneofCase.ModbusRtu => (connection.ModbusRtu.Encoding ?? new V2.ModbusEncoding(), connection.ModbusRtu.Polling, linkFactory ?? new ModbusRtuLinkFactory(connection.ModbusRtu)),
            _ => throw new ArgumentException("The connection has no Modbus settings.", nameof(connection)),
        };
        _plan = BuildPlan(connection);
    }

    public Guid EndpointId { get; }

    public V2.Protocol Protocol { get; }

    public bool IsConnected => _linkUp;

    public IReadOnlyList<EndpointHealth> Health
    {
        get
        {
            var health = new List<EndpointHealth>
            {
                new(EndpointId, _linkUp, _lastSeenAt, _linkUp ? DeviceDiagnosticReason.ConnectedHealthy : _reasonCode, _linkUp ? null : _lastError),
            };
            foreach (var (endpointId, _) in Volatile.Read(ref _plan).Stations.Where(s => s.EndpointId != EndpointId))
            {
                var state = _stations.GetValueOrDefault(endpointId);
                var connected = _linkUp && (state?.Answering ?? true);
                health.Add(new EndpointHealth(
                    endpointId,
                    connected,
                    state?.LastSeenAt,
                    connected ? DeviceDiagnosticReason.ConnectedHealthy : _linkUp ? DeviceDiagnosticReason.UnreachablePhysicalDevice : _reasonCode,
                    _linkUp ? state?.Error : _lastError
                ));
            }

            return health;
        }
    }

    public void UpdatePoints(V2.Connection connection)
    {
        var plan = BuildPlan(connection);
        Volatile.Write(ref _plan, plan);
        var kept = plan.Groups.SelectMany(g => g.Blocks).SelectMany(b => b.Points).Select(p => p.Point.SignalId).ToHashSet();
        foreach (var signalId in _lastValues.Keys.Where(id => !kept.Contains(id)))
        {
            _lastValues.TryRemove(signalId, out _);
        }

        _logger.LogInformation(
            "[MODBUS-CONFIG] Connection {Code}: read plan updated on the open link ({Blocks} block(s) in {Groups} poll group(s)).",
            _code,
            plan.Groups.Sum(g => g.Blocks.Count),
            plan.Groups.Count
        );
        Volatile.Read(ref _replan)?.Cancel();
    }

    private Plan BuildPlan(V2.Connection connection)
    {
        var points = new List<(TimeSpan Interval, byte Unit, ModbusPoint Point)>();
        var stations = new List<(Guid EndpointId, byte Unit)>();
        var connectionInterval = ModbusPolling.IntervalMs(_polling);
        foreach (var station in connection.Stations)
        {
            var endpointId = EdgeIds.ToGuid(station.EndpointId);
            if (station.StationAddress > byte.MaxValue)
            {
                _logger.LogWarning("[MODBUS-CONFIG] Station {Code} has unit id {Unit}, beyond 255; it is not read.", station.Code, station.StationAddress);
                continue;
            }

            var unit = (byte)station.StationAddress;
            stations.Add((endpointId, unit));
            foreach (var signal in station.Points)
            {
                if (!ModbusAddressParser.TryParse(signal.Address, _encoding.AddressBase, out var address, out var error))
                {
                    _logger.LogWarning("[MODBUS-CONFIG] Point {Code} has address '{Address}': {Error}; it is not read.", signal.Code, signal.Address, error);
                    continue;
                }

                var dataType = address.Width ?? signal.DataType;
                if (address.IsRegister && dataType == V2.DataType.String)
                {
                    _logger.LogWarning("[MODBUS-CONFIG] Point {Code} is a String, which Modbus registers do not carry here; it is not read.", signal.Code);
                    continue;
                }

                var length = address.IsRegister && !address.Bit.HasValue ? ModbusValueDecoder.RegisterCount(dataType) : 1;
                if (address.Offset + length > ushort.MaxValue + 1)
                {
                    _logger.LogWarning("[MODBUS-CONFIG] Point {Code} at '{Address}' runs past the end of its table; it is not read.", signal.Code, signal.Address);
                    continue;
                }

                var intervalMs = signal.PollIntervalMs > 0 ? (int)signal.PollIntervalMs
                    : station.PollIntervalMs > 0 ? (int)station.PollIntervalMs
                    : connectionInterval;
                var point = new AcquiredPoint(signal, endpointId, station.StationAddress);
                points.Add((TimeSpan.FromMilliseconds(intervalMs), unit, new ModbusPoint(point, address with { Width = dataType }, length)));
            }
        }

        var groups = points
            .GroupBy(p => p.Interval)
            .OrderBy(g => g.Key)
            .Select(g => (g.Key, (IReadOnlyList<ModbusBlock>)g
                .GroupBy(p => p.Unit)
                .SelectMany(u => ModbusBlockPlanner.Plan(u.Key, u.Select(p => p.Point), (int)_encoding.MaxBlockRegisters))
                .ToList()))
            .ToList();
        return new Plan(groups, stations);
    }

    public async Task RunAsync(CancellationToken ct)
    {
        var delayMs = ReconnectDelayMs;
        while (!ct.IsCancellationRequested)
        {
            IModbusLink? link = null;
            try
            {
                _logger.LogInformation("[MODBUS-CONN] Opening {Code} ({Target})...", _code, _linkFactory.Target);
                link = await _linkFactory.OpenAsync(ct);
                _linkUp = true;
                _lastError = null;
                _reasonCode = DeviceDiagnosticReason.ConnectedHealthy;
                delayMs = ReconnectDelayMs;
                _logger.LogInformation("[MODBUS-CONN] {Code} ({Target}) is open.", _code, _linkFactory.Target);
                await PollAsync(link, ct);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                var detail = ex.InnerException != null ? $"{ex.Message} ({ex.InnerException.Message})" : ex.Message;
                _lastError = _linkUp ? $"The link to {_linkFactory.Target} failed: {detail}" : $"Opening {_linkFactory.Target} failed: {detail}";
                _reasonCode = DeviceDiagnosticReason.UnreachablePhysicalDevice;
            }
            finally
            {
                link?.Dispose();
                LinkLost();
            }

            if (ct.IsCancellationRequested)
            {
                break;
            }

            _logger.LogWarning(
                "[MODBUS-CONN] {Code} ({Target}) is down ({Error}). Reconnecting in {Delay} ms.",
                _code,
                _linkFactory.Target,
                _lastError,
                delayMs
            );
            await Task.Delay(delayMs, ct);
            delayMs = Math.Min(delayMs * 2, MaxReconnectDelayMs);
        }
    }

    /// <summary>Runs every poll group on its own schedule until the link fails or the plan changes.</summary>
    private async Task PollAsync(IModbusLink link, CancellationToken ct)
    {
        while (true)
        {
            using var replan = CancellationTokenSource.CreateLinkedTokenSource(ct);
            Volatile.Write(ref _replan, replan);
            var plan = Volatile.Read(ref _plan);
            var due = plan.Groups.Select(_ => DateTime.UtcNow).ToArray();
            try
            {
                while (true)
                {
                    for (var i = 0; i < plan.Groups.Count; i++)
                    {
                        if (DateTime.UtcNow < due[i])
                        {
                            continue;
                        }

                        await ReadGroupAsync(link, plan.Groups[i].Blocks, replan.Token);
                        due[i] = due[i] + plan.Groups[i].Interval > DateTime.UtcNow ? due[i] + plan.Groups[i].Interval : DateTime.UtcNow + plan.Groups[i].Interval;
                    }

                    var wait = plan.Groups.Count == 0 ? TimeSpan.FromSeconds(1) : due.Min() - DateTime.UtcNow;
                    if (wait > TimeSpan.Zero)
                    {
                        await Task.Delay(wait, replan.Token);
                    }
                }
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                // The plan changed: start over with the new one on the same link.
            }
        }
    }

    private async Task ReadGroupAsync(IModbusLink link, IReadOnlyList<ModbusBlock> blocks, CancellationToken ct)
    {
        foreach (var unitBlocks in blocks.GroupBy(b => b.Unit))
        {
            var answered = false;
            string? error = null;
            foreach (var block in unitBlocks)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    var now = DateTime.UtcNow;
                    if (block.Table is ModbusTable.Coil or ModbusTable.DiscreteInput)
                    {
                        var bits = await link.ReadBitsAsync(block.Unit, block.Table, block.Start, block.Count);
                        foreach (var point in block.Points)
                        {
                            Emit(point.Point, bits[point.Address.Offset - block.Start] ? 1 : 0, now);
                        }
                    }
                    else
                    {
                        var registers = await link.ReadRegistersAsync(block.Unit, block.Table, block.Start, block.Count);
                        foreach (var point in block.Points)
                        {
                            var raw = ModbusValueDecoder.Decode(
                                registers.AsSpan(point.Address.Offset - block.Start, point.Length),
                                point.Address.Width ?? point.Point.DataType,
                                _encoding.ByteOrder,
                                _encoding.WordOrder,
                                point.Address.Bit
                            );
                            if (double.IsFinite(raw))
                            {
                                Emit(point.Point, raw, now);
                            }
                        }
                    }

                    answered = true;
                    _lastSeenAt = now;
                }
                catch (SlaveException ex) when (ex.SlaveExceptionCode is GatewayPathUnavailable or GatewayTargetFailedToRespond)
                {
                    error = $"Unit {block.Unit} does not answer behind the gateway: {ex.Message}";
                    break;
                }
                catch (SlaveException ex)
                {
                    // The station answered, with a Modbus exception for this range only.
                    answered = true;
                    error = $"{block.Table} {block.Start}-{block.End - 1}: {ex.Message}";
                    if (_reportedBlockErrors.TryAdd($"{block.Unit}:{block.Table}:{block.Start}:{block.Count}", 0))
                    {
                        _logger.LogWarning("[MODBUS-RX] {Code} unit {Unit}: {Error}", _code, block.Unit, error);
                    }
                }
                catch (TimeoutException ex)
                {
                    error = $"Unit {block.Unit} does not answer: {ex.Message}";
                    break;
                }
            }

            StationAnswered(unitBlocks.Key, answered, error);
        }
    }

    private void Emit(AcquiredPoint point, double raw, DateTime now)
    {
        var value = point.ToEngineering(raw);
        _lastValues[point.SignalId] = value;
        _sink.Write(new SignalReading(point.SignalId, EndpointId, value, now, CanonicalQualityStatus.Good, 0, SampleTimeSource.ReceiptUntimed));
    }

    private void StationAnswered(byte unit, bool answered, string? error)
    {
        foreach (var (endpointId, _) in Volatile.Read(ref _plan).Stations.Where(s => s.Unit == unit))
        {
            var state = _stations.GetOrAdd(endpointId, id => new StationState(id, unit));
            state.Error = error;
            if (answered)
            {
                state.Answering = true;
                state.LastSeenAt = DateTime.UtcNow;
                continue;
            }

            if (state.Answering)
            {
                state.Answering = false;
                _logger.LogWarning("[MODBUS-RX] {Code}: {Error}; its signals are marked Offline.", _code, error);
                MarkOffline(SignalsOfUnit(unit));
            }
        }
    }

    private IEnumerable<Guid> SignalsOfUnit(byte unit) =>
        Volatile.Read(ref _plan).Groups.SelectMany(g => g.Blocks).Where(b => b.Unit == unit).SelectMany(b => b.Points).Select(p => p.Point.SignalId).Distinct();

    private void MarkOffline(IEnumerable<Guid> signals)
    {
        var now = DateTime.UtcNow;
        foreach (var signalId in signals)
        {
            if (_lastValues.TryGetValue(signalId, out var value))
            {
                _sink.Write(new SignalReading(signalId, EndpointId, value, now, CanonicalQualityStatus.Offline, 0, SampleTimeSource.ReceiptUntimed));
            }
        }
    }

    /// <summary>Marks the link down; the first time after it was up, sends one Offline sample per signal read.</summary>
    private void LinkLost()
    {
        if (!_linkUp)
        {
            return;
        }

        _linkUp = false;
        // Signals of a station already marked down got their Offline sample then.
        var down = _stations.Values.Where(s => !s.Answering).Select(s => s.Unit).ToHashSet();
        MarkOffline(_lastValues.Keys.Except(down.SelectMany(SignalsOfUnit)));
        foreach (var state in _stations.Values)
        {
            state.Answering = true;
        }

        _logger.LogWarning("[MODBUS-CONN] {Code} lost; {Count} signal(s) marked Offline.", _code, _lastValues.Count);
    }

    public ValueTask DisposeAsync() => ValueTask.CompletedTask;
}
