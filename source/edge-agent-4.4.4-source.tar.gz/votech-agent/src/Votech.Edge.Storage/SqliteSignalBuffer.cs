using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Entities;
using Votech.Edge.Core.Interfaces;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Votech.Edge.Storage;

/// <summary>
/// SQLite <see cref="ISignalBuffer"/>: <c>SignalBatches</c> (one row per batch, small) decides what is sent and when;
/// <c>SignalSamples</c> holds the samples by batch id. Batches are only ever written, published or deleted whole, so a
/// resend always carries exactly the samples of the first attempt. The outbox and the status read the unpublished
/// batches with <c>is_published = 0</c> in SQL: EF Core writes a negated flag as <c>NOT (is_published)</c>, which SQLite
/// cannot look up in <c>IX_SignalBatches_IsPublished_CreatedAt</c>, so it would scan and sort the whole table every
/// time.
/// </summary>
/// <param name="diskSpace">The free and total space of the disk that holds a database file (null for an in-memory
/// database); the drive of the file unless given (tests).</param>
public sealed class SqliteSignalBuffer(
    IDbContextFactory<EdgeDbContext> contextFactory,
    ILogger<SqliteSignalBuffer> logger,
    Func<string?, SqliteSignalBuffer.DiskSpace?>? diskSpace = null
) : ISignalBuffer, IDisposable
{
    private readonly IDbContextFactory<EdgeDbContext> _contextFactory = contextFactory;
    private readonly ILogger<SqliteSignalBuffer> _logger = logger;
    private readonly Func<string?, DiskSpace?> _diskSpace = diskSpace ?? DriveOf;
    private readonly SemaphoreSlim _stored = new(0, 1);
    private long _evictedTotal;

    /// <summary>The free and total bytes of a disk.</summary>
    public readonly record struct DiskSpace(long AvailableBytes, long TotalBytes);

    /// <summary>The pages of the database file: in use and free (reused before the file grows), and their size.</summary>
    private const string PagesSql =
        "SELECT (SELECT page_count FROM pragma_page_count()) AS Pages, (SELECT freelist_count FROM pragma_freelist_count()) AS FreePages, (SELECT page_size FROM pragma_page_size()) AS PageSize";

    /// <summary>The oldest unpublished batch, read through the index.</summary>
    private const string OldestUnpublishedSql =
        "SELECT * FROM SignalBatches WHERE is_published = 0 ORDER BY created_at LIMIT 1";

    /// <summary>The unpublished samples and when the oldest unpublished batch was stored, read through the index.</summary>
    private const string UnpublishedTotalsSql =
        "SELECT COALESCE(SUM(sample_count), 0) AS Samples, COALESCE(MIN(created_at), 0) AS OldestMs FROM SignalBatches WHERE is_published = 0";

    public bool IsEvicting { get; private set; }

    public long EvictedTotal => Interlocked.Read(ref _evictedTotal);

    public async Task SaveAsync(IReadOnlyList<StoredSignalBatch> batches, CancellationToken ct)
    {
        if (batches.Count == 0)
        {
            return;
        }

        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        await using var transaction = await db.Database.BeginTransactionAsync(ct);
        foreach (var batch in batches)
        {
            db.SignalBatches.Add(batch.Batch);
            db.SignalSamples.AddRange(batch.Samples);
        }

        await db.SaveChangesAsync(ct);
        await transaction.CommitAsync(ct);
        Wake();
    }

    public async Task<StoredSignalBatch?> NextUnpublishedAsync(CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var batch = await db.SignalBatches.FromSqlRaw(OldestUnpublishedSql).AsNoTracking().FirstOrDefaultAsync(ct);
        if (batch == null)
        {
            return null;
        }

        var samples = await db.SignalSamples.AsNoTracking()
            .Where(s => s.BatchId == batch.BatchId)
            .OrderBy(s => s.Id)
            .ToListAsync(ct);
        return new StoredSignalBatch(batch, samples);
    }

    public async Task MarkPublishedAsync(byte[] batchId, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        await db.SignalBatches.Where(b => b.BatchId == batchId)
            .ExecuteUpdateAsync(setters => setters.SetProperty(b => b.IsPublished, true), ct);
    }

    public async Task WaitForBatchesAsync(TimeSpan timeout, CancellationToken ct) =>
        await _stored.WaitAsync(timeout, ct);

    public async Task<SignalBufferStatus> GetStatusAsync(CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var totals = await db.Database.SqlQueryRaw<UnpublishedTotals>(UnpublishedTotalsSql).SingleAsync(ct);
        return new SignalBufferStatus(totals.Samples, totals.OldestMs);
    }

    private sealed class UnpublishedTotals
    {
        public long Samples { get; init; }

        public long OldestMs { get; init; }
    }

    public async Task<int> PurgePublishedAsync(int retentionDays, CancellationToken ct)
    {
        var cutoff = DateTimeOffset.UtcNow.AddDays(-retentionDays).ToUnixTimeMilliseconds();
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var ids = await db.SignalBatches.AsNoTracking()
            .Where(b => b.IsPublished && b.CreatedAtMs < cutoff)
            .Select(b => b.BatchId)
            .ToListAsync(ct);
        var deleted = await DeleteBatchesAsync(db, ids, ct);
        if (deleted > 0)
        {
            _logger.LogInformation(
                "[STORAGE] Purged {Samples} published samples older than {Days} days ({Batches} batches).",
                deleted,
                retentionDays,
                ids.Count
            );
        }

        return deleted;
    }

    public async Task EnforceStorageCapAsync(StorageOptions options, CancellationToken ct)
    {
        await using var db = await _contextFactory.CreateDbContextAsync(ct);
        var samples = await db.SignalBatches.AsNoTracking().SumAsync(b => (long)b.SampleCount, ct);
        var pages = await db.Database.SqlQueryRaw<PageCounts>(PagesSql).SingleAsync(ct);
        var usedMb = (pages.Pages - pages.FreePages) * pages.PageSize / (1024.0 * 1024);
        var (freeGb, floorGb) = MeasureDisk(db, options);
        // Free pages are reused before the file grows: they count as free disk space, or every run would delete more.
        var freeWithPagesGb = freeGb + pages.FreePages * pages.PageSize / (1024.0 * 1024 * 1024);
        var overCount = samples > options.MaxRecordCapacity;
        var overSize = usedMb > options.MaxDbSizeMb;
        var overDisk = freeWithPagesGb < floorGb;
        if (!overCount && !overSize && !overDisk)
        {
            IsEvicting = false;
            return;
        }

        // Back to 90 % of the capacity, and at least 10 % of it per run.
        var target = Math.Min(
            samples,
            Math.Max(
                samples - (long)(options.MaxRecordCapacity * StorageConstants.TargetHeadroomPercent),
                Math.Max(1, (long)(options.MaxRecordCapacity * 0.10))
            )
        );
        _logger.LogWarning(
            "[STORAGE] Buffer limit reached: {Samples}/{MaxSamples} samples, {UsedMb:F0}/{MaxSizeMb} MB in use, {FreeGb:F1} GB free with the free pages (floor {FloorGb:F1} GB). Deleting the oldest {Target} published samples.",
            samples,
            options.MaxRecordCapacity,
            usedMb,
            options.MaxDbSizeMb,
            freeWithPagesGb,
            floorGb,
            target
        );

        var published = await OldestAsync(db, true, target, ct);
        var deletedPublished = await DeleteBatchesAsync(db, published, ct);
        var deletedUnpublished = 0;
        if (deletedPublished < target && overDisk)
        {
            // Only the disk floor deletes samples that were never sent: the agent would stop otherwise.
            var unpublished = await OldestAsync(db, false, target - deletedPublished, ct);
            deletedUnpublished = await DeleteBatchesAsync(db, unpublished, ct);
            Interlocked.Add(ref _evictedTotal, deletedUnpublished);
            _logger.LogWarning(
                "[CRITICAL-STORAGE-ALARM] The disk is at its free space floor ({FreeGb:F1} GB free, floor {FloorGb:F1} GB) with too few published samples. Deleted the {Count} oldest unpublished samples to keep the node running.",
                freeWithPagesGb,
                floorGb,
                deletedUnpublished
            );
        }
        else if (deletedPublished < target)
        {
            _logger.LogWarning(
                "[STORAGE] The buffer is over its limit with unpublished samples; they are kept until they are sent or the disk reaches its free space floor."
            );
        }

        IsEvicting = deletedUnpublished > 0;
        await db.Database.ExecuteSqlRawAsync("PRAGMA wal_checkpoint(TRUNCATE);", ct);
    }

    private sealed class PageCounts
    {
        public long Pages { get; init; }

        public long FreePages { get; init; }

        public long PageSize { get; init; }
    }

    /// <summary>The oldest batch ids of one kind until they hold at least <paramref name="samples"/> samples.</summary>
    private static async Task<List<byte[]>> OldestAsync(EdgeDbContext db, bool published, long samples, CancellationToken ct)
    {
        var ids = new List<byte[]>();
        long total = 0;
        await foreach (var batch in db.SignalBatches.AsNoTracking()
            .Where(b => b.IsPublished == published)
            .OrderBy(b => b.CreatedAtMs)
            .Select(b => new { b.BatchId, b.SampleCount })
            .AsAsyncEnumerable()
            .WithCancellation(ct))
        {
            if (total >= samples)
            {
                break;
            }

            ids.Add(batch.BatchId);
            total += batch.SampleCount;
        }

        return ids;
    }

    /// <summary>Deletes batches with their samples; returns the number of samples deleted.</summary>
    private static async Task<int> DeleteBatchesAsync(EdgeDbContext db, List<byte[]> ids, CancellationToken ct)
    {
        var deleted = 0;
        foreach (var chunk in ids.Chunk(StorageConstants.MaxSqliteParameterChunkSize))
        {
            deleted += await db.SignalSamples.Where(s => chunk.Contains(s.BatchId)).ExecuteDeleteAsync(ct);
            await db.SignalBatches.Where(b => chunk.Contains(b.BatchId)).ExecuteDeleteAsync(ct);
        }

        return deleted;
    }

    /// <summary>The free space of the database's disk (GB) and its free space floor (GB); no floor in memory.</summary>
    private (double FreeGb, double FloorGb) MeasureDisk(EdgeDbContext db, StorageOptions options)
    {
        try
        {
            if (_diskSpace(EdgeDatabaseMigrator.DatabaseFile(db)) is not { } disk)
            {
                return (double.MaxValue, 0);
            }

            const double gb = 1024.0 * 1024 * 1024;
            var floor = Math.Max(options.MinFreeDiskSpaceGb, options.MinFreeDiskSpacePercent / 100.0 * disk.TotalBytes / gb);
            return (disk.AvailableBytes / gb, floor);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException or SqliteException)
        {
            _logger.LogWarning(ex, "[STORAGE] The free disk space cannot be measured.");
            return (double.MaxValue, 0);
        }
    }

    /// <summary>The drive of a database file.</summary>
    private static DiskSpace? DriveOf(string? file)
    {
        if (file == null)
        {
            return null;
        }

        // A full path always has a root, so GetPathRoot is not null.
        var drive = new DriveInfo(Path.GetPathRoot(Path.GetFullPath(file))!);
        return new DiskSpace(drive.AvailableFreeSpace, drive.TotalSize);
    }

    private void Wake()
    {
        try
        {
            if (_stored.CurrentCount == 0)
            {
                _stored.Release();
            }
        }
        catch (SemaphoreFullException)
        {
            // Already signalled.
        }
    }

    public void Dispose() => _stored.Dispose();

    /// <inheritdoc />
    public async Task CheckpointDatabaseAsync(CancellationToken ct)
    {
        await using var context = await _contextFactory.CreateDbContextAsync(ct);

        if (context.Database.ProviderName != "Microsoft.EntityFrameworkCore.Sqlite")
        {
            _logger.LogDebug(
                "Skipping WAL checkpoint: provider is not SQLite ({Provider}).",
                context.Database.ProviderName
            );
            return;
        }

        var connection = context.Database.GetDbConnection();
        if (connection.State != System.Data.ConnectionState.Open)
        {
            await connection.OpenAsync(ct);
        }

        try
        {
            // 1. Run WAL checkpoint
            int busy = 0;
            int log = -1;
            int checkPointed = -1;

            using (var cmd = connection.CreateCommand())
            {
                cmd.CommandText = "PRAGMA wal_checkpoint(PASSIVE);";
                await using var reader = await cmd.ExecuteReaderAsync(ct);
                if (await reader.ReadAsync(ct))
                {
                    busy = !reader.IsDBNull(0) ? reader.GetInt32(0) : 0;
                    log = !reader.IsDBNull(1) ? reader.GetInt32(1) : -1;
                    checkPointed = !reader.IsDBNull(2) ? reader.GetInt32(2) : -1;
                }
            }

            if (busy != 0 || (log > 0 && checkPointed < log))
            {
                _logger.LogWarning(
                    "SQLite WAL checkpoint was blocked or incomplete. busy={busy}, logPages={logPages}, checkPointedPages={checkPointed}.",
                    busy,
                    log,
                    checkPointed
                );
            }
            else
            {
                _logger.LogDebug(
                    "SQLite WAL passive checkpoint executed successfully. logPages={logPages}, checkPointedPages={checkPointed}.",
                    log,
                    checkPointed
                );
            }

            // 2. Monitor WAL file size
            try
            {
                var dbPathString = connection.ConnectionString;
                var connStringBuilder = new Microsoft.Data.Sqlite.SqliteConnectionStringBuilder(
                    dbPathString
                );
                var dataSource = connStringBuilder.DataSource;

                if (
                    !string.IsNullOrEmpty(dataSource)
                    && !dataSource.Equals(":memory:", StringComparison.OrdinalIgnoreCase)
                )
                {
                    var absoluteDbPath = System.IO.Path.GetFullPath(dataSource);
                    var walPath = absoluteDbPath + "-wal";

                    if (System.IO.File.Exists(walPath))
                    {
                        var fileInfo = new System.IO.FileInfo(walPath);
                        var sizeMb = fileInfo.Length / (1024.0 * 1024.0);
                        if (sizeMb > 50.0)
                        {
                            _logger.LogWarning(
                                "SQLite WAL file size is excessive: {SizeMb:F2} MB (threshold: 50.0 MB). Check for blocked checkpoints or long-running read transactions.",
                                sizeMb
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(
                    ex,
                    "Failed to inspect SQLite WAL file size during checkpoint monitoring."
                );
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to execute SQLite WAL passive checkpoint.");
            throw;
        }
    }
}
