using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Interfaces;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Votech.Edge.Storage;

/// <summary>
/// Background service that periodically runs storage maintenance on the SQLite sample buffer to protect edge storage
/// from exhaustion: capping and eviction, and WAL checkpoints.
/// </summary>
public sealed class StorageMaintenanceService(
    ISignalBuffer signalBuffer,
    IOptions<EdgeAgentOptions> options,
    ILogger<StorageMaintenanceService> logger
) : BackgroundService
{
    private readonly ISignalBuffer _signalBuffer = signalBuffer;
    private readonly IOptions<EdgeAgentOptions> _options = options;
    private readonly ILogger<StorageMaintenanceService> _logger = logger;

    // Run periodic storage maintenance checks every 10 minutes.
    private static readonly TimeSpan MaintenanceInterval = TimeSpan.FromMinutes(10);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Storage Maintenance Service started.");

        var cappingTask = RunStorageCappingLoopAsync(stoppingToken);
        var checkpointTask = RunCheckpointLoopAsync(stoppingToken);

        await Task.WhenAll(cappingTask, checkpointTask);

        _logger.LogInformation("Storage Maintenance Service stopped.");
    }

    private async Task RunStorageCappingLoopAsync(CancellationToken ct)
    {
        _logger.LogInformation(
            "Storage Capping Loop started. Running every {IntervalMinutes} minutes.",
            MaintenanceInterval.TotalMinutes
        );

        // Run once immediately at startup
        try
        {
            await RunMaintenanceAsync(ct);
        }
        catch (OperationCanceledException)
        {
            return;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Initial storage maintenance check failed.");
        }

        using var timer = new PeriodicTimer(MaintenanceInterval);

        while (!ct.IsCancellationRequested)
        {
            try
            {
                await timer.WaitForNextTickAsync(ct);
                await RunMaintenanceAsync(ct);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during periodic storage maintenance check.");
            }
        }
    }

    private async Task RunCheckpointLoopAsync(CancellationToken ct)
    {
        var interval = TimeSpan.FromMinutes(_options.Value.Storage.CheckpointIntervalMinutes);
        _logger.LogInformation(
            "SQLite WAL checkpoint loop started. Running every {IntervalMinutes} minutes.",
            interval.TotalMinutes
        );

        // Run once immediately at startup
        try
        {
            await _signalBuffer.CheckpointDatabaseAsync(ct);
        }
        catch (OperationCanceledException)
        {
            return;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Initial SQLite WAL checkpoint failed.");
        }

        using var timer = new PeriodicTimer(interval);

        while (!ct.IsCancellationRequested)
        {
            try
            {
                await timer.WaitForNextTickAsync(ct);
                await _signalBuffer.CheckpointDatabaseAsync(ct);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during periodic SQLite WAL checkpoint check.");
            }
        }
    }

    private async Task RunMaintenanceAsync(CancellationToken ct)
    {
        _logger.LogDebug("Evaluating storage limits and enforcing capacity thresholds...");
        await _signalBuffer.EnforceStorageCapAsync(_options.Value.Storage, ct);
    }
}
