using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Votech.Edge.Storage.Migrations
{
    /// <inheritdoc />
    public partial class AddSampleTimeSource : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<long>(
                name: "device_timestamp",
                table: "SignalSamples",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<long>(
                name: "receive_lag",
                table: "SignalSamples",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<byte>(
                name: "time_source",
                table: "SignalSamples",
                type: "INTEGER",
                nullable: false,
                defaultValue: (byte)0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "device_timestamp",
                table: "SignalSamples");

            migrationBuilder.DropColumn(
                name: "receive_lag",
                table: "SignalSamples");

            migrationBuilder.DropColumn(
                name: "time_source",
                table: "SignalSamples");
        }
    }
}
