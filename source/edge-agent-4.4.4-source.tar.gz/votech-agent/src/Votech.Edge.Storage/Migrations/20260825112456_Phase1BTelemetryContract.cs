﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Votech.Edge.Storage.Migrations
{
    /// <inheritdoc />
    public partial class Phase1BTelemetryContract : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "batch_id",
                table: "TelemetryPoints",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "quality_status",
                table: "TelemetryPoints",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "tag_id",
                table: "TelemetryPoints",
                type: "TEXT",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "CachedDeviceConfigs",
                columns: table => new
                {
                    device_id = table.Column<string>(type: "TEXT", nullable: false),
                    site_id = table.Column<string>(type: "TEXT", nullable: false),
                    device_name = table.Column<string>(type: "TEXT", nullable: false),
                    protocol = table.Column<string>(type: "TEXT", nullable: false),
                    json_data = table.Column<string>(type: "TEXT", nullable: false),
                    updated_at = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CachedDeviceConfigs", x => x.device_id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CachedDeviceConfigs");

            migrationBuilder.DropColumn(
                name: "batch_id",
                table: "TelemetryPoints");

            migrationBuilder.DropColumn(
                name: "quality_status",
                table: "TelemetryPoints");

            migrationBuilder.DropColumn(
                name: "tag_id",
                table: "TelemetryPoints");
        }
    }
}
