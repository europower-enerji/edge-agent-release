using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Votech.Edge.Storage.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TelemetryPoints",
                columns: table => new
                {
                    id = table.Column<string>(type: "TEXT", nullable: false),
                    device_id = table.Column<string>(type: "TEXT", nullable: false),
                    tag_name = table.Column<string>(type: "TEXT", nullable: false),
                    value = table.Column<double>(type: "REAL", nullable: false),
                    timestamp = table.Column<DateTime>(type: "TEXT", nullable: false),
                    is_published = table.Column<bool>(type: "INTEGER", nullable: false),
                    quality = table.Column<byte>(type: "INTEGER", nullable: false),
                    data_type = table.Column<string>(type: "TEXT", nullable: false),
                    protocol = table.Column<string>(type: "TEXT", nullable: false),
                    protocol_address = table.Column<string>(type: "TEXT", nullable: true),
                    unit = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TelemetryPoints", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TelemetryPoints_DeviceId_Timestamp",
                table: "TelemetryPoints",
                columns: new[] { "device_id", "timestamp" });

            migrationBuilder.CreateIndex(
                name: "IX_TelemetryPoints_IsPublished_Timestamp",
                table: "TelemetryPoints",
                columns: new[] { "is_published", "timestamp" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TelemetryPoints");
        }
    }
}
