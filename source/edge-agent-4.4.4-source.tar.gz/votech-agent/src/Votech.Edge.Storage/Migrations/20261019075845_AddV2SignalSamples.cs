using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Votech.Edge.Storage.Migrations
{
    /// <inheritdoc />
    public partial class AddV2SignalSamples : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EdgeConfigurationCache",
                columns: table => new
                {
                    id = table.Column<int>(type: "INTEGER", nullable: false),
                    revision = table.Column<string>(type: "TEXT", nullable: false),
                    schema_version = table.Column<int>(type: "INTEGER", nullable: false),
                    payload = table.Column<byte[]>(type: "BLOB", nullable: false),
                    fetched_at = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EdgeConfigurationCache", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "SignalBatches",
                columns: table => new
                {
                    batch_id = table.Column<byte[]>(type: "BLOB", nullable: false),
                    endpoint_id = table.Column<byte[]>(type: "BLOB", nullable: false),
                    config_revision = table.Column<string>(type: "TEXT", nullable: false),
                    created_at = table.Column<long>(type: "INTEGER", nullable: false),
                    sample_count = table.Column<int>(type: "INTEGER", nullable: false),
                    is_published = table.Column<bool>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SignalBatches", x => x.batch_id);
                });

            migrationBuilder.CreateTable(
                name: "SignalSamples",
                columns: table => new
                {
                    id = table.Column<long>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    batch_id = table.Column<byte[]>(type: "BLOB", nullable: false),
                    signal_id = table.Column<byte[]>(type: "BLOB", nullable: false),
                    value = table.Column<double>(type: "REAL", nullable: false),
                    timestamp = table.Column<long>(type: "INTEGER", nullable: false),
                    quality_status = table.Column<byte>(type: "INTEGER", nullable: false),
                    raw_quality = table.Column<int>(type: "INTEGER", nullable: false),
                    device_time = table.Column<bool>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SignalSamples", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_SignalBatches_IsPublished_CreatedAt",
                table: "SignalBatches",
                columns: new[] { "is_published", "created_at" });

            migrationBuilder.CreateIndex(
                name: "IX_SignalSamples_BatchId",
                table: "SignalSamples",
                column: "batch_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EdgeConfigurationCache");

            migrationBuilder.DropTable(
                name: "SignalBatches");

            migrationBuilder.DropTable(
                name: "SignalSamples");
        }
    }
}
