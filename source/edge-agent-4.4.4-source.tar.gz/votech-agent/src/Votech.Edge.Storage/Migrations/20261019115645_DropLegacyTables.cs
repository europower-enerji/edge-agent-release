using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Votech.Edge.Storage.Migrations
{
    /// <inheritdoc />
    public partial class DropLegacyTables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CachedDeviceConfigs");

            migrationBuilder.DropTable(
                name: "TelemetryPoints");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CachedDeviceConfigs",
                columns: table => new
                {
                    device_id = table.Column<string>(type: "TEXT", nullable: false),
                    device_name = table.Column<string>(type: "TEXT", nullable: false),
                    json_data = table.Column<string>(type: "TEXT", nullable: false),
                    protocol = table.Column<string>(type: "TEXT", nullable: false),
                    site_id = table.Column<string>(type: "TEXT", nullable: false),
                    updated_at = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CachedDeviceConfigs", x => x.device_id);
                });

            migrationBuilder.CreateTable(
                name: "TelemetryPoints",
                columns: table => new
                {
                    id = table.Column<string>(type: "TEXT", nullable: false),
                    batch_id = table.Column<string>(type: "TEXT", nullable: false),
                    data_type = table.Column<string>(type: "TEXT", nullable: false),
                    device_id = table.Column<string>(type: "TEXT", nullable: false),
                    is_published = table.Column<bool>(type: "INTEGER", nullable: false),
                    protocol = table.Column<string>(type: "TEXT", nullable: false),
                    protocol_address = table.Column<string>(type: "TEXT", nullable: true),
                    quality = table.Column<byte>(type: "INTEGER", nullable: false),
                    quality_status = table.Column<int>(type: "INTEGER", nullable: false),
                    site_id = table.Column<string>(type: "TEXT", nullable: false),
                    tag_id = table.Column<string>(type: "TEXT", nullable: true),
                    tag_name = table.Column<string>(type: "TEXT", nullable: false),
                    tenant_id = table.Column<string>(type: "TEXT", nullable: false),
                    timestamp = table.Column<DateTime>(type: "TEXT", nullable: false),
                    unit = table.Column<string>(type: "TEXT", nullable: false),
                    value = table.Column<double>(type: "REAL", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TelemetryPoints", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TelemetryPoints_DeviceId_Timestamp",
                table: "TelemetryPoints",
                columns: new[] { "device_id", "timestamp" });

            migrationBuilder.CreateIndex(
                name: "IX_TelemetryPoints_IsPublished_Timestamp",
                table: "TelemetryPoints",
                columns: new[] { "is_published", "timestamp" });
        }
    }
}
