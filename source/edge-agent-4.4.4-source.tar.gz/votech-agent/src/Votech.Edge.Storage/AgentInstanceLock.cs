using System.Text;

namespace Votech.Edge.Storage;

/// <summary>
/// Holds <c>&lt;database&gt;-lock</c> exclusively for the life of the process, so one agent runs per local database. A
/// second agent would also connect to every RTU, and most RTUs serve one master: the second connection gets no STARTDT.
/// The file holds the owner's process id; the lock is released when the process exits, however it exits.
/// </summary>
public sealed class AgentInstanceLock : IDisposable
{
    private readonly FileStream _file;

    private AgentInstanceLock(FileStream file, string path)
    {
        _file = file;
        Path = path;
    }

    /// <summary>The lock file.</summary>
    public string Path { get; }

    /// <summary>
    /// Locks the database at <paramref name="dataSource"/>, waiting up to <paramref name="wait"/> for an agent that is
    /// still stopping (a dotnet watch restart). Null for an in-memory database.
    /// </summary>
    /// <exception cref="InvalidOperationException">Another agent still holds the lock after <paramref name="wait"/>.</exception>
    public static AgentInstanceLock? Acquire(string dataSource, TimeSpan wait)
    {
        if (string.IsNullOrEmpty(dataSource) || dataSource.Equals(":memory:", StringComparison.OrdinalIgnoreCase))
        {
            return null;
        }

        var path = System.IO.Path.GetFullPath(dataSource) + "-lock";
        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path)!);
        var deadline = DateTime.UtcNow + wait;
        while (true)
        {
            try
            {
                var file = new FileStream(path, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
                file.SetLength(0);
                file.Write(Encoding.ASCII.GetBytes(Environment.ProcessId.ToString()));
                file.Flush();
                return new AgentInstanceLock(file, path);
            }
            catch (IOException) when (DateTime.UtcNow < deadline)
            {
                Thread.Sleep(250);
            }
            catch (IOException ex)
            {
                throw new InvalidOperationException(
                    $"Another agent is running on {dataSource}: {path} is locked (it holds that agent's process id). Stop it first; two agents would both connect to every RTU.",
                    ex
                );
            }
        }
    }

    public void Dispose() => _file.Dispose();
}
