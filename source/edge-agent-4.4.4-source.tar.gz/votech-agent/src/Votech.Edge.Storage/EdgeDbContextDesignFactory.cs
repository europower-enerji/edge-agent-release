using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Votech.Edge.Storage;

/// <summary>
/// Builds the context for <c>dotnet ef</c> (migrations add, script) without the agent's configuration, so no
/// <c>.env</c>, agent key or database password is needed. The database is never opened at design time.
/// <code>dotnet ef migrations add &lt;Name&gt; --project src/Votech.Edge.Storage --startup-project src/Votech.Edge.Storage</code>
/// </summary>
public sealed class EdgeDbContextDesignFactory : IDesignTimeDbContextFactory<EdgeDbContext>
{
    public EdgeDbContext CreateDbContext(string[] args) =>
        new(new DbContextOptionsBuilder<EdgeDbContext>().UseSqlite("Data Source=edge-design.db").Options);
}
