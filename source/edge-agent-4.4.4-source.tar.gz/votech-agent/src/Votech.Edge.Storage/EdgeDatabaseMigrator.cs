using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace Votech.Edge.Storage;

/// <summary>
/// Applies the pending migrations of the local buffer. Before it changes an existing database file it copies the file
/// to <c>&lt;file&gt;.bak-&lt;version&gt;</c>, so an upgrade can be rolled back to the previous agent with its
/// unpublished data. The WAL is checkpointed first, so the copy holds every committed write.
/// </summary>
public static class EdgeDatabaseMigrator
{
    /// <summary>Migrates <paramref name="db"/>; returns the path of the backup, or null when none was made.</summary>
    public static async Task<string?> MigrateAsync(
        EdgeDbContext db,
        string agentVersion,
        ILogger logger,
        CancellationToken ct = default
    )
    {
        var pending = (await db.Database.GetPendingMigrationsAsync(ct)).ToList();
        if (pending.Count == 0)
        {
            return null;
        }

        string? backup = null;
        var applied = (await db.Database.GetAppliedMigrationsAsync(ct)).ToList();
        var file = DatabaseFile(db);
        if (applied.Count > 0 && file != null && File.Exists(file))
        {
            await db.Database.ExecuteSqlRawAsync("PRAGMA wal_checkpoint(TRUNCATE);", ct);
            backup = $"{file}.bak-{agentVersion}";
            File.Copy(file, backup, overwrite: true);
            logger.LogInformation(
                "[STORAGE] Copied {File} to {Backup} before applying {Count} migration(s): {Migrations}.",
                file,
                backup,
                pending.Count,
                string.Join(", ", pending)
            );
        }

        await db.Database.MigrateAsync(ct);
        return backup;
    }

    /// <summary>The full path of the database file, or null for an in-memory database.</summary>
    internal static string? DatabaseFile(EdgeDbContext db)
    {
        var dataSource = new SqliteConnectionStringBuilder(db.Database.GetConnectionString()).DataSource;
        return string.IsNullOrEmpty(dataSource)
            || dataSource.Equals(":memory:", StringComparison.OrdinalIgnoreCase)
            || dataSource.StartsWith("file::memory:", StringComparison.OrdinalIgnoreCase)
            ? null
            : Path.GetFullPath(dataSource);
    }
}
