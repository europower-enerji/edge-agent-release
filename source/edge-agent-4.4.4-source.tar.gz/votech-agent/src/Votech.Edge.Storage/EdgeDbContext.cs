using Votech.Edge.Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace Votech.Edge.Storage;

public class EdgeDbContext : DbContext
{
    public DbSet<BufferedSignalBatch> SignalBatches { get; set; } = null!;
    public DbSet<BufferedSignalSample> SignalSamples { get; set; } = null!;
    public DbSet<CachedEdgeConfiguration> EdgeConfigurationCache { get; set; } = null!;

    public EdgeDbContext(DbContextOptions<EdgeDbContext> options)
        : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // ─── Contract v2 buffer: batches are sent whole, oldest first ───────────
        modelBuilder.Entity<BufferedSignalBatch>(entity =>
        {
            entity.ToTable("SignalBatches");
            entity.HasKey(e => e.BatchId);
            entity
                .HasIndex(e => new { e.IsPublished, e.CreatedAtMs })
                .HasDatabaseName("IX_SignalBatches_IsPublished_CreatedAt");

            entity.Property(e => e.BatchId).HasColumnName("batch_id");
            entity.Property(e => e.EndpointId).HasColumnName("endpoint_id");
            entity.Property(e => e.ConfigRevision).HasColumnName("config_revision");
            entity.Property(e => e.CreatedAtMs).HasColumnName("created_at");
            entity.Property(e => e.SampleCount).HasColumnName("sample_count");
            entity.Property(e => e.IsPublished).HasColumnName("is_published");
        });

        modelBuilder.Entity<BufferedSignalSample>(entity =>
        {
            entity.ToTable("SignalSamples");
            entity.HasKey(e => e.Id);
            entity.HasIndex(e => e.BatchId).HasDatabaseName("IX_SignalSamples_BatchId");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.BatchId).HasColumnName("batch_id");
            entity.Property(e => e.SignalId).HasColumnName("signal_id");
            entity.Property(e => e.Value).HasColumnName("value");
            entity.Property(e => e.TimestampMs).HasColumnName("timestamp");
            entity.Property(e => e.QualityStatus).HasColumnName("quality_status");
            entity.Property(e => e.RawQuality).HasColumnName("raw_quality");
            entity.Property(e => e.DeviceTime).HasColumnName("device_time");
            entity.Property(e => e.TimeSource).HasColumnName("time_source");
            entity.Property(e => e.DeviceTimestampMs).HasColumnName("device_timestamp");
            entity.Property(e => e.ReceiveLagMs).HasColumnName("receive_lag");
        });

        modelBuilder.Entity<CachedEdgeConfiguration>(entity =>
        {
            entity.ToTable("EdgeConfigurationCache");
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id).HasColumnName("id").ValueGeneratedNever();
            entity.Property(e => e.Revision).HasColumnName("revision");
            entity.Property(e => e.SchemaVersion).HasColumnName("schema_version");
            entity.Property(e => e.Payload).HasColumnName("payload");
            entity.Property(e => e.FetchedAt).HasColumnName("fetched_at");
        });
    }
}
