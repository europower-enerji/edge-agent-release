using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Storage;

/// <summary>
/// Every site has its own SQLite buffer, <c>{folder of Storage:SqliteConnectionString}/{tenantId}/{siteId}.db</c>, so
/// one site's samples, cached configuration and storage cap never touch another's, and each file has its own
/// single-agent lock. A database written by agent 2.x at the configured path keeps serving the site whose
/// configuration it caches, with its unpublished batches.
/// </summary>
public static class SiteDatabase
{
    /// <summary>The connection string of <paramref name="site"/>'s database, derived from the configured one.</summary>
    public static string ConnectionStringFor(AgentSite site, string configuredConnectionString, string? password, ILogger logger)
    {
        var builder = new SqliteConnectionStringBuilder(configuredConnectionString);
        if (!string.IsNullOrEmpty(password))
        {
            builder.Password = password;
        }

        if (IsInMemory(builder.DataSource))
        {
            return builder.ConnectionString;
        }

        var configured = Path.GetFullPath(builder.DataSource);
        var own = Path.Combine(Path.GetDirectoryName(configured)!, site.TenantId.ToString(), $"{site.SiteId}.db");
        if (!File.Exists(own) && File.Exists(configured) && CachedSiteOf(builder.ConnectionString) == site.SiteId)
        {
            logger.LogInformation(
                "[STORAGE] Site {SiteId} keeps its database {File} (written by agent 2.x; it holds this site's configuration and buffered samples).",
                site.SiteId,
                configured
            );
            return builder.ConnectionString;
        }

        builder.DataSource = own;
        return builder.ConnectionString;
    }

    /// <summary>Creates the folder, applies the migrations (copying an existing file first) and the PRAGMAs.</summary>
    public static async Task PrepareAsync(IDbContextFactory<EdgeDbContext> factory, string agentVersion, ILogger logger, CancellationToken ct)
    {
        await using var db = await factory.CreateDbContextAsync(ct);
        var file = EdgeDatabaseMigrator.DatabaseFile(db);
        if (file != null)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(file)!);
        }

        await EdgeDatabaseMigrator.MigrateAsync(db, agentVersion, logger, ct);
        await db.Database.ExecuteSqlRawAsync("PRAGMA journal_mode = WAL;", ct);
        await db.Database.ExecuteSqlRawAsync($"PRAGMA busy_timeout = {StorageConstants.BusyTimeoutMs};", ct);
        await db.Database.ExecuteSqlRawAsync("PRAGMA synchronous = NORMAL;", ct);
        await db.Database.ExecuteSqlRawAsync($"PRAGMA cache_size = {StorageConstants.DefaultPageCacheKb};", ct);
        logger.LogInformation("[STORAGE] Database {File} ready (WAL).", file ?? ":memory:");
    }

    /// <summary>The data source of a connection string, for the lock file.</summary>
    public static string DataSourceOf(string connectionString) => new SqliteConnectionStringBuilder(connectionString).DataSource;

    /// <summary>The site of the configuration cached in a 2.x database, or null when there is none or it cannot be read.</summary>
    internal static Guid? CachedSiteOf(string connectionString)
    {
        try
        {
            var readOnly = new SqliteConnectionStringBuilder(connectionString) { Mode = SqliteOpenMode.ReadOnly, Pooling = false };
            using var connection = new SqliteConnection(readOnly.ConnectionString);
            connection.Open();
            using var command = connection.CreateCommand();
            command.CommandText = "SELECT payload FROM EdgeConfigurationCache LIMIT 1";
            return command.ExecuteScalar() is byte[] payload ? EdgeIds.ToGuid(V2.EdgeConfiguration.Parser.ParseFrom(payload).SiteId) : null;
        }
        catch (Exception ex) when (ex is SqliteException or Google.Protobuf.InvalidProtocolBufferException or InvalidOperationException)
        {
            return null;
        }
    }

    private static bool IsInMemory(string dataSource) =>
        string.IsNullOrEmpty(dataSource)
        || dataSource.Equals(":memory:", StringComparison.OrdinalIgnoreCase)
        || dataSource.StartsWith("file::memory:", StringComparison.OrdinalIgnoreCase);
}
