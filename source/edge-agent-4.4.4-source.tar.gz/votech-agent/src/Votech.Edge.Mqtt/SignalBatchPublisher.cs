using Google.Protobuf;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Interfaces;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Mqtt;

/// <summary>
/// The only path from the buffer to the broker (contract v2): sends the oldest unpublished batch as a
/// <c>SignalBatch</c> to <c>{prefix}/v2/telemetry/{siteId}/{endpointId}</c>, marks it published after the broker's
/// PUBACK, and repeats until the buffer is empty. It wakes when batches are stored, and every
/// <c>FlushIntervalMs</c>. A failed publish leaves the batch in place; the next attempt sends the same samples under
/// the same batch id, so the backend applies it once.
/// </summary>
public sealed class SignalBatchPublisher(
    ISignalBuffer buffer,
    IMqttPublisher publisher,
    IOptions<EdgeAgentOptions> options,
    ILogger<SignalBatchPublisher> logger,
    TimeProvider? timeProvider = null
)
{
    private static readonly TimeSpan SummaryInterval = TimeSpan.FromMinutes(1);

    private readonly ISignalBuffer _buffer = buffer;
    private readonly IMqttPublisher _publisher = publisher;
    private readonly EdgeAgentOptions _options = options.Value;
    private readonly ILogger<SignalBatchPublisher> _logger = logger;
    private readonly TimeProvider _time = timeProvider ?? TimeProvider.System;
    private readonly Guid _siteId = Guid.TryParse(options.Value.SiteId, out var siteId) ? siteId : Guid.Empty;
    private long _batches;
    private long _samples;
    private DateTimeOffset _summaryAt = (timeProvider ?? TimeProvider.System).GetUtcNow();

    public async Task RunAsync(CancellationToken ct)
    {
        var interval = TimeSpan.FromMilliseconds(_options.FlushIntervalMs);
        while (!ct.IsCancellationRequested)
        {
            try
            {
                if (_publisher.IsConnected)
                {
                    await PublishPendingAsync(ct);
                }

                await _buffer.WaitForBatchesAsync(interval, ct);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "[MQTT-V2] Publishing from the buffer failed; retrying.");
                await Task.Delay(interval, _time, ct);
            }
        }
    }

    /// <summary>Publishes until the buffer is empty or a publish fails; returns the number of batches sent.</summary>
    public async Task<int> PublishPendingAsync(CancellationToken ct)
    {
        var sent = 0;
        while (_publisher.IsConnected && await _buffer.NextUnpublishedAsync(ct) is { } stored)
        {
            var batch = ToMessage(stored, _siteId, _time.GetUtcNow());
            try
            {
                await _publisher.PublishSignalBatchAsync(batch, ct);
            }
            catch (Exception ex) when (ex is not OperationCanceledException || !ct.IsCancellationRequested)
            {
                _logger.LogWarning(
                    ex,
                    "[MQTT-V2] Batch {BatchId} ({Count} samples) was not acknowledged; it stays in the buffer.",
                    Convert.ToHexStringLower(stored.Batch.BatchId),
                    stored.Samples.Count
                );
                break;
            }

            await _buffer.MarkPublishedAsync(stored.Batch.BatchId, ct);
            sent++;
            _batches++;
            _samples += stored.Samples.Count;
        }

        await LogSummaryAsync(ct);
        return sent;
    }

    /// <summary>The wire form of a stored batch: its own id, endpoint and revision, and the samples in stored order.</summary>
    public static V2.SignalBatch ToMessage(StoredSignalBatch stored, Guid siteId, DateTimeOffset sentAt)
    {
        var batch = new V2.SignalBatch
        {
            BatchId = EdgeIds.ToByteString(stored.Batch.BatchId),
            SiteId = EdgeIds.ToByteString(siteId),
            EndpointId = EdgeIds.ToByteString(stored.Batch.EndpointId),
            ConfigRevision = stored.Batch.ConfigRevision,
            SentAtMs = sentAt.ToUnixTimeMilliseconds(),
        };
        batch.Samples.AddRange(stored.Samples.Select(s => new V2.SignalSample
        {
            SignalId = UnsafeByteOperations.UnsafeWrap(s.SignalId),
            Value = s.Value,
            TimestampMs = s.TimestampMs,
            Quality = (V2.Quality)s.QualityStatus,
            RawQuality = (uint)s.RawQuality,
            DeviceTime = s.DeviceTime,
            TimeSource = (V2.TimeSource)s.TimeSource,
            DeviceTimestampMs = s.DeviceTimestampMs,
            ReceiveLagMs = s.ReceiveLagMs,
        }));
        return batch;
    }

    private async Task LogSummaryAsync(CancellationToken ct)
    {
        var now = _time.GetUtcNow();
        if (now - _summaryAt < SummaryInterval || _batches == 0)
        {
            return;
        }

        var waiting = await _buffer.GetStatusAsync(ct);
        _logger.LogInformation(
            "[MQTT-V2] Sent {Batches} batches, {Samples} samples in {Seconds:0} s; {Waiting} waiting.",
            _batches,
            _samples,
            (now - _summaryAt).TotalSeconds,
            waiting.UnpublishedSamples
        );
        (_batches, _samples, _summaryAt) = (0, 0, now);
    }
}
