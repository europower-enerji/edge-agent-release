using Votech.Edge.Core.Configuration;
using Microsoft.Extensions.Logging;
using MQTTnet.Client;

namespace Votech.Edge.Mqtt;

/// <summary>
/// The broker transport of both sessions of a site, the data session (<see cref="MqttPublisher"/>) and the command
/// session (<see cref="V2CommandSubscriber"/>): TCP to <c>BrokerHost:BrokerPort</c>, or WebSockets to
/// <see cref="MqttOptions.WebSocketUri"/> when <see cref="MqttOptions.WebSocketPath"/> is set (EMS-202). Both take the
/// same TLS options (<see cref="MqttTlsOptionsFactory"/>), the private CA (A-02) included.
/// </summary>
public static class MqttBrokerConnection
{
    public static MqttClientOptionsBuilder WithBroker(this MqttClientOptionsBuilder builder, MqttOptions options, ILogger? logger = null)
    {
        if (options.UsesWebSocket)
        {
            builder.WithWebSocketServer(webSocket => webSocket.WithUri(options.WebSocketUri));
        }
        else
        {
            builder.WithTcpServer(options.BrokerHost, options.BrokerPort);
        }

        if (options.UseTls)
        {
            builder.WithTlsOptions(MqttTlsOptionsFactory.BuildTlsOptions(options, logger));
        }

        return builder;
    }
}
