using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using Votech.Edge.Core.Configuration;
using Microsoft.Extensions.Logging;
using MQTTnet.Client;

namespace Votech.Edge.Mqtt;

/// <summary>
/// Helper factory to build unified MQTT client TLS options with private CA validation (<see cref="PrivateCaTrust"/>) and
/// mTLS support. Shared across MQTT publisher and command subscriber connections to guarantee transport security parity.
/// </summary>
public static class MqttTlsOptionsFactory
{
    /// <summary>
    /// Builds an <see cref="MqttClientTlsOptions"/> instance based on <see cref="MqttOptions"/>.
    /// Configures TLS 1.2/1.3, private CA verification, and mTLS client certificates. Throws
    /// <see cref="InvalidOperationException"/> when a configured CA file cannot be read.
    /// </summary>
    public static MqttClientTlsOptions BuildTlsOptions(MqttOptions options, ILogger? logger = null)
    {
        var tlsBuilder = new MqttClientTlsOptionsBuilder()
            .UseTls()
            .WithSslProtocols(SslProtocols.Tls12 | SslProtocols.Tls13);

        // A private CA (A-02): only it is trusted, the certificate must name the broker host, and a CA file that cannot
        // be read stops this connection instead of falling back to the system store (the options validator stops the
        // agent at startup before it gets here)
        if (!string.IsNullOrEmpty(options.CaCertificatePath))
        {
            var roots = PrivateCaTrust.Load(options.CaCertificatePath);
            tlsBuilder.WithCertificateValidationHandler(ctx =>
            {
                if (PrivateCaTrust.Validate(ctx.Certificate, ctx.Chain, ctx.SslPolicyErrors, roots, out var reason))
                {
                    return true;
                }

                logger?.LogError(
                    "[MqttTls] Refused the certificate of broker {Host}: {Reason}. Only the CA in {Path} is trusted.",
                    options.BrokerHost,
                    reason,
                    options.CaCertificatePath
                );
                return false;
            });
        }

        // Load client certificate for mTLS if configured
        if (
            !string.IsNullOrEmpty(options.ClientCertificatePath)
            && !string.IsNullOrEmpty(options.ClientKeyPath)
        )
        {
            if (File.Exists(options.ClientCertificatePath) && File.Exists(options.ClientKeyPath))
            {
                try
                {
                    var cert = X509Certificate2.CreateFromPemFile(
                        options.ClientCertificatePath,
                        options.ClientKeyPath
                    );
                    var pfxBytes = cert.Export(X509ContentType.Pkcs12);
                    var certPfx = X509CertificateLoader.LoadPkcs12(
                        pfxBytes,
                        (string?)null,
                        X509KeyStorageFlags.EphemeralKeySet
                    );
                    tlsBuilder.WithClientCertificates(new[] { certPfx });
                }
                catch (Exception ex)
                {
                    logger?.LogError(
                        ex,
                        "[MqttTls] Failed to load mTLS client certificate ({CertPath}) or key ({KeyPath})",
                        options.ClientCertificatePath,
                        options.ClientKeyPath
                    );
                }
            }
            else
            {
                logger?.LogWarning(
                    "[MqttTls] Specified mTLS Client Certificate ({CertPath}) or Key ({KeyPath}) file not found.",
                    options.ClientCertificatePath,
                    options.ClientKeyPath
                );
            }
        }

        return tlsBuilder.Build();
    }
}
