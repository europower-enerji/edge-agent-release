using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;

namespace Votech.Edge.Mqtt;

/// <summary>
/// Builds MQTT topic strings following the Votech topic schema.
/// All segments reference MqttConstants — never inline strings.
///
/// Schema:
///   v2:         {prefix}/v2/{telemetry|status|ack|commands}/{siteId}/{endpointId|clientId|command}
/// </summary>
public sealed class MqttTopicBuilder
{
    private readonly string _prefix;
    private readonly string _clientId;

    public MqttTopicBuilder(MqttOptions options)
    {
        _prefix = options.TopicPrefix.TrimEnd('/');
        _clientId = options.ClientId;
    }

    // ─── Contract v2 (ADR-002): {prefix}/v2/{kind}/{siteId}/… ────────────────

    public string V2Telemetry(Guid siteId, Guid endpointId) =>
        $"{_prefix}/{EdgeContractConstants.TopicVersion}/{MqttConstants.TopicTelemetry}/{siteId}/{endpointId}";

    public string V2Status(Guid siteId) =>
        $"{_prefix}/{EdgeContractConstants.TopicVersion}/{MqttConstants.TopicStatus}/{siteId}/{_clientId}";

    public string V2Ack(Guid siteId, Guid endpointId) =>
        $"{_prefix}/{EdgeContractConstants.TopicVersion}/{MqttConstants.TopicAck}/{siteId}/{endpointId}";

    public string V2Command(Guid siteId, string command) =>
        $"{_prefix}/{EdgeContractConstants.TopicVersion}/{MqttConstants.TopicCommands}/{siteId}/{command}";
}
