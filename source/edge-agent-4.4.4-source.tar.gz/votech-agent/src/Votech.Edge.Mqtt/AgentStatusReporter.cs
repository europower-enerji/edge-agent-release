using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Interfaces;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Mqtt;

/// <summary>
/// Publishes the retained v2 <c>AgentStatus</c> (<c>{prefix}/v2/status/{siteId}/{clientId}</c>): the agent version and
/// the protocols it can acquire, the configuration revision it runs, the health of every endpoint (each connection's
/// root and the stations behind it) and the buffer. It is sent every <c>HeartbeatIntervalSec</c>, at once (and logged)
/// when an endpoint connects, disconnects or changes its reason, and as OFFLINE on a clean shutdown (the broker sends the
/// Last Will otherwise). A connected station without a single point is reported with
/// <see cref="DeviceDiagnosticReason.NoPointsConfigured"/> and a text saying nothing is read, so the web does not show it
/// as healthy. The buffer status carries the readings the sink dropped and the unpublished samples the buffer evicted.
/// </summary>
public sealed class AgentStatusReporter(
    IConnectionManager connections,
    ISignalBuffer buffer,
    IMqttPublisher publisher,
    IOptions<EdgeAgentOptions> options,
    ILogger<AgentStatusReporter> logger,
    IEdgeConfigurationSource? configuration = null,
    TimeProvider? timeProvider = null,
    ISignalSink? sink = null
) : BackgroundService
{
    private static readonly TimeSpan ChangeCheckInterval = TimeSpan.FromSeconds(1);

    private readonly IConnectionManager _connections = connections;
    private readonly ISignalBuffer _buffer = buffer;
    private readonly IMqttPublisher _publisher = publisher;
    private readonly EdgeAgentOptions _options = options.Value;
    private readonly ILogger<AgentStatusReporter> _logger = logger;
    private readonly IEdgeConfigurationSource? _configuration = configuration;
    private readonly ISignalSink? _sink = sink;
    private readonly TimeProvider _time = timeProvider ?? TimeProvider.System;

    /// <summary>The error text of a connected station without points.</summary>
    public const string NoPointsError = "Connected, but none of its signals has an address: nothing is read. Give its signals their addresses (signal address or IO list import).";
    private readonly Guid _siteId = Guid.TryParse(options.Value.SiteId, out var siteId) ? siteId : Guid.Empty;

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var heartbeat = TimeSpan.FromSeconds(_options.Mqtt.HeartbeatIntervalSec);
        var lastSent = DateTimeOffset.MinValue;
        string? lastShape = null;
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                var shape = Shape();
                if (_publisher.IsConnected && (shape != lastShape || _time.GetUtcNow() - lastSent >= heartbeat))
                {
                    var status = await PublishAsync(V2.AgentState.Online, stoppingToken);
                    if (shape != lastShape)
                    {
                        _logger.LogInformation(
                            "[STATUS] {State}: {Connected}/{Total} endpoints connected.",
                            status.State,
                            status.Endpoints.Count(e => e.Connected),
                            status.Endpoints.Count
                        );
                    }

                    (lastShape, lastSent) = (shape, _time.GetUtcNow());
                }

                await Task.Delay(ChangeCheckInterval, _time, stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "[STATUS] Publishing the agent status failed.");
                await Task.Delay(ChangeCheckInterval, _time, stoppingToken);
            }
        }
    }

    public override async Task StopAsync(CancellationToken cancellationToken)
    {
        await base.StopAsync(cancellationToken);
        if (_publisher.IsConnected)
        {
            try
            {
                await PublishAsync(V2.AgentState.Offline, cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "[STATUS] The OFFLINE status could not be published on shutdown.");
            }
        }
    }

    /// <summary>
    /// Publishes the status. <paramref name="state"/> ONLINE becomes DEGRADED when an endpoint is down or the buffer
    /// drops unpublished samples.
    /// </summary>
    internal async Task<V2.AgentStatus> PublishAsync(V2.AgentState state, CancellationToken ct)
    {
        var bufferStatus = await _buffer.GetStatusAsync(ct);
        var status = Build(
            _options.Mqtt.ClientId,
            _siteId,
            _connections.RunningRevision,
            Endpoints(),
            bufferStatus,
            _buffer.IsEvicting,
            state,
            _time.GetUtcNow(),
            _sink?.DroppedTotal ?? 0,
            _buffer.EvictedTotal
        );
        await _publisher.PublishAgentStatusAsync(status, ct);
        return status;
    }

    /// <summary>The health of every endpoint, with a connected station that has no point marked as such.</summary>
    private List<EndpointHealth> Endpoints() =>
        MarkStationsWithoutPoints(_connections.Connections.SelectMany(c => c.Health).ToList(), StationsWithoutPoints(_configuration?.Current));

    /// <summary>The endpoints of the stations of <paramref name="configuration"/> that have no point.</summary>
    public static IReadOnlySet<Guid> StationsWithoutPoints(V2.EdgeConfiguration? configuration) =>
        configuration?.Connections
            .SelectMany(c => c.Stations)
            .Where(s => s.Points.Count == 0)
            .Select(s => EdgeIds.ToGuid(s.EndpointId))
            .ToHashSet() ?? [];

    /// <summary>A healthy connected endpoint of <paramref name="withoutPoints"/> gets <see cref="DeviceDiagnosticReason.NoPointsConfigured"/>; it stays connected.</summary>
    public static List<EndpointHealth> MarkStationsWithoutPoints(IReadOnlyList<EndpointHealth> endpoints, IReadOnlySet<Guid> withoutPoints) =>
        endpoints
            .Select(e => e.Connected && e.ReasonCode == DeviceDiagnosticReason.ConnectedHealthy && withoutPoints.Contains(e.EndpointId)
                ? e with { ReasonCode = DeviceDiagnosticReason.NoPointsConfigured, Error = NoPointsError }
                : e)
            .ToList();

    public static V2.AgentStatus Build(
        string clientId,
        Guid siteId,
        string revision,
        IReadOnlyList<EndpointHealth> endpoints,
        SignalBufferStatus buffer,
        bool evicting,
        V2.AgentState state,
        DateTimeOffset now,
        long droppedTotal = 0,
        long evictedTotal = 0
    )
    {
        var status = new V2.AgentStatus
        {
            ClientId = clientId,
            SiteId = EdgeIds.ToByteString(siteId),
            AgentVersion = AgentCapabilities.AgentVersion,
            ConfigRevision = revision,
            State = state == V2.AgentState.Online && (evicting || endpoints.Any(e => !e.Connected)) ? V2.AgentState.Degraded : state,
            TimestampMs = now.ToUnixTimeMilliseconds(),
            Buffer = new V2.BufferStatus
            {
                UnpublishedCount = (ulong)Math.Max(0, buffer.UnpublishedSamples),
                OldestUnpublishedMs = buffer.OldestUnpublishedMs,
                Evicting = evicting,
                DroppedTotal = (ulong)Math.Max(0, droppedTotal),
                EvictedTotal = (ulong)Math.Max(0, evictedTotal),
            },
        };
        status.SupportedProtocols.AddRange(AgentCapabilities.SupportedProtocols);
        status.Endpoints.AddRange(endpoints.Select(e => new V2.EndpointStatus
        {
            EndpointId = EdgeIds.ToByteString(e.EndpointId),
            Connected = e.Connected,
            LastSeenAtMs = e.LastSeenAt.HasValue ? new DateTimeOffset(DateTime.SpecifyKind(e.LastSeenAt.Value, DateTimeKind.Utc)).ToUnixTimeMilliseconds() : 0,
            ReasonCode = e.ReasonCode,
            Error = e.Error ?? string.Empty,
        }));
        return status;
    }

    /// <summary>What a status change means: the revision, and which endpoints are connected and why.</summary>
    private string Shape() =>
        _connections.RunningRevision + "|" + string.Join(
            ',',
            Endpoints().OrderBy(h => h.EndpointId).Select(h => $"{h.EndpointId:N}:{h.Connected}:{h.ReasonCode}")
        );
}
