namespace Votech.Edge.Core.Models;

/// <summary>
/// Where a sample's timestamp comes from; the values of the v2 contract's <c>TimeSource</c> (shared 2.2.0).
/// </summary>
public enum SampleTimeSource
{
    /// <summary>Not known: a sample stored by an agent before 3.1.</summary>
    Unspecified = 0,

    /// <summary>The device's own time (IEC 104 CP56Time2a), trusted.</summary>
    Device = 1,

    /// <summary>The value carries no time (Modbus, IEC 104 types without CP56Time2a): the time of receipt.</summary>
    ReceiptUntimed = 2,

    /// <summary>The device time is not trusted (its clock is off): the time of receipt; the device time is kept.</summary>
    ReceiptClockSkew = 3,

    /// <summary>The device marked its time invalid, or it is no date: the time of receipt.</summary>
    ReceiptTimeInvalid = 4,
}
