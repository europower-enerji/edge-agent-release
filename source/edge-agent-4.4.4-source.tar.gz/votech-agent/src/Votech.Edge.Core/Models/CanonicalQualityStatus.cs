namespace Votech.Edge.Core.Models;

/// <summary>
/// Internal canonical quality status decoupled from protobuf/shared contracts.
/// </summary>
public enum CanonicalQualityStatus
{
    Unspecified = 0,
    Good = 1,
    Uncertain = 2,
    Bad = 3,
    Stale = 4,
    Offline = 5
}
