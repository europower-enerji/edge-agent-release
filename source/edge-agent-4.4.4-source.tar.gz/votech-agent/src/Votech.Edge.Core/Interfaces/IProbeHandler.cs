using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Core.Interfaces;

/// <summary>Answers one v2 <c>ProbeCommand</c>.</summary>
public interface IProbeHandler
{
    Task<V2.CommandAck> ProbeAsync(V2.ProbeCommand command, DateTimeOffset now, CancellationToken ct);
}
