using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Entities;

namespace Votech.Edge.Core.Interfaces;

/// <summary>A stored v2 batch with its samples, in the order they were acquired.</summary>
public sealed record StoredSignalBatch(BufferedSignalBatch Batch, IReadOnlyList<BufferedSignalSample> Samples);

/// <summary>The unpublished part of the buffer, reported in <c>AgentStatus.buffer</c>.</summary>
/// <param name="UnpublishedSamples">Samples not yet acknowledged by the broker.</param>
/// <param name="OldestUnpublishedMs">When the oldest unpublished batch was stored (Unix ms); 0 = none.</param>
public sealed record SignalBufferStatus(long UnpublishedSamples, long OldestUnpublishedMs);

/// <summary>
/// The v2 store-and-forward buffer (SQLite): samples are stored in batches, and a batch is sent whole, oldest first,
/// until the broker acknowledges it.
/// </summary>
public interface ISignalBuffer
{
    /// <summary>Stores batches with their samples in one transaction and wakes the publisher.</summary>
    Task SaveAsync(IReadOnlyList<StoredSignalBatch> batches, CancellationToken ct);

    /// <summary>The oldest batch not yet published, or null.</summary>
    Task<StoredSignalBatch?> NextUnpublishedAsync(CancellationToken ct);

    Task MarkPublishedAsync(byte[] batchId, CancellationToken ct);

    /// <summary>Completes when batches were stored since the last call, or after <paramref name="timeout"/>.</summary>
    Task WaitForBatchesAsync(TimeSpan timeout, CancellationToken ct);

    Task<SignalBufferStatus> GetStatusAsync(CancellationToken ct);

    /// <summary>Deletes published batches stored more than <paramref name="retentionDays"/> ago.</summary>
    Task<int> PurgePublishedAsync(int retentionDays, CancellationToken ct);

    /// <summary>
    /// Keeps the buffer within <see cref="StorageOptions.MaxRecordCapacity"/> samples and <see cref="StorageOptions.MaxDbSizeMb"/>
    /// (the pages in use, not the file size: SQLite never shrinks its file) by deleting the oldest whole published
    /// batches. Unpublished batches are deleted, oldest first and counted in <see cref="EvictedTotal"/>, only when the disk
    /// reaches its free space floor (the free pages of the file count as free space).
    /// </summary>
    Task EnforceStorageCapAsync(StorageOptions options, CancellationToken ct);

    /// <summary>
    /// Runs a passive WAL checkpoint of the database, so the WAL file does not grow without bound, and warns when it
    /// stays large (a blocked checkpoint or a long read).
    /// </summary>
    Task CheckpointDatabaseAsync(CancellationToken ct);

    /// <summary>True while the last cap check had to delete unpublished samples.</summary>
    bool IsEvicting { get; }

    /// <summary>Unpublished samples deleted at the disk floor since the buffer was created.</summary>
    long EvictedTotal { get; }
}
