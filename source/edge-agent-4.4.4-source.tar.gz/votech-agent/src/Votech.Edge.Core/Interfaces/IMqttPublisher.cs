using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Core.Interfaces;

/// <summary>
/// MQTT transport contract for the edge agent (contract v2).
/// </summary>
public interface IMqttPublisher
{
    /// <summary>True when the MQTT client has an active connection to the broker.</summary>
    bool IsConnected { get; }

    /// <summary>
    /// Establishes a connection to the MQTT broker.
    /// Configures TLS, CleanSession=false, and the Will Message for offline detection.
    /// Non-fatal: failures are caught by the caller; the flush loop retries on the next cycle.
    /// </summary>
    Task ConnectAsync(CancellationToken ct);

    /// <summary>
    /// Publishes a v2 <c>SignalBatch</c> as one message at QoS 1 and returns once the broker acknowledged it.
    /// Topic: {TopicPrefix}/v2/telemetry/{siteId}/{endpointId}, the batch's own site and endpoint.
    /// Throws on failure — the caller must NOT mark the batch as published.
    /// </summary>
    Task PublishSignalBatchAsync(V2.SignalBatch batch, CancellationToken ct);

    /// <summary>
    /// Publishes a v2 <c>AgentStatus</c>, retained, at QoS 1.
    /// Topic: {TopicPrefix}/v2/status/{siteId}/{clientId}
    /// </summary>
    Task PublishAgentStatusAsync(V2.AgentStatus status, CancellationToken ct);

    /// <summary>
    /// Publishes a v2 <c>CommandAck</c> at QoS 1.
    /// Topic: {TopicPrefix}/v2/ack/{siteId}/{endpointId}
    /// </summary>
    Task PublishCommandAckAsync(Guid siteId, V2.CommandAck ack, CancellationToken ct);
}
