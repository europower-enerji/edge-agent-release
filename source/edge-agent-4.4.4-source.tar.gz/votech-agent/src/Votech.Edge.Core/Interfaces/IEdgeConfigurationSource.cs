using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Core.Interfaces;

/// <summary>
/// The v2 configuration of the agent's site (ADR-002 2.1): fetched from the backend with its revision, cached locally
/// for offline starts, and reloaded on a reload command or the fallback poll.
/// </summary>
public interface IEdgeConfigurationSource
{
    /// <summary>The configuration the agent runs; null until one was received or read from the cache.</summary>
    V2.EdgeConfiguration? Current { get; }

    /// <summary>Raised with the new configuration whenever the running revision changes.</summary>
    event EventHandler<V2.EdgeConfiguration>? ConfigurationChanged;

    /// <summary>Fetches the configuration now (304 keeps the running one).</summary>
    Task SyncAsync(CancellationToken ct = default);

    /// <summary>A reload command: fetches unless <paramref name="revision"/> is the running revision.</summary>
    Task ReloadAsync(string? revision, CancellationToken ct = default);
}
