namespace Votech.Edge.Core.Acquisition;

/// <summary>
/// The health of one endpoint of a connection (the root or a station behind it), reported in <c>AgentStatus</c>.
/// </summary>
/// <param name="EndpointId">The endpoint.</param>
/// <param name="Connected">True while values or link responses arrive.</param>
/// <param name="LastSeenAt">The last value or link response, UTC; null = never.</param>
/// <param name="ReasonCode">A <see cref="Constants.DeviceDiagnosticReason"/>.</param>
/// <param name="Error">The last error, if any.</param>
public sealed record EndpointHealth(Guid EndpointId, bool Connected, DateTime? LastSeenAt, string ReasonCode, string? Error);
