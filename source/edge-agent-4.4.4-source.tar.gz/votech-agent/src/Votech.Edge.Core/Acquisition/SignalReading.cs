using Votech.Edge.Core.Models;

namespace Votech.Edge.Core.Acquisition;

/// <summary>
/// One acquired value of a signal, as sent in a v2 <c>SignalSample</c>.
/// </summary>
/// <param name="SignalId">The signal.</param>
/// <param name="EndpointId">The connection's root endpoint; the batch and topic it is sent under.</param>
/// <param name="Value">Engineering value, after transform and scaling.</param>
/// <param name="Timestamp">UTC.</param>
/// <param name="Quality">The canonical quality.</param>
/// <param name="RawQuality">Protocol quality bits as received; 0 for Modbus.</param>
/// <param name="TimeSource">Where <paramref name="Timestamp"/> comes from: the device or the time of receipt, and why.</param>
/// <param name="DeviceTimestampMs">The device time as read (Unix ms, CP56Time2a fields as UTC) when it was not used; 0 = none.</param>
/// <param name="ReceiveLagMs">When the agent received the value minus <paramref name="Timestamp"/> (ms); 0 for a receipt time.</param>
public readonly record struct SignalReading(
    Guid SignalId,
    Guid EndpointId,
    double Value,
    DateTime Timestamp,
    CanonicalQualityStatus Quality,
    uint RawQuality,
    SampleTimeSource TimeSource,
    long DeviceTimestampMs = 0,
    long ReceiveLagMs = 0
)
{
    /// <summary>True when <see cref="Timestamp"/> comes from the device (IEC 104 CP56Time2a).</summary>
    public bool DeviceTime => TimeSource == SampleTimeSource.Device;
}

/// <summary>Receives the readings of every connection poller and stores them for sending.</summary>
public interface ISignalSink
{
    /// <summary>Queues a reading; never blocks the protocol thread.</summary>
    void Write(in SignalReading reading);

    /// <summary>Stores every queued reading and stops accepting new ones; called once the pollers have stopped.</summary>
    Task DrainAsync(CancellationToken ct = default);

    /// <summary>Readings that never reached the buffer (the queue overflowed, or storing them kept failing) since the sink was created.</summary>
    long DroppedTotal { get; }
}
