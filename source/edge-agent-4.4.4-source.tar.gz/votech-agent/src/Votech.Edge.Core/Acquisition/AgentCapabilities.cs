using System.Reflection;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Core.Acquisition;

/// <summary>What this agent version can acquire (ADR-002 2.5), reported in <c>AgentStatus.supported_protocols</c>.</summary>
public static class AgentCapabilities
{
    public static IReadOnlyList<V2.Protocol> SupportedProtocols { get; } =
        [V2.Protocol.Iec104, V2.Protocol.ModbusTcp, V2.Protocol.ModbusRtu];

    /// <summary>The agent release (major.minor.patch) of the running executable; names the database copies.</summary>
    public static string AgentRelease { get; } = Assembly.GetEntryAssembly()?.GetName().Version?.ToString(3) ?? "0.0.0";

    /// <summary>
    /// The agent version with the commit it was built from ("3.1.0+abc1234"), reported in the status and the log, so two
    /// builds of one release can be told apart.
    /// </summary>
    public static string AgentVersion { get; } = FormatVersion(
        Assembly.GetEntryAssembly()?.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion,
        AgentRelease
    );

    /// <summary>
    /// The informational version with its commit cut to 7 characters ("3.1.0+abc1234"); <paramref name="release"/> when
    /// there is none.
    /// </summary>
    public static string FormatVersion(string? informational, string release)
    {
        if (string.IsNullOrEmpty(informational))
        {
            return release;
        }

        var plus = informational.IndexOf('+');
        if (plus < 0)
        {
            return informational;
        }

        var commit = informational[(plus + 1)..];
        return $"{informational[..plus]}+{commit[..Math.Min(7, commit.Length)]}";
    }
}
