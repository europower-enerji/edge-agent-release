using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Core.Acquisition;

/// <summary>
/// Reads one v2 <c>Connection</c>: one physical link (an IEC 104 TCP connection, a Modbus TCP socket or serial port)
/// and every station behind it. Readings go to the <see cref="ISignalSink"/> it was created with.
/// </summary>
public interface IConnectionPoller : IAsyncDisposable
{
    /// <summary>The connection's root endpoint.</summary>
    Guid EndpointId { get; }

    V2.Protocol Protocol { get; }

    /// <summary>True while the physical link is up.</summary>
    bool IsConnected { get; }

    /// <summary>The root endpoint and every station of the connection.</summary>
    IReadOnlyList<EndpointHealth> Health { get; }

    /// <summary>Connects, reads and reconnects until <paramref name="ct"/> is cancelled.</summary>
    Task RunAsync(CancellationToken ct);

    /// <summary>
    /// Takes the stations and points of <paramref name="connection"/> (same endpoint, protocol and settings) without
    /// dropping the link.
    /// </summary>
    void UpdatePoints(V2.Connection connection);
}

/// <summary>Creates the poller of a connection.</summary>
public interface IConnectionPollerFactory
{
    /// <summary>The poller, or null when this agent cannot read the connection (logged).</summary>
    IConnectionPoller? Create(V2.Connection connection, ISignalSink sink);
}

/// <summary>Runs one poller per connection of the running configuration.</summary>
public interface IConnectionManager
{
    /// <summary>The pollers running now; read at every use, they change with the configuration.</summary>
    IReadOnlyCollection<IConnectionPoller> Connections { get; }

    /// <summary>The revision of the configuration the pollers run; empty before the first one.</summary>
    string RunningRevision { get; }

    /// <summary>
    /// Runs <paramref name="probe"/> unless a poller holds the connection, and never while a revision is being applied,
    /// so a one-shot probe cannot open a second socket next to a starting or stopping poller. Null when a poller runs.
    /// </summary>
    Task<T?> ProbeIfIdleAsync<T>(Guid rootEndpointId, Func<CancellationToken, Task<T>> probe, CancellationToken ct)
        where T : class;

    Task StartAsync(CancellationToken ct = default);

    Task StopAsync(CancellationToken ct = default);
}
