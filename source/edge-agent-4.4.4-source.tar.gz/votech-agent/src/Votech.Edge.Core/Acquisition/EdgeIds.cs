using Google.Protobuf;

namespace Votech.Edge.Core.Acquisition;

/// <summary>
/// Ids of the v2 contract: 16 bytes in RFC 4122 (big-endian) order, the same on the backend.
/// </summary>
public static class EdgeIds
{
    /// <summary>The id in <paramref name="bytes"/>; <see cref="Guid.Empty"/> unless it has 16 bytes.</summary>
    public static Guid ToGuid(ByteString bytes) => bytes.Length == 16 ? new Guid(bytes.Span, bigEndian: true) : Guid.Empty;

    /// <summary>The id in <paramref name="bytes"/>; <see cref="Guid.Empty"/> unless it has 16 bytes.</summary>
    public static Guid ToGuid(byte[] bytes) => bytes.Length == 16 ? new Guid(bytes, bigEndian: true) : Guid.Empty;

    public static byte[] ToBytes(Guid id)
    {
        var bytes = new byte[16];
        id.TryWriteBytes(bytes, bigEndian: true, out _);
        return bytes;
    }

    public static ByteString ToByteString(Guid id) => UnsafeByteOperations.UnsafeWrap(ToBytes(id));

    public static ByteString ToByteString(byte[] bytes) => ByteString.CopyFrom(bytes);
}
