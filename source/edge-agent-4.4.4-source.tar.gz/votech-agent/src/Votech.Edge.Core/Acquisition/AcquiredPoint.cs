using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Core.Acquisition;

/// <summary>
/// A configured <c>SignalPoint</c> in the form the pollers use: the signal id as a <see cref="Guid"/>, and the raw to
/// engineering conversion (transform, then scaling) of the contract.
/// </summary>
public sealed class AcquiredPoint
{
    private readonly V2.Scaling? _scaling;
    private readonly V2.Transform? _transform;

    public AcquiredPoint(V2.SignalPoint point, Guid stationEndpointId, uint stationAddress)
    {
        SignalId = EdgeIds.ToGuid(point.SignalId);
        Code = point.Code;
        Address = point.Address;
        DataType = point.DataType;
        PollIntervalMs = point.PollIntervalMs;
        StationEndpointId = stationEndpointId;
        StationAddress = stationAddress;
        _scaling = point.Scaling;
        _transform = point.Transform;
    }

    public Guid SignalId { get; }
    public string Code { get; }
    public string Address { get; }
    public V2.DataType DataType { get; }

    /// <summary>The point's own Modbus period; 0 = the station's.</summary>
    public uint PollIntervalMs { get; }

    /// <summary>The endpoint of the station the point is read from.</summary>
    public Guid StationEndpointId { get; }

    /// <summary>The station's IEC 104 common address or Modbus unit id.</summary>
    public uint StationAddress { get; }

    /// <summary>True for values that are states rather than measurements.</summary>
    public bool IsDigital => DataType is V2.DataType.Boolean or V2.DataType.DoublePoint;

    /// <summary>
    /// The engineering value of a raw value: the transform first (bit mask, then boolean inversion), then the scaling
    /// (<c>raw * multiplier + offset</c>, or linear between the raw and engineering ranges).
    /// </summary>
    public double ToEngineering(double raw)
    {
        var value = raw;
        if (_transform != null)
        {
            if (_transform.BitMask != 0)
            {
                value = (ulong)(long)value & _transform.BitMask;
            }

            if (_transform.InvertBool)
            {
                value = value != 0 ? 0 : 1;
            }
        }

        if (_scaling == null)
        {
            return value;
        }

        return _scaling.Type switch
        {
            V2.ScalingType.Multiplier => value * _scaling.Multiplier + _scaling.Offset,
            V2.ScalingType.Linear when _scaling.RawMax != _scaling.RawMin =>
                _scaling.EngMin + (value - _scaling.RawMin) * (_scaling.EngMax - _scaling.EngMin) / (_scaling.RawMax - _scaling.RawMin),
            _ => value,
        };
    }

    /// <summary>The points of every station of <paramref name="connection"/>.</summary>
    public static IEnumerable<AcquiredPoint> Of(V2.Connection connection) =>
        connection.Stations.SelectMany(station =>
            station.Points.Select(point => new AcquiredPoint(point, EdgeIds.ToGuid(station.EndpointId), station.StationAddress))
        );
}
