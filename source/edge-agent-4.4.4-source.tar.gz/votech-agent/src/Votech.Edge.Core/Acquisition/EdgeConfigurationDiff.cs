using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Core.Acquisition;

/// <summary>
/// What changes per connection between the running and a new configuration, keyed by the root endpoint id:
/// <list type="bullet">
/// <item><see cref="Added"/> and <see cref="Removed"/> connections are started and stopped.</item>
/// <item><see cref="Reconnect"/>: the protocol or a connection setting changed, so the link is opened again.</item>
/// <item><see cref="Repoint"/>: only stations or points changed; the point map is swapped on the open link.</item>
/// </list>
/// </summary>
public sealed record EdgeConfigurationDiff(
    IReadOnlyList<V2.Connection> Added,
    IReadOnlyList<Guid> Removed,
    IReadOnlyList<V2.Connection> Reconnect,
    IReadOnlyList<V2.Connection> Repoint
)
{
    public bool IsEmpty => Added.Count == 0 && Removed.Count == 0 && Reconnect.Count == 0 && Repoint.Count == 0;

    public static EdgeConfigurationDiff Between(V2.EdgeConfiguration? running, V2.EdgeConfiguration target)
    {
        var before = (running?.Connections ?? []).ToDictionary(c => EdgeIds.ToGuid(c.EndpointId));
        var after = target.Connections.ToDictionary(c => EdgeIds.ToGuid(c.EndpointId));

        var added = after.Where(c => !before.ContainsKey(c.Key)).Select(c => c.Value).ToList();
        var removed = before.Keys.Where(id => !after.ContainsKey(id)).ToList();
        var reconnect = new List<V2.Connection>();
        var repoint = new List<V2.Connection>();
        foreach (var (id, connection) in after)
        {
            if (!before.TryGetValue(id, out var old) || old.Equals(connection))
            {
                continue;
            }

            if (Link(old).Equals(Link(connection)))
            {
                repoint.Add(connection);
            }
            else
            {
                reconnect.Add(connection);
            }
        }

        return new EdgeConfigurationDiff(added, removed, reconnect, repoint);
    }

    /// <summary>The connection without its stations: what the physical link depends on.</summary>
    private static V2.Connection Link(V2.Connection connection)
    {
        var link = connection.Clone();
        link.Stations.Clear();
        link.Code = string.Empty;
        return link;
    }
}
