namespace Votech.Edge.Core.Entities;

/// <summary>
/// The last v2 configuration received from the backend (a single row), used offline and after a restart.
/// </summary>
public class CachedEdgeConfiguration
{
    public const int SingletonId = 1;

    public int Id { get; set; } = SingletonId;

    public string Revision { get; set; } = string.Empty;

    public int SchemaVersion { get; set; }

    /// <summary>The protobuf <c>EdgeConfiguration</c> as received.</summary>
    public byte[] Payload { get; set; } = [];

    /// <summary>The last successful contact with the backend (200 or 304), UTC; the offline window starts here.</summary>
    public DateTime FetchedAt { get; set; }
}
