namespace Votech.Edge.Core.Entities;

/// <summary>
/// One acquired v2 sample in the local buffer (about 70 bytes a row). Its batch decides when it is sent.
/// </summary>
public class BufferedSignalSample
{
    public long Id { get; set; }

    /// <summary>The <see cref="BufferedSignalBatch"/> it is sent with.</summary>
    public byte[] BatchId { get; set; } = [];

    /// <summary>16-byte RFC 4122 (big-endian) signal id.</summary>
    public byte[] SignalId { get; set; } = [];

    /// <summary>Engineering value, after transform and scaling.</summary>
    public double Value { get; set; }

    /// <summary>Unix ms, UTC.</summary>
    public long TimestampMs { get; set; }

    /// <summary>A <see cref="Models.CanonicalQualityStatus"/>.</summary>
    public byte QualityStatus { get; set; }

    /// <summary>Protocol quality bits as received; 0 for Modbus.</summary>
    public int RawQuality { get; set; }

    /// <summary>True when the timestamp comes from the device (IEC 104 CP56Time2a).</summary>
    public bool DeviceTime { get; set; }

    /// <summary>A <see cref="Models.SampleTimeSource"/>; 0 for a sample stored by an agent before 3.1.</summary>
    public byte TimeSource { get; set; }

    /// <summary>The device time as read (Unix ms, CP56Time2a fields as UTC) when it was not used; 0 = none.</summary>
    public long DeviceTimestampMs { get; set; }

    /// <summary>When the agent received the value minus <see cref="TimestampMs"/> (ms); 0 for a receipt time.</summary>
    public long ReceiveLagMs { get; set; }
}
