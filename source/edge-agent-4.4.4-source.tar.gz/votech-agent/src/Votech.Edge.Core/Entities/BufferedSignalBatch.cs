namespace Votech.Edge.Core.Entities;

/// <summary>
/// One v2 <c>SignalBatch</c> waiting in the local buffer: the samples of one connection that were stored together.
/// It is always sent whole and under its own id, so a resend after a lost PUBACK or a restart carries the same samples
/// under the same id, and the backend skips it.
/// </summary>
public class BufferedSignalBatch
{
    /// <summary>16-byte RFC 4122 (big-endian) id, assigned when the batch is stored.</summary>
    public byte[] BatchId { get; set; } = [];

    /// <summary>The connection's root endpoint (16-byte RFC 4122).</summary>
    public byte[] EndpointId { get; set; } = [];

    /// <summary>Revision of the configuration the samples were read with.</summary>
    public string ConfigRevision { get; set; } = string.Empty;

    /// <summary>When the batch was stored (Unix ms, UTC); the publish order.</summary>
    public long CreatedAtMs { get; set; }

    public int SampleCount { get; set; }

    /// <summary>True once the broker acknowledged the batch (QoS 1 PUBACK).</summary>
    public bool IsPublished { get; set; }
}
