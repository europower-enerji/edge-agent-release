namespace Votech.Edge.Core.Constants;

/// <summary>
/// IEC 60870-5-104 standard constants and commonly-used default values.
/// Source: IEC 60870-5-104:2006 §9 (APCI parameters) and §7.2.6.3 (quality descriptor).
///
/// RULE: All protocol adapters and options classes MUST reference these constants.
///       Hard-coding port numbers, timeouts, or TypeIDs inline is forbidden.
/// </summary>
public static class Iec104Constants
{
    // ─── Network ──────────────────────────────────────────────────────────────

    /// <summary>IANA-registered TCP port for IEC 60870-5-104. Default value is 2404.</summary>
    public const int DefaultPort = 2404;

    // ─── APCI T-parameters (seconds) ─────────────────────────────────────────

    /// <summary>T0: Connection establishment timeout. Default value is 30 seconds.</summary>
    public const int T0TimeoutSec = 30;

    /// <summary>T1: Send/test APDU timeout (awaiting APDU acknowledgement). Default value is 15 seconds.</summary>
    public const int T1TimeoutSec = 15;

    /// <summary>T2: Supervisory acknowledgement timeout (ack unconfirmed I-frames). Default value is 10 seconds.</summary>
    public const int T2TimeoutSec = 10;

    /// <summary>T3: Test frame send timeout (idle link keep-alive). Default value is 20 seconds.</summary>
    public const int T3TimeoutSec = 20;

    // ─── APCI K/W parameters ─────────────────────────────────────────────────

    /// <summary>K: Maximum number of unconfirmed I-PDUs (outstanding send window). Default value is 12.</summary>
    public const int DefaultK = 12;

    /// <summary>W: Latest acknowledgement after receiving this many I-frames. Default value is 8.</summary>
    public const int DefaultW = 8;

    // ─── Application layer defaults ───────────────────────────────────────────

    /// <summary>
    /// ASDU common address of an IEC 104 RTU configured without one (backend 5.0.0; it was 1). The configuration always
    /// carries the address it compiled. Default value is 7.
    /// </summary>
    public const int DefaultCommonAddress = 7;

    /// <summary>Highest information object address of a 3-octet IOA. Default value is 16777215.</summary>
    public const int MaxIoa = 16_777_215;

    /// <summary>A CP56Time2a further ahead of the agent's clock than this is not trusted. Default value is 5 minutes.</summary>
    public const int DeviceTimeFutureToleranceMinutes = 5;

    /// <summary>A CP56Time2a older than this is not trusted (an RTU clock left in a past year). Default value is 24 hours.</summary>
    public const int DefaultMaxDeviceTimeAgeHours = 24;

    /// <summary>
    /// A connection whose device clock is further off than this is not trusted (<c>ClockPolicy</c> Enforce): its values
    /// are stamped on receipt. Default value is 60 seconds.
    /// </summary>
    public const int DefaultClockSkewToleranceSec = 60;

    /// <summary>Window over which the newest device time gives the offset of a connection's clock. Default value is 60 seconds.</summary>
    public const int ClockEstimateWindowSec = 60;

    /// <summary>
    /// Windows in a row whose newest device time is not newer than any before, after which the offset is taken anyway
    /// (the device clock was set back). Default value is 10.
    /// </summary>
    public const int ClockStaleWindowsBeforeReset = 10;

    /// <summary>Seconds between clock synchronisations with <c>CLOCK_SYNC_MODE_PERIODIC</c> and no interval. Default value is 3600.</summary>
    public const int DefaultClockSyncIntervalSec = 3_600;

    /// <summary>A clock sync the station has not confirmed within this time is reported as unanswered.</summary>
    public const int ClockSyncConfirmTimeoutSec = 30;

    /// <summary>Period of the per-connection device clock line in the log. Default value is 60 minutes.</summary>
    public const int ClockLogIntervalMinutes = 60;

    /// <summary>Period of the per-connection traffic summary in the log. Default value is 5 minutes.</summary>
    public const int DefaultStatsIntervalMinutes = 5;

    /// <summary>QOI qualifier for station-level General Interrogation (C_IC_NA_1). Default value is 20.</summary>
    public const byte StationInterrogationQualifier = 20;

    /// <summary>Default interval between automatic General Interrogation requests. Default value is 60 seconds.</summary>
    public const int DefaultGiIntervalSec = 60;

    /// <summary>Initial reconnect delay after a lost connection. Default value is 5 seconds.</summary>
    public const int DefaultReconnectDelayMs = 5_000;

    /// <summary>Maximum reconnect delay (exponential backoff ceiling). Default value is 60 seconds.</summary>
    public const int MaxReconnectDelayMs = 60_000;

    // ─── ASDU TypeIDs — Monitoring direction (field device → master) ──────────

    /// <summary>M_SP_NA_1: Single-point information (no timestamp). Default value is 1.</summary>
    public const int TypeIdSinglePoint = 1;

    /// <summary>M_DP_NA_1: Double-point information (no timestamp). Default value is 3.</summary>
    public const int TypeIdDoublePoint = 3;

    /// <summary>M_ME_NA_1: Measured value, normalized (no timestamp). Default value is 9.</summary>
    public const int TypeIdMeasNormalized = 9;

    /// <summary>M_ME_NB_1: Measured value, scaled integer (no timestamp). Default value is 11.</summary>
    public const int TypeIdMeasScaled = 11;

    /// <summary>M_ME_NC_1: Measured value, short float (no timestamp). Default value is 13.</summary>
    public const int TypeIdMeasFloat = 13;

    /// <summary>M_SP_TB_1: Single-point information with CP56Time2a. Default value is 30.</summary>
    public const int TypeIdSinglePointTs = 30;

    /// <summary>M_DP_TB_1: Double-point information with CP56Time2a. Default value is 31.</summary>
    public const int TypeIdDoublePointTs = 31;

    /// <summary>M_ME_TD_1: Measured value, normalized with CP56Time2a. Default value is 34.</summary>
    public const int TypeIdMeasNormalizedTs = 34;

    /// <summary>M_ME_TE_1: Measured value, scaled with CP56Time2a. Default value is 35.</summary>
    public const int TypeIdMeasScaledTs = 35;

    /// <summary>M_ME_TF_1: Measured value, short float with CP56Time2a. Preferred for inverters. Default value is 36.</summary>
    public const int TypeIdMeasFloatTs = 36;

    // ─── ASDU TypeIDs — Control direction (master → field device) ────────────

    /// <summary>C_SC_NA_1: Single command (ON/OFF). Default value is 45.</summary>
    public const int TypeIdSingleCmd = 45;

    /// <summary>C_DC_NA_1: Double command (Select-Before-Operate ON/OFF). Default value is 46.</summary>
    public const int TypeIdDoubleCmd = 46;

    /// <summary>C_SE_NC_1: Set-point command, short float (analog setpoint). Default value is 50.</summary>
    public const int TypeIdSetpointFloat = 50;

    /// <summary>C_IC_NA_1: General interrogation command. Default value is 100.</summary>
    public const int TypeIdGenInterrogation = 100;

    /// <summary>C_CS_NA_1: Clock synchronization command. Default value is 103.</summary>
    public const int TypeIdClockSync = 103;

    // ─── Quality descriptor bit masks (§7.2.6.3) ─────────────────────────────

    /// <summary>Quality: Good (no bits set). Default value is 0.</summary>
    public const byte QualityGood = 0;

    /// <summary>Quality bit: Overflow — value > range of measurement. Default value is 1.</summary>
    public const byte QualityOverflow = 1;

    /// <summary>Quality bit: Blocked — value blocked by operator or test mode. Default value is 16.</summary>
    public const byte QualityBlocked = 16;

    /// <summary>Quality bit: Substituted — value replaced by operator. Default value is 32.</summary>
    public const byte QualitySubstituted = 32;

    /// <summary>Quality bit: Non-topical — not in the cyclic reporting period. Default value is 64.</summary>
    public const byte QualityNonTopical = 64;

    /// <summary>Quality bit: Invalid — value not usable (sensor failure, etc.). Default value is 128.</summary>
    public const byte QualityInvalid = 128;
}

/// <summary>
/// Modbus protocol default values.
/// Source: Modbus Application Protocol Specification V1.1b3.
/// </summary>
public static class ModbusConstants
{
    /// <summary>Standard Modbus TCP port. Default value is 502.</summary>
    public const int DefaultTcpPort = 502;

    /// <summary>Default Modbus unit/slave ID. Default value is 1.</summary>
    public const byte DefaultUnitId = 1;

    /// <summary>Default polling interval in milliseconds. Default value is 1000 ms.</summary>
    public const int DefaultPollingIntervalMs = 1000;

    /// <summary>Default socket/response timeout in milliseconds. Default value is 3000 ms.</summary>
    public const int DefaultTimeoutMs = 3000;

    /// <summary>Default serial baud rate for RTU. Default value is 9600.</summary>
    public const int DefaultBaudRate = 9600;

    /// <summary>Default data bits. Default value is 8.</summary>
    public const int DefaultDataBits = 8;

    /// <summary>Default parity ("None", "Even", "Odd"). Default value is "None".</summary>
    public const string DefaultParity = "None";

    /// <summary>Default stop bits (1, 2). Default value is 1.</summary>
    public const int DefaultStopBits = 1;
}

/// <summary>
/// MQTT transport constants.
/// Source: MQTT 3.1.1 specification (OASIS, 2014).
/// </summary>
public static class MqttConstants
{
    /// <summary>Standard MQTT TLS port. Default value is 8883.</summary>
    public const int DefaultTlsPort = 8883;

    /// <summary>Standard MQTT plain-text port (use only in local dev/testing). Default value is 1883.</summary>
    public const int DefaultPlainPort = 1883;

    /// <summary>Default heartbeat interval for AgentStatus publish. Default value is 30 seconds.</summary>
    public const int HeartbeatIntervalSec = 30;

    /// <summary>Initial reconnect delay after broker disconnection. Default value is 1 second.</summary>
    public const int ReconnectBaseDelayMs = 1_000;

    /// <summary>Maximum reconnect delay (exponential backoff ceiling). Default value is 60 seconds.</summary>
    public const int ReconnectMaxDelayMs = 60_000;

    /// <summary>
    /// Maximum reconnection attempts before aborting; 0 (the default) never gives up. A field agent must outlive
    /// internet outages of any length: nothing else reconnects once a reconnect loop stops.
    /// </summary>
    public const int MaxReconnectAttempts = 0;

    /// <summary>Default flush loop interval. Default value is 5 seconds.</summary>
    public const int DefaultFlushIntervalMs = 5_000;

    // ─── Topic segments ───────────────────────────────────────────────────────
    /// <summary>Default topic prefix. Default value is "edge".</summary>
    public const string TopicTelemetry = "telemetry";

    /// <summary>Default topic for commands. Default value is "commands".</summary>
    public const string TopicCommands = "commands";

    /// <summary>Default topic for status. Default value is "status".</summary>
    public const string TopicStatus = "status";

    /// <summary>Default topic for acknowledgments. Default value is "ack".</summary>
    public const string TopicAck = "ack";
}

/// <summary>
/// SQLite storage constants.
/// </summary>
public static class StorageConstants
{
    /// <summary>Attempts to store a window of readings before they are dropped and counted. Default value is 5.</summary>
    public const int StoreAttempts = 5;

    /// <summary>Wait after the first failed store, doubling after each (0.5, 1, 2, 4 s). Default value is 500 ms.</summary>
    public const int StoreRetryFirstDelayMs = 500;

    /// <summary>
    /// Default number of days to keep published records before purging; the buffer only needs what was not sent, and a
    /// small table keeps the publisher fast. Default value is 1 day.
    /// </summary>
    public const int DefaultRetentionDays = 1;

    /// <summary>How often the purge job runs. Default value is 1 hour.</summary>
    public const int PurgeIntervalHours = 1;

    /// <summary>SQLite page cache size in KB (negative = KB, per SQLite PRAGMA spec). Default value is 32 MB.</summary>
    public const int DefaultPageCacheKb = -32_768; // 32 MB

    /// <summary>SQLite busy_timeout in milliseconds — prevents "database is locked" errors. Default value is 5 seconds.</summary>
    public const int BusyTimeoutMs = 5_000;

    /// <summary>Default maximum in-memory pending telemetry queue capacity. Default value is 20,000.</summary>
    public const int DefaultMaxPendingQueueSize = 20_000;

    /// <summary>Maximum number of SQL parameter variables per chunk in SQLite bulk queries (safe threshold &lt;= 500).</summary>
    public const int MaxSqliteParameterChunkSize = 500;

    /// <summary>Target headroom percentage when evicting storage on capacity limit breach (e.g. 0.90 = keep 90% of capacity, freeing 10% headroom).</summary>
    public const double TargetHeadroomPercent = 0.90;
}

/// <summary>
/// Diagnostic status reason codes for device connection tracking.
/// </summary>
public static class DeviceDiagnosticReason
{
    public const string ConnectedHealthy = "CONNECTED_HEALTHY";

    /// <summary>The first connection attempt has not finished yet.</summary>
    public const string Connecting = "CONNECTING";

    /// <summary>IEC 104: the station accepted TCP but did not confirm STARTDT (another master, or not an allowed master).</summary>
    public const string StartDtNotConfirmed = "STARTDT_NOT_CONFIRMED";
    public const string UnreachablePhysicalDevice = "UNREACHABLE_PHYSICAL_DEVICE";
    public const string ConfigurationMismatch = "CONFIGURATION_MISMATCH";

    /// <summary>The link is up, but no signal of the endpoint has an address, so nothing is read (agent 3.0.1).</summary>
    public const string NoPointsConfigured = "NO_POINTS_CONFIGURED";
}

/// <summary>
/// How the agent runs its sites: each in its own runtime, started again after it stops.
/// </summary>
public static class AgentConstants
{
    /// <summary>First wait before a stopped or failed site runtime starts again. Default value is 60 seconds.</summary>
    public const int SiteRestartMinDelaySec = 60;

    /// <summary>Longest wait between restarts of a site that keeps stopping (doubling from the first). Default value is 30 minutes.</summary>
    public const int SiteRestartMaxDelaySec = 1_800;

    /// <summary>A site that ran this long starts over with the shortest restart wait. Default value is 10 minutes.</summary>
    public const int SiteStableRunMinutes = 10;

    /// <summary>Time a site runtime gets to stop its pollers and store its samples. Default value is 20 seconds.</summary>
    public const int SiteStopTimeoutSec = 20;

    /// <summary>Wait for a site database held by an agent that is still stopping. Default value is 15 seconds.</summary>
    public const int SiteLockWaitSec = 15;

    /// <summary>
    /// First wait before the agent asks for its sites again after the backend refused it (401/403), doubling while the
    /// refusals go on (X-01). Default value is 60 seconds.
    /// </summary>
    public const int RefusedRetryMinDelaySec = 60;

    /// <summary>Longest wait between requests while the backend keeps refusing the agent. Default value is 15 minutes.</summary>
    public const int RefusedRetryMaxDelaySec = 900;

    /// <summary>
    /// The agent's sites stop only after the key itself was refused (a key code) this many times in a row,
    /// over at least <see cref="KeyRefusedStopMinutes"/>. Default value is 3.
    /// </summary>
    public const int KeyRefusedStopCount = 3;

    /// <summary>The shortest run of key refusals that stops the agent's sites. Default value is 10 minutes.</summary>
    public const int KeyRefusedStopMinutes = 10;
}
