namespace Votech.Edge.Core.Constants;

/// <summary>
/// The edge contract v2 (ADR-002, votech-shared <c>protobuf/v2</c>): configuration route, topics and versions.
/// </summary>
public static class EdgeContractConstants
{
    /// <summary>The <c>EdgeConfiguration.schema_version</c> this agent reads.</summary>
    public const uint SchemaVersion = 2;

    /// <summary>The configuration route, relative to <c>ApiBaseUrl</c>; {0} is the site id.</summary>
    public const string ConfigurationPathFormat = "api/v1/edge/sites/{0}/configuration";

    /// <summary>The sites the agent key serves (<c>AgentAssignment</c>, shared 2.1.0), relative to <c>ApiBaseUrl</c>.</summary>
    public const string AgentAssignmentPath = "api/v1/edge/agent";

    public const string ProtobufContentType = "application/x-protobuf";

    public const string AgentKeyHeader = "X-Edge-Api-Key";

    /// <summary>The tenant of the agent key, sent with every configuration request (shared 2.1.0).</summary>
    public const string TenantIdHeader = "X-Edge-Tenant-Id";

    /// <summary>The configuration is fetched again this often even without a reload command.</summary>
    public const int FallbackPollSeconds = 60;

    /// <summary>401 <c>code</c> (backend 5.14, shared 2.2.1): no key, an unknown key, or a rotated one.</summary>
    public const string KeyInvalidCode = "EDGE_KEY_INVALID";

    /// <summary>401 <c>code</c>: the key of a revoked or deleted agent.</summary>
    public const string KeyRevokedCode = "EDGE_KEY_REVOKED";

    /// <summary>401 <c>code</c>: the key is not an agent of the organisation in <c>X-Edge-Tenant-Id</c> (<c>TENANT_ID</c>).</summary>
    public const string KeyTenantMismatchCode = "EDGE_KEY_TENANT_MISMATCH";

    /// <summary>403 <c>code</c> of the discovery: the agent's organisation is suspended.</summary>
    public const string TenantSuspendedCode = "TENANT_SUSPENDED";

    /// <summary>403 <c>code</c> of a site's configuration: the agent does not serve that site (any more).</summary>
    public const string SiteNotServedCode = "ERRORS.FORBIDDEN_EDGE_SITE_MISMATCH";

    /// <summary>The version segment of every v2 topic: {prefix}/v2/{kind}/{siteId}/…</summary>
    public const string TopicVersion = "v2";

    /// <summary>{prefix}/v2/commands/{siteId}/reload</summary>
    public const string TopicReload = "reload";

    /// <summary>{prefix}/v2/commands/{siteId}/probe</summary>
    public const string TopicProbe = "probe";
}
