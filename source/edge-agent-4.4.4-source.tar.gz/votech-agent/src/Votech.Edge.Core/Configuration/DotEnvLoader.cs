using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Extensions.Configuration;

namespace Votech.Edge.Core.Configuration;

/// <summary>
/// Lightweight .env file locator, parser, and environment/configuration populator.
/// Automatically discovers .env files by walking up from the current or base directory,
/// sets environment variables, and normalizes keys (e.g. AGENT_KEY, TENANT_ID) for ASP.NET / Microsoft.Extensions.Configuration.
/// </summary>
public static class DotEnvLoader
{
    /// <summary>
    /// The setting names of the customer's <c>.env</c> (deploy/customer/env.example) and their configuration keys: the same
    /// translation docker-compose.yml makes, so the Windows service (EMS-217) reads the same file as the container.
    /// </summary>
    private static readonly Dictionary<string, string> Aliases = new(StringComparer.OrdinalIgnoreCase)
    {
        ["AGENT_KEY"] = "EdgeAgent:AgentKey",
        ["AgentKey"] = "EdgeAgent:AgentKey",
        ["API_KEY"] = "EdgeAgent:AgentKey",
        ["ApiKey"] = "EdgeAgent:AgentKey",
        ["TENANT_ID"] = "EdgeAgent:TenantId",
        ["TenantId"] = "EdgeAgent:TenantId",
        // Refused since agent 3.0 (the backend assigns the sites), with a message saying so.
        ["SITE_ID"] = "EdgeAgent:SiteId",
        ["SiteId"] = "EdgeAgent:SiteId",
        ["API_BASE_URL"] = "EdgeAgent:ApiBaseUrl",
        ["ApiBaseUrl"] = "EdgeAgent:ApiBaseUrl",
        ["API_CA_CERT"] = "EdgeAgent:ApiCaCertificatePath",
        ["MQTT_HOST"] = "EdgeAgent:Mqtt:BrokerHost",
        ["MQTT_PORT"] = "EdgeAgent:Mqtt:BrokerPort",
        ["MQTT_USE_TLS"] = "EdgeAgent:Mqtt:UseTls",
        ["MQTT_WEBSOCKET_PATH"] = "EdgeAgent:Mqtt:WebSocketPath",
        ["MQTT_USERNAME"] = "EdgeAgent:Mqtt:Username",
        ["MQTT_PASSWORD"] = "EdgeAgent:Mqtt:Password",
        ["MQTT_CA_CERT"] = "EdgeAgent:Mqtt:CaCertificatePath",
        ["DB_PASSWORD"] = "EdgeAgent:Storage:DbPassword",
        ["LOG_LEVEL"] = "Serilog:MinimumLevel:Default",
    };

    /// <summary>
    /// Locates the .env file by searching starting from base directories up parent directories.
    /// </summary>
    /// <param name="explicitPath">Optional explicit path to .env file.</param>
    /// <returns>Full path to the .env file, or null if not found.</returns>
    public static string? FindDotEnvFile(string? explicitPath = null)
    {
        if (!string.IsNullOrWhiteSpace(explicitPath) && File.Exists(explicitPath))
            return Path.GetFullPath(explicitPath);

        var envVarPath = Environment.GetEnvironmentVariable("DOTENV_PATH");
        if (!string.IsNullOrWhiteSpace(envVarPath) && File.Exists(envVarPath))
            return Path.GetFullPath(envVarPath);

        var candidateDirs = new[]
        {
            Directory.GetCurrentDirectory(),
            AppContext.BaseDirectory
        };

        foreach (var startDir in candidateDirs)
        {
            try
            {
                var dir = new DirectoryInfo(startDir);
                for (int i = 0; i < 6 && dir != null; i++)
                {
                    var candidate = Path.Combine(dir.FullName, ".env");
                    if (File.Exists(candidate))
                        return candidate;

                    dir = dir.Parent;
                }
            }
            catch
            {
                // Ignore directory traversal errors
            }
        }

        return null;
    }

    /// <summary>
    /// Reads and parses the .env file, populates System.Environment variables,
    /// and returns configuration mappings ready for Microsoft.Extensions.Configuration.
    /// </summary>
    /// <param name="path">Optional explicit path to the .env file.</param>
    /// <returns>A dictionary containing raw and mapped configuration key-value pairs.</returns>
    public static Dictionary<string, string?> Load(string? path = null)
    {
        var configDict = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase);
        var envFilePath = FindDotEnvFile(path);

        if (envFilePath == null || !File.Exists(envFilePath))
            return configDict;

        try
        {
            var lines = File.ReadAllLines(envFilePath);
            foreach (var line in lines)
            {
                var trimmed = line.Trim();
                if (string.IsNullOrWhiteSpace(trimmed) || trimmed.StartsWith('#'))
                    continue;

                var equalsIdx = trimmed.IndexOf('=');
                if (equalsIdx <= 0)
                    continue;

                var key = trimmed[..equalsIdx].Trim();
                var value = trimmed[(equalsIdx + 1)..].Trim();

                // Strip surrounding single or double quotes
                if (value.Length >= 2 &&
                    ((value.StartsWith('"') && value.EndsWith('"')) ||
                     (value.StartsWith('\'') && value.EndsWith('\''))))
                {
                    value = value[1..^1];
                }

                // Unescape standard control characters
                value = value.Replace("\\n", "\n").Replace("\\r", "\r").Replace("\\t", "\t");

                // Set process environment variable
                Environment.SetEnvironmentVariable(key, value);

                configDict[key] = value;

                // Map well-known aliases into Microsoft.Extensions.Configuration hierarchy
                if (Aliases.TryGetValue(key, out var configKey))
                {
                    configDict[configKey] = value;
                }
                else if (key.StartsWith("EdgeAgent__", StringComparison.OrdinalIgnoreCase))
                {
                    configDict[key.Replace("__", ":")] = value;
                }
            }
        }
        catch
        {
            // Fail gracefully if reading .env encounters permission/IO issues
        }

        return configDict;
    }

    /// <summary>
    /// Extension method to add .env file configuration to an IConfigurationBuilder.
    /// </summary>
    public static IConfigurationBuilder AddDotEnv(this IConfigurationBuilder builder, string? path = null)
    {
        var values = Load(path);
        if (values.Count > 0)
        {
            builder.AddInMemoryCollection(values);
        }
        return builder;
    }
}
