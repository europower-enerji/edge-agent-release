using Microsoft.Extensions.Options;

namespace Votech.Edge.Core.Configuration;

/// <summary>
/// Transport security: the agent key travels in every API request and as the MQTT password.
/// <list type="bullet">
/// <item>Outside <c>DOTNET_ENVIRONMENT=Development</c>, <c>ApiBaseUrl</c> must be https and <c>Mqtt.UseTls</c> true.</item>
/// <item>In every environment, a configured private CA file (<c>MQTT_CA_CERT</c> with TLS, <c>API_CA_CERT</c>) must
/// hold a certificate. The agent never falls back to the system certificates when it cannot read one (A-02).</item>
/// </list>
/// </summary>
public sealed class EdgeAgentOptionsValidator(string environmentName) : IValidateOptions<EdgeAgentOptions>
{
    public const string DevelopmentEnvironment = "Development";

    public ValidateOptionsResult Validate(string? name, EdgeAgentOptions options)
    {
        var failures = new List<string>();
        CheckCa(failures, "EdgeAgent:Mqtt:CaCertificatePath (MQTT_CA_CERT)", options.Mqtt.UseTls ? options.Mqtt.CaCertificatePath : null);
        CheckCa(failures, "EdgeAgent:ApiCaCertificatePath (API_CA_CERT)", options.ApiCaCertificatePath);

        // A path only: the scheme, host and port come from UseTls, BrokerHost and BrokerPort (EMS-202)
        var webSocketPath = options.Mqtt.WebSocketPath;
        if (options.Mqtt.UsesWebSocket && (webSocketPath.Contains("://", StringComparison.Ordinal) || webSocketPath.Trim().IndexOfAny([' ', '?', '#']) >= 0))
        {
            failures.Add($"EdgeAgent:Mqtt:WebSocketPath (MQTT_WEBSOCKET_PATH) must be a path such as /mqtt (it is '{webSocketPath}'). Put the host name in MQTT_HOST and the port in MQTT_PORT.");
        }

        if (string.Equals(environmentName, DevelopmentEnvironment, StringComparison.OrdinalIgnoreCase))
        {
            return failures.Count == 0 ? ValidateOptionsResult.Success : ValidateOptionsResult.Fail(failures);
        }

        if (!Uri.TryCreate(options.ApiBaseUrl, UriKind.Absolute, out var api) || api.Scheme != Uri.UriSchemeHttps)
        {
            failures.Add($"EdgeAgent:ApiBaseUrl must be an https address outside Development (it is '{options.ApiBaseUrl}'; environment '{environmentName}').");
        }

        if (!options.Mqtt.UseTls)
        {
            failures.Add($"EdgeAgent:Mqtt:UseTls must be true outside Development (environment '{environmentName}').");
        }

        return failures.Count == 0 ? ValidateOptionsResult.Success : ValidateOptionsResult.Fail(failures);
    }

    private static void CheckCa(List<string> failures, string setting, string? path)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return;
        }

        try
        {
            PrivateCaTrust.Load(path);
        }
        catch (InvalidOperationException ex)
        {
            failures.Add($"{setting}: {ex.Message} Fix the path (and the certs volume), or clear the setting to use the system certificates.");
        }
    }
}
