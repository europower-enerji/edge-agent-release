using Microsoft.Extensions.Options;

namespace Votech.Edge.Core.Configuration;

/// <summary>
/// The agent's own settings (not those of a site runtime): an agent key, which outside Development must be an agent key
/// of the backend (<c>eak_live_{keyId}_{secret}</c>, or <c>gpk_live_</c> for an older key, whose key id is the MQTT
/// username); <c>TENANT_ID</c>, when set, a
/// UUID; and no configured site, since the backend assigns the sites (agent 3.0).
/// </summary>
public sealed class AgentKeyValidator(string environmentName) : IValidateOptions<EdgeAgentOptions>
{
    public ValidateOptionsResult Validate(string? name, EdgeAgentOptions options)
    {
        var failures = new List<string>();
        if (!string.IsNullOrWhiteSpace(options.SiteId))
        {
            failures.Add("EdgeAgent:SiteId (SITE_ID) is no longer used since agent 3.0: the sites of an agent are assigned on the Site connectors page, and the agent asks for them. Remove SITE_ID; keep AGENT_KEY (and TENANT_ID if you like).");
        }

        if (!string.IsNullOrWhiteSpace(options.TenantId) && !Guid.TryParse(options.TenantId, out _))
        {
            failures.Add($"EdgeAgent:TenantId (TENANT_ID) '{options.TenantId}' is not a UUID.");
        }

        var development = string.Equals(environmentName, EdgeAgentOptionsValidator.DevelopmentEnvironment, StringComparison.OrdinalIgnoreCase);
        if (!development && !string.IsNullOrWhiteSpace(options.AgentKey) && !EdgeAgentKey.TryGetKeyId(options.AgentKey, out _))
        {
            failures.Add("EdgeAgent:AgentKey (AGENT_KEY) is not an agent key (eak_live_<key id>_<secret>). Issue one on the Site connectors page.");
        }

        return failures.Count == 0 ? ValidateOptionsResult.Success : ValidateOptionsResult.Fail(failures);
    }
}
