namespace Votech.Edge.Core.Configuration;

/// <summary>A site assigned to this agent (<c>AgentAssignment.sites</c>): the agent runs one site runtime for it.</summary>
public sealed record AgentSite(Guid TenantId, Guid SiteId, string Name, string TenantName)
{
    private const int MaxLabelLength = 32;

    /// <summary>How log lines name the site: its name, or the first 8 hex digits of its id.</summary>
    public string Label =>
        string.IsNullOrWhiteSpace(Name) ? ShortId
        : Name.Length > MaxLabelLength ? Name[..MaxLabelLength].TrimEnd() + "…"
        : Name;

    /// <summary>The first 8 hex digits of the site id, for log lines.</summary>
    public string ShortId => SiteId.ToString("N")[..8];
}
