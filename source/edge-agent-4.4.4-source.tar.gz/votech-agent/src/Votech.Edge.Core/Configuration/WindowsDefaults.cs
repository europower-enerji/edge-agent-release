using Microsoft.Extensions.Configuration;

namespace Votech.Edge.Core.Configuration;

/// <summary>
/// The folders of the Windows service (EMS-217). appsettings.json names the container's folders
/// (<c>/var/lib/edge-agent</c>, <c>/var/log/edge-agent</c>); on Windows they become <c>%ProgramData%\EdgeAgent\data</c>
/// and <c>\logs</c>, named without the product like the container's, the folders install.ps1 creates and protects. Only
/// a setting that still holds the container default changes, so a value from .env, the environment or the command line
/// stays as it is.
/// </summary>
public static class WindowsDefaults
{
    public const string DatabaseKey = "EdgeAgent:Storage:SqliteConnectionString";

    /// <summary>The file sink's path in appsettings.json (<c>Serilog:WriteTo</c>, first entry).</summary>
    public const string LogFileKey = "Serilog:WriteTo:0:Args:path";

    private const string ContainerData = "/var/lib/edge-agent/";
    private const string ContainerLogs = "/var/log/edge-agent/";

    /// <summary><c>{programData}\EdgeAgent</c>; <paramref name="programData"/> is <c>C:\ProgramData</c> on a default Windows.</summary>
    public static string Root(string programData) => Path.Combine(programData, "EdgeAgent");

    /// <summary>The settings to add on Windows: the container folders of <paramref name="configuration"/> moved under <see cref="Root"/>.</summary>
    public static Dictionary<string, string?> For(IConfiguration configuration, string programData)
    {
        var overrides = new Dictionary<string, string?>();
        Move(configuration, DatabaseKey, ContainerData, Path.Combine(Root(programData), "data"), overrides);
        Move(configuration, LogFileKey, ContainerLogs, Path.Combine(Root(programData), "logs"), overrides);
        return overrides;
    }

    private static void Move(IConfiguration configuration, string key, string containerFolder, string windowsFolder, Dictionary<string, string?> overrides)
    {
        var value = configuration[key];
        if (value != null && value.Contains(containerFolder, StringComparison.Ordinal))
        {
            overrides[key] = value.Replace(containerFolder, windowsFolder + Path.DirectorySeparatorChar, StringComparison.Ordinal);
        }
    }
}
