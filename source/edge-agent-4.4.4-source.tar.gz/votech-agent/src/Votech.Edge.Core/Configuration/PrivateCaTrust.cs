using System.Net.Security;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace Votech.Edge.Core.Configuration;

/// <summary>
/// Trust in a private CA (A-02), for the broker (<c>MQTT_CA_CERT</c>) and the API (<c>API_CA_CERT</c>). When a CA file
/// is configured, a server certificate is accepted only if it names the host the agent connects to and its chain ends
/// at a certificate of that file. The system store is not consulted. A CA file that cannot be read stops the agent at
/// startup (<see cref="EdgeAgentOptionsValidator"/>) instead of falling back to the system store. Without a CA file the
/// normal system validation applies.
/// </summary>
public static class PrivateCaTrust
{
    /// <summary>
    /// The certificates of a PEM file (one or more) or a DER file. Throws <see cref="InvalidOperationException"/>
    /// naming the file when it is missing or holds no certificate.
    /// </summary>
    public static X509Certificate2Collection Load(string path)
    {
        if (!File.Exists(path))
        {
            throw new InvalidOperationException($"The CA certificate file '{path}' does not exist.");
        }

        var roots = new X509Certificate2Collection();
        try
        {
            roots.ImportFromPemFile(path);
        }
        catch (CryptographicException)
        {
            // Not PEM: tried as DER below
        }

        if (roots.Count > 0)
        {
            return roots;
        }

        try
        {
            roots.Add(X509CertificateLoader.LoadCertificateFromFile(path));
            return roots;
        }
        catch (CryptographicException ex)
        {
            throw new InvalidOperationException($"The CA certificate file '{path}' holds no certificate ({ex.Message.Trim()}).", ex);
        }
    }

    /// <summary>
    /// Whether a server certificate may be trusted: the TLS layer found it and found it names the host, and its chain
    /// builds up to one of <paramref name="roots"/> only. Revocation is not checked, because private CAs rarely
    /// publish revocation lists. <paramref name="reason"/> says why a certificate is refused.
    /// </summary>
    public static bool Validate(X509Certificate? certificate, X509Chain? presented, SslPolicyErrors errors, X509Certificate2Collection roots, out string reason)
    {
        if (certificate is null || errors.HasFlag(SslPolicyErrors.RemoteCertificateNotAvailable))
        {
            reason = "the server sent no certificate";
            return false;
        }

        if (errors.HasFlag(SslPolicyErrors.RemoteCertificateNameMismatch))
        {
            reason = "the certificate does not name the host the agent connects to";
            return false;
        }

        using var chain = new X509Chain();
        chain.ChainPolicy.TrustMode = X509ChainTrustMode.CustomRootTrust;
        chain.ChainPolicy.CustomTrustStore.AddRange(roots);
        chain.ChainPolicy.RevocationMode = X509RevocationMode.NoCheck;
        // Intermediates the server sent help build the chain; they are never trusted on their own
        if (presented != null)
        {
            foreach (var element in presented.ChainElements)
            {
                chain.ChainPolicy.ExtraStore.Add(element.Certificate);
            }
        }

        var leaf = certificate as X509Certificate2 ?? X509CertificateLoader.LoadCertificate(certificate.GetRawCertData());
        if (chain.Build(leaf))
        {
            reason = string.Empty;
            return true;
        }

        var status = string.Join("; ", chain.ChainStatus.Select(s => s.StatusInformation.Trim()).Where(s => s.Length > 0).Distinct());
        reason = $"its chain does not end at the configured CA{(status.Length > 0 ? $" ({status})" : string.Empty)}";
        return false;
    }
}
