using System.Text.RegularExpressions;

namespace Votech.Edge.Core.Configuration;

/// <summary>
/// A tenant agent key, <c>eak_live_{keyId}_{secret}</c> ("edge agent key", backend 5.18.0; keys issued since backend
/// 5.0.0 start with <c>gpk_live_</c> and are accepted too): <c>keyId</c> is 16 hex characters and is the MQTT username;
/// the whole key is the password and the <c>X-Edge-Api-Key</c> value.
/// </summary>
public static partial class EdgeAgentKey
{
    /// <summary>True for a key of the backend's format; the key id is its public part.</summary>
    public static bool TryGetKeyId(string? key, out string keyId)
    {
        var match = key is null ? Match.Empty : Format().Match(key.Trim());
        keyId = match.Success ? match.Groups["id"].Value : string.Empty;
        return match.Success;
    }

    /// <summary>
    /// The MQTT client id of a site's data session, <c>edge-{keyId}-{siteId:N}</c> (agent 3.3, X-03). The broker hooks
    /// accept an agent key only under a client id of its own key, and the backend closes exactly these sessions (and
    /// the <c>-cmd</c> one of the commands) when the key is revoked or rotated, or the site is taken away. A value that
    /// is not a key gets <c>edge-nokey-…</c>, which the broker refuses like the key itself.
    /// </summary>
    public static string ClientIdFor(string? key, Guid siteId) =>
        $"edge-{(TryGetKeyId(key, out var keyId) ? keyId : "nokey")}-{siteId:N}";

    /// <summary>"eak_live_0123456789abcdef" (or "gpk_live_…" for an older key), safe to log.</summary>
    public static string Prefix(string? key)
    {
        var match = key is null ? Match.Empty : Format().Match(key.Trim());
        return match.Success
            ? $"{match.Groups["prefix"].Value}_{match.Groups["kind"].Value}_{match.Groups["id"].Value}"
            : "(not an agent key)";
    }

    [GeneratedRegex("^(?<prefix>eak|gpk)_(?<kind>live|test)_(?<id>[0-9a-f]{16})_[0-9a-f]{64}$")]
    private static partial Regex Format();
}
