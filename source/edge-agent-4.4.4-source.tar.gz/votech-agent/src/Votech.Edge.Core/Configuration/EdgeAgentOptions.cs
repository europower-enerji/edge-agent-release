using System.ComponentModel.DataAnnotations;
using Votech.Edge.Core.Constants;

namespace Votech.Edge.Core.Configuration;

/// <summary>
/// SQLite buffer and data retention options.
/// </summary>
public class StorageOptions
{
    [Required, MinLength(1)]
    public string SqliteConnectionString { get; set; } = "Data Source=edge.db";

    /// <summary>Database password for SQLCipher encryption. Optional.</summary>
    public string? DbPassword { get; set; }

    /// <summary>Number of days to retain published records before purging. Default: 1.</summary>
    [Range(1, 365)]
    public int RetentionDays { get; set; } = StorageConstants.DefaultRetentionDays;

    /// <summary>How often the background purge job runs (hours). Default: 1.</summary>
    [Range(1, 24)]
    public int PurgeIntervalHours { get; set; } = StorageConstants.PurgeIntervalHours;

    /// <summary>
    /// Max size of the SQLite buffer in MB, counted as the pages in use (the file itself never shrinks). Default: 2048,
    /// about 25 million samples: the 72 h offline window at about 100 samples per second, since every sample is sent
    /// (contract v2). Only published samples are deleted to keep it; unpublished ones only at the disk floor.
    /// </summary>
    public long MaxDbSizeMb { get; set; } = 2048;

    /// <summary>Max number of buffered samples (published and unpublished). Default: 25,000,000.</summary>
    public long MaxRecordCapacity { get; set; } = 25_000_000;

    /// <summary>Minimum free host disk space floor percent. Default: 20.</summary>
    public int MinFreeDiskSpacePercent { get; set; } = 20;

    /// <summary>Minimum free host disk space floor in GB. Default: 2.</summary>
    public int MinFreeDiskSpaceGb { get; set; } = 2;

    /// <summary>How often to run a passive WAL checkpoint (minutes). Default: 1.</summary>
    [Range(1, 60)]
    public int CheckpointIntervalMinutes { get; set; } = 1;

    /// <summary>Maximum in-memory pending telemetry queue capacity. Default: 20000.</summary>
    [Range(100, 100_000)]
    public int MaxPendingQueueSize { get; set; } = StorageConstants.DefaultMaxPendingQueueSize;
}

/// <summary>
/// Agent-side IEC 104 behaviour that the edge configuration does not carry.
/// </summary>
public class Iec104AgentOptions
{
    /// <summary>
    /// How long an attempt waits for the STARTDT confirmation (seconds); 0 = t3 + t1 + 2, so the library's link test
    /// (TESTFR at t3) runs first, as in agent 1.x.
    /// </summary>
    [Range(0, 600)]
    public int StartDtTimeoutSec { get; set; }

    /// <summary>
    /// Log every APDU sent and received, decoded (frame kind, type, cause, common address and every object with its value,
    /// quality and time) at Debug, and the hex bytes at Verbose. Nothing is decoded unless the Debug level is on.
    /// Diagnostics only: noisy during interrogations. Default: false.
    /// </summary>
    public bool LogRawFrames { get; set; }

    /// <summary>
    /// A device time (CP56Time2a) older than this many hours is replaced by the time of receipt, as one further than
    /// 5 minutes ahead already is; 0 = 24 h. Buffered events older than this after a long outage get their receipt time.
    /// </summary>
    [Range(0, 87_600)]
    public int MaxDeviceTimeAgeHours { get; set; }

    /// <summary>
    /// How device times are judged. <see cref="Iec104ClockPolicy.Observe"/> (default) keeps the window above and logs the
    /// offset of each connection's clock; <see cref="Iec104ClockPolicy.Enforce"/> stamps every value of a connection whose
    /// clock is off by more than <see cref="ClockSkewToleranceSec"/> on receipt, and keeps the device times of one that
    /// is not, buffered events included.
    /// </summary>
    public Iec104ClockPolicy ClockPolicy { get; set; } = Iec104ClockPolicy.Observe;

    /// <summary>How far a connection's clock may be off before its device times are not trusted (seconds). Default: 60.</summary>
    [Range(1, 3_600)]
    public int ClockSkewToleranceSec { get; set; } = Iec104Constants.DefaultClockSkewToleranceSec;

    /// <summary>Minutes between the per-connection traffic summaries (<c>[IEC104-STATS]</c>); 0 turns them off. Default: 5.</summary>
    [Range(0, 1_440)]
    public int StatsIntervalMinutes { get; set; } = Iec104Constants.DefaultStatsIntervalMinutes;
}

/// <summary>How the agent judges IEC 104 device times (<see cref="Iec104AgentOptions.ClockPolicy"/>).</summary>
public enum Iec104ClockPolicy
{
    /// <summary>
    /// A device time is used unless it is more than 5 minutes ahead or older than the maximum age; the offset of each
    /// connection's clock is only measured and logged.
    /// </summary>
    Observe = 0,

    /// <summary>
    /// A connection whose clock is off by more than the tolerance gets the time of receipt on every value; one that is
    /// not keeps its device times back to the maximum age.
    /// </summary>
    Enforce = 1,
}

/// <summary>
/// Root edge agent options aggregate.
/// Bound from the "EdgeAgent" configuration section.
/// </summary>
public class EdgeAgentOptions
{
    /// <summary>
    /// Optional guard (.env <c>TENANT_ID</c>): the organisation the agent key must belong to. Sent as
    /// <c>X-Edge-Tenant-Id</c>; the backend refuses the key of another organisation. Leave empty for a platform agent,
    /// which serves sites of several organisations.
    /// </summary>
    public string TenantId { get; set; } = string.Empty;

    /// <summary>
    /// The site a site runtime reads, set by the agent from its assignment (<c>GET api/v1/edge/agent</c>). Not configured:
    /// since agent 3.0 the backend says which sites an agent serves, and a configured site id is refused.
    /// </summary>
    public string SiteId { get; set; } = string.Empty;

    /// <summary>The organisation of <see cref="SiteId"/>, set with it; a configuration of another one is refused.</summary>
    public string SiteTenantId { get; set; } = string.Empty;

    /// <summary>Backend REST API base URL; the v2 configuration is read from it.</summary>
    [Required, Url]
    public string ApiBaseUrl { get; set; } = "http://localhost:5050";

    /// <summary>
    /// A private CA (PEM or DER) the API's certificate must chain to, when Votech runs on a server with its own CA
    /// (<c>API_CA_CERT</c>; often the same file as <c>MQTT_CA_CERT</c>). Only that CA is trusted, the certificate must
    /// name the API host, and a file that cannot be read stops the agent (A-02). Empty: the system certificates.
    /// </summary>
    public string? ApiCaCertificatePath { get; set; }

    private string _agentKey = string.Empty;

    /// <summary>
    /// The agent's key, issued on the Edge agents page (<c>gpk_live_{keyId}_{secret}</c>, .env <c>AGENT_KEY</c>). It belongs
    /// to this installed agent, which serves the sites assigned to it there.
    /// </summary>
    [Required(ErrorMessage = "AgentKey (AGENT_KEY) is required to run the Edge Agent.")]
    [MinLength(1, ErrorMessage = "AgentKey (AGENT_KEY) cannot be empty.")]
    public string AgentKey
    {
        get => _agentKey;
        set => _agentKey = value;
    }

    /// <summary>The MQTT username of <see cref="AgentKey"/>: its key id (the site id for a development key of another format).</summary>
    public string BrokerUsername => EdgeAgentKey.TryGetKeyId(AgentKey, out var keyId) ? keyId : SiteId;

    /// <summary>Legacy alias for AgentKey. Use AgentKey instead.</summary>
    [Obsolete("Use AgentKey instead.")]
    public string? ApiKey
    {
        get => _agentKey;
        set => _agentKey = value ?? string.Empty;
    }

    public StorageOptions Storage { get; set; } = new();
    public MqttOptions Mqtt { get; set; } = new();
    public Iec104AgentOptions Iec104 { get; set; } = new();

    /// <summary>Interval between flush loop iterations (milliseconds).</summary>
    [Range(100, 60_000)]
    public int FlushIntervalMs { get; set; } = MqttConstants.DefaultFlushIntervalMs;

    /// <summary>Micro-batching accumulation window in milliseconds for real-time telemetry ingestion. Default: 2000ms (2 seconds).</summary>
    [Range(50, 10_000)]
    public int BatchWindowMs { get; set; } = 2000;

    /// <summary>Maximum signal count per micro-batch before triggering an immediate flush. Default: 500.</summary>
    [Range(1, 2_000)]
    public int MaxBatchSize { get; set; } = 500;

    /// <summary>
    /// How long (hours) a cached configuration may be used while the server cannot be reached; an older one may no longer
    /// match the field, so the agent stops. Default: 72 hours.
    /// </summary>
    [Range(1, 8760)]
    public int MaxOfflineCacheHours { get; set; } = 72;
}
