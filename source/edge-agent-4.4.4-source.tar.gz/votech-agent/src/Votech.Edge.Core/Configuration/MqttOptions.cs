using System.ComponentModel.DataAnnotations;
using Votech.Edge.Core.Constants;

namespace Votech.Edge.Core.Configuration;

/// <summary>
/// MQTT broker connection and transport options.
/// </summary>
public class MqttOptions
{
    [Required, MinLength(1)]
    public string BrokerHost { get; set; } = string.Empty;

    [Range(1, 65535)]
    public int BrokerPort { get; set; } = MqttConstants.DefaultTlsPort;

    /// <summary>Enable TLS. Must be true in production. Only false for local dev/test.</summary>
    public bool UseTls { get; set; } = true;

    /// <summary>
    /// The broker's WebSocket path (<c>MQTT_WEBSOCKET_PATH</c>, e.g. <c>/mqtt</c>, EMS-202). Empty: MQTT over TCP to
    /// <see cref="BrokerHost"/>:<see cref="BrokerPort"/>. Set: MQTT over WebSockets at <see cref="WebSocketUri"/>, through
    /// the HTTPS port a proxy already serves, so a site needs no outbound port other than 443.
    /// </summary>
    public string WebSocketPath { get; set; } = string.Empty;

    /// <summary>True when the broker is reached over WebSockets (<see cref="WebSocketPath"/> is set).</summary>
    public bool UsesWebSocket => !string.IsNullOrWhiteSpace(WebSocketPath);

    /// <summary>
    /// <c>wss://{BrokerHost}:{BrokerPort}/{path}</c>, the path with or without its leading slash; <c>ws://</c> without TLS,
    /// which only Development allows (<see cref="EdgeAgentOptionsValidator"/>).
    /// </summary>
    public string WebSocketUri => $"{(UseTls ? "wss" : "ws")}://{BrokerHost}:{BrokerPort}/{WebSocketPath.Trim().TrimStart('/')}";

    /// <summary>The broker address for log lines: <see cref="WebSocketUri"/>, or host:port.</summary>
    public string BrokerAddress => UsesWebSocket ? WebSocketUri : $"{BrokerHost}:{BrokerPort}";

    /// <summary>
    /// The MQTT client id of a site's data session, set by the agent for each site (agent 3.3):
    /// <c>edge-{keyId}-{siteId:N}</c> (<see cref="EdgeAgentKey.ClientIdFor"/>), and <c>…-cmd</c> for its commands. A value
    /// configured in <c>EdgeAgent:Mqtt:ClientId</c> (<c>MQTT_CLIENT_ID</c>) is ignored with a warning.
    /// </summary>
    [Required, MinLength(1)]
    public string ClientId { get; set; } = string.Empty;

    /// <summary>MQTT topic prefix (e.g. "edge").</summary>
    public string TopicPrefix { get; set; } = "edge";

    /// <summary>MQTT username. Leave empty if anonymous auth is used (local dev only).</summary>
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// MQTT password. DO NOT commit this value — inject via environment variable.
    /// Env var: EdgeAgent__Mqtt__Password
    /// </summary>
    public string Password { get; set; } = string.Empty;

    /// <summary>
    /// A private CA (PEM or DER) the broker's certificate must chain to (<c>MQTT_CA_CERT</c>). Only that CA is trusted,
    /// the certificate must name the broker host, and a file that cannot be read stops the agent (A-02). Empty: the
    /// system certificates.
    /// </summary>
    public string? CaCertificatePath { get; set; }

    /// <summary>Path to the client certificate (PEM) for mTLS authentication.</summary>
    public string? ClientCertificatePath { get; set; }

    /// <summary>Path to the client private key (PEM) for mTLS authentication.</summary>
    public string? ClientKeyPath { get; set; }

    /// <summary>AgentStatus heartbeat publish interval.</summary>
    [Range(5, 300)]
    public int HeartbeatIntervalSec { get; set; } = MqttConstants.HeartbeatIntervalSec;

    /// <summary>Initial reconnect delay after broker disconnection.</summary>
    public int ReconnectBaseDelayMs { get; set; } = MqttConstants.ReconnectBaseDelayMs;

    /// <summary>Maximum reconnect delay (exponential backoff ceiling).</summary>
    public int ReconnectMaxDelayMs { get; set; } = MqttConstants.ReconnectMaxDelayMs;

    /// <summary>Maximum reconnection attempts before aborting; 0 or less means never give up (the default).</summary>
    public int MaxReconnectAttempts { get; set; } = MqttConstants.MaxReconnectAttempts;

    /// <summary>True when <paramref name="attempt"/> is past a positive <see cref="MaxReconnectAttempts"/>.</summary>
    public bool ReconnectAttemptsExhausted(int attempt) => MaxReconnectAttempts > 0 && attempt > MaxReconnectAttempts;

    /// <summary>The attempt limit for log lines.</summary>
    public string ReconnectAttemptLimitText => MaxReconnectAttempts > 0 ? MaxReconnectAttempts.ToString() : "unlimited";
}
