#!/usr/bin/env bash
# =============================================================================
# Manual (break-glass) publish of the multi-arch Votech Edge Agent image to
# GitHub Container Registry. Normal releases go through the "CI & Release"
# GitHub Actions workflow (push a vX.Y.Z tag); see agent/RELEASING.md in the
# private platform-ops repository.
#
# The version comes from <Version> in Votech.Edge.Service.csproj and is
# pushed as X.Y.Z, X.Y, X and latest (pre-releases such as 1.9.0-rc.1 get
# only their exact tag). Published versions are never overwritten.
#
# Usage (from anywhere, after logging in with a classic PAT that has write:packages):
#   echo "$GHCR_TOKEN" | docker login ghcr.io -u <github-username> --password-stdin
#   deploy/publish-image.sh
#
# Overrides:
#   IMAGE=ghcr.io/<owner>/edge-agent
#   PLATFORMS=linux/amd64,linux/arm64
#   SHARED_DIR=<path to votech-shared checkout>
# =============================================================================
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE="${IMAGE:-ghcr.io/europower-enerji/edge-agent}"
PLATFORMS="${PLATFORMS:-linux/amd64,linux/arm64}"
SHARED_DIR="${SHARED_DIR:-$REPO_ROOT/../votech-shared}"
BUILDER="edge-agent-builder"
CSPROJ="$REPO_ROOT/src/Votech.Edge.Service/Votech.Edge.Service.csproj"

VERSION="$(sed -n 's:.*<Version>\(.*\)</Version>.*:\1:p' "$CSPROJ" | head -n1)"
if [[ ! "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+(-[0-9A-Za-z.-]+)?$ ]]; then
  echo "ERROR: could not read a SemVer <Version> from $CSPROJ (got '$VERSION')." >&2
  exit 1
fi

if [[ ! -f "$SHARED_DIR/protobuf/v1/messages.proto" ]]; then
  echo "ERROR: $SHARED_DIR/protobuf/v1/messages.proto not found. Set SHARED_DIR to your votech-shared checkout." >&2
  exit 1
fi

if [[ -n "$(git -C "$REPO_ROOT" status --porcelain)" ]]; then
  echo "WARNING: working tree has uncommitted changes; the image will not match a commit." >&2
fi

if docker buildx imagetools inspect "$IMAGE:$VERSION" >/dev/null 2>&1; then
  echo "ERROR: $IMAGE:$VERSION is already published. Bump <Version> in Votech.Edge.Service.csproj first." >&2
  exit 1
fi

TAGS=("$IMAGE:$VERSION")
if [[ "$VERSION" != *-* ]]; then
  TAGS+=("$IMAGE:${VERSION%.*}" "$IMAGE:${VERSION%%.*}" "$IMAGE:latest")
fi
TAG_ARGS=()
for tag in "${TAGS[@]}"; do TAG_ARGS+=(-t "$tag"); done

# A docker-container builder is required for multi-platform pushes
docker buildx inspect "$BUILDER" >/dev/null 2>&1 \
  || docker buildx create --name "$BUILDER" --driver docker-container >/dev/null

echo "Publishing $IMAGE:$VERSION for $PLATFORMS ..."
docker buildx build \
  --builder "$BUILDER" \
  --file "$REPO_ROOT/deploy/Dockerfile" \
  --build-context shared="$SHARED_DIR" \
  --platform "$PLATFORMS" \
  --label org.opencontainers.image.version="$VERSION" \
  --label org.opencontainers.image.revision="$(git -C "$REPO_ROOT" rev-parse HEAD)" \
  --label org.opencontainers.image.created="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  "${TAG_ARGS[@]}" \
  --push \
  "$REPO_ROOT"

echo
echo "Done. Published tags:"
printf '  %s\n' "${TAGS[@]}"
echo
echo "Next: make the package public if it is not yet, then run deploy/publish-customer-bundle.sh (after pushing tag v$VERSION)."
