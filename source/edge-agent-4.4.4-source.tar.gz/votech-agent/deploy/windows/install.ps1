<#
.SYNOPSIS
  Installs, updates, configures, checks or removes the Votech Edge Agent as a Windows service, without Docker or WSL.
  Run it in an elevated PowerShell ("Run as administrator"), in the folder of this file.

.DESCRIPTION
    .\install.ps1                      Install, or update the program when it is already installed. The first time it
                                       creates the settings file and opens it in Notepad. Settings and buffered data
                                       are kept on every update.
    .\install.ps1 -Action Config       Open the settings in Notepad, check them, and restart the agent.
    .\install.ps1 -Action Status       The service, the version, a check of the settings and the last log lines.
    .\install.ps1 -Action Uninstall    Remove the service and the program. Settings and buffered data stay, unless
                                       -RemoveData is given as well.

  Program:  C:\Program Files\EdgeAgent
  Settings: C:\ProgramData\EdgeAgent\.env   readable only by Administrators, SYSTEM and (read only) the service
  Data:     C:\ProgramData\EdgeAgent\data   the local buffer
  Logs:     C:\ProgramData\EdgeAgent\logs   one file per day, 7 days
  Service:  VotechEdgeAgent ("Votech Edge Agent"): starts after boot without anyone signing in, restarts after an
            error, runs as its own virtual account NT SERVICE\VotechEdgeAgent (no password, no administrator rights).
#>
param(
    [ValidateSet('Install', 'Config', 'Status', 'Uninstall')]
    [string]$Action = 'Install',
    [switch]$RemoveData
)
$ErrorActionPreference = 'Stop'

$ServiceName = 'VotechEdgeAgent'
$DisplayName = 'Votech Edge Agent'
$ServiceAccount = "NT SERVICE\$ServiceName"
$ProgramDir = Join-Path $env:ProgramFiles 'EdgeAgent'
$DataRoot = Join-Path $env:ProgramData 'EdgeAgent'
$DataDir = Join-Path $DataRoot 'data'
$LogDir = Join-Path $DataRoot 'logs'
$EnvFile = Join-Path $DataRoot '.env'
$ExeName = 'Votech.Edge.Service.exe'
$Exe = Join-Path $ProgramDir $ExeName
$PackageProgram = Join-Path $PSScriptRoot 'agent'
$Template = Join-Path $PSScriptRoot 'env.example'
$ExampleKey = 'eak_live_0000000000000000_0000000000000000000000000000000000000000000000000000000000000000'
$Admins = '*S-1-5-32-544'
$System = '*S-1-5-18'

$script:failed = $false
function Pass($m) { Write-Host "PASS  $m" -ForegroundColor Green }
function Fail($m) { Write-Host "FAIL  $m" -ForegroundColor Red; $script:failed = $true }
function Warn($m) { Write-Host "WARN  $m" -ForegroundColor Yellow }
function Info($m) { Write-Host "INFO  $m" }
function Step($m) { Write-Host ''; Write-Host "== $m" -ForegroundColor Cyan }
function Stop-Here($m) {
    Fail $m
    Write-Host ''
    Write-Host 'RESULT: FAIL. Stopped here; nothing after this point was done.' -ForegroundColor Red
    exit 1
}

# Native programs (sc.exe, icacls, robocopy) can write to stderr in ways Windows PowerShell 5.1 turns into errors; their
# exit code decides.
function Invoke-Native([string]$FilePath, [string[]]$ArgumentList = @()) {
    $eap = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { & $FilePath @ArgumentList 2>$null } finally { $ErrorActionPreference = $eap }
}

function Assert-Admin {
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Stop-Here 'this needs an elevated PowerShell: right-click Windows PowerShell or Windows Terminal, "Run as administrator", then run it again'
    }
    if (-not [Environment]::Is64BitOperatingSystem) { Stop-Here 'this agent needs 64-bit Windows' }
}

function Set-Acl-Native([string]$Path, [string[]]$Arguments) {
    Invoke-Native icacls (@($Path) + $Arguments) | Out-Null
    if ($LASTEXITCODE -ne 0) { Stop-Here "icacls could not set the permissions of $Path (exit $LASTEXITCODE)" }
}

# Before any secret is written: the settings folder belongs to Administrators and SYSTEM only (no inherited rights).
function Protect-DataRoot {
    New-Item -ItemType Directory -Force -Path $DataRoot | Out-Null
    Set-Acl-Native $DataRoot @('/inheritance:r', '/grant:r', "${Admins}:(OI)(CI)F", "${System}:(OI)(CI)F")
    foreach ($d in @($DataDir, $LogDir)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
}

# Once the service exists: it may read the program and .env, and change data and logs; nothing else.
function Grant-Service {
    Set-Acl-Native $ProgramDir @('/grant', "${ServiceAccount}:(OI)(CI)RX")
    Set-Acl-Native $DataRoot @('/grant', "${ServiceAccount}:RX")
    foreach ($d in @($DataDir, $LogDir)) { Set-Acl-Native $d @('/grant', "${ServiceAccount}:(OI)(CI)M") }
    Set-Acl-Native $EnvFile @('/grant', "${ServiceAccount}:R")
    Pass "permissions: Administrators and SYSTEM full; the service reads the program and .env and writes data and logs only"
}

# The settings as the agent reads them: NAME=value lines; comments and empty lines skipped; surrounding quotes removed.
function Read-Settings {
    $settings = @{}
    if (-not (Test-Path -LiteralPath $EnvFile)) { return $settings }
    foreach ($line in Get-Content -LiteralPath $EnvFile) {
        $t = $line.Trim()
        if ($t -eq '' -or $t.StartsWith('#')) { continue }
        $i = $t.IndexOf('=')
        if ($i -le 0) { continue }
        $value = $t.Substring($i + 1).Trim()
        if ($value.Length -ge 2 -and (($value.StartsWith('"') -and $value.EndsWith('"')) -or ($value.StartsWith("'") -and $value.EndsWith("'")))) {
            $value = $value.Substring(1, $value.Length - 2)
        }
        $settings[$t.Substring(0, $i).Trim()] = $value
    }
    return $settings
}

# Checks the values a customer enters and prints one line each. True when the agent can start with them; leaves the
# script's result to the caller.
function Test-Settings {
    $before = $script:failed
    $script:failed = $false
    $s = Read-Settings
    if ($s.Count -eq 0) {
        Fail "$EnvFile is missing or empty"
    } else {
        $key = [string]$s['AGENT_KEY']
        if ($key -eq '' -or $key -eq $ExampleKey) { Fail 'AGENT_KEY: enter the key of this agent from the Site connectors page' }
        elseif ($key -notmatch '^(eak|gpk)_(live|test)_[0-9a-f]{16}_[0-9a-f]{64}$') { Fail 'AGENT_KEY: not a whole agent key (eak_live_, then 16 and 64 characters); copy it again' }
        else { Pass "AGENT_KEY: $($key.Substring(0, 25))... (the rest is not shown)" }

        $api = [string]$s['API_BASE_URL']
        $uri = $null
        if (-not [Uri]::TryCreate($api, [UriKind]::Absolute, [ref]$uri) -or $uri.Scheme -ne 'https') { Fail "API_BASE_URL must start with https:// (it is '$api')" }
        elseif ($uri.Host -like '*example.com') { Fail 'API_BASE_URL is still the example: enter the address Votech gave you' }
        else { Pass "API_BASE_URL: $api" }

        $mqttHost = [string]$s['MQTT_HOST']
        if ($mqttHost -eq '' -or $mqttHost -like '*example.com') { Fail 'MQTT_HOST: enter the host name Votech gave you' }
        elseif ($mqttHost -match '://|:|/') { Fail "MQTT_HOST: the host name only, no https:// and no :port (it is '$mqttHost')" }
        elseif ($mqttHost -match '^(localhost|127\.)') { Fail 'MQTT_HOST: localhost or 127.x is this computer, not Votech' }
        else { Pass "MQTT_HOST: $mqttHost" }

        $port = [string]$s['MQTT_PORT']
        if ($port -eq '') { $port = '8883' }
        $n = 0
        if (-not [int]::TryParse($port, [ref]$n) -or $n -lt 1 -or $n -gt 65535) { Fail "MQTT_PORT must be a port number (it is '$port')" }
        else { Pass "MQTT_PORT: $port" }

        $tls = [string]$s['MQTT_USE_TLS']
        if ($tls -ne '' -and $tls -ne 'true') { Fail 'MQTT_USE_TLS must be true: the agent sends over encrypted connections only' }
        else { Pass 'MQTT_USE_TLS: true' }

        $path = [string]$s['MQTT_WEBSOCKET_PATH']
        if ($path -ne '') {
            if ($path -match '://|\s|\?|#') { Fail "MQTT_WEBSOCKET_PATH must be a path such as /mqtt (it is '$path')" }
            else { Pass "MQTT_WEBSOCKET_PATH: $path (the agent sends over HTTPS on port $port)" }
            if ($port -ne '443') { Warn "MQTT_WEBSOCKET_PATH is set and MQTT_PORT is $port; Votech's HTTPS port is usually 443" }
        }
    }
    $ok = -not $script:failed
    $script:failed = $before
    return $ok
}

function Edit-Settings {
    Info "Notepad opens $EnvFile. Enter the values Votech gave you, save (Ctrl+S) and close Notepad to continue."
    Start-Process -FilePath notepad.exe -ArgumentList "`"$EnvFile`"" -Wait
}

# Notepad until the settings pass, at most three times.
function Confirm-Settings {
    for ($round = 1; $round -le 3; $round++) {
        Step 'Settings'
        if (Test-Settings) { return }
        if ($round -lt 3) { Edit-Settings }
    }
    Stop-Here 'the settings still have FAIL lines. Fix them, then run: .\install.ps1 -Action Config'
}

function Get-Agent { Get-Service -Name $ServiceName -ErrorAction SilentlyContinue }

function Stop-Agent {
    $svc = Get-Agent
    if ($svc -and $svc.Status -ne 'Stopped') {
        Info 'stopping the agent (it sends what it can and closes its buffer first)'
        Stop-Service -Name $ServiceName
        $svc.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(60))
        Pass 'agent stopped'
    }
}

function Start-Agent {
    try {
        Start-Service -Name $ServiceName
    } catch {
        Fail "the service did not start: $($_.Exception.Message)"
    }
    Start-Sleep -Seconds 15
    $svc = Get-Agent
    if ($svc.Status -eq 'Running') { Pass 'the agent is running' } else { Fail "the agent is '$($svc.Status)': see the log lines below" }
    Show-Log 25
}

function Show-Log([int]$Lines) {
    $file = Get-ChildItem -LiteralPath $LogDir -Filter 'agent-*.log' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime | Select-Object -Last 1
    if (-not $file) { Warn "no log file in $LogDir yet"; return }
    Step "Last $Lines lines of $($file.FullName)"
    Get-Content -LiteralPath $file.FullName -Tail $Lines
    Write-Host ''
    Info ('Look for "[MQTT] Connected successfully". The whole log: notepad "' + $file.FullName + '"')
}

function Install-Agent {
    Assert-Admin
    Step 'Package'
    if (-not (Test-Path -LiteralPath (Join-Path $PackageProgram $ExeName))) {
        Stop-Here "no agent\$ExeName next to this script: extract the whole ZIP and run install.ps1 from its folder"
    }
    $version = (Get-Item -LiteralPath (Join-Path $PackageProgram $ExeName)).VersionInfo.ProductVersion
    Pass "package: Votech Edge Agent $version"

    Protect-DataRoot
    if (-not (Test-Path -LiteralPath $EnvFile)) {
        Copy-Item -LiteralPath $Template -Destination $EnvFile
        Pass "settings file created from env.example: $EnvFile"
        Edit-Settings
    } else {
        Pass "settings kept: $EnvFile"
    }
    Confirm-Settings

    $existing = Get-Agent
    if ($existing) { Step 'Update the program' } else { Step 'Install the program' }
    Stop-Agent
    Invoke-Native robocopy @($PackageProgram, $ProgramDir, '/MIR', '/NFL', '/NDL', '/NJH', '/NJS', '/NP', '/R:3', '/W:2') | Out-Null
    if ($LASTEXITCODE -ge 8) { Stop-Here "copying the program to $ProgramDir failed (robocopy exit $LASTEXITCODE)" }
    # This script stays with the program, for -Action Status, Config and Uninstall once the download is gone
    Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $ProgramDir 'install.ps1') -Force
    Pass "program in $ProgramDir (with install.ps1 for Status, Config and Uninstall)"

    Step 'Service'
    if (-not $existing) {
        New-Service -Name $ServiceName -BinaryPathName "`"$Exe`"" -DisplayName $DisplayName -StartupType Automatic `
            -Description "Reads the site's devices and sends the readings to Votech. Settings: $EnvFile" | Out-Null
        Pass "service $ServiceName created"
    }
    # A virtual account needs the service's own SID; then the account itself: no password, no administrator rights
    Invoke-Native sc.exe @('sidtype', $ServiceName, 'unrestricted') | Out-Null
    if ($LASTEXITCODE -ne 0) { Stop-Here "sc.exe sidtype failed (exit $LASTEXITCODE)" }
    Invoke-Native sc.exe @('config', $ServiceName, 'obj=', $ServiceAccount, 'start=', 'delayed-auto') | Out-Null
    if ($LASTEXITCODE -ne 0) { Stop-Here "sc.exe config failed (exit $LASTEXITCODE)" }
    # Restarted 10 s, 30 s and 60 s after a stop on an error; the count resets after a day
    Invoke-Native sc.exe @('failure', $ServiceName, 'reset=', '86400', 'actions=', 'restart/10000/restart/30000/restart/60000') | Out-Null
    Invoke-Native sc.exe @('failureflag', $ServiceName, '1') | Out-Null
    # Where the settings are, for the agent
    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName" -Name Environment -Type MultiString `
        -Value ([string[]]@("DOTENV_PATH=$EnvFile", 'DOTNET_ENVIRONMENT=Production'))
    Pass "runs as $ServiceAccount, starts after boot, restarts after an error, reads $EnvFile"
    Grant-Service

    Step 'Start'
    Start-Agent
}

switch ($Action) {
    'Install' { Install-Agent }
    'Config' {
        Assert-Admin
        if (-not (Test-Path -LiteralPath $EnvFile)) { Stop-Here 'the agent is not installed yet: run .\install.ps1' }
        Edit-Settings
        Confirm-Settings
        if (Get-Agent) {
            Step 'Restart'
            Stop-Agent
            Start-Agent
        }
    }
    'Status' {
        Assert-Admin
        Step 'Service'
        $svc = Get-Agent
        if (-not $svc) {
            Fail "service $ServiceName is not installed: run .\install.ps1"
        } else {
            $cim = Get-CimInstance Win32_Service -Filter "Name='$ServiceName'"
            if ($svc.Status -eq 'Running') { Pass "$DisplayName is running" } else { Fail "$DisplayName is '$($svc.Status)'" }
            Info "start: $($cim.StartMode), account: $($cim.StartName)"
            if (Test-Path -LiteralPath $Exe) { Info "version: $((Get-Item -LiteralPath $Exe).VersionInfo.ProductVersion)" }
        }
        Step 'Settings'
        if (-not (Test-Settings)) { $script:failed = $true }
        Show-Log 30
    }
    'Uninstall' {
        Assert-Admin
        Step 'Remove'
        if (Get-Agent) {
            Stop-Agent
            Invoke-Native sc.exe @('delete', $ServiceName) | Out-Null
            Pass "service $ServiceName removed"
        } else {
            Info "service $ServiceName is not installed"
        }
        if (Test-Path -LiteralPath $ProgramDir) { Remove-Item -LiteralPath $ProgramDir -Recurse -Force; Pass "$ProgramDir removed" }
        if ($RemoveData) {
            if (Test-Path -LiteralPath $DataRoot) { Remove-Item -LiteralPath $DataRoot -Recurse -Force; Pass "$DataRoot removed (settings, buffer and logs)" }
        } else {
            Info "kept: $DataRoot (settings, buffered data, logs). Add -RemoveData only after Votech confirms all data has arrived."
        }
    }
}

Write-Host ''
if ($script:failed) { Write-Host 'RESULT: FAIL' -ForegroundColor Red; exit 1 }
Write-Host 'RESULT: PASS' -ForegroundColor Green
