#!/usr/bin/env bash
# =============================================================================
# Builds the Windows package of the agent (EMS-218):
#   votech-edge-agent-<version>-windows-x64.zip
#     <name>/install.ps1          install, update, settings, status, uninstall (deploy/windows/install.ps1)
#     <name>/env.example          the same settings template as the Docker install
#     <name>/README.md            the customer guide ("Windows Server (no Docker)")
#     <name>/LICENSE, THIRD-PARTY-NOTICES.md
#     <name>/agent/               the agent for win-x64, self-contained: the server needs no .NET installation
#
# The text files get Windows line endings: Notepad before Windows Server 2019 shows LF-only files on one line.
# The version is <Version> in Votech.Edge.Service.csproj.
#
# Usage (Linux or WSL, with the .NET 10 SDK and zip):
#   deploy/windows/build-package.sh [OUT_DIR]          default OUT_DIR: dist/
# The protobuf contract comes from ../votech-shared, as for every build of the agent.
# =============================================================================
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
OUT_DIR="$(mkdir -p "${1:-$REPO_ROOT/dist}" && cd "${1:-$REPO_ROOT/dist}" && pwd)"
CSPROJ="$REPO_ROOT/src/Votech.Edge.Service/Votech.Edge.Service.csproj"

fail() { echo "ERROR: $*" >&2; exit 1; }
command -v dotnet >/dev/null || fail "the .NET SDK is missing"
command -v zip >/dev/null || fail "zip is missing"

VERSION="$(sed -n 's:.*<Version>\(.*\)</Version>.*:\1:p' "$CSPROJ" | head -n1)"
[[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+(-[0-9A-Za-z.-]+)?$ ]] || fail "could not read a SemVer <Version> from $CSPROJ (got '$VERSION')"
NAME="votech-edge-agent-$VERSION-windows-x64"
REVISION="$(git -C "$REPO_ROOT" rev-parse --short HEAD 2>/dev/null || true)"

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
PKG="$WORK/$NAME"

echo "Publishing the agent $VERSION for win-x64 (self-contained) ..."
# No shared build servers: a busy compiler server of another build can stall this one
if ! dotnet publish "$CSPROJ" --configuration Release --runtime win-x64 --self-contained true \
    ${REVISION:+-p:SourceRevisionId=$REVISION} --output "$PKG/agent" \
    --disable-build-servers -nodeReuse:false -tl:off -v minimal -nologo >"$WORK/publish.log" 2>&1; then
    grep -E ' error |error :' "$WORK/publish.log" | head -20 >&2 || tail -20 "$WORK/publish.log" >&2
    fail "dotnet publish failed"
fi
# Development settings never ship; the service runs in Production (install.ps1)
rm -f "$PKG/agent/appsettings.Development.json"
[ -f "$PKG/agent/Votech.Edge.Service.exe" ] || fail "Votech.Edge.Service.exe missing in the publish output"
find "$PKG/agent" -iname 'e_sqlcipher.dll' | grep -q . || fail "e_sqlcipher.dll missing: the agent could not open its buffer"
if find "$PKG/agent" -iname '*.db' -o -iname '.env' | grep -q .; then fail "a database or .env in the publish output"; fi

cp "$REPO_ROOT/deploy/windows/install.ps1" "$REPO_ROOT/deploy/customer/env.example" "$REPO_ROOT/deploy/customer/README.md" \
    "$REPO_ROOT/LICENSE" "$REPO_ROOT/THIRD-PARTY-NOTICES.md" "$PKG/"
for f in install.ps1 env.example README.md LICENSE THIRD-PARTY-NOTICES.md; do
    sed -i 's/\r$//; s/$/\r/' "$PKG/$f"
done

rm -f "$OUT_DIR/$NAME.zip"
(cd "$WORK" && zip -qr -9 "$OUT_DIR/$NAME.zip" "$NAME")
(cd "$OUT_DIR" && sha256sum "$NAME.zip" > "$NAME.zip.sha256")

echo
echo "Built $OUT_DIR/$NAME.zip ($(du -h "$OUT_DIR/$NAME.zip" | cut -f1), $(find "$PKG/agent" -type f | wc -l) program files)"
echo "sha256: $(cut -d' ' -f1 "$OUT_DIR/$NAME.zip.sha256")"
