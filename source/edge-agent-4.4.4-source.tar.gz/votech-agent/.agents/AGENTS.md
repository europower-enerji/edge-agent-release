# Agent Rules & Engineering Protocol — Votech Edge SCADA Agent

> **Mandatory Compliance**: All AI agents and developers working on Votech Edge SCADA Agent MUST read and strictly enforce the guidelines defined in [IMPLEMENTATION_CHECKLIST.md](../IMPLEMENTATION_CHECKLIST.md) and the rules below before planning, modifying code, or marking any task complete.

---

## 1. Strict Vibe-Trace & Automatic Versioning Protocol

When completing a task (implementing a feature, fixing a bug, or performing refactoring/maintenance), AI agents and developers MUST create a trace record in `.trace/` AND increment the application version in `Votech.Edge.Service.csproj`. DO NOT be lazy with formatting or omit technical details.

### 1.1 Mandatory Project Version Increment (Votech.Edge.Service.csproj)

Whenever a task is executed and a trace entry is recorded, the AI agent MUST update the `<Version>` tag in `src/Votech.Edge.Service/Votech.Edge.Service.csproj` following standard Semantic Versioning (SemVer) logical increment rules:

- **Patch Increment (`x.y.Z` -> `x.y.Z+1`)**: Applied for bug fixes, protocol driver patch adjustments, minor refactoring, configuration tweaks, or documentation updates.
- **Minor Increment (`x.Y.z` -> `x.Y+1.0`)**: Applied for new feature implementations, new SCADA protocol handlers (IEC-104/Modbus/IEC-61850), storage/sync pipeline extensions, or major capability extensions.
- **Major Increment (`X.y.z` -> `X+1.0.0`)**: Applied for breaking protocol payload changes, total edge architecture overhauls, or fundamental engine redesigns.

### 1.2 Vibe-Trace Formatting Standard

1. **File Naming**: Name the file exactly `YYYY-MM-DD-HH-MM-short-description.md` inside `.trace/`. Do not append to old trace files.
2. **Title**: Start with an H1 title representing the task, e.g., `# Vibe Coding Trace - [Task Name]`.
3. **Strict Markdown Bullets**: You MUST use exact Markdown bullet points (`-`) and bold text (`**...**`) for the keys.
4. **Required Structure**:
   - **Date and Location:** [Date] [Time] [Timezone]
   - **Agent:** [Tool/Model] (e.g., Gemini 3.6 Flash, Cursor)
   - **Developer and email:** [Your Name] <[EMAIL_ADDRESS]> (e.g. Amin Abbasi <amin4193@gmail.com>)
   - **App Version:** [Updated Version in Votech.Edge.Service.csproj (e.g., 1.0.6)]
   - **Context:** High-detail bullet points explaining _everything_ that was changed, including specific service/driver names and logic refactors.
   - **Protocols Touched:** List the protocol adapters, ASDU types, or IEC 61850 data paths modified.
   - **Architectural Shift:** High-detail bullet points explaining structural changes, edge state shifts, pattern shifts, or module creations.
   - **Vibes:** A short, informal summary of the session's success, blockers, or feeling.

---

## 2. AI Engineering & Anti-Hallucination Commandments (STRICT)

- **Hard Halt on Missing Protocol Data**: If a requested edge collector feature requires ASDU types, IOA addresses, or Protobuf message fields not present in `ProtocolConstants.cs` or shared Protobuf definitions, the agent MUST immediately halt and emit: `STATUS: DATA_NOT_FOUND` listing missing definitions. NEVER invent fake protocol constants or undocumented ASDU TypeIDs.
- **Ground Truth Inventory First**: Inspect existing services in `Votech.Edge.Core`, `Votech.Edge.Ingestion`, `Votech.Edge.Storage`, and `Votech.Edge.Mqtt` before writing code.
- **Open Source (GPLv3)**: The connector links lib60870.NET (GPL-3.0-only) and is published under GPLv3 (`LICENSE`, `THIRD-PARTY-NOTICES.md`). Every dependency must be GPLv3-compatible (MIT, BSD, Apache-2.0, LGPL or GPL); never add a proprietary or source-unavailable package, and list each new runtime package in `THIRD-PARTY-NOTICES.md`. Connector code is never copied into the backend, web, mobile or license platform. LFDCC/IEC60870 and Jeprotec/IEC-60870 are GPL code relabelled "MIT": never use them. `PackageLicenseTests` fails on any other licence and on those packages (EMS-173).
- **Public Repository**: Never put customer or site names, real site or tenant ids, addresses of customer devices, keys, passwords or incident details in any file, tests and `.trace` records included. Use neutral names ("North Solar Plant") and documentation addresses (192.0.2.x, 198.51.100.x, 203.0.113.x). `PublicAddressInRepositoryTests` fails on a public address with a port. Business logic (plans, prices, licence checks) lives in the backend only.

---

## 3. Core Architectural & Code Quality Commandments

- **Industrial Reliability First**: Edge Agent collector services must handle transient network loss, buffer samples locally in the SQLite batch buffer (`SqliteSignalBuffer`) with zero telemetry drop, and retry automatically.
- **Strict Protobuf Schema Alignment**: Every MQTT payload and the configuration must strictly adhere to the shared edge contract v2 messages (`Votech.Shared.Protobuf.V2`, `votech-shared/protobuf/v2`, ADR-002).
- **No Inline Protocol Constants**: Port numbers (e.g. `2404` for IEC 104, `102` for IEC 61850), timeouts, TypeIDs, quality bytes, and frame counts MUST be referenced from `Votech.Edge.Core/Constants/ProtocolConstants.cs`.
- **Async/Await & Thread Safety**: No `Thread.Sleep()`, no `.Result` or `.Wait()`. Always `await Task.Delay(ms, cancellationToken)`.
- **Fast-Path Verification & Anti-Mock Loop Protocol**: Run ONLY targeted unit tests (`dotnet test tests/Votech.Edge.Ingestion.Tests/Votech.Edge.Ingestion.Tests.csproj`). Maximum 2 consecutive test runs permitted.
- **Relative File Paths Only (STRICT MANDATE)**: NEVER hardcode machine-specific absolute file links in markdown documentation, trace files, or code. Always use clean relative markdown paths.
- **Clean Build Gate**: Always verify .NET compilation (`dotnet build Votech.Edge.sln`) passes without warnings or errors before finalizing a task.