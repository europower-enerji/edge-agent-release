using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using Xunit;

namespace Votech.Edge.Ingestion.Tests;

/// <summary>
/// Every NuGet package the solution restores may ship in a GPL-3.0-only agent (EMS-173): a permissive licence or one of
/// the GPL family. A package without an SPDX expression (a licence file or URL) needs an entry in
/// <see cref="FromLicenceFile"/>. The IEC 104 libraries copied from GPL code and relabelled "MIT" are banned by id.
/// </summary>
public class PackageLicenseTests
{
    private static readonly HashSet<string> Allowed = new(StringComparer.OrdinalIgnoreCase)
    {
        "MIT", "Apache-2.0", "BSD-2-Clause", "BSD-3-Clause", "ISC", "0BSD", "Unlicense",
        "GPL-3.0-only", "GPL-3.0-or-later", "LGPL-2.1-or-later", "LGPL-3.0-only", "LGPL-3.0-or-later",
    };

    /// <summary>Packages without an SPDX expression, with the licence their licence file or URL states.</summary>
    private static readonly Dictionary<string, string> FromLicenceFile = new(StringComparer.OrdinalIgnoreCase)
    {
        ["NModbus"] = "MIT",
        ["NModbus.Serial"] = "MIT", // same project and LICENSE.txt as NModbus
        ["xunit.abstractions"] = "Apache-2.0",
    };

    private static readonly string[] Banned = ["IEC60870", "LFDCC.IEC60870.Core", "LFDCC.IEC60870.CS101", "LFDCC.IEC60870.CS103", "LFDCC.IEC60870.CS104"];

    [Fact]
    public void EveryRestoredPackage_HasAnAllowedLicence()
    {
        var problems = RestoredPackages(ProductNameInSourceTests.RepositoryRoot())
            .Select(p => (p.Id, p.Version, Licence: FromLicenceFile.GetValueOrDefault(p.Id) ?? p.Expression))
            .Where(p => Banned.Contains(p.Id, StringComparer.OrdinalIgnoreCase) || !IsAllowed(p.Licence))
            .Select(p => $"{p.Id} {p.Version}: {p.Licence ?? "no SPDX licence"}")
            .ToList();

        Assert.True(problems.Count == 0, "Not allowed in the agent (IMPLEMENTATION_CHECKLIST.md, Open Source):\n" + string.Join("\n", problems));
    }

    /// <summary>Whether one alternative (OR) of the SPDX expression has only allowed licences (AND).</summary>
    private static bool IsAllowed(string? expression) =>
        expression != null
        && expression.Replace("(", "").Replace(")", "").Split(" OR ").Any(alternative => alternative.Split(" AND ").All(id => Allowed.Contains(id.Trim())));

    /// <summary>Every package in the restore output (obj/project.assets.json) of the projects under src/ and tests/.</summary>
    private static List<(string Id, string Version, string? Expression)> RestoredPackages(string root)
    {
        var assets = new[] { "src", "tests" }
            .SelectMany(folder => Directory.EnumerateFiles(Path.Combine(root, folder), "project.assets.json", SearchOption.AllDirectories))
            .ToList();
        Assert.NotEmpty(assets);

        var packages = new Dictionary<string, (string, string, string?)>(StringComparer.OrdinalIgnoreCase);
        foreach (var path in assets)
        {
            using var json = JsonDocument.Parse(File.ReadAllText(path));
            var folders = json.RootElement.GetProperty("packageFolders").EnumerateObject().Select(f => f.Name).ToList();
            foreach (var library in json.RootElement.GetProperty("libraries").EnumerateObject())
            {
                if (library.Value.GetProperty("type").GetString() != "package" || packages.ContainsKey(library.Name))
                {
                    continue;
                }

                var id = library.Name.Split('/')[0];
                var version = library.Name.Split('/')[1];
                var nuspec = folders
                    .Select(folder => Path.Combine(folder, id.ToLowerInvariant(), version.ToLowerInvariant(), $"{id.ToLowerInvariant()}.nuspec"))
                    .FirstOrDefault(File.Exists);
                var match = nuspec == null ? Match.Empty : Regex.Match(File.ReadAllText(nuspec), "<license type=\"expression\">([^<]+)</license>");
                packages[library.Name] = (id, version, match.Success ? match.Groups[1].Value : null);
            }
        }

        return packages.Values.ToList();
    }
}
