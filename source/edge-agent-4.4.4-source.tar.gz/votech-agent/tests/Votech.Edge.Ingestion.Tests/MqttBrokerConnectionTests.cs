using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Mqtt;
using MQTTnet;
using MQTTnet.Client;
using Xunit;

namespace Votech.Edge.Ingestion.Tests;

/// <summary>EMS-202: the broker over TCP (8883) or over WebSockets (wss on 443), with the same TLS checks.</summary>
public class MqttBrokerConnectionTests
{
    [Fact]
    public void WithoutAWebSocketPath_TheBrokerIsReachedOverTcp()
    {
        var options = new MqttOptions { BrokerHost = "broker.example.com", BrokerPort = 8883, UseTls = true };

        var channel = Assert.IsType<MqttClientTcpOptions>(Build(options).ChannelOptions);

        var endpoint = Assert.IsType<DnsEndPoint>(channel.RemoteEndpoint);
        Assert.Equal("broker.example.com", endpoint.Host);
        Assert.Equal(8883, endpoint.Port);
        Assert.True(channel.TlsOptions.UseTls);
        Assert.Equal("broker.example.com:8883", options.BrokerAddress);
    }

    [Theory]
    [InlineData("/mqtt")]
    [InlineData("mqtt")]
    [InlineData(" /mqtt ")]
    public void WithAWebSocketPath_TheBrokerIsReachedOverSecureWebSockets(string path)
    {
        var options = new MqttOptions { BrokerHost = "broker.example.com", BrokerPort = 443, UseTls = true, WebSocketPath = path };

        var channel = Assert.IsType<MqttClientWebSocketOptions>(Build(options).ChannelOptions);

        Assert.Equal("wss://broker.example.com:443/mqtt", channel.Uri);
        Assert.True(channel.TlsOptions.UseTls);
        Assert.Equal("wss://broker.example.com:443/mqtt", options.BrokerAddress);
    }

    [Fact]
    public void WithoutTls_TheWebSocketIsPlain_WhichOnlyDevelopmentAllows()
    {
        var options = new MqttOptions { BrokerHost = "localhost", BrokerPort = 8080, UseTls = false, WebSocketPath = "/mqtt" };

        var channel = Assert.IsType<MqttClientWebSocketOptions>(Build(options).ChannelOptions);

        Assert.Equal("ws://localhost:8080/mqtt", channel.Uri);
        Assert.False(new EdgeAgentOptionsValidator("Production").Validate(null, new EdgeAgentOptions { ApiBaseUrl = "https://api.example.com", Mqtt = options }).Succeeded);
    }

    [Theory]
    [InlineData("/mqtt", true)]
    [InlineData("", true)]
    [InlineData("wss://broker.example.com/mqtt", false)]
    [InlineData("/mqtt?token=1", false)]
    [InlineData("/my mqtt", false)]
    public void TheWebSocketPath_MustBeAPath(string path, bool valid)
    {
        var options = new EdgeAgentOptions
        {
            ApiBaseUrl = "https://api.example.com",
            Mqtt = new MqttOptions { BrokerHost = "broker.example.com", BrokerPort = 443, UseTls = true, WebSocketPath = path },
        };

        var result = new EdgeAgentOptionsValidator("Production").Validate(null, options);

        Assert.Equal(valid, result.Succeeded);
        if (!valid)
        {
            Assert.Contains("MQTT_WEBSOCKET_PATH", result.FailureMessage);
        }
    }

    /// <summary>
    /// A-02 over WebSockets: a TLS server on loopback presenting each certificate, the agent's broker options with the
    /// private CA. Only an accepted certificate lets the client send its WebSocket upgrade for the path, with the MQTT
    /// subprotocol.
    /// </summary>
    [Theory]
    [InlineData("the CA's, for the broker host", true)]
    [InlineData("the CA's, for another host", false)]
    [InlineData("self-signed", false)]
    [InlineData("another CA's", false)]
    public async Task TheWebSocketConnection_TrustsOnlyTheCa_AndOnlyForTheBrokerHost(string certificate, bool upgrades)
    {
        using var certificates = new TestCertificates("localhost");
        var serverCertificate = certificate switch
        {
            "the CA's, for the broker host" => certificates.Server,
            "the CA's, for another host" => certificates.WrongHost,
            "self-signed" => certificates.SelfSigned,
            _ => certificates.OtherCaServer,
        };
        // localhost may resolve to ::1 or 127.0.0.1
        var listener = new TcpListener(IPAddress.IPv6Any, 0);
        listener.Server.DualMode = true;
        listener.Start();
        try
        {
            var port = ((IPEndPoint)listener.LocalEndpoint).Port;
            var server = ReadWebSocketRequestAsync(listener, serverCertificate);
            var options = new MqttOptions
            {
                BrokerHost = "localhost",
                BrokerPort = port,
                UseTls = true,
                WebSocketPath = "/mqtt",
                CaCertificatePath = certificates.CaPemPath,
            };
            using var client = new MqttFactory().CreateMqttClient();

            try
            {
                await client.ConnectAsync(Build(options, TimeSpan.FromSeconds(5)));
            }
            catch (Exception)
            {
                // The test server never completes the upgrade; what it received is the result
            }

            var request = await server;
            if (upgrades)
            {
                Assert.NotNull(request);
                Assert.StartsWith("GET /mqtt HTTP/1.1", request);
                Assert.Contains("sec-websocket-protocol: mqtt", request, StringComparison.OrdinalIgnoreCase);
            }
            else
            {
                Assert.Null(request);
            }
        }
        finally
        {
            listener.Stop();
        }
    }

    private static MqttClientOptions Build(MqttOptions options, TimeSpan? timeout = null) =>
        new MqttClientOptionsBuilder().WithClientId("edge-test").WithBroker(options).WithTimeout(timeout ?? TimeSpan.FromSeconds(5)).Build();

    /// <summary>
    /// The client's HTTP upgrade request, or null when the client refused the certificate: the handshake fails on the
    /// server, or (TLS 1.3, where the server finishes first) the client closes without sending anything.
    /// </summary>
    private static async Task<string?> ReadWebSocketRequestAsync(TcpListener listener, X509Certificate2 certificate)
    {
        using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(15));
        using var socket = await listener.AcceptTcpClientAsync(timeout.Token);
        await using var ssl = new SslStream(socket.GetStream());
        try
        {
            await ssl.AuthenticateAsServerAsync(certificate);
            var buffer = new byte[4096];
            var request = new StringBuilder();
            while (!request.ToString().Contains("\r\n\r\n", StringComparison.Ordinal))
            {
                var read = await ssl.ReadAsync(buffer, timeout.Token);
                if (read == 0)
                {
                    break;
                }

                request.Append(Encoding.ASCII.GetString(buffer, 0, read));
            }

            return request.Length == 0 ? null : request.ToString();
        }
        catch (Exception ex) when (ex is AuthenticationException or IOException)
        {
            return null;
        }
    }
}
