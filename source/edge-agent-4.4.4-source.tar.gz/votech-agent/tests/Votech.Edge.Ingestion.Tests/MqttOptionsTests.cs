using Votech.Edge.Core.Configuration;
using Xunit;

namespace Votech.Edge.Ingestion.Tests;

public class MqttOptionsTests
{
    [Theory]
    [InlineData(0, 1_000_000, false)]
    [InlineData(-1, 5, false)]
    [InlineData(10, 10, false)]
    [InlineData(10, 11, true)]
    public void ReconnectAttemptsExhausted_NeverGivesUpWithoutAPositiveLimit(int limit, int attempt, bool expected)
    {
        var options = new MqttOptions { MaxReconnectAttempts = limit };

        Assert.Equal(expected, options.ReconnectAttemptsExhausted(attempt));
    }

    [Fact]
    public void MaxReconnectAttempts_DefaultsToUnlimited()
    {
        Assert.Equal("unlimited", new MqttOptions().ReconnectAttemptLimitText);
    }
}
