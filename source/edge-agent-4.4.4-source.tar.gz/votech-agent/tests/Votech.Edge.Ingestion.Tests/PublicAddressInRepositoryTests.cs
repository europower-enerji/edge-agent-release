using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using Xunit;

namespace Votech.Edge.Ingestion.Tests;

/// <summary>
/// The repository is public: no file may hold a public IPv4 address with a port, the address of a real customer device
/// (IEC 104 has no password). Private, loopback and documentation addresses (192.0.2.x, 198.51.100.x, 203.0.113.x) are
/// allowed in tests and examples.
/// </summary>
public class PublicAddressInRepositoryTests
{
    private static readonly Regex AddressWithPort = new(@"(?<![\d.])(\d{1,3}(?:\.\d{1,3}){3}):\d{1,5}(?!\d)", RegexOptions.CultureInvariant);

    private static readonly string[] SkippedFolders = [".git", "bin", "obj", "node_modules", ".vs", "TestResults"];

    private static readonly string[] BinaryExtensions = [".db", ".db-shm", ".db-wal", ".db-lock", ".png", ".jpg", ".ico", ".pfx", ".p12", ".dll", ".pdb", ".gz", ".zip"];

    [Fact]
    public void NoFile_HoldsAPublicAddressWithAPort()
    {
        var root = ProductNameInSourceTests.RepositoryRoot();
        var findings = PublishedFiles(root)
            .Where(path => !BinaryExtensions.Contains(Path.GetExtension(path), StringComparer.OrdinalIgnoreCase))
            .SelectMany(path => File.ReadLines(path).Select((line, i) => (path, line, number: i + 1)))
            .SelectMany(l => AddressWithPort.Matches(l.line).Where(m => IsPublic(m.Groups[1].Value)).Select(m => $"{Path.GetRelativePath(root, l.path)}:{l.number}  {m.Value}"))
            .ToList();

        Assert.True(findings.Count == 0, "Replace these with a documentation address (192.0.2.x) or remove them:\n" + string.Join("\n", findings));
    }

    /// <summary>The tracked files (local databases and .env files are never published); every file in a source package.</summary>
    private static IEnumerable<string> PublishedFiles(string root)
    {
        try
        {
            using var git = Process.Start(new ProcessStartInfo("git", "ls-files -z") { WorkingDirectory = root, RedirectStandardOutput = true })!;
            var output = git.StandardOutput.ReadToEnd();
            git.WaitForExit();
            if (git.ExitCode == 0)
            {
                return output.Split('\0', StringSplitOptions.RemoveEmptyEntries).Select(f => Path.Combine(root, f)).Where(File.Exists).ToList();
            }
        }
        catch (System.ComponentModel.Win32Exception)
        {
            // No git: a source package, where every file is published.
        }

        return Directory
            .EnumerateFiles(root, "*", SearchOption.AllDirectories)
            .Where(path => !Path.GetRelativePath(root, path).Split(Path.DirectorySeparatorChar).Any(SkippedFolders.Contains))
            .ToList();
    }

    private static bool IsPublic(string text)
    {
        if (!IPAddress.TryParse(text, out var address) || text.Split('.').Any(part => int.Parse(part) > 255))
        {
            return false;
        }

        var b = address.GetAddressBytes();
        return !(b[0] is 0 or 10 or 127 or >= 224
            || (b[0] == 100 && b[1] >= 64 && b[1] <= 127)
            || (b[0] == 169 && b[1] == 254)
            || (b[0] == 172 && b[1] >= 16 && b[1] <= 31)
            || (b[0] == 192 && b[1] == 168)
            || (b[0] == 192 && b[1] == 0 && b[2] == 2)
            || (b[0] == 198 && b[1] == 51 && b[2] == 100)
            || (b[0] == 203 && b[1] == 0 && b[2] == 113));
    }
}
