using Votech.Edge.Core.Configuration;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace Votech.Edge.Ingestion.Tests;

/// <summary>EMS-217: on Windows the container folders of appsettings.json move under %ProgramData%\EdgeAgent.</summary>
public class WindowsDefaultsTests
{
    private const string ProgramData = "C:\\ProgramData";

    [Fact]
    public void TheContainerFolders_MoveUnderProgramData()
    {
        var overrides = WindowsDefaults.For(Configuration(
            ("EdgeAgent:Storage:SqliteConnectionString", "Data Source=/var/lib/edge-agent/edge.db"),
            ("Serilog:WriteTo:0:Args:path", "/var/log/edge-agent/agent-.log")), ProgramData);

        var root = Path.Combine(ProgramData, "EdgeAgent");
        Assert.Equal($"Data Source={Path.Combine(root, "data")}{Path.DirectorySeparatorChar}edge.db", overrides[WindowsDefaults.DatabaseKey]);
        Assert.Equal($"{Path.Combine(root, "logs")}{Path.DirectorySeparatorChar}agent-.log", overrides[WindowsDefaults.LogFileKey]);
    }

    [Fact]
    public void AFolderSetByTheCustomer_StaysAsItIs()
    {
        var overrides = WindowsDefaults.For(Configuration(
            ("EdgeAgent:Storage:SqliteConnectionString", @"Data Source=D:\Votech\edge.db"),
            ("Serilog:WriteTo:0:Args:path", @"D:\Votech\logs\agent-.log")), ProgramData);

        Assert.Empty(overrides);
    }

    [Fact]
    public void TheShippedAppsettings_HaveTheContainerFolders_ThisClassMoves()
    {
        using var json = System.Text.Json.JsonDocument.Parse(
            File.ReadAllText(Path.Combine(ProductNameInSourceTests.RepositoryRoot(), "src", "Votech.Edge.Service", "appsettings.json")));
        var root = json.RootElement;
        var appsettings = Configuration(
            (WindowsDefaults.DatabaseKey, root.GetProperty("EdgeAgent").GetProperty("Storage").GetProperty("SqliteConnectionString").GetString()!),
            (WindowsDefaults.LogFileKey, root.GetProperty("Serilog").GetProperty("WriteTo")[0].GetProperty("Args").GetProperty("path").GetString()!));

        var overrides = WindowsDefaults.For(appsettings, ProgramData);

        Assert.Contains(WindowsDefaults.DatabaseKey, overrides.Keys);
        Assert.Contains(WindowsDefaults.LogFileKey, overrides.Keys);
    }

    private static IConfiguration Configuration(params (string Key, string Value)[] values) =>
        new ConfigurationBuilder().AddInMemoryCollection(values.Select(v => new KeyValuePair<string, string?>(v.Key, v.Value))).Build();
}
