using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Xunit;

namespace Votech.Edge.Ingestion.Tests;

/// <summary>
/// The agent's logs and messages name no product: they point to the "Site connectors" page and say "the server" or
/// "the broker", so a product rename needs no agent release. No string in the agent code may spell GridPlus, EuroScada,
/// Votech or a brand domain; namespace-qualified type names are not text and are skipped. An exception, if one is ever
/// needed, says why it may stay.
/// </summary>
public class ProductNameInSourceTests
{
    // GridPlus, Grid Plus, EuroGridPlus, EuroScada, Votech and the brand domains, in any letter case
    private static readonly Regex ProductName = new(
        @"grid[ _-]?plus|euro[ -]?scada|votech|vo-tech\.com",
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant
    );

    private static readonly Regex QualifiedTypeName = new(@"\b(?:GridPlus|Votech)(?:\.[A-Z][A-Za-z0-9]*)+", RegexOptions.CultureInvariant);
    private static readonly Regex StringLiteral = new(@"@""(?:[^""]|"""")*""|""(?:[^""\\\n]|\\.)*""", RegexOptions.CultureInvariant);

    private sealed record Allowed(string File, string Pattern, string Reason);

    private static readonly Allowed[] Exceptions = [];

    [Fact]
    public void NoCodeString_SpellsTheProductName_ExceptTheListedOnes()
    {
        var unexpected = Findings()
            .Where(f => !Exceptions.Any(e => Covers(e, f)))
            .Select(f => $"{f.File}:{f.Line}  {f.Text}")
            .ToList();

        Assert.True(unexpected.Count == 0, "Write the text without a product name:\n" + string.Join("\n", unexpected));
    }

    [Fact]
    public void EveryException_IsStillNeeded()
    {
        var findings = Findings();
        var unused = Exceptions.Where(e => !findings.Any(f => Covers(e, f))).Select(e => $"{e.File}: {e.Pattern}").ToList();

        Assert.True(unused.Count == 0, "Remove the exceptions that no longer match anything:\n" + string.Join("\n", unused));
    }

    private sealed record Finding(string File, int Line, string Text);

    private static bool Covers(Allowed allowed, Finding finding) =>
        finding.File == allowed.File && Regex.IsMatch(finding.Text, allowed.Pattern, RegexOptions.CultureInvariant);

    /// <summary>Every C# string literal under src/ that spells a product name (comments are not scanned).</summary>
    private static List<Finding> Findings()
    {
        var root = RepositoryRoot();
        var findings = new List<Finding>();
        foreach (var path in Directory.EnumerateFiles(Path.Combine(root, "src"), "*.cs", SearchOption.AllDirectories))
        {
            var relative = Path.GetRelativePath(root, path).Replace('\\', '/');
            if (relative.Contains("/bin/") || relative.Contains("/obj/") || relative.Contains("/Migrations/"))
            {
                continue;
            }

            var lines = File.ReadAllLines(path);
            for (var i = 0; i < lines.Length; i++)
            {
                var line = lines[i].Trim();
                if (line.StartsWith("//", StringComparison.Ordinal))
                {
                    continue;
                }

                findings.AddRange(StringLiteral.Matches(line)
                    .Select(m => m.Value)
                    .Where(text => ProductName.IsMatch(QualifiedTypeName.Replace(text, string.Empty)))
                    .Select(text => new Finding(relative, i + 1, text)));
            }
        }

        return findings;
    }

    /// <summary>The folder holding src/ and the solution file (or .git), above the test binaries.</summary>
    internal static string RepositoryRoot()
    {
        for (var dir = new DirectoryInfo(AppContext.BaseDirectory); dir != null; dir = dir.Parent)
        {
            if (Directory.Exists(Path.Combine(dir.FullName, "src"))
                && (dir.EnumerateFiles("*.sln").Any() || dir.EnumerateFiles("*.slnx").Any() || Directory.Exists(Path.Combine(dir.FullName, ".git"))))
            {
                return dir.FullName;
            }
        }

        throw new InvalidOperationException("The repository root (src/ next to a solution file or .git) was not found.");
    }
}
