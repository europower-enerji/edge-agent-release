using Votech.Edge.Core.Configuration;
using Xunit;

namespace Votech.Edge.Ingestion.Tests;

/// <summary>
/// A-02: with a private CA, the agent trusts only certificates that CA issued for the host it connects to, and a CA
/// file it cannot read stops it instead of falling back to the system certificates.
/// </summary>
public sealed class PrivateCaTrustTests : IDisposable
{
    private readonly TestCertificates _certificates = new();

    public void Dispose() => _certificates.Dispose();

    private async Task<(bool Accepted, string Reason)> ConnectAsync(System.Security.Cryptography.X509Certificates.X509Certificate2 server)
    {
        var roots = PrivateCaTrust.Load(_certificates.CaPemPath);
        var reason = string.Empty;
        var accepted = await TestCertificates.HandshakeAsync(server, (_, certificate, chain, errors) => PrivateCaTrust.Validate(certificate, chain, errors, roots, out reason));
        return (accepted, reason);
    }

    [Fact]
    public async Task ACertificateTheCaIssuedForTheHost_IsTrusted()
    {
        Assert.True((await ConnectAsync(_certificates.Server)).Accepted);
    }

    [Fact]
    public async Task ACertificateForAnotherHost_IsRefused_EvenFromTheCa()
    {
        var (accepted, reason) = await ConnectAsync(_certificates.WrongHost);

        Assert.False(accepted);
        Assert.Contains("does not name the host", reason);
    }

    [Fact]
    public async Task ASelfSignedCertificate_IsRefused()
    {
        var (accepted, reason) = await ConnectAsync(_certificates.SelfSigned);

        Assert.False(accepted);
        Assert.Contains("does not end at the configured CA", reason);
    }

    [Fact]
    public async Task ACertificateOfAnotherCa_IsRefused()
    {
        var (accepted, reason) = await ConnectAsync(_certificates.OtherCaServer);

        Assert.False(accepted);
        Assert.Contains("does not end at the configured CA", reason);
    }

    [Fact]
    public void TheCaFile_MayBePemDerOrABundle()
    {
        Assert.Single(PrivateCaTrust.Load(_certificates.CaPemPath));
        Assert.Single(PrivateCaTrust.Load(_certificates.CaDerPath));
        var bundle = _certificates.WriteFile("bundle.pem", File.ReadAllText(_certificates.CaPemPath) + "\n" + _certificates.Server.ExportCertificatePem());
        Assert.Equal(2, PrivateCaTrust.Load(bundle).Count);
    }

    [Fact]
    public void AMissingOrEmptyCaFile_Throws_AndNamesIt()
    {
        Assert.Contains("missing-ca.pem", Assert.Throws<InvalidOperationException>(() => PrivateCaTrust.Load("missing-ca.pem")).Message);
        var garbage = _certificates.WriteFile("garbage.pem", "not a certificate");
        Assert.Contains("garbage.pem", Assert.Throws<InvalidOperationException>(() => PrivateCaTrust.Load(garbage)).Message);
    }

    [Theory]
    [InlineData("Development")]
    [InlineData("Production")]
    public void ACaFileThatCannotBeRead_StopsTheAgent_InEveryEnvironment(string environment)
    {
        var validator = new EdgeAgentOptionsValidator(environment);
        EdgeAgentOptions Options(string? mqttCa, bool tls, string? apiCa) => new()
        {
            ApiBaseUrl = "https://votech.example.com",
            ApiCaCertificatePath = apiCa,
            Mqtt = new MqttOptions { BrokerHost = "votech.example.com", UseTls = tls, CaCertificatePath = mqttCa },
        };

        var mqtt = validator.Validate(null, Options("missing-ca.pem", tls: true, apiCa: null));
        var api = validator.Validate(null, Options(null, tls: true, apiCa: "missing-ca.pem"));
        var both = validator.Validate(null, Options(_certificates.CaPemPath, tls: true, apiCa: _certificates.CaDerPath));
        // Without TLS the broker CA is not used, so it is not checked
        var plain = validator.Validate(null, Options("missing-ca.pem", tls: false, apiCa: null));

        Assert.Contains("MQTT_CA_CERT", Assert.Single(mqtt.Failures!));
        Assert.Contains("API_CA_CERT", Assert.Single(api.Failures!));
        Assert.True(both.Succeeded);
        Assert.Equal(environment == "Development", plain.Succeeded);
    }
}
