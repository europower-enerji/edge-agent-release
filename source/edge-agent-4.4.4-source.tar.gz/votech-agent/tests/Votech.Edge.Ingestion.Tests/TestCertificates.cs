using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace Votech.Edge.Ingestion.Tests;

/// <summary>
/// A private CA and server certificates for A-02: one the CA issued for the host, one for another host, a self-signed
/// one, and one from another CA. Also compiled into Votech.Edge.Storage.Tests.
/// </summary>
internal sealed class TestCertificates : IDisposable
{
    public const string Host = "broker.test";

    private readonly string _directory = Path.Combine(Path.GetTempPath(), $"votech-ca-{Guid.NewGuid():N}");

    /// <param name="host">The host the server certificates name; a WebSocket client checks the host of its URL.</param>
    public TestCertificates(string host = Host)
    {
        Directory.CreateDirectory(_directory);
        Ca = CreateCa("CN=Votech Test CA");
        Server = Issue(host, Ca);
        WrongHost = Issue("other.test", Ca);
        SelfSigned = Issue(host, issuer: null);
        using var otherCa = CreateCa("CN=Somebody Else's CA");
        OtherCaServer = Issue(host, otherCa);

        CaPemPath = Path.Combine(_directory, "ca.pem");
        File.WriteAllText(CaPemPath, Ca.ExportCertificatePem());
        CaDerPath = Path.Combine(_directory, "ca.der");
        File.WriteAllBytes(CaDerPath, Ca.Export(X509ContentType.Cert));
    }

    public X509Certificate2 Ca { get; }

    public X509Certificate2 Server { get; }

    public X509Certificate2 WrongHost { get; }

    public X509Certificate2 SelfSigned { get; }

    public X509Certificate2 OtherCaServer { get; }

    public string CaPemPath { get; }

    public string CaDerPath { get; }

    /// <summary>A file in the test folder with <paramref name="content"/>.</summary>
    public string WriteFile(string name, string content)
    {
        var path = Path.Combine(_directory, name);
        File.WriteAllText(path, content);
        return path;
    }

    /// <summary>A TLS handshake on loopback: the server presents <paramref name="serverCertificate"/>, the client connects to <see cref="Host"/>.</summary>
    public static async Task<bool> HandshakeAsync(X509Certificate2 serverCertificate, RemoteCertificateValidationCallback validate)
    {
        using var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        var server = ServeOnceAsync(listener, serverCertificate, response: null);
        using var client = new TcpClient();
        await client.ConnectAsync(IPAddress.Loopback, ((IPEndPoint)listener.LocalEndpoint).Port);
        await using var stream = new SslStream(client.GetStream());
        try
        {
            await stream.AuthenticateAsClientAsync(new SslClientAuthenticationOptions { TargetHost = Host, RemoteCertificateValidationCallback = validate });
            return true;
        }
        catch (AuthenticationException)
        {
            return false;
        }
        finally
        {
            client.Close();
            await server;
        }
    }

    /// <summary>Accepts one connection, completes TLS with <paramref name="certificate"/> and, for HTTP, answers 200 "ok".</summary>
    public static async Task ServeOnceAsync(TcpListener listener, X509Certificate2 certificate, string? response)
    {
        using var socket = await listener.AcceptTcpClientAsync();
        await using var ssl = new SslStream(socket.GetStream());
        try
        {
            await ssl.AuthenticateAsServerAsync(certificate);
            if (response == null)
            {
                return;
            }

            var buffer = new byte[4096];
            var request = string.Empty;
            while (!request.Contains("\r\n\r\n", StringComparison.Ordinal))
            {
                var read = await ssl.ReadAsync(buffer);
                if (read == 0)
                {
                    return;
                }

                request += System.Text.Encoding.ASCII.GetString(buffer, 0, read);
            }

            await ssl.WriteAsync(System.Text.Encoding.ASCII.GetBytes($"HTTP/1.1 200 OK\r\nContent-Length: {response.Length}\r\nConnection: close\r\n\r\n{response}"));
        }
        catch (Exception ex) when (ex is AuthenticationException or IOException)
        {
            // The client refused the certificate
        }
    }

    public void Dispose()
    {
        foreach (var certificate in new[] { Ca, Server, WrongHost, SelfSigned, OtherCaServer })
        {
            certificate.Dispose();
        }

        Directory.Delete(_directory, true);
    }

    private static X509Certificate2 CreateCa(string subject)
    {
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var request = new CertificateRequest(subject, key, HashAlgorithmName.SHA256);
        request.CertificateExtensions.Add(new X509BasicConstraintsExtension(true, false, 0, true));
        request.CertificateExtensions.Add(new X509KeyUsageExtension(X509KeyUsageFlags.KeyCertSign | X509KeyUsageFlags.CrlSign, true));
        request.CertificateExtensions.Add(new X509SubjectKeyIdentifierExtension(request.PublicKey, false));
        using var ca = request.CreateSelfSigned(DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddYears(1));
        return Reload(ca);
    }

    private static X509Certificate2 Issue(string host, X509Certificate2? issuer)
    {
        using var key = ECDsa.Create(ECCurve.NamedCurves.nistP256);
        var request = new CertificateRequest($"CN={host}", key, HashAlgorithmName.SHA256);
        var names = new SubjectAlternativeNameBuilder();
        names.AddDnsName(host);
        request.CertificateExtensions.Add(names.Build());
        request.CertificateExtensions.Add(new X509BasicConstraintsExtension(false, false, 0, false));
        request.CertificateExtensions.Add(new X509EnhancedKeyUsageExtension([new Oid("1.3.6.1.5.5.7.3.1")], false));
        if (issuer == null)
        {
            using var selfSigned = request.CreateSelfSigned(DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddDays(30));
            return Reload(selfSigned);
        }

        request.CertificateExtensions.Add(X509AuthorityKeyIdentifierExtension.CreateFromCertificate(issuer, true, false));
        using var issued = request.Create(issuer, DateTimeOffset.UtcNow.AddDays(-1), DateTimeOffset.UtcNow.AddDays(30), RandomNumberGenerator.GetBytes(8));
        using var withKey = issued.CopyWithPrivateKey(key);
        return Reload(withKey);
    }

    // SslStream needs a certificate whose key it can use; a PKCS#12 round trip gives one on every platform
    private static X509Certificate2 Reload(X509Certificate2 certificate) =>
        X509CertificateLoader.LoadPkcs12(certificate.Export(X509ContentType.Pkcs12), null);
}
