using System.Net;
using System.Net.Sockets;
using System.Security.Authentication;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Mqtt;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Server;
using Xunit;

namespace Votech.Edge.Ingestion.Tests;

public class MqttTlsOptionsFactoryTests
{
    [Fact]
    public void BuildTlsOptions_WhenUseTlsIsTrue_SetsTls12AndTls13Protocols()
    {
        // Arrange
        var options = new MqttOptions
        {
            UseTls = true,
            BrokerHost = "localhost",
            BrokerPort = 8883,
            ClientId = "test-client",
        };

        // Act
        var tlsOptions = MqttTlsOptionsFactory.BuildTlsOptions(options);

        // Assert
        Assert.NotNull(tlsOptions);
        Assert.Equal(SslProtocols.Tls12 | SslProtocols.Tls13, tlsOptions.SslProtocol);
    }

    [Fact]
    public void BuildTlsOptions_WithAMissingCaFile_Throws_InsteadOfTrustingTheSystemCertificates()
    {
        var options = new MqttOptions { UseTls = true, BrokerHost = "broker.test", CaCertificatePath = "non_existent_ca.crt" };

        var error = Assert.Throws<InvalidOperationException>(() => MqttTlsOptionsFactory.BuildTlsOptions(options));

        Assert.Contains("non_existent_ca.crt", error.Message);
    }

    [Fact]
    public void BuildTlsOptions_WithACaFile_ChecksTheBrokerCertificateItself()
    {
        using var certificates = new TestCertificates();
        var options = new MqttOptions { UseTls = true, BrokerHost = TestCertificates.Host, CaCertificatePath = certificates.CaPemPath };

        var tlsOptions = MqttTlsOptionsFactory.BuildTlsOptions(options);

        Assert.NotNull(tlsOptions.CertificateValidationHandler);
    }

    [Fact]
    public void BuildTlsOptions_WithMissingClientCertificateFiles_StillBuilds()
    {
        var options = new MqttOptions
        {
            UseTls = true,
            ClientCertificatePath = "non_existent_client.crt",
            ClientKeyPath = "non_existent_client.key",
        };

        Assert.NotNull(MqttTlsOptionsFactory.BuildTlsOptions(options));
    }

    /// <summary>A-02 end to end: a TLS broker (in-process MQTTnet) presenting each certificate, the agent's TLS options.</summary>
    [Theory]
    [InlineData("the CA's, for the broker host", true)]
    [InlineData("the CA's, for another host", false)]
    [InlineData("self-signed", false)]
    [InlineData("another CA's", false)]
    public async Task TheBrokerConnection_TrustsOnlyTheCa_AndOnlyForTheBrokerHost(string certificate, bool connects)
    {
        using var certificates = new TestCertificates();
        var serverCertificate = certificate switch
        {
            "the CA's, for the broker host" => certificates.Server,
            "the CA's, for another host" => certificates.WrongHost,
            "self-signed" => certificates.SelfSigned,
            _ => certificates.OtherCaServer,
        };
        var port = FreePort();
        var factory = new MqttFactory();
        using var broker = factory.CreateMqttServer(new MqttServerOptionsBuilder()
            .WithoutDefaultEndpoint()
            .WithEncryptedEndpoint()
            .WithEncryptedEndpointPort(port)
            .WithEncryptionCertificate(serverCertificate)
            .Build());
        await broker.StartAsync();
        var tls = MqttTlsOptionsFactory.BuildTlsOptions(new MqttOptions { UseTls = true, BrokerHost = TestCertificates.Host, CaCertificatePath = certificates.CaPemPath });
        // The TCP connection goes to loopback; the certificate is checked against the broker host name
        tls.TargetHost = TestCertificates.Host;
        using var client = factory.CreateMqttClient();

        bool connected;
        try
        {
            await client.ConnectAsync(new MqttClientOptionsBuilder().WithTcpServer("127.0.0.1", port).WithTlsOptions(tls).WithTimeout(TimeSpan.FromSeconds(5)).Build());
            connected = client.IsConnected;
        }
        catch (Exception ex) when (ex is MQTTnet.Exceptions.MqttCommunicationException or AuthenticationException or OperationCanceledException)
        {
            connected = false;
        }
        finally
        {
            await broker.StopAsync();
        }

        Assert.Equal(connects, connected);
    }

    private static int FreePort()
    {
        using var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        return ((IPEndPoint)listener.LocalEndpoint).Port;
    }
}
