using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Interfaces;
using Votech.Edge.Ingestion.Services;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Tests.Contract;

public class ConnectionManagerTests
{
    private sealed class FakeSource : IEdgeConfigurationSource
    {
        public V2.EdgeConfiguration? Current { get; set; }
        public event EventHandler<V2.EdgeConfiguration>? ConfigurationChanged;
        public Task SyncAsync(CancellationToken ct = default) => Task.CompletedTask;
        public Task ReloadAsync(string? revision, CancellationToken ct = default) => Task.CompletedTask;
        public void Raise(V2.EdgeConfiguration configuration) => ConfigurationChanged?.Invoke(this, configuration);
    }

    private sealed class FakePoller(V2.Connection connection) : IConnectionPoller
    {
        public Guid EndpointId { get; } = EdgeIds.ToGuid(connection.EndpointId);
        public V2.Protocol Protocol { get; } = connection.Protocol;
        public bool IsConnected => true;
        public IReadOnlyList<EndpointHealth> Health => [];
        public V2.Connection Connection { get; private set; } = connection;
        public bool Disposed { get; private set; }
        /// <summary>Holds <see cref="DisposeAsync"/> open, like a socket that is still closing.</summary>
        public TaskCompletionSource? DisposeGate { get; set; }
        public Task RunAsync(CancellationToken ct) => Task.Delay(Timeout.Infinite, ct);
        public void UpdatePoints(V2.Connection updated) => Connection = updated;
        public ValueTask DisposeAsync()
        {
            Disposed = true;
            return DisposeGate is { } gate ? new ValueTask(gate.Task) : ValueTask.CompletedTask;
        }
    }

    private sealed class FakeFactory : IConnectionPollerFactory
    {
        public List<FakePoller> Created { get; } = [];
        public IConnectionPoller? Create(V2.Connection connection, ISignalSink sink)
        {
            if (connection.Protocol == V2.Protocol.Unspecified)
            {
                return null;
            }

            var poller = new FakePoller(connection);
            Created.Add(poller);
            return poller;
        }
    }

    private sealed class NullSink : ISignalSink
    {
        public void Write(in SignalReading reading) { }
        public Task DrainAsync(CancellationToken ct = default) => Task.CompletedTask;
        public long DroppedTotal => 0;
    }

    private static V2.Connection Connection(Guid id, string host, params Guid[] signals)
    {
        var connection = new V2.Connection
        {
            EndpointId = EdgeIds.ToByteString(id),
            Code = $"C-{host}",
            Protocol = V2.Protocol.Iec104,
            Iec104 = new V2.Iec104Settings { Host = host },
        };
        var station = new V2.Station { EndpointId = EdgeIds.ToByteString(id), StationAddress = 7 };
        station.Points.AddRange(signals.Select((s, i) => new V2.SignalPoint { SignalId = EdgeIds.ToByteString(s), Address = $"{1001 + i}" }));
        connection.Stations.Add(station);
        return connection;
    }

    private static V2.EdgeConfiguration Configuration(string revision, params V2.Connection[] connections)
    {
        var configuration = new V2.EdgeConfiguration { SchemaVersion = 2, Revision = revision };
        configuration.Connections.AddRange(connections);
        return configuration;
    }

    [Fact]
    public void TheDiff_SeparatesLinkChangesFromPointChanges()
    {
        Guid kept = Guid.NewGuid(), repointed = Guid.NewGuid(), reconnected = Guid.NewGuid(), removed = Guid.NewGuid(), added = Guid.NewGuid();
        var signal = Guid.NewGuid();
        var running = Configuration("1", Connection(kept, "a", signal), Connection(repointed, "b", signal), Connection(reconnected, "c"), Connection(removed, "d"));
        var renamed = Connection(kept, "a", signal);
        renamed.Code = "renamed";
        var target = Configuration("2", renamed, Connection(repointed, "b", signal, Guid.NewGuid()), Connection(reconnected, "c2"), Connection(added, "e"));

        var diff = EdgeConfigurationDiff.Between(running, target);

        Assert.Equal([added], diff.Added.Select(c => EdgeIds.ToGuid(c.EndpointId)));
        Assert.Equal([removed], diff.Removed);
        Assert.Equal([reconnected], diff.Reconnect.Select(c => EdgeIds.ToGuid(c.EndpointId)));
        Assert.Equal([kept, repointed], diff.Repoint.Select(c => EdgeIds.ToGuid(c.EndpointId)).OrderBy(id => id == repointed));
    }

    [Fact]
    public async Task ARevision_StartsStopsReconnectsAndRepointsPerConnection()
    {
        Guid first = Guid.NewGuid(), second = Guid.NewGuid(), third = Guid.NewGuid();
        var source = new FakeSource { Current = Configuration("1", Connection(first, "a"), Connection(second, "b")) };
        var factory = new FakeFactory();
        var manager = new ConnectionManager(source, factory, new NullSink(), NullLogger<ConnectionManager>.Instance);

        await manager.StartAsync();
        Assert.Equal(2, manager.Connections.Count);
        Assert.Equal("1", manager.RunningRevision);
        var (firstPoller, secondPoller) = (factory.Created[0], factory.Created[1]);

        var newSignal = Guid.NewGuid();
        await manager.ApplyAsync(Configuration("2", Connection(first, "a", newSignal), Connection(second, "b-moved"), Connection(third, "c")));

        Assert.False(firstPoller.Disposed);
        Assert.Equal(newSignal, EdgeIds.ToGuid(firstPoller.Connection.Stations[0].Points[0].SignalId));
        Assert.True(secondPoller.Disposed);
        Assert.Equal(4, factory.Created.Count);
        Assert.Equal(new[] { first, second, third }.Order(), manager.Connections.Select(p => p.EndpointId).Order());

        await manager.ApplyAsync(Configuration("3", Connection(first, "a", newSignal)));
        Assert.Equal([first], manager.Connections.Select(p => p.EndpointId));
        Assert.All(factory.Created.Skip(1), p => Assert.True(p.Disposed));

        await manager.StopAsync();
        Assert.True(firstPoller.Disposed);
        Assert.Empty(manager.Connections);
    }

    [Fact]
    public async Task TheSameRevision_ChangesNothing_AndAConnectionWithoutADriverIsSkipped()
    {
        var unsupported = Connection(Guid.NewGuid(), "x");
        unsupported.Protocol = V2.Protocol.Unspecified;
        var source = new FakeSource { Current = Configuration("1", Connection(Guid.NewGuid(), "a"), unsupported) };
        var factory = new FakeFactory();
        var manager = new ConnectionManager(source, factory, new NullSink(), NullLogger<ConnectionManager>.Instance);
        await manager.StartAsync();

        source.Raise(Configuration("1"));
        await manager.ApplyAsync(Configuration("1"));

        Assert.Single(manager.Connections);
        Assert.Single(factory.Created);
        await manager.StopAsync();
    }

    [Fact]
    public async Task AOneShotProbe_RunsOnlyWithoutAPoller_AndWaitsForARevisionBeingApplied()
    {
        Guid running = Guid.NewGuid(), idle = Guid.NewGuid();
        var source = new FakeSource { Current = Configuration("1", Connection(running, "a")) };
        var factory = new FakeFactory();
        var manager = new ConnectionManager(source, factory, new NullSink(), NullLogger<ConnectionManager>.Instance);
        await manager.StartAsync();

        Assert.Null(await manager.ProbeIfIdleAsync(running, _ => Task.FromResult("probed"), default));
        Assert.Equal("probed", await manager.ProbeIfIdleAsync(idle, _ => Task.FromResult("probed"), default));

        // A reconnect has removed the old poller but not closed its socket yet: the probe waits, then finds the new one.
        var gate = new TaskCompletionSource();
        factory.Created[0].DisposeGate = gate;
        var apply = manager.ApplyAsync(Configuration("2", Connection(running, "a-moved")));
        var probed = false;
        var probe = manager.ProbeIfIdleAsync(running, _ =>
        {
            probed = true;
            return Task.FromResult("probed");
        }, default);
        await Task.Delay(200);
        Assert.False(probe.IsCompleted);

        gate.SetResult();
        await apply;
        Assert.Null(await probe);
        Assert.False(probed);
        Assert.Equal(2, factory.Created.Count);
        await manager.StopAsync();
    }

    [Theory]
    [InlineData(10.0, null, null, 10.0)]
    [InlineData(10.0, 2.0, 1.0, 21.0)]
    [InlineData(5.0, null, 0.0, 5.0)]
    public void APoint_ConvertsRawValuesWithItsScaling(double raw, double? multiplier, double? offset, double expected)
    {
        var point = new V2.SignalPoint { SignalId = EdgeIds.ToByteString(Guid.NewGuid()), Address = "1" };
        if (multiplier.HasValue)
        {
            point.Scaling = new V2.Scaling { Type = V2.ScalingType.Multiplier, Multiplier = multiplier.Value, Offset = offset ?? 0 };
        }

        Assert.Equal(expected, new AcquiredPoint(point, Guid.Empty, 1).ToEngineering(raw));
    }

    [Fact]
    public void APoint_AppliesTheTransformBeforeALinearScaling()
    {
        var linear = new V2.SignalPoint
        {
            Scaling = new V2.Scaling { Type = V2.ScalingType.Linear, RawMin = 0, RawMax = 32000, EngMin = 0, EngMax = 100 },
        };
        Assert.Equal(50, new AcquiredPoint(linear, Guid.Empty, 1).ToEngineering(16000));

        var masked = new V2.SignalPoint { Transform = new V2.Transform { BitMask = 0b0100, InvertBool = true } };
        Assert.Equal(0, new AcquiredPoint(masked, Guid.Empty, 1).ToEngineering(0b0110));
        Assert.Equal(1, new AcquiredPoint(masked, Guid.Empty, 1).ToEngineering(0b0010));
    }
}
