using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Models;
using Votech.Edge.Ingestion.Modbus;
using Microsoft.Extensions.Logging.Abstractions;
using NModbus;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Tests.Contract;

public class ModbusTests
{
    [Theory]
    [InlineData("40001", V2.AddressBase.Modicon, ModbusTable.HoldingRegister, 0, null, null)]
    [InlineData("40001", V2.AddressBase.ZeroBased, ModbusTable.HoldingRegister, 1, null, null)]
    [InlineData("40000", V2.AddressBase.ZeroBased, ModbusTable.HoldingRegister, 0, null, null)]
    [InlineData("400001", V2.AddressBase.Modicon, ModbusTable.HoldingRegister, 0, null, null)]
    [InlineData("465536", V2.AddressBase.Modicon, ModbusTable.HoldingRegister, 65535, null, null)]
    [InlineData("00001", V2.AddressBase.Modicon, ModbusTable.Coil, 0, null, null)]
    [InlineData("10001", V2.AddressBase.Modicon, ModbusTable.DiscreteInput, 0, null, null)]
    [InlineData("30010", V2.AddressBase.Modicon, ModbusTable.InputRegister, 9, null, null)]
    [InlineData("HR:0", V2.AddressBase.Modicon, ModbusTable.HoldingRegister, 0, null, null)]
    [InlineData("ir:12", V2.AddressBase.ZeroBased, ModbusTable.InputRegister, 12, null, null)]
    [InlineData("CO:5", V2.AddressBase.Modicon, ModbusTable.Coil, 5, null, null)]
    [InlineData("40001.3", V2.AddressBase.Modicon, ModbusTable.HoldingRegister, 0, 3, null)]
    [InlineData("40001:F32", V2.AddressBase.Modicon, ModbusTable.HoldingRegister, 0, null, V2.DataType.Float32)]
    [InlineData("HR:10:u32", V2.AddressBase.Modicon, ModbusTable.HoldingRegister, 10, null, V2.DataType.Uint32)]
    public void AValidAddress_IsParsed(string address, V2.AddressBase addressBase, ModbusTable table, int offset, int? bit, V2.DataType? width)
    {
        Assert.True(ModbusAddressParser.TryParse(address, addressBase, out var parsed, out var error), error);
        Assert.Equal(new ModbusAddress(table, (ushort)offset, bit, width), parsed);
    }

    [Theory]
    [InlineData("40000", V2.AddressBase.Modicon)]
    [InlineData("465537", V2.AddressBase.Modicon)]
    [InlineData("HR:65536", V2.AddressBase.Modicon)]
    [InlineData("50001", V2.AddressBase.Modicon)]
    [InlineData("40001.16", V2.AddressBase.Modicon)]
    [InlineData("00001.1", V2.AddressBase.Modicon)]
    [InlineData("CO:1:F32", V2.AddressBase.Modicon)]
    [InlineData("40001.3:F32", V2.AddressBase.Modicon)]
    [InlineData("IOA:1001", V2.AddressBase.Modicon)]
    [InlineData("", V2.AddressBase.Modicon)]
    public void AnInvalidAddress_IsRefused(string address, V2.AddressBase addressBase)
    {
        Assert.False(ModbusAddressParser.TryParse(address, addressBase, out _, out var error));
        Assert.NotEmpty(error);
    }

    [Theory]
    [InlineData(new ushort[] { 0xFFFF }, V2.DataType.Int16, V2.ByteOrder.BigEndian, V2.WordOrder.HighFirst, null, -1.0)]
    [InlineData(new ushort[] { 0xFFFF }, V2.DataType.Uint16, V2.ByteOrder.BigEndian, V2.WordOrder.HighFirst, null, 65535.0)]
    [InlineData(new ushort[] { 0x3412 }, V2.DataType.Uint16, V2.ByteOrder.LittleEndian, V2.WordOrder.HighFirst, null, 0x1234)]
    [InlineData(new ushort[] { 0xFFFF, 0xFFFE }, V2.DataType.Int32, V2.ByteOrder.BigEndian, V2.WordOrder.HighFirst, null, -2.0)]
    [InlineData(new ushort[] { 0x0001, 0x0000 }, V2.DataType.Uint32, V2.ByteOrder.BigEndian, V2.WordOrder.HighFirst, null, 65536.0)]
    [InlineData(new ushort[] { 0x0000, 0x0001 }, V2.DataType.Uint32, V2.ByteOrder.BigEndian, V2.WordOrder.LowFirst, null, 65536.0)]
    [InlineData(new ushort[] { 0x4148, 0x0000 }, V2.DataType.Float32, V2.ByteOrder.BigEndian, V2.WordOrder.HighFirst, null, 12.5)]
    [InlineData(new ushort[] { 0x0000, 0x4148 }, V2.DataType.Float32, V2.ByteOrder.BigEndian, V2.WordOrder.LowFirst, null, 12.5)]
    [InlineData(new ushort[] { 0x4841, 0x0000 }, V2.DataType.Float32, V2.ByteOrder.LittleEndian, V2.WordOrder.HighFirst, null, 12.5)]
    [InlineData(new ushort[] { 0x0000, 0x0000, 0x0000, 0x0001 }, V2.DataType.Int64, V2.ByteOrder.BigEndian, V2.WordOrder.HighFirst, null, 1.0)]
    [InlineData(new ushort[] { 0x4029, 0x0000, 0x0000, 0x0000 }, V2.DataType.Float64, V2.ByteOrder.BigEndian, V2.WordOrder.HighFirst, null, 12.5)]
    [InlineData(new ushort[] { 0x0000, 0x0000, 0x0000, 0x4029 }, V2.DataType.Float64, V2.ByteOrder.BigEndian, V2.WordOrder.LowFirst, null, 12.5)]
    [InlineData(new ushort[] { 0x0008 }, V2.DataType.Boolean, V2.ByteOrder.BigEndian, V2.WordOrder.HighFirst, 3, 1.0)]
    [InlineData(new ushort[] { 0x0008 }, V2.DataType.Boolean, V2.ByteOrder.BigEndian, V2.WordOrder.HighFirst, 2, 0.0)]
    [InlineData(new ushort[] { 0x0005 }, V2.DataType.Boolean, V2.ByteOrder.BigEndian, V2.WordOrder.HighFirst, null, 1.0)]
    [InlineData(new ushort[] { 0x0006 }, V2.DataType.DoublePoint, V2.ByteOrder.BigEndian, V2.WordOrder.HighFirst, null, 2.0)]
    public void RegisterValues_AreDecodedWithTheConnectionsOrder(ushort[] registers, V2.DataType type, V2.ByteOrder byteOrder, V2.WordOrder wordOrder, int? bit, double expected)
    {
        Assert.Equal(expected, ModbusValueDecoder.Decode(registers, type, byteOrder, wordOrder, bit));
    }

    private static ModbusPoint Point(string address, V2.DataType type = V2.DataType.Uint16)
    {
        Assert.True(ModbusAddressParser.TryParse(address, V2.AddressBase.ZeroBased, out var parsed, out _));
        var length = parsed.IsRegister && !parsed.Bit.HasValue ? ModbusValueDecoder.RegisterCount(type) : 1;
        var signal = new V2.SignalPoint { SignalId = EdgeIds.ToByteString(Guid.NewGuid()), Address = address, DataType = type };
        return new ModbusPoint(new AcquiredPoint(signal, Guid.Empty, 1), parsed with { Width = type }, length);
    }

    [Fact]
    public void ThePlanner_ReadsTouchingRangesTogether_AndNeverReadsAGap()
    {
        var blocks = ModbusBlockPlanner.Plan(
            1,
            [Point("HR:0"), Point("HR:1", V2.DataType.Float32), Point("HR:3"), Point("HR:3.4", V2.DataType.Boolean), Point("HR:10"), Point("IR:0"), Point("CO:0"), Point("CO:7")],
            0
        );

        Assert.Equal(
            new[] { (ModbusTable.HoldingRegister, 0, 4, 4), (ModbusTable.HoldingRegister, 10, 1, 1), (ModbusTable.InputRegister, 0, 1, 1), (ModbusTable.Coil, 0, 1, 1), (ModbusTable.Coil, 7, 1, 1) }.Order(),
            blocks.Select(b => (b.Table, (int)b.Start, (int)b.Count, b.Points.Count)).Order());
    }

    [Fact]
    public void ThePlanner_SplitsAtTheLargestBlock()
    {
        var blocks = ModbusBlockPlanner.Plan(1, Enumerable.Range(0, 10).Select(i => Point($"HR:{i}")), 4);

        Assert.Equal([(0, 4), (4, 4), (8, 2)], blocks.Select(b => ((int)b.Start, (int)b.Count)));
    }

    private sealed class FakeLink : IModbusLink
    {
        public Dictionary<(byte Unit, ModbusTable Table), ushort[]> Registers { get; } = [];
        public HashSet<byte> Silent { get; } = [];
        public List<(byte Unit, ModbusTable Table, ushort Start, ushort Count)> Requests { get; } = [];
        public bool Broken { get; set; }

        public Task<bool[]> ReadBitsAsync(byte unit, ModbusTable table, ushort start, ushort count) =>
            Task.FromResult(Read(unit, table, start, count).Select(r => r != 0).ToArray());

        public Task<ushort[]> ReadRegistersAsync(byte unit, ModbusTable table, ushort start, ushort count) =>
            Task.FromResult(Read(unit, table, start, count));

        private ushort[] Read(byte unit, ModbusTable table, ushort start, ushort count)
        {
            lock (Requests)
            {
                Requests.Add((unit, table, start, count));
            }

            if (Broken)
            {
                throw new IOException("connection reset");
            }

            if (Silent.Contains(unit))
            {
                throw new TimeoutException("no answer");
            }

            if (unit == 9)
            {
                throw new SlaveException("Illegal data address");
            }

            return Registers[(unit, table)].AsSpan(start, count).ToArray();
        }

        public void Dispose() { }
    }

    private sealed class FakeLinkFactory(FakeLink link) : IModbusLinkFactory
    {
        public int Opened { get; private set; }
        public string Target => "fake:502";

        public Task<IModbusLink> OpenAsync(CancellationToken ct)
        {
            Opened++;
            link.Broken = false;
            return Task.FromResult<IModbusLink>(link);
        }
    }

    [Fact]
    public async Task APoller_ReadsEachStation_MarksASilentOneOffline_AndSurvivesAnExceptionResponse()
    {
        Guid root = Guid.NewGuid(), meterA = Guid.NewGuid(), meterB = Guid.NewGuid(), broken = Guid.NewGuid();
        Guid powerA = Guid.NewGuid(), powerB = Guid.NewGuid(), flag = Guid.NewGuid(), bad = Guid.NewGuid();
        var connection = new V2.Connection
        {
            EndpointId = EdgeIds.ToByteString(root),
            Code = "GW",
            Protocol = V2.Protocol.ModbusTcp,
            ModbusTcp = new V2.ModbusTcpSettings
            {
                Host = "fake",
                Encoding = new V2.ModbusEncoding { AddressBase = V2.AddressBase.Modicon },
                Polling = new V2.PollingSettings { PollIntervalMs = 50 },
            },
        };
        connection.Stations.Add(Station(meterA, 1, (powerA, "40001:F32", V2.DataType.Float32), (flag, "40003.0", V2.DataType.Boolean)));
        connection.Stations.Add(Station(meterB, 2, (powerB, "40001", V2.DataType.Int16)));
        connection.Stations.Add(Station(broken, 9, (bad, "40001", V2.DataType.Int16)));

        var link = new FakeLink();
        link.Registers[(1, ModbusTable.HoldingRegister)] = [0x4148, 0x0000, 0x0001];
        link.Registers[(2, ModbusTable.HoldingRegister)] = [0xFFFE];
        var sink = new RecordingSink();
        var factory = new FakeLinkFactory(link);
        await using var poller = new ModbusConnectionPoller(connection, sink, NullLogger.Instance, factory);
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var run = poller.RunAsync(cts.Token);
        try
        {
            await WaitUntil(() => sink.Readings.Any(r => r.SignalId == powerB));
            Assert.Contains(sink.Readings, r => (r.SignalId, r.Value, r.Quality) == (powerA, 12.5, CanonicalQualityStatus.Good));
            Assert.Contains(sink.Readings, r => (r.SignalId, r.Value) == (flag, 1.0));
            Assert.Contains(sink.Readings, r => (r.SignalId, r.Value) == (powerB, -2.0));
            Assert.DoesNotContain(sink.Readings, r => r.SignalId == bad);
            Assert.Contains(link.Requests, r => r == (1, ModbusTable.HoldingRegister, 0, 3));
            Assert.All(poller.Health, h => Assert.True(h.Connected));
            Assert.Contains("HoldingRegister 0-0", poller.Health.Single(h => h.EndpointId == broken).Error);

            link.Silent.Add(2);
            await WaitUntil(() => sink.Readings.Any(r => r.SignalId == powerB && r.Quality == CanonicalQualityStatus.Offline));
            Assert.False(poller.Health.Single(h => h.EndpointId == meterB).Connected);
            Assert.True(poller.Health.Single(h => h.EndpointId == meterA).Connected);
            Assert.Equal(-2.0, sink.Readings.Last(r => r.SignalId == powerB).Value);

            link.Silent.Clear();
            link.Broken = true;
            await WaitUntil(() => sink.Readings.Any(r => r.SignalId == powerA && r.Quality == CanonicalQualityStatus.Offline));
            Assert.Single(sink.Readings, r => r.SignalId == powerB && r.Quality == CanonicalQualityStatus.Offline);
            await WaitUntil(() => factory.Opened == 2 && poller.IsConnected);
        }
        finally
        {
            await cts.CancelAsync();
            await Task.WhenAny(run, Task.Delay(5000));
        }
    }

    [Fact]
    public async Task APoller_ReadsEachPollGroupOnItsOwnInterval()
    {
        Guid fast = Guid.NewGuid(), slow = Guid.NewGuid();
        var connection = new V2.Connection
        {
            EndpointId = EdgeIds.ToByteString(Guid.NewGuid()),
            Protocol = V2.Protocol.ModbusRtu,
            // The slow group's 60 s cannot come round within the test, however late a busy test machine resumes it
            ModbusRtu = new V2.ModbusRtuSettings { SerialPort = "/dev/null", Polling = new V2.PollingSettings { PollIntervalMs = 60_000 } },
        };
        var station = Station(Guid.NewGuid(), 1, (fast, "40001", V2.DataType.Uint16), (slow, "40010", V2.DataType.Uint16));
        station.Points[0].PollIntervalMs = 50;
        connection.Stations.Add(station);
        var link = new FakeLink();
        link.Registers[(1, ModbusTable.HoldingRegister)] = new ushort[16];
        var sink = new RecordingSink();
        await using var poller = new ModbusConnectionPoller(connection, sink, NullLogger.Instance, new FakeLinkFactory(link));
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var clock = System.Diagnostics.Stopwatch.StartNew();
        var run = poller.RunAsync(cts.Token);

        await Task.Delay(700);
        await cts.CancelAsync();
        var ranMs = clock.ElapsedMilliseconds;
        await Task.WhenAny(run, Task.Delay(5000));

        var counts = sink.Readings.Where(r => r.Quality == CanonicalQualityStatus.Good).GroupBy(r => r.SignalId).ToDictionary(g => g.Key, g => g.Count());
        Assert.Equal(1, counts[slow]);
        // Every 50 ms while the poller ran, plus the read at the start and one in flight at the cancel
        Assert.InRange(counts[fast], 5, (int)(ranMs / 50) + 2);
    }

    private static V2.Station Station(Guid endpointId, uint unit, params (Guid SignalId, string Address, V2.DataType Type)[] points)
    {
        var station = new V2.Station { EndpointId = EdgeIds.ToByteString(endpointId), Code = $"U{unit}", StationAddress = unit };
        station.Points.AddRange(points.Select(p => new V2.SignalPoint { SignalId = EdgeIds.ToByteString(p.SignalId), Code = p.Address, Address = p.Address, DataType = p.Type }));
        return station;
    }

    private static async Task WaitUntil(Func<bool> condition)
    {
        var deadline = DateTime.UtcNow.AddSeconds(15);
        while (!condition())
        {
            Assert.True(DateTime.UtcNow < deadline, "timed out waiting for the poller");
            await Task.Delay(20);
        }
    }
}
