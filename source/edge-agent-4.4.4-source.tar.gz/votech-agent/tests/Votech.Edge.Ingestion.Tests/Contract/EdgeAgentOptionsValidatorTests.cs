using Votech.Edge.Core.Configuration;
using Xunit;

namespace Votech.Edge.Ingestion.Tests.Contract;

public class EdgeAgentOptionsValidatorTests
{
    [Theory]
    [InlineData("Production", "https://api.votechpower.com", true, true)]
    [InlineData("Production", "http://api.votechpower.com", true, false)]
    [InlineData("Production", "https://api.votechpower.com", false, false)]
    [InlineData("Staging", "http://localhost:5050", false, false)]
    [InlineData("Development", "http://localhost:5050", false, true)]
    [InlineData("development", "http://localhost:5050", false, true)]
    public void PlainTransport_IsAllowedOnlyInDevelopment(string environment, string apiBaseUrl, bool useTls, bool valid)
    {
        var options = new EdgeAgentOptions { ApiBaseUrl = apiBaseUrl, Mqtt = new MqttOptions { UseTls = useTls } };

        var result = new EdgeAgentOptionsValidator(environment).Validate(null, options);

        Assert.Equal(valid, result.Succeeded);
        if (!valid)
        {
            Assert.Contains(environment, result.FailureMessage);
        }
    }
}
