using Votech.Edge.Ingestion.Services;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;
using Outcome = Votech.Edge.Ingestion.Services.AgentAssignmentSource.Outcome;
using Result = Votech.Edge.Ingestion.Services.AgentAssignmentSource.Result;

namespace Votech.Edge.Ingestion.Tests.Contract;

/// <summary>
/// X-01: one refusal never stops the agent. Its sites keep running while it asks less often, and only a key refused for
/// long enough stops them, without ending the process.
/// </summary>
public sealed class KeyRefusalPolicyTests
{
    private static readonly DateTimeOffset Start = new(2026, 11, 3, 9, 0, 0, TimeSpan.Zero);
    private static readonly V2.AgentAssignment Copy = new() { Name = "Main server" };

    private static Result Fresh() => new(Outcome.Fresh, Copy, null);

    private static Result Cached() => new(Outcome.Cached, Copy, "the backend cannot be reached");

    private static Result KeyRefused(bool withCopy = true) => new(Outcome.Refused, withCopy ? Copy : null, "revoked", "EDGE_KEY_REVOKED", KeyRefused: true);

    private static Result Suspended() => new(Outcome.Refused, Copy, "suspended", "TENANT_SUSPENDED");

    [Fact]
    public void ARefusedKey_KeepsTheSites_WhileItBacksOff_AndStopsThemOnlyAfterTenMinutes()
    {
        var policy = new KeyRefusalPolicy();
        var now = Start;
        var decisions = new List<KeyRefusalPolicy.Decision>();
        for (var i = 0; i < 6; i++)
        {
            var decision = policy.Next(KeyRefused(), now);
            decisions.Add(decision);
            now += decision.Delay;
        }

        Assert.Equal([1, 2, 4, 8, 15, 15], decisions.Select(d => d.Delay.TotalMinutes));
        // Refused at 0, 1, 3 and 7 min: the sites run on the local copy. At 15 min the key has been refused for long enough.
        Assert.Equal(
            [KeyRefusalPolicy.Action.Apply, KeyRefusalPolicy.Action.Apply, KeyRefusalPolicy.Action.Apply, KeyRefusalPolicy.Action.Apply, KeyRefusalPolicy.Action.StopAll, KeyRefusalPolicy.Action.StopAll],
            decisions.Select(d => d.Action));
        Assert.True(policy.Stopped);
    }

    [Fact]
    public void StoppedSites_StayStopped_WithoutTheBackend_AndStartOnAFreshAssignment()
    {
        var policy = new KeyRefusalPolicy();
        var now = Start;
        while (!policy.Stopped)
        {
            now += policy.Next(KeyRefused(), now).Delay;
        }

        var offline = policy.Next(Cached(), now);
        var suspended = policy.Next(Suspended(), now);
        var accepted = policy.Next(Fresh(), now);

        Assert.Equal(KeyRefusalPolicy.Action.Keep, offline.Action);
        Assert.Equal(KeyRefusalPolicy.Action.Keep, suspended.Action);
        Assert.Equal((KeyRefusalPolicy.Action.Apply, 60, 0), (accepted.Action, accepted.Delay.TotalSeconds, accepted.Refusals));
        Assert.False(policy.Stopped);
    }

    [Fact]
    public void RefusalsWithoutAKeyCode_NeverStopTheSites()
    {
        var policy = new KeyRefusalPolicy();
        var now = Start;
        var proxy = new Result(Outcome.Refused, Copy, "no reason given");
        for (var i = 0; i < 40; i++)
        {
            var decision = policy.Next(i % 2 == 0 ? Suspended() : proxy, now);
            Assert.Equal(KeyRefusalPolicy.Action.Apply, decision.Action);
            Assert.True(decision.Delay <= TimeSpan.FromMinutes(15));
            now += decision.Delay;
        }

        Assert.False(policy.Stopped);
        Assert.True(now - Start > TimeSpan.FromHours(8));
    }

    [Fact]
    public void AnyOtherAnswer_StartsTheCountOver()
    {
        var policy = new KeyRefusalPolicy();
        var now = Start;
        for (var i = 0; i < 4; i++)
        {
            now += policy.Next(KeyRefused(), now).Delay;
        }

        var unreachable = policy.Next(Cached(), now);
        now += unreachable.Delay;
        var again = policy.Next(KeyRefused(), now);

        Assert.Equal((KeyRefusalPolicy.Action.Apply, 0), (unreachable.Action, unreachable.Refusals));
        Assert.Equal((KeyRefusalPolicy.Action.Apply, 1, 1), (again.Action, again.Delay.TotalMinutes, again.Refusals));
    }

    [Fact]
    public void ARefusalWithoutALocalCopy_ChangesNothing()
    {
        var decision = new KeyRefusalPolicy().Next(KeyRefused(withCopy: false), Start);

        Assert.Equal(KeyRefusalPolicy.Action.Keep, decision.Action);
    }
}
