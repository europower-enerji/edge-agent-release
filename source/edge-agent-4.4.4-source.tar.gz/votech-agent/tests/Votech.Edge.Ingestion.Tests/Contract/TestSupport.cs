using System.Data.Common;
using System.Net;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Storage;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Tests.Contract;

/// <summary>An in-memory SQLite buffer database with the real schema, alive until disposed; keeps the SQL it ran.</summary>
internal sealed class SqliteTestDatabase : IDbContextFactory<EdgeDbContext>, IDisposable
{
    private readonly SqliteConnection _connection;
    private readonly DbContextOptions<EdgeDbContext> _options;

    static SqliteTestDatabase() => SQLitePCL.Batteries.Init();

    public SqliteTestDatabase()
    {
        _connection = new SqliteConnection("DataSource=:memory:");
        _connection.Open();
        _options = new DbContextOptionsBuilder<EdgeDbContext>().UseSqlite(_connection).AddInterceptors(new CommandRecorder(Commands)).Options;
        using var db = CreateDbContext();
        db.Database.EnsureCreated();
    }

    /// <summary>The text of every query the contexts ran.</summary>
    public List<string> Commands { get; } = [];

    public EdgeDbContext CreateDbContext() => new(_options);

    /// <summary>The steps of SQLite's plan for <paramref name="sql"/> (EXPLAIN QUERY PLAN).</summary>
    public List<string> QueryPlan(string sql)
    {
        using var command = _connection.CreateCommand();
        command.CommandText = "EXPLAIN QUERY PLAN " + sql;
        using var reader = command.ExecuteReader();
        var steps = new List<string>();
        while (reader.Read())
        {
            steps.Add(reader.GetString(3));
        }

        return steps;
    }

    public void Dispose() => _connection.Dispose();

    private sealed class CommandRecorder(List<string> commands) : DbCommandInterceptor
    {
        public override ValueTask<InterceptionResult<DbDataReader>> ReaderExecutingAsync(
            DbCommand command, CommandEventData eventData, InterceptionResult<DbDataReader> result, CancellationToken cancellationToken = default)
        {
            lock (commands)
            {
                commands.Add(command.CommandText);
            }

            return ValueTask.FromResult(result);
        }
    }
}

/// <summary>Answers HTTP requests from a queue and records them.</summary>
internal sealed class QueueHttpHandler : HttpMessageHandler
{
    public Queue<Func<HttpRequestMessage, HttpResponseMessage>> Responses { get; } = new();
    public List<HttpRequestMessage> Requests { get; } = [];

    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        Requests.Add(request);
        if (Responses.Count == 0)
        {
            throw new HttpRequestException("no answer queued");
        }

        return Task.FromResult(Responses.Dequeue()(request));
    }
}

/// <summary>A clock the test moves.</summary>
internal sealed class ManualTimeProvider(DateTimeOffset now) : TimeProvider
{
    public DateTimeOffset Now { get; set; } = now;

    public override DateTimeOffset GetUtcNow() => Now;
}

/// <summary>Builds v2 configurations for tests.</summary>
internal static class TestConfigurations
{
    public static readonly Guid SiteId = Guid.Parse("5a17e000-0000-4000-8000-0000000000c3");

    public static V2.EdgeConfiguration Iec104(string revision, params (Guid EndpointId, uint CommonAddress, (Guid SignalId, string Address, V2.DataType Type)[] Points)[] stations)
    {
        var connection = new V2.Connection
        {
            EndpointId = EdgeIds.ToByteString(stations.Length > 0 ? stations[0].EndpointId : Guid.NewGuid()),
            Code = "RTU",
            Protocol = V2.Protocol.Iec104,
            Iec104 = new V2.Iec104Settings { Host = "127.0.0.1", Port = 2404 },
        };
        foreach (var (endpointId, commonAddress, points) in stations)
        {
            var station = new V2.Station { EndpointId = EdgeIds.ToByteString(endpointId), Code = $"S{commonAddress}", StationAddress = commonAddress };
            station.Points.AddRange(points.Select(p => new V2.SignalPoint
            {
                SignalId = EdgeIds.ToByteString(p.SignalId),
                Code = p.Address,
                Address = p.Address,
                DataType = p.Type,
            }));
            connection.Stations.Add(station);
        }

        var configuration = new V2.EdgeConfiguration
        {
            SchemaVersion = 2,
            Revision = revision,
            SiteId = EdgeIds.ToByteString(SiteId),
            TenantId = EdgeIds.ToByteString(Guid.NewGuid()),
        };
        configuration.Connections.Add(connection);
        return configuration;
    }

    /// <summary>A refusal as the backend sends it: problem+json with a <c>code</c>, or an empty body without one.</summary>
    public static HttpResponseMessage Refusal(HttpStatusCode status, string? code) =>
        new(status)
        {
            Content = code is null
                ? new StringContent(string.Empty)
                : new StringContent($"{{\"status\":{(int)status},\"code\":\"{code}\"}}", System.Text.Encoding.UTF8, "application/problem+json"),
        };

    public static HttpResponseMessage Protobuf(V2.EdgeConfiguration configuration)
    {
        var content = new ByteArrayContent(Google.Protobuf.MessageExtensions.ToByteArray(configuration));
        content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/x-protobuf");
        var response = new HttpResponseMessage(HttpStatusCode.OK) { Content = content };
        response.Headers.ETag = new System.Net.Http.Headers.EntityTagHeaderValue($"\"{configuration.Revision}\"");
        return response;
    }
}
