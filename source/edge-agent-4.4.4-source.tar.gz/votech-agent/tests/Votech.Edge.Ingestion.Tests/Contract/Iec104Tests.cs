using System.Collections.Concurrent;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Models;
using Votech.Edge.Ingestion.Iec104;
using lib60870;
using lib60870.CS101;
using lib60870.CS104;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Tests.Contract;

/// <summary>Records readings for assertions.</summary>
internal sealed class RecordingSink : ISignalSink
{
    public ConcurrentQueue<SignalReading> Readings { get; } = new();
    public void Write(in SignalReading reading) => Readings.Enqueue(reading);
    public Task DrainAsync(CancellationToken ct = default) => Task.CompletedTask;
    public long DroppedTotal => 0;
}

/// <summary>Keeps the formatted log lines from <see cref="MinimumLevel"/> up for assertions.</summary>
internal sealed class ListLogger : ILogger
{
    public ConcurrentQueue<string> Messages { get; } = new();
    public LogLevel MinimumLevel { get; init; } = LogLevel.Trace;
    public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;
    public bool IsEnabled(LogLevel logLevel) => logLevel >= MinimumLevel;
    public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
    {
        if (IsEnabled(logLevel))
        {
            Messages.Enqueue(formatter(state, exception));
        }
    }
}

/// <summary>The system clock moved by <see cref="Shift"/>; timers stay real.</summary>
internal sealed class ShiftedTimeProvider : TimeProvider
{
    public TimeSpan Shift { get; set; }
    public override DateTimeOffset GetUtcNow() => base.GetUtcNow() + Shift;
}

public class Iec104Tests
{
    private static readonly DateTime Now = new(2026, 10, 19, 10, 0, 0, DateTimeKind.Utc);
    private static readonly Guid Gateway = Guid.NewGuid();
    private static readonly Guid InverterA = Guid.NewGuid();
    private static readonly Guid InverterB = Guid.NewGuid();
    private static readonly Guid PowerA = Guid.NewGuid();
    private static readonly Guid PowerB = Guid.NewGuid();
    private static readonly Guid Breaker = Guid.NewGuid();
    private static readonly Guid Energy = Guid.NewGuid();

    // Two inverters behind one gateway reuse IOA 1001 under their own common addresses (gap B10).
    private static V2.Connection Connection(int port = 2404)
    {
        var connection = TestConfigurations.Iec104(
            "rev",
            (Gateway, 7, [(Breaker, "IOA:2001", V2.DataType.DoublePoint)]),
            (InverterA, 11, [(PowerA, "1001", V2.DataType.Float32), (Energy, "3001", V2.DataType.Int32)]),
            (InverterB, 12, [(PowerB, "1001", V2.DataType.Float32)])
        ).Connections[0];
        connection.Iec104.Port = (uint)port;
        connection.Iec104.GiIntervalS = 60;
        return connection;
    }

    private static Iec104PointMap Map() => new(Connection(), NullLogger.Instance);

    private static ASDU Asdu(int ca, params InformationObject[] objects)
    {
        var asdu = new ASDU(new ApplicationLayerParameters(), CauseOfTransmission.SPONTANEOUS, false, false, 0, ca, false);
        foreach (var io in objects)
        {
            asdu.AddInformationObject(io);
        }

        // Round-trip through the wire format, as the library hands it to the poller.
        var bytes = asdu.AsByteArray();
        return new ASDU(new ApplicationLayerParameters(), bytes, 0, bytes.Length);
    }

    [Theory]
    [InlineData("1001", 1001)]
    [InlineData("IOA:1001", 1001)]
    [InlineData("ioa:16777215", 16777215)]
    [InlineData("0", null)]
    [InlineData("16777216", null)]
    [InlineData("40001.3", null)]
    [InlineData("28.1.42", 1835306)]
    [InlineData("1.100.200", null)]
    public void AnIoa_IsParsedFromEveryForm(string address, int? expected)
    {
        Assert.Equal(expected.HasValue, Iec104PointMap.TryParseIoa(address, out var ioa));
        if (expected.HasValue)
        {
            Assert.Equal(expected.Value, ioa);
        }
    }

    [Fact]
    public void TheSameIoa_IsRoutedPerCommonAddress()
    {
        var map = Map();

        var readings = Iec104SignalMapper.Map(
            Asdu(11, new MeasuredValueShort(1001, 50.5f, new QualityDescriptor())),
            map, Gateway, Now, out _)
            .Concat(Iec104SignalMapper.Map(Asdu(12, new MeasuredValueShort(1001, 70f, new QualityDescriptor())), map, Gateway, Now, out _))
            .ToList();

        Assert.Equal([(PowerA, 50.5), (PowerB, 70.0)], readings.Select(r => (r.SignalId, r.Value)));
        Assert.All(readings, r => Assert.Equal((Gateway, Now, false, CanonicalQualityStatus.Good), (r.EndpointId, r.Timestamp, r.DeviceTime, r.Quality)));
        Assert.Equal([7, 11, 12], map.CommonAddresses);
    }

    [Fact]
    public void AnUnknownCommonAddressOrIoa_IsCountedAndSkipped()
    {
        var readings = Iec104SignalMapper.Map(
            Asdu(99, new MeasuredValueShort(1001, 1f, new QualityDescriptor()), new MeasuredValueShort(1002, 1f, new QualityDescriptor())),
            Map(), Gateway, Now, out var unknown);

        Assert.Empty(readings);
        Assert.Equal(2, unknown);
    }

    [Theory]
    [InlineData(0x00, CanonicalQualityStatus.Good)]
    [InlineData(0x01, CanonicalQualityStatus.Uncertain)]
    [InlineData(0x10, CanonicalQualityStatus.Bad)]
    [InlineData(0x20, CanonicalQualityStatus.Bad)]
    [InlineData(0x40, CanonicalQualityStatus.Bad)]
    [InlineData(0x80, CanonicalQualityStatus.Bad)]
    [InlineData(0x81, CanonicalQualityStatus.Bad)]
    public void TheQualityDescriptor_MapsToTheCanonicalQuality_AndIsKeptRaw(byte bits, CanonicalQualityStatus expected)
    {
        var reading = Assert.Single(Iec104SignalMapper.Map(
            Asdu(11, new MeasuredValueShort(1001, 1f, new QualityDescriptor { EncodedValue = bits })),
            Map(), Gateway, Now, out _));

        Assert.Equal((expected, (uint)bits), (reading.Quality, reading.RawQuality));
    }

    [Fact]
    public void ADeviceTime_IsUsedUnlessItsInvalidBitIsSetOrItLiesAhead()
    {
        var device = Now.AddSeconds(-3);
        var valid = new CP56Time2a(device);
        var invalid = new CP56Time2a(device) { Invalid = true };
        var ahead = new CP56Time2a(Now.AddHours(3));
        var map = Map();

        Reading(valid, out var first);
        Reading(invalid, out var second);
        Reading(ahead, out var third);

        Assert.Equal((device, true), (first.Timestamp, first.DeviceTime));
        Assert.Equal((Now, false), (second.Timestamp, second.DeviceTime));
        Assert.Equal((Now, false), (third.Timestamp, third.DeviceTime));

        void Reading(CP56Time2a time, out SignalReading reading) =>
            reading = Assert.Single(Iec104SignalMapper.Map(
                Asdu(11, new MeasuredValueShortWithCP56Time2a(1001, 1f, new QualityDescriptor(), time)),
                map, Gateway, Now, out _));
    }

    [Fact]
    public void EveryReading_SaysWhereItsTimeComesFrom_AndKeepsADeviceTimeItDidNotUse()
    {
        var map = Map();
        var behind = Now.AddSeconds(-3);
        var stale = new DateTime(2021, 2, 11, 21, 39, 0, DateTimeKind.Utc);

        var device = Single(new MeasuredValueShortWithCP56Time2a(1001, 1f, new QualityDescriptor(), new CP56Time2a(behind)));
        var untimed = Single(new MeasuredValueShort(1001, 1f, new QualityDescriptor()));
        var skewed = Single(new MeasuredValueShortWithCP56Time2a(1001, 1f, new QualityDescriptor(), new CP56Time2a(stale)));
        var invalid = Single(new MeasuredValueShortWithCP56Time2a(1001, 1f, new QualityDescriptor(), new CP56Time2a(behind) { Invalid = true }));

        Assert.Equal((behind, SampleTimeSource.Device, 0L, 3_000L), (device.Timestamp, device.TimeSource, device.DeviceTimestampMs, device.ReceiveLagMs));
        Assert.Equal((Now, SampleTimeSource.ReceiptUntimed, 0L, 0L), (untimed.Timestamp, untimed.TimeSource, untimed.DeviceTimestampMs, untimed.ReceiveLagMs));
        Assert.Equal((Now, SampleTimeSource.ReceiptClockSkew, Ms(stale), 0L), (skewed.Timestamp, skewed.TimeSource, skewed.DeviceTimestampMs, skewed.ReceiveLagMs));
        Assert.Equal((Now, SampleTimeSource.ReceiptTimeInvalid, Ms(behind), 0L), (invalid.Timestamp, invalid.TimeSource, invalid.DeviceTimestampMs, invalid.ReceiveLagMs));
        Assert.True(device.DeviceTime);
        Assert.False(skewed.DeviceTime);

        SignalReading Single(InformationObject io) => Assert.Single(Iec104SignalMapper.Map(Asdu(11, io), map, Gateway, Now, out _));
        static long Ms(DateTime time) => new DateTimeOffset(time).ToUnixTimeMilliseconds();
    }

    [Fact]
    public void ADeviceTimeOlderThanTheMaximumAge_IsReplacedByTheReceiptTime_AndTheClockIsRecorded()
    {
        var map = Map();
        var stale = new DateTime(2021, 2, 11, 21, 39, 0, DateTimeKind.Utc); // a field RTU clock seen on 2026-10-21
        var clock = new DeviceClock();

        var old = Assert.Single(Iec104SignalMapper.Map(Timed(stale), map, Gateway, Now, out _, clock: clock));
        var recent = Assert.Single(Iec104SignalMapper.Map(Timed(Now.AddHours(-23)), map, Gateway, Now, out _, clock: clock));
        var afterAnOutage = Assert.Single(Iec104SignalMapper.Map(Timed(stale), map, Gateway, Now, out _, policy: Iec104SignalMapper.TimePolicy.Default with { MaxDeviceAge = TimeSpan.FromDays(3650) }));

        Assert.Equal((Now, false), (old.Timestamp, old.DeviceTime));
        Assert.Equal((Now.AddHours(-23), true), (recent.Timestamp, recent.DeviceTime));
        Assert.Equal((stale, true), (afterAnOutage.Timestamp, afterAnOutage.DeviceTime));
        Assert.Equal(((DateTime?)Now.AddHours(-23), 1, 1), clock.Take());

        ASDU Timed(DateTime device) => Asdu(11, new MeasuredValueShortWithCP56Time2a(1001, 1f, new QualityDescriptor(), new CP56Time2a(device)));
    }

    [Fact]
    public void TheClockOffset_ComesFromTheNewestDeviceTimeOfAWindow_AndABacklogDoesNotMoveIt()
    {
        var clock = new DeviceClock();
        Assert.Null(clock.Offset);

        // First window: a live value 2 s behind, and an event the RTU buffered 40 minutes ago.
        clock.Observe(Now.AddSeconds(-2), Now, true);
        clock.Observe(Now.AddMinutes(-40), Now.AddSeconds(1), true);
        Assert.Null(clock.Offset);

        // The next window closes the first: its newest device time gives the offset.
        clock.Observe(Now.AddSeconds(61), Now.AddSeconds(62), true);
        Assert.Equal(TimeSpan.FromSeconds(-2), clock.Offset);

        // A window that holds only a backlog after a link loss is skipped.
        clock.Observe(Now.AddMinutes(-10), Now.AddSeconds(130), true);
        clock.Observe(Now.AddSeconds(200), Now.AddSeconds(200), true);
        Assert.Equal(TimeSpan.FromSeconds(-1), clock.Offset);
        clock.Observe(Now.AddSeconds(300), Now.AddSeconds(300), true);
        Assert.Equal(TimeSpan.Zero, clock.Offset);
    }

    [Fact]
    public void AClockSetBack_IsTakenAfterTenWindowsThatAreNotNewer()
    {
        var clock = new DeviceClock();
        var ahead = TimeSpan.FromHours(3); // an RTU on local time, then corrected to UTC
        clock.Observe(Now + ahead, Now, true);
        clock.Observe(Now.AddMinutes(1) + ahead, Now.AddMinutes(1), true);
        Assert.Equal(ahead, clock.Offset);

        for (var minute = 2; minute <= 12; minute++)
        {
            clock.Observe(Now.AddMinutes(minute), Now.AddMinutes(minute), true);
        }

        Assert.Equal(TimeSpan.Zero, clock.Offset);
    }

    [Fact]
    public void AClockSetByTheAgent_IsMeasuredAgainInTheNextWindow()
    {
        var clock = new DeviceClock();
        var ahead = TimeSpan.FromMinutes(5); // an RTU 5 min ahead, then set by a confirmed clock sync
        clock.Observe(Now + ahead, Now, true);
        clock.Observe(Now.AddMinutes(1) + ahead, Now.AddMinutes(1), true);
        Assert.Equal(ahead, clock.Offset);

        clock.Restart();
        Assert.Null(clock.Offset);

        clock.Observe(Now.AddMinutes(2).AddMilliseconds(-50), Now.AddMinutes(2), true);
        clock.Observe(Now.AddMinutes(3), Now.AddMinutes(3), true);
        Assert.Equal(TimeSpan.FromMilliseconds(-50), clock.Offset);
    }

    [Fact]
    public void Enforce_StampsAConnectionWhoseClockIsOff_OnReceipt_AndKeepsTheBufferedEventsOfOneThatIsNot()
    {
        var map = Map();
        var enforce = Iec104SignalMapper.TimePolicy.Default with { Mode = Iec104ClockPolicy.Enforce };
        var behind = new DeviceClock();
        var inStep = new DeviceClock();

        // Before the first offset, Enforce judges like Observe: two hours behind is within the 24 h window.
        Assert.Equal(SampleTimeSource.Device, Read(behind, Now.AddHours(-2), Now, enforce).TimeSource);
        Read(behind, Now.AddHours(-2).AddSeconds(61), Now.AddSeconds(61), enforce);
        var skewed = Read(behind, Now.AddHours(-2).AddSeconds(62), Now.AddSeconds(62), enforce);
        var observed = Read(behind, Now.AddHours(-2).AddSeconds(63), Now.AddSeconds(63), Iec104SignalMapper.TimePolicy.Default);

        Read(inStep, Now.AddSeconds(-1), Now, enforce);
        Read(inStep, Now.AddSeconds(60), Now.AddSeconds(61), enforce);
        var buffered = Read(inStep, Now.AddMinutes(-30), Now.AddSeconds(62), enforce);
        var ahead = Read(inStep, Now.AddSeconds(62 + 90), Now.AddSeconds(62), enforce);

        Assert.Equal((Now.AddSeconds(62), SampleTimeSource.ReceiptClockSkew), (skewed.Timestamp, skewed.TimeSource));
        Assert.Equal(new DateTimeOffset(Now.AddHours(-2).AddSeconds(62)).ToUnixTimeMilliseconds(), skewed.DeviceTimestampMs);
        Assert.Equal(SampleTimeSource.Device, observed.TimeSource);
        Assert.Equal((Now.AddMinutes(-30), SampleTimeSource.Device), (buffered.Timestamp, buffered.TimeSource));
        Assert.Equal(SampleTimeSource.ReceiptClockSkew, ahead.TimeSource);
        Assert.Equal((3, 1, 1), inStep.TakeHour()); // used (the buffered event late), stamped on receipt

        SignalReading Read(DeviceClock clock, DateTime device, DateTime receivedAt, Iec104SignalMapper.TimePolicy policy) =>
            Assert.Single(Iec104SignalMapper.Map(
                Asdu(11, new MeasuredValueShortWithCP56Time2a(1001, 1f, new QualityDescriptor(), new CP56Time2a(device))),
                map, Gateway, receivedAt, out _, policy, clock: clock));
    }

    [Fact]
    public void AFrame_IsDecodedForTheLog()
    {
        // Frames captured from two field RTUs (2026-10-21).
        var map = new Iec104PointMap(TestConfigurations.Iec104("rev", (Gateway, 7, [(PowerA, "27.13.13", V2.DataType.Float32)])).Connections[0], NullLogger.Instance);

        Assert.Equal(
            "I(ns=231 nr=2) M_ME_TF_1 spont CA 7, 1 object: 1772813 (27.13.13) = 993.8 good @2021-02-11 22:58:53.660 → 27.13.13",
            Text("6819CE0104002401030107000D0D1B33737844009CD13A168B0215"));
        Assert.Equal(
            "I(ns=17 nr=1) C_IC_NA_1 unknown common address (COT 46) NEGATIVE CA 1, 1 object: 0 (0.0.0) QOI 20 (station)",
            Text("680E2200020064016E00010000000014"));
        Assert.Equal("U TESTFR act (link test)", Text("680443000000"));
        Assert.Equal("S ack nr=113", Text("68040100E200"));

        string Text(string hex)
        {
            var bytes = Convert.FromHexString(hex);
            return Iec104FrameText.Describe(bytes, bytes.Length, new ApplicationLayerParameters(), map);
        }
    }

    [Theory]
    [InlineData(12, "12 s")]
    [InlineData(14 * 60, "14 min")]
    [InlineData(3 * 3600, "3.0 h")]
    [InlineData(3 * 86400 + 4 * 3600, "3.2 days")]
    [InlineData(48607.3 * 3600, "5.5 years")] // the TM4 RTU clock, 2026-10-21
    public void ALongTime_IsSaidInDaysOrYears(double seconds, string expected) =>
        Assert.Equal(expected, Iec104ConnectionPoller.Describe(TimeSpan.FromSeconds(seconds)));

    [Fact]
    public async Task AConnectionWithoutPoints_IsWarnedAbout()
    {
        var logger = new ListLogger();
        await using var poller = new Iec104ConnectionPoller(TestConfigurations.Iec104("rev", (Gateway, 7, [])).Connections[0], new RecordingSink(), logger);

        Assert.Contains(logger.Messages, m => m.StartsWith("[IEC104-CONFIG] Connection RTU has no point with an IEC 104 address"));
    }

    [Fact]
    public void StatesStepsAndBitstrings_AreRead()
    {
        var map = Map();
        Assert.Equal(2, Assert.Single(Iec104SignalMapper.Map(Asdu(7, new DoublePointInformation(2001, DoublePointValue.ON, new QualityDescriptor())), map, Gateway, Now, out _)).Value);
        Assert.Equal(-5, Assert.Single(Iec104SignalMapper.Map(Asdu(11, new StepPositionInformation(3001, -5, false, new QualityDescriptor())), map, Gateway, Now, out _)).Value);
        Assert.Equal(0xF0F0, Assert.Single(Iec104SignalMapper.Map(Asdu(11, new Bitstring32(3001, 0xF0F0, new QualityDescriptor())), map, Gateway, Now, out _)).Value);
    }

    [Fact]
    public void AnIntegratedTotal_CarriesItsCounterFlags()
    {
        var map = Map();
        var good = new BinaryCounterReading { Value = 123456, SequenceNumber = 3 };
        var carried = new BinaryCounterReading { Value = 5, Carry = true };
        var invalid = new BinaryCounterReading { Value = 5, Invalid = true };

        var readings = Iec104SignalMapper.Map(
            Asdu(11, new IntegratedTotalsWithCP56Time2a(3001, good, new CP56Time2a(Now.AddSeconds(-1)))), map, Gateway, Now, out _)
            .Concat(Iec104SignalMapper.Map(Asdu(11, new IntegratedTotals(3001, carried)), map, Gateway, Now, out _))
            .Concat(Iec104SignalMapper.Map(Asdu(11, new IntegratedTotals(3001, invalid)), map, Gateway, Now, out _))
            .ToList();

        Assert.Equal(
            [(Energy, 123456.0, CanonicalQualityStatus.Good, 3u, true), (Energy, 5.0, CanonicalQualityStatus.Uncertain, 0x20u, false), (Energy, 5.0, CanonicalQualityStatus.Bad, 0x80u, false)],
            readings.Select(r => (r.SignalId, r.Value, r.Quality, r.RawQuality, r.DeviceTime)));
    }

    [Fact]
    public async Task APoller_InterrogatesEachStation_ReadsItsValues_AndMarksThemOfflineWhenTheLinkDrops()
    {
        var port = FreePort();
        var interrogated = new ConcurrentBag<int>();
        var server = new Server();
        server.SetLocalAddress("127.0.0.1");
        server.SetLocalPort(port);
        server.SetInterrogationHandler((_, connection, asdu, _) =>
        {
            interrogated.Add(asdu.Ca);
            connection.SendACT_CON(asdu, false);
            var data = new ASDU(connection.GetApplicationLayerParameters(), CauseOfTransmission.INTERROGATED_BY_STATION, false, false, 0, asdu.Ca, false);
            data.AddInformationObject(new MeasuredValueShort(1001, asdu.Ca * 10f, new QualityDescriptor()));
            connection.SendASDU(data);
            connection.SendACT_TERM(asdu);
            return true;
        }, null);
        server.Start();

        var sink = new RecordingSink();
        var logger = new ListLogger();
        await using var poller = new Iec104ConnectionPoller(Connection(port), sink, logger);
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var run = poller.RunAsync(cts.Token);
        try
        {
            await WaitUntil(() =>
                poller.IsConnected
                && interrogated.Distinct().Count() == 3
                && sink.Readings.Any(r => r.SignalId == PowerA)
                && sink.Readings.Any(r => r.SignalId == PowerB)
                && logger.Messages.Count(m => m.StartsWith("[IEC104-GI]") && m.Contains(" done in ")) == 3);

            Assert.Equal([7, 11, 12], interrogated.Order());
            var done = logger.Messages.Where(m => m.Contains(" done in ")).ToList();
            Assert.Contains(done, m => m.Contains("common address 11 done") && m.Contains("1 objects, 1 read, 0 not configured; 1 configured point(s) did not answer (e.g. 3001 3001 (0.11.185))"));
            Assert.Contains(done, m => m.Contains("common address 7 done") && m.Contains("1 not configured (e.g. 1001 (0.3.233)); 1 configured point(s) did not answer (e.g. IOA:2001 2001 (0.7.209))"));
            Assert.Equal([(PowerA, 110.0), (PowerB, 120.0)], sink.Readings.Select(r => (r.SignalId, r.Value)).OrderBy(r => r.Value));
            Assert.All(poller.Health, h => Assert.True(h.Connected));
            Assert.Equal([Gateway, InverterA, InverterB], poller.Health.Select(h => h.EndpointId));

            server.Stop();
            await WaitUntil(() => sink.Readings.Count(r => r.Quality == CanonicalQualityStatus.Offline) == 2);

            Assert.False(poller.IsConnected);
            Assert.Equal(
                [(PowerA, 110.0), (PowerB, 120.0)],
                sink.Readings.Where(r => r.Quality == CanonicalQualityStatus.Offline).Select(r => (r.SignalId, r.Value)).OrderBy(r => r.Value));
            Assert.All(sink.Readings.Where(r => r.Quality == CanonicalQualityStatus.Offline), offline =>
            {
                Assert.Equal(SampleTimeSource.ReceiptUntimed, offline.TimeSource);
                Assert.True(offline.Timestamp > sink.Readings.First(r => r.SignalId == offline.SignalId).Timestamp);
            });
            Assert.All(poller.Health, h => Assert.False(h.Connected));
        }
        finally
        {
            await cts.CancelAsync();
            await Task.WhenAny(run, Task.Delay(5000));
            server.Stop();
        }
    }

    [Fact]
    public void AnOfflineSample_IsStampedOnTheClockItsValueCameFrom_AfterThatValue()
    {
        var behind = TimeSpan.FromSeconds(-50);
        var deviceValue = new Iec104ConnectionPoller.LastSample(1, Now.AddSeconds(-55), true);
        var receiptValue = new Iec104ConnectionPoller.LastSample(1, Now.AddSeconds(-10), false);

        // An RTU 50 s behind: its next value (at its clock) must not be older than the Offline sample.
        Assert.Equal(Now + behind, Iec104ConnectionPoller.OfflineTime(deviceValue, Now, behind, null));
        // No offset yet: the newest device time, and never before the value itself.
        Assert.Equal(Now.AddSeconds(-52), Iec104ConnectionPoller.OfflineTime(deviceValue, Now, null, Now.AddSeconds(-52)));
        Assert.Equal(Now.AddSeconds(-55).AddMilliseconds(1), Iec104ConnectionPoller.OfflineTime(deviceValue, Now, null, null));
        // A receipt time: the agent's time; a value stamped in the same millisecond still comes first.
        Assert.Equal(Now, Iec104ConnectionPoller.OfflineTime(receiptValue, Now, behind, null));
        Assert.Equal(Now.AddMilliseconds(1), Iec104ConnectionPoller.OfflineTime(receiptValue with { Timestamp = Now }, Now, null, null));
    }

    [Fact]
    public void AnOfflineSample_OfAnRtuClockFarAhead_IsStampedAtTheAgentTime_SoTheNextValuesAreNotHidden()
    {
        // Sertavul RES, 2026-11-05: the RTU clock ran about 6 h ahead; Offline samples were stamped 18:49 UTC at 13:04 UTC
        // and hid every later value (stamped on receipt) until the evening.
        var ahead = TimeSpan.FromHours(6);
        var deviceValue = new Iec104ConnectionPoller.LastSample(0, Now.AddMinutes(-10), true);

        Assert.Equal(Now, Iec104ConnectionPoller.OfflineTime(deviceValue, Now, ahead, null));
        // No offset yet, only a newest device time far ahead: the same.
        Assert.Equal(Now, Iec104ConnectionPoller.OfflineTime(deviceValue, Now, null, Now + ahead));
        // Within the tolerance the RTU's times are used, so its clock still stamps the Offline sample.
        var slightlyAhead = TimeSpan.FromMinutes(2);
        Assert.Equal(Now + slightlyAhead, Iec104ConnectionPoller.OfflineTime(deviceValue, Now, slightlyAhead, null));
        // With Enforce, the connection's own tolerance is the limit.
        Assert.Equal(Now, Iec104ConnectionPoller.OfflineTime(deviceValue, Now, slightlyAhead, null, TimeSpan.FromSeconds(30)));
        // Never before the value itself.
        var lastAtNow = deviceValue with { Timestamp = Now };
        Assert.Equal(Now.AddMilliseconds(1), Iec104ConnectionPoller.OfflineTime(lastAtNow, Now, ahead, null));
    }

    [Fact]
    public void TheReconnectDelay_DoublesToItsCap_AndStartsOverOnlyAfterAStableLink()
    {
        int? delay = null;
        var delays = new List<int>();
        for (var i = 0; i < 6; i++)
        {
            delay = Iec104ConnectionPoller.NextDelayMs(delay, null);
            delays.Add(delay.Value);
        }

        Assert.Equal([5_000, 10_000, 20_000, 40_000, 60_000, 60_000], delays);
        Assert.Equal(20_000, Iec104ConnectionPoller.NextDelayMs(10_000, TimeSpan.FromSeconds(59)));
        Assert.Equal(5_000, Iec104ConnectionPoller.NextDelayMs(60_000, TimeSpan.FromMinutes(1)));
    }

    [Theory]
    [InlineData(0.0, 4_000)]
    [InlineData(0.5, 5_000)]
    [InlineData(1.0, 6_000)]
    public void TheJitter_StaysWithinTwentyPercent(double unit, double expectedMs)
    {
        Assert.Equal(expectedMs, Math.Round(Iec104ConnectionPoller.WithJitter(5_000, unit).TotalMilliseconds));
    }

    [Fact]
    public async Task AFailedAttemptAfterAStableLinkDropped_WaitsLonger_NotFiveSecondsAgain()
    {
        // 2.1.0 compared the last link-up with now, so once a link had been up a minute every failure waited 5 s.
        var port = FreePort();
        var server = new Server();
        server.SetLocalAddress("127.0.0.1");
        server.SetLocalPort(port);
        server.Start();
        var time = new ShiftedTimeProvider();
        var logger = new ListLogger();
        await using var poller = new Iec104ConnectionPoller(Connection(port), new RecordingSink(), logger, time);
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var run = poller.RunAsync(cts.Token);
        try
        {
            await WaitUntil(() => poller.IsConnected);
            time.Shift = TimeSpan.FromMinutes(2);
            server.Stop();

            // The drop of the stable link waits 5 s; the refused attempt after it waits 10 s.
            await WaitUntil(() => NextAttemptDelays(logger).Count == 2);
            var delays = NextAttemptDelays(logger);
            Assert.InRange(delays[0], 4, 6);
            Assert.InRange(delays[1], 8, 12);
            Assert.Contains(logger.Messages, m => m.Contains("(first attempt;"));
            Assert.Contains(logger.Messages, m => m.Contains("confirmed STARTDT on attempt 1."));
            Assert.Contains(logger.Messages, m => m.Contains("(attempt 1 after UNREACHABLE_PHYSICAL_DEVICE;"));
        }
        finally
        {
            await cts.CancelAsync();
            await Task.WhenAny(run, Task.Delay(5000));
            server.Stop();
        }
    }

    private static List<int> NextAttemptDelays(ListLogger logger) =>
        logger.Messages.Select(m => Regex.Match(m, @"next attempt in (\d+) s\.")).Where(m => m.Success).Select(m => int.Parse(m.Groups[1].Value)).ToList();

    [Fact]
    public void ANewPoller_ReportsConnecting_NotUnreachable()
    {
        var poller = new Iec104ConnectionPoller(Connection(), new RecordingSink(), NullLogger.Instance);

        Assert.All(poller.Health, h => Assert.Equal((false, "CONNECTING", (string?)null), (h.Connected, h.ReasonCode, h.Error)));
    }

    [Fact]
    public async Task AStationThatAcceptsTcpButNeverConfirmsStartDt_IsReportedAsSuch_AndTheAttemptsSocketIsClosed()
    {
        // Accepts and stays silent, like an RTU that does not serve this master.
        using var station = new RawStation(answerTestFr: false);
        var connection = Connection(station.Port);
        connection.Iec104.T1S = 1;
        connection.Iec104.T3S = 2;
        await using var poller = new Iec104ConnectionPoller(connection, new RecordingSink(), NullLogger.Instance);
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var run = poller.RunAsync(cts.Token);
        try
        {
            await WaitUntil(() => poller.Health[0].ReasonCode == "STARTDT_NOT_CONFIRMED");

            var root = poller.Health[0];
            Assert.False(root.Connected);
            Assert.Contains($"127.0.0.1:{station.Port} accepted the TCP connection but answered neither STARTDT nor the link test (TESTFR)", root.Error);
            Assert.All(poller.Health, h => Assert.Equal("STARTDT_NOT_CONFIRMED", h.ReasonCode));

            // The library starts data transfer by itself, and tests the link at t3 as agent 1.x did.
            Assert.Contains(RawStation.StartDtAct, station.Received);
            Assert.Contains(RawStation.TestFrAct, station.Received);

            // The station sees the end of the attempt (FIN or RST) before the next one, so its session slot is free.
            await WaitUntil(() => station.ClosedConnections >= 1);
        }
        finally
        {
            await cts.CancelAsync();
            await Task.WhenAny(run, Task.Delay(5000));
        }
    }

    [Fact]
    public async Task AStationThatAnswersTheLinkTestButNotStartDt_IsReportedAsServingAnotherMaster()
    {
        using var station = new RawStation(answerTestFr: true);
        var connection = Connection(station.Port);
        connection.Iec104.T1S = 1;
        connection.Iec104.T3S = 1;
        await using var poller = new Iec104ConnectionPoller(connection, new RecordingSink(), NullLogger.Instance);
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var run = poller.RunAsync(cts.Token);
        try
        {
            await WaitUntil(() => poller.Health[0].ReasonCode == "STARTDT_NOT_CONFIRMED");

            Assert.Contains(
                $"127.0.0.1:{station.Port} accepted the TCP connection and answers the link test (TESTFR), but did not confirm STARTDT within 4 s",
                poller.Health[0].Error);
        }
        finally
        {
            await cts.CancelAsync();
            await Task.WhenAny(run, Task.Delay(5000));
        }
    }

    [Theory]
    [InlineData(V2.ClockSyncMode.Unspecified, 0u, "", 0)]
    [InlineData(V2.ClockSyncMode.Unspecified, 60u, "", 0)]
    [InlineData(V2.ClockSyncMode.Off, 0u, "", 0)]
    [InlineData(V2.ClockSyncMode.OnConnect, 0u, "", 3)]
    [InlineData(V2.ClockSyncMode.Periodic, 0u, "", 3)]
    [InlineData(V2.ClockSyncMode.OnConnect, 0u, "Europe/Istanbul", 3)]
    [InlineData(V2.ClockSyncMode.OnConnect, 0u, "Mars/Olympus", 0)]
    public async Task TheClockIsSetAfterConnect_OnlyWhenTheConnectionAsks(V2.ClockSyncMode mode, uint intervalS, string timeZone, int expectedSyncs)
    {
        var port = FreePort();
        var syncs = new ConcurrentBag<int>();
        var interrogated = new ConcurrentBag<int>();
        var server = new Server();
        server.SetLocalAddress("127.0.0.1");
        server.SetLocalPort(port);
        server.SetClockSynchronizationHandler((_, _, asdu, _) =>
        {
            syncs.Add(asdu.Ca);
            return true;
        }, null);
        server.SetInterrogationHandler((_, connection, asdu, _) =>
        {
            interrogated.Add(asdu.Ca);
            connection.SendACT_CON(asdu, false);
            connection.SendACT_TERM(asdu);
            return true;
        }, null);
        server.Start();

        var connection = Connection(port);
        connection.Iec104.ClockSync = mode;
        connection.Iec104.ClockSyncIntervalS = intervalS;
        connection.Iec104.TimeZone = timeZone;
        await using var poller = new Iec104ConnectionPoller(connection, new RecordingSink(), NullLogger.Instance);
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var run = poller.RunAsync(cts.Token);
        try
        {
            await WaitUntil(() => interrogated.Distinct().Count() == 3 && syncs.Count >= expectedSyncs);
            await Task.Delay(500);

            Assert.Equal(expectedSyncs, syncs.Count);
        }
        finally
        {
            await cts.CancelAsync();
            await Task.WhenAny(run, Task.Delay(5000));
            server.Stop();
        }
    }

    [Theory]
    [InlineData(V2.ClockSyncMode.Unspecified, 0u, "", false, null)]
    [InlineData(V2.ClockSyncMode.Unspecified, 600u, "", false, 600)]
    [InlineData(V2.ClockSyncMode.Off, 600u, "", false, null)]
    [InlineData(V2.ClockSyncMode.OnConnect, 600u, "", true, null)]
    [InlineData(V2.ClockSyncMode.Periodic, 0u, "", true, 3600)]
    [InlineData(V2.ClockSyncMode.Periodic, 600u, "", true, 600)]
    [InlineData(V2.ClockSyncMode.Periodic, 600u, "Europe/Istanbul", true, 600)]
    public void TheClockSyncPlan_FollowsTheConnectionsMode(V2.ClockSyncMode mode, uint intervalS, string timeZone, bool onConnect, int? everySeconds)
    {
        var settings = new V2.Iec104Settings { ClockSync = mode, ClockSyncIntervalS = intervalS, TimeZone = timeZone };

        var (connect, every) = Iec104ConnectionPoller.ClockSyncPlan(settings);

        Assert.Equal((onConnect, everySeconds), (connect, every.HasValue ? (int?)every.Value.TotalSeconds : null));
    }

    [Theory]
    [InlineData("accept", "confirmed the clock sync")]
    [InlineData("refuse", "refused the clock sync")]
    [InlineData("unknown", "as unknown cause (COT 45); its clock is not set")]
    public async Task TheStationsAnswerToAClockSync_IsLogged(string answer, string expected)
    {
        // "unknown": the handler declines the command, so the library mirrors it with COT 45, as a station without
        // clock sync does.
        var accept = answer == "accept";
        var port = FreePort();
        var server = new Server();
        server.SetLocalAddress("127.0.0.1");
        server.SetLocalPort(port);
        server.SetClockSynchronizationHandler((_, connection, asdu, _) =>
        {
            if (answer == "refuse")
            {
                connection.SendACT_CON(asdu, true);
            }

            return accept;
        }, null);
        server.SetInterrogationHandler((_, connection, asdu, _) =>
        {
            connection.SendACT_CON(asdu, false);
            connection.SendACT_TERM(asdu);
            return true;
        }, null);
        server.Start();

        var connection = Connection(port);
        connection.Iec104.ClockSync = V2.ClockSyncMode.OnConnect;
        var logger = new ListLogger { MinimumLevel = LogLevel.Information };
        await using var poller = new Iec104ConnectionPoller(connection, new RecordingSink(), logger);
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var run = poller.RunAsync(cts.Token);
        try
        {
            await WaitUntil(() => logger.Messages.Count(m => m.Contains(expected)) == 3);

            Assert.DoesNotContain(logger.Messages, m => !m.Contains(expected) && (m.Contains("the clock sync (") || m.Contains("did not confirm the clock sync")));
        }
        finally
        {
            await cts.CancelAsync();
            await Task.WhenAny(run, Task.Delay(5000));
            server.Stop();
        }
    }

    [Fact]
    public void AStationZoneUnknownHere_NeverHasItsClockSet()
    {
        var settings = new V2.Iec104Settings { ClockSync = V2.ClockSyncMode.Periodic, ClockSyncIntervalS = 600, TimeZone = "Mars/Olympus" };

        Assert.False(StationTime.TryResolve(settings.TimeZone, out _));
        Assert.Equal((false, (TimeSpan?)null), Iec104ConnectionPoller.ClockSyncPlan(settings, zoneKnown: false));
    }

    [Theory]
    [InlineData(LogLevel.Information, false)]
    [InlineData(LogLevel.Debug, true)]
    public async Task RawFrames_AreLoggedAtDebug_AndOnlyWhenDebugIsOn(LogLevel level, bool logged)
    {
        var logger = new ListLogger { MinimumLevel = level };
        await RunAgainst(
            Connection(),
            logger,
            (_, link, asdu) =>
            {
                link.SendACT_CON(asdu, false);
                link.SendACT_TERM(asdu);
            },
            async poller =>
            {
                await WaitUntil(() => logger.Messages.Count(m => m.StartsWith("[IEC104-GI]") && m.Contains(" done in ")) == 3);
                Assert.Equal(logged, logger.Messages.Any(m => m.StartsWith("[IEC104-FRAME]")));
            },
            new Iec104AgentOptions { LogRawFrames = true });
    }

    [Fact]
    public async Task AStationThatRefusesTcp_IsReportedUnreachable()
    {
        var port = FreePort();
        await using var poller = new Iec104ConnectionPoller(Connection(port), new RecordingSink(), NullLogger.Instance);
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var run = poller.RunAsync(cts.Token);
        try
        {
            await WaitUntil(() => poller.Health[0].ReasonCode == "UNREACHABLE_PHYSICAL_DEVICE");

            Assert.StartsWith($"TCP connection to 127.0.0.1:{port} failed", poller.Health[0].Error);
        }
        finally
        {
            await cts.CancelAsync();
            await Task.WhenAny(run, Task.Delay(5000));
        }
    }

    [Fact]
    public async Task AnRtuThatRefusesTheCommonAddress_IsAMismatch_NamingTheAddressItSends()
    {
        // A case seen in the field: the agent interrogates common address 1, the RTU answers COT 46 and sends on 7.
        var rtu = Guid.NewGuid();
        var connection = TestConfigurations.Iec104("rev", (rtu, 1, [(PowerA, "1001", V2.DataType.Float32)])).Connections[0];
        var logger = new ListLogger();
        await RunAgainst(connection, logger, (server, link, asdu) =>
        {
            var data = new ASDU(link.GetApplicationLayerParameters(), CauseOfTransmission.SPONTANEOUS, false, false, 0, 7, false);
            data.AddInformationObject(new MeasuredValueShort(1001, 1f, new QualityDescriptor()));
            link.SendASDU(data);
            asdu.Cot = CauseOfTransmission.UNKNOWN_COMMON_ADDRESS_OF_ASDU;
            asdu.IsNegative = true;
            link.SendASDU(asdu);
        }, async poller =>
        {
            await WaitUntil(() => poller.IsConnected && poller.Health[0].ReasonCode == "CONFIGURATION_MISMATCH");

            var health = Assert.Single(poller.Health);
            Assert.False(health.Connected);
            Assert.Equal(
                "The RTU refused the general interrogation of common address 1: unknown common address (COT 46). The RTU sends common address 7: set it as the station's common address.",
                health.Error);
            Assert.Contains(logger.Messages, m => m.StartsWith("[IEC104-CA] Connection RTU: the RTU refused the general interrogation of common address 1: unknown common address (COT 46)."));
            Assert.Contains(logger.Messages, m => m.StartsWith("[IEC104-CONFIG] Connection RTU receives common address 7, which is no configured station (1)"));
        });
    }

    [Fact]
    public async Task APointWhoseIoaArrivesWithReversedOctets_IsNamed()
    {
        var connection = TestConfigurations.Iec104("rev", (InverterA, 11, [(PowerA, "28.1.42", V2.DataType.Float32)])).Connections[0];
        var logger = new ListLogger();
        await RunAgainst(connection, logger, (server, link, asdu) =>
        {
            link.SendACT_CON(asdu, false);
            var data = new ASDU(link.GetApplicationLayerParameters(), CauseOfTransmission.INTERROGATED_BY_STATION, false, false, 0, 11, false);
            data.AddInformationObject(new MeasuredValueShort(Iec104Address.Reverse(1835306), 5f, new QualityDescriptor()));
            link.SendASDU(data);
            link.SendACT_TERM(asdu);
        }, async poller =>
        {
            await WaitUntil(() => logger.Messages.Any(m => m.Contains("octets reversed")));

            Assert.Contains(logger.Messages, m => m.Contains("1 point(s) of common address 11 never arrive, but the IOA with their octets reversed does: 28.1.42 1835306 (28.1.42) arrives as 2752796 (42.1.28)."));
            Assert.Contains(logger.Messages, m => m.Contains("common address 11 done") && m.Contains("1 not configured (e.g. 2752796 (42.1.28)); 1 configured point(s) did not answer (e.g. 28.1.42 1835306 (28.1.42))"));
        });
    }

    /// <summary>Runs a poller for <paramref name="connection"/> against a loopback lib60870 server whose interrogation handler is <paramref name="onInterrogation"/>.</summary>
    private static async Task RunAgainst(V2.Connection connection, ILogger logger, Action<Server, IMasterConnection, ASDU> onInterrogation, Func<Iec104ConnectionPoller, Task> assert, Iec104AgentOptions? options = null)
    {
        var port = FreePort();
        var server = new Server();
        server.SetLocalAddress("127.0.0.1");
        server.SetLocalPort(port);
        server.SetInterrogationHandler((_, link, asdu, _) =>
        {
            onInterrogation(server, link, asdu);
            return true;
        }, null);
        server.Start();
        connection.Iec104.Port = (uint)port;
        await using var poller = new Iec104ConnectionPoller(connection, new RecordingSink(), logger, agentOptions: options);
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        var run = poller.RunAsync(cts.Token);
        try
        {
            await assert(poller);
        }
        finally
        {
            await cts.CancelAsync();
            await Task.WhenAny(run, Task.Delay(5000));
            server.Stop();
        }
    }

    private static int FreePort()
    {
        var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        var port = ((IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop();
        return port;
    }

    private static async Task WaitUntil(Func<bool> condition)
    {
        var deadline = DateTime.UtcNow.AddSeconds(15);
        while (!condition())
        {
            Assert.True(DateTime.UtcNow < deadline, "timed out waiting for the poller");
            await Task.Delay(50);
        }
    }
}

/// <summary>
/// A loopback TCP station that records every APDU it receives (as hex) and never confirms STARTDT; it answers the link
/// test (TESTFR act) when asked to.
/// </summary>
internal sealed class RawStation : IDisposable
{
    public const string StartDtAct = "680407000000";
    public const string TestFrAct = "680443000000";
    private static readonly byte[] TestFrCon = [0x68, 0x04, 0x83, 0x00, 0x00, 0x00];

    private readonly TcpListener _listener = new(IPAddress.Loopback, 0);
    private readonly List<TcpClient> _clients = [];
    private readonly bool _answerTestFr;

    public RawStation(bool answerTestFr)
    {
        _answerTestFr = answerTestFr;
        _listener.Start();
        Port = ((IPEndPoint)_listener.LocalEndpoint).Port;
        _ = Task.Run(AcceptAsync);
    }

    public int Port { get; }

    public ConcurrentBag<string> Received { get; } = [];

    /// <summary>Connections the client ended (FIN or RST).</summary>
    public int ClosedConnections => Volatile.Read(ref _closed);

    private int _closed;

    private async Task AcceptAsync()
    {
        try
        {
            while (true)
            {
                var client = await _listener.AcceptTcpClientAsync();
                lock (_clients)
                {
                    _clients.Add(client);
                }

                _ = Task.Run(() => ReadAsync(client));
            }
        }
        catch (Exception)
        {
            // Listener stopped
        }
    }

    private async Task ReadAsync(TcpClient client)
    {
        try
        {
            var stream = client.GetStream();
            var header = new byte[2];
            while (await stream.ReadAtLeastAsync(header, 2, throwOnEndOfStream: false) == 2)
            {
                var body = new byte[header[1]];
                await stream.ReadExactlyAsync(body);
                var frame = Convert.ToHexString([.. header, .. body]);
                Received.Add(frame);
                if (_answerTestFr && frame == TestFrAct)
                {
                    await stream.WriteAsync(TestFrCon);
                }
            }
        }
        catch (Exception)
        {
            // Reset by the client, or the station is disposing
        }

        Interlocked.Increment(ref _closed);
    }

    public void Dispose()
    {
        _listener.Stop();
        lock (_clients)
        {
            _clients.ForEach(c => c.Dispose());
        }
    }
}
