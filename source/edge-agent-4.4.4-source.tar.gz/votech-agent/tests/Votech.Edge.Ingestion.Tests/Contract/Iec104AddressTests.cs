using System.Text.Json;
using Votech.Edge.Ingestion.Iec104;
using Xunit;

namespace Votech.Edge.Ingestion.Tests.Contract;

/// <summary>
/// The IEC 104 address grammar against the shared vectors (votech-shared protobuf/v2/iec104_address_vectors.json),
/// which the backend and the web test too.
/// </summary>
public class Iec104AddressTests
{
    private static readonly JsonElement Vectors = JsonDocument.Parse(
        File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "Contract", "iec104_address_vectors.json"))
    ).RootElement;

    public static TheoryData<string, int, string> Valid() => Rows("valid", v => (v.GetProperty("ioa").GetInt32(), v.GetProperty("octets").GetString()!));

    public static TheoryData<string, int, int> Ambiguous()
    {
        var data = new TheoryData<string, int, int>();
        foreach (var v in Vectors.GetProperty("ambiguous").EnumerateArray())
        {
            var candidates = v.GetProperty("candidates");
            data.Add(v.GetProperty("input").GetString()!, candidates[0].GetInt32(), candidates[1].GetInt32());
        }

        return data;
    }

    public static TheoryData<string, string> Invalid()
    {
        var data = new TheoryData<string, string>();
        foreach (var v in Vectors.GetProperty("invalid").EnumerateArray())
        {
            data.Add(v.GetProperty("input").GetString()!, v.GetProperty("reason").GetString()!);
        }

        return data;
    }

    [Theory]
    [MemberData(nameof(Valid))]
    public void AValidAddress_GivesItsIoa_AndItsOctets(string input, int ioa, string octets)
    {
        Assert.Equal(new Iec104Address.Result(Iec104Address.Outcome.Valid, ioa), Iec104Address.Parse(input));
        Assert.Equal(octets, Iec104Address.ToOctets(ioa));
    }

    [Theory]
    [MemberData(nameof(Ambiguous))]
    public void AnAmbiguousAddress_IsRefused_WithBothReadings(string input, int thousands, int octets)
    {
        Assert.Equal(new Iec104Address.Result(Iec104Address.Outcome.Ambiguous, Thousands: thousands, Octets: octets), Iec104Address.Parse(input));
        Assert.False(Iec104Address.TryParse(input, out _));
    }

    [Theory]
    [MemberData(nameof(Invalid))]
    public void AnInvalidAddress_IsRefused_WithItsReason(string input, string reason)
    {
        Assert.Equal(Iec104Address.Result.Invalid(reason), Iec104Address.Parse(input));
    }

    [Fact]
    public void TheVectors_CoverEveryOutcome()
    {
        Assert.Equal("2.1.0", Vectors.GetProperty("contractVersion").GetString());
        Assert.NotEmpty(Valid());
        Assert.NotEmpty(Ambiguous());
        Assert.NotEmpty(Invalid());
    }

    [Theory]
    [InlineData(1835306, 2752796)] // 28.1.42 ↔ 42.1.28
    [InlineData(131332, 262402)] // 2.1.4 ↔ 4.1.2
    [InlineData(1772813, 855323)] // 27.13.13 ↔ 13.13.27
    [InlineData(859917, 859917)] // 13.27.13 reads the same both ways
    public void ReversingTheOctets_SwapsHighAndLow(int ioa, int reversed)
    {
        Assert.Equal(reversed, Iec104Address.Reverse(ioa));
        Assert.Equal(ioa, Iec104Address.Reverse(reversed));
    }

    private static TheoryData<string, int, string> Rows(string kind, Func<JsonElement, (int Ioa, string Octets)> read)
    {
        var data = new TheoryData<string, int, string>();
        foreach (var v in Vectors.GetProperty(kind).EnumerateArray())
        {
            var (ioa, octets) = read(v);
            data.Add(v.GetProperty("input").GetString()!, ioa, octets);
        }

        return data;
    }
}
