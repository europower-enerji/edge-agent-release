using System.Net;
using Google.Protobuf;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Ingestion.Services;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Tests.Contract;

/// <summary>
/// Agent 3.0: a key belongs to an installed agent; the backend says which sites it serves (<c>GET api/v1/edge/agent</c>),
/// and the agent keeps a local copy for restarts without the backend.
/// </summary>
public sealed class AgentAssignmentTests : IDisposable
{
    private const string Key = "gpk_live_0123456789abcdef_" + "00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff";
    private static readonly Guid Tenant = Guid.Parse("1b2c3d4e-0000-4000-8000-000000000001");
    private static readonly Guid OtherTenant = Guid.Parse("1b2c3d4e-0000-4000-8000-000000000002");
    private static readonly Guid SiteA = Guid.Parse("5a17e000-0000-4000-8000-0000000000a1");
    private static readonly Guid SiteB = Guid.Parse("7c6d5e4f-3a2b-4e8f-9b21-3f2b8c1e5a4d");

    private readonly QueueHttpHandler _http = new();
    private readonly ManualTimeProvider _time = new(new DateTimeOffset(2026, 10, 21, 12, 0, 0, TimeSpan.Zero));
    private readonly string _directory = Path.Combine(Path.GetTempPath(), $"votech-assignment-{Guid.NewGuid():N}");

    public void Dispose()
    {
        if (Directory.Exists(_directory))
        {
            Directory.Delete(_directory, true);
        }
    }

    private string CacheFile => Path.Combine(_directory, "agent-assignment.pb");

    private AgentAssignmentSource Source(string tenantId = "") =>
        new(
            new HttpClient(_http) { BaseAddress = new Uri("http://backend.test/") },
            Options.Create(new EdgeAgentOptions { AgentKey = Key, TenantId = tenantId, MaxOfflineCacheHours = 72 }),
            NullLogger<AgentAssignmentSource>.Instance,
            CacheFile,
            _time
        );

    /// <summary>A platform agent with sites of two organisations, or a tenant agent when <paramref name="tenant"/> is set.</summary>
    private static V2.AgentAssignment Assignment(Guid? tenant = null)
    {
        var assignment = new V2.AgentAssignment { AgentId = EdgeIds.ToByteString(Guid.NewGuid()), Name = "Main server" };
        if (tenant is { } id)
        {
            assignment.TenantId = EdgeIds.ToByteString(id);
        }

        assignment.Sites.Add(new V2.AssignedSite { SiteId = EdgeIds.ToByteString(SiteA), TenantId = EdgeIds.ToByteString(Tenant), Name = "North Solar Plant", TenantName = "North Energy" });
        assignment.Sites.Add(new V2.AssignedSite { SiteId = EdgeIds.ToByteString(SiteB), TenantId = EdgeIds.ToByteString(OtherTenant), Name = "South Solar Plant", TenantName = "South Energy" });
        return assignment;
    }

    private static HttpResponseMessage Protobuf(IMessage message)
    {
        var content = new ByteArrayContent(message.ToByteArray());
        content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/x-protobuf");
        return new HttpResponseMessage(HttpStatusCode.OK) { Content = content };
    }

    [Fact]
    public async Task TheBackend_SaysWhichSitesTheAgentServes_OfAnyOrganisation_AndTheAnswerIsKept()
    {
        _http.Responses.Enqueue(_ => Protobuf(Assignment()));

        var result = await Source().FetchAsync(CancellationToken.None);

        Assert.Equal(AgentAssignmentSource.Outcome.Fresh, result.Outcome);
        Assert.Equal(
            [(Tenant, SiteA, "North Solar Plant", "North Energy"), (OtherTenant, SiteB, "South Solar Plant", "South Energy")],
            result.Sites.Select(s => (s.TenantId, s.SiteId, s.Name, s.TenantName)));
        var request = Assert.Single(_http.Requests);
        Assert.Equal("http://backend.test/api/v1/edge/agent", request.RequestUri!.ToString());
        Assert.Equal(Key, request.Headers.GetValues("X-Edge-Api-Key").Single());
        Assert.False(request.Headers.Contains("X-Edge-Tenant-Id"));
        Assert.True(File.Exists(CacheFile));
    }

    [Fact]
    public async Task WithTenantId_TheGuardIsSent_AndAnAgentOfAnotherOrganisationIsNotRun()
    {
        _http.Responses.Enqueue(_ => Protobuf(Assignment(Tenant)));
        _http.Responses.Enqueue(_ => Protobuf(Assignment(OtherTenant)));
        var source = Source(Tenant.ToString());

        var own = await source.FetchAsync(CancellationToken.None);
        var other = await source.FetchAsync(CancellationToken.None);

        Assert.Equal(AgentAssignmentSource.Outcome.Fresh, own.Outcome);
        Assert.Equal(Tenant.ToString(), _http.Requests[0].Headers.GetValues("X-Edge-Tenant-Id").Single());
        Assert.Equal(AgentAssignmentSource.Outcome.Unavailable, other.Outcome);
        Assert.Contains($"organisation {Tenant}", other.Reason);
    }

    [Theory]
    [InlineData(HttpStatusCode.Unauthorized, "EDGE_KEY_INVALID", true, "rotated")]
    [InlineData(HttpStatusCode.Unauthorized, "EDGE_KEY_REVOKED", true, "revoked")]
    [InlineData(HttpStatusCode.Unauthorized, "EDGE_KEY_TENANT_MISMATCH", true, "TENANT_ID")]
    [InlineData(HttpStatusCode.Forbidden, "TENANT_SUSPENDED", false, "suspended")]
    [InlineData(HttpStatusCode.Unauthorized, null, false, "proxy")]
    [InlineData(HttpStatusCode.Forbidden, null, false, "proxy")]
    public async Task ARefusal_ComesWithTheLocalCopy_AndSaysWhetherTheKeyItselfIsWrong(HttpStatusCode status, string? code, bool keyRefused, string why)
    {
        _http.Responses.Enqueue(_ => Protobuf(Assignment()));
        var source = Source();
        await source.FetchAsync(CancellationToken.None);
        _time.Now = DateTimeOffset.UtcNow.AddMinutes(1);
        _http.Responses.Enqueue(_ => TestConfigurations.Refusal(status, code));

        var result = await source.FetchAsync(CancellationToken.None);

        Assert.Equal((AgentAssignmentSource.Outcome.Refused, 2), (result.Outcome, result.Sites.Count));
        Assert.Equal((code, keyRefused), (result.Code, result.KeyRefused));
        Assert.Contains(why, result.Reason);
        Assert.Contains("gpk_live_0123456789abcdef", result.Reason);
        Assert.DoesNotContain("00112233445566778899", result.Reason);
    }

    [Fact]
    public async Task ARefusal_WithoutALocalCopy_HasNoSites_AndACodeThatIsNotPlainIsIgnored()
    {
        _http.Responses.Enqueue(_ => TestConfigurations.Refusal(HttpStatusCode.Unauthorized, "<b>EDGE_KEY_REVOKED</b>"));

        var result = await Source().FetchAsync(CancellationToken.None);

        Assert.Equal((AgentAssignmentSource.Outcome.Refused, null, false), (result.Outcome, result.Code, result.KeyRefused));
        Assert.Null(result.Assignment);
    }

    [Fact]
    public async Task WithoutTheBackend_TheLocalCopyIsUsed_WhileItIsInsideTheOfflineWindow()
    {
        _http.Responses.Enqueue(_ => Protobuf(Assignment()));
        var source = Source();
        await source.FetchAsync(CancellationToken.None);
        _time.Now = DateTimeOffset.UtcNow.AddHours(1);

        var cached = await source.FetchAsync(CancellationToken.None);
        _time.Now = DateTimeOffset.UtcNow.AddHours(73);
        var expired = await source.FetchAsync(CancellationToken.None);

        Assert.Equal((AgentAssignmentSource.Outcome.Cached, 2), (cached.Outcome, cached.Sites.Count));
        Assert.Equal(AgentAssignmentSource.Outcome.Unavailable, expired.Outcome);
        Assert.Contains("73 h old (72 h allowed)", expired.Reason);
    }

    [Fact]
    public async Task AnUnchangedAssignment_IsNotWrittenAgain_ButItsCopyStaysFresh()
    {
        var first = Assignment();
        first.GeneratedAtMs = 1;
        var again = Assignment();
        again.Sites.Clear();
        again.Sites.AddRange(first.Sites);
        again.AgentId = first.AgentId;
        again.GeneratedAtMs = 2;
        var changed = again.Clone();
        changed.Sites.RemoveAt(1);
        _http.Responses.Enqueue(_ => Protobuf(first));
        _http.Responses.Enqueue(_ => Protobuf(again));
        _http.Responses.Enqueue(_ => Protobuf(changed));
        var source = Source();

        await source.FetchAsync(CancellationToken.None);
        var written = File.ReadAllBytes(CacheFile);
        File.SetLastWriteTimeUtc(CacheFile, DateTime.UtcNow.AddHours(-10));
        await source.FetchAsync(CancellationToken.None);

        Assert.Equal(written, File.ReadAllBytes(CacheFile));
        Assert.True(DateTime.UtcNow - File.GetLastWriteTimeUtc(CacheFile) < TimeSpan.FromMinutes(1));

        await source.FetchAsync(CancellationToken.None);
        Assert.Single(V2.AgentAssignment.Parser.ParseFrom(File.ReadAllBytes(CacheFile)).Sites);
    }

    [Fact]
    public async Task WithoutTheBackendOrALocalCopy_NothingIsKnown()
    {
        var result = await Source().FetchAsync(CancellationToken.None);

        Assert.Equal(AgentAssignmentSource.Outcome.Unavailable, result.Outcome);
        Assert.Contains("no local copy", result.Reason);
    }

    [Fact]
    public void AnAgentKey_GivesItsKeyIdAsTheBrokerUsername_AndAPrefixSafeToLog()
    {
        Assert.True(EdgeAgentKey.TryGetKeyId(Key, out var keyId));
        Assert.Equal("0123456789abcdef", keyId);
        Assert.Equal("gpk_live_0123456789abcdef", EdgeAgentKey.Prefix(Key));
        Assert.Equal("0123456789abcdef", new EdgeAgentOptions { AgentKey = Key, SiteId = SiteA.ToString() }.BrokerUsername);
        Assert.False(EdgeAgentKey.TryGetKeyId("gpk_live_xxxxxxxxxxxxxxxx", out _));
        Assert.Equal(SiteA.ToString(), new EdgeAgentOptions { AgentKey = "dev-key", SiteId = SiteA.ToString() }.BrokerUsername);
    }

    [Fact]
    public void AKeyOfTheNewFormat_IsReadTheSameWay_AndAnythingElseIsNoKey()
    {
        // Backend 5.18.0 issues eak_live_ keys ("edge agent key"); the gpk_live_ keys issued before keep working
        var newKey = "eak_live_0123456789abcdef_" + new string('a', 64);

        Assert.True(EdgeAgentKey.TryGetKeyId(newKey, out var keyId));
        Assert.Equal("0123456789abcdef", keyId);
        Assert.Equal("eak_live_0123456789abcdef", EdgeAgentKey.Prefix(newKey));
        Assert.Equal($"edge-0123456789abcdef-{SiteA:N}", EdgeAgentKey.ClientIdFor(newKey, SiteA));
        Assert.False(EdgeAgentKey.TryGetKeyId("xyz_live_0123456789abcdef_" + new string('a', 64), out _));
        Assert.Equal("(not an agent key)", EdgeAgentKey.Prefix("dev-key"));
    }

    [Fact]
    public void EachSite_ConnectsUnderAClientIdOfTheKey_TheOnlyOneTheBrokerAccepts()
    {
        // X-03: the backend accepts edge-<key id>[-…] for this key, and closes exactly these sessions on revocation.
        Assert.Equal("edge-0123456789abcdef-5a17e0000000400080000000000000a1", EdgeAgentKey.ClientIdFor(Key, SiteA));
        Assert.Equal("edge-0123456789abcdef-7c6d5e4f3a2b4e8f9b213f2b8c1e5a4d", EdgeAgentKey.ClientIdFor(" " + Key + " ", SiteB));
        Assert.Equal("edge-nokey-5a17e0000000400080000000000000a1", EdgeAgentKey.ClientIdFor("dev-key", SiteA));
        Assert.Equal("edge-nokey-5a17e0000000400080000000000000a1", EdgeAgentKey.ClientIdFor(null, SiteA));
    }

    [Theory]
    [InlineData("Production", Key, "", "", true)]
    [InlineData("Production", "eak_live_0123456789abcdef_00112233445566778899aabbccddeeff00112233445566778899aabbccddeeff", "", "", true)]
    [InlineData("Production", Key, "1b2c3d4e-0000-4000-8000-000000000001", "", true)]
    [InlineData("Production", "dev-key", "", "", false)]
    [InlineData("Development", "dev-key", "", "", true)]
    [InlineData("Production", Key, "not-a-uuid", "", false)]
    [InlineData("Development", Key, "", "5a17e000-0000-4000-8000-0000000000a1", false)]
    public void TheAgentSettings_NeedAnAgentKey_AndNoSiteOfTheirOwn(string environment, string key, string tenantId, string siteId, bool valid)
    {
        var result = new AgentKeyValidator(environment).Validate(null, new EdgeAgentOptions { AgentKey = key, TenantId = tenantId, SiteId = siteId });

        Assert.Equal(valid, result.Succeeded);
        if (!string.IsNullOrEmpty(siteId))
        {
            Assert.Contains("SITE_ID", result.FailureMessage);
        }
    }

    [Fact]
    public void ASiteIsNamedInTheLog_ByItsNameOrItsShortId()
    {
        Assert.Equal("North Solar Plant", new AgentSite(Tenant, SiteA, "North Solar Plant", "North Energy").Label);
        Assert.Equal("5a17e000", new AgentSite(Tenant, SiteA, "", "North Energy").Label);
        Assert.Equal("5a17e000", new AgentSite(Tenant, SiteA, "", "").ShortId);
        Assert.EndsWith("…", new AgentSite(Tenant, SiteA, new string('x', 40), "").Label);
    }
}
