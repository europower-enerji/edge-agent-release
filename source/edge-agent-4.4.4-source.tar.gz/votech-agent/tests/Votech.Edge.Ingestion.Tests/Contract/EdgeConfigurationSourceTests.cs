using System.Net;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Entities;
using Votech.Edge.Ingestion.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Moq;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Tests.Contract;

public sealed class EdgeConfigurationSourceTests : IDisposable
{
    private readonly SqliteTestDatabase _db = new();
    private readonly QueueHttpHandler _http = new();
    private readonly Mock<IHostApplicationLifetime> _lifetime = new();
    private readonly ManualTimeProvider _time = new(new DateTimeOffset(2026, 10, 19, 10, 0, 0, TimeSpan.Zero));
    private readonly List<V2.EdgeConfiguration> _changes = [];

    public void Dispose() => _db.Dispose();

    private EdgeConfigurationSource Source(string tenantId = "", string siteTenantId = "")
    {
        var source = new EdgeConfigurationSource(
            new HttpClient(_http) { BaseAddress = new Uri("http://backend.test/") },
            _db,
            Options.Create(new EdgeAgentOptions { SiteId = TestConfigurations.SiteId.ToString(), TenantId = tenantId, SiteTenantId = siteTenantId, AgentKey = "gpk_test", MaxOfflineCacheHours = 72 }),
            NullLogger<EdgeConfigurationSource>.Instance,
            _lifetime.Object,
            _time
        );
        source.ConfigurationChanged += (_, configuration) => _changes.Add(configuration);
        return source;
    }

    private static V2.EdgeConfiguration Configuration(string revision) => TestConfigurations.Iec104(revision, (Guid.NewGuid(), 7, []));

    [Fact]
    public async Task A200_RunsAndCachesTheConfiguration_AndSendsTheKeyAndAcceptHeader()
    {
        var source = Source();
        _http.Responses.Enqueue(_ => TestConfigurations.Protobuf(Configuration("rev-1")));

        await source.SyncAsync();

        Assert.Equal("rev-1", source.Current!.Revision);
        Assert.Equal("rev-1", Assert.Single(_changes).Revision);
        var request = Assert.Single(_http.Requests);
        Assert.Equal($"http://backend.test/api/v1/edge/sites/{TestConfigurations.SiteId}/configuration", request.RequestUri!.ToString());
        Assert.Equal("gpk_test", request.Headers.GetValues("X-Edge-Api-Key").Single());
        Assert.Equal("application/x-protobuf", request.Headers.Accept.Single().MediaType);
        Assert.Empty(request.Headers.IfNoneMatch);
        await using var db = _db.CreateDbContext();
        var cached = await db.EdgeConfigurationCache.SingleAsync();
        Assert.Equal(("rev-1", 2), (cached.Revision, cached.SchemaVersion));
    }

    [Fact]
    public async Task A304_KeepsTheRunningConfiguration_AndRenewsTheLastContact()
    {
        var source = Source();
        _http.Responses.Enqueue(_ => TestConfigurations.Protobuf(Configuration("rev-1")));
        await source.SyncAsync();
        _time.Now = _time.Now.AddHours(1);
        _http.Responses.Enqueue(_ => new HttpResponseMessage(HttpStatusCode.NotModified));

        await source.SyncAsync();

        Assert.Equal("\"rev-1\"", _http.Requests[1].Headers.IfNoneMatch.Single().Tag);
        Assert.Single(_changes);
        await using var db = _db.CreateDbContext();
        Assert.Equal(_time.Now.UtcDateTime, (await db.EdgeConfigurationCache.SingleAsync()).FetchedAt);
    }

    [Theory]
    [InlineData("garbage")]
    [InlineData("schema")]
    [InlineData("site")]
    [InlineData("content-type")]
    public async Task AnUnusableResponse_KeepsTheLastGoodConfiguration(string fault)
    {
        var source = Source();
        _http.Responses.Enqueue(_ => TestConfigurations.Protobuf(Configuration("rev-1")));
        await source.SyncAsync();
        var bad = Configuration("rev-2");
        _http.Responses.Enqueue(_ =>
        {
            switch (fault)
            {
                case "garbage":
                    var garbage = new ByteArrayContent([0xff, 0xff, 0xff, 0x01]);
                    garbage.Headers.ContentType = new("application/x-protobuf");
                    return new HttpResponseMessage(HttpStatusCode.OK) { Content = garbage };
                case "schema":
                    bad.SchemaVersion = 3;
                    return TestConfigurations.Protobuf(bad);
                case "site":
                    bad.SiteId = Core.Acquisition.EdgeIds.ToByteString(Guid.NewGuid());
                    return TestConfigurations.Protobuf(bad);
                default:
                    var html = TestConfigurations.Protobuf(bad);
                    html.Content.Headers.ContentType = new("text/html");
                    return html;
            }
        });

        await source.SyncAsync();

        Assert.Equal("rev-1", source.Current!.Revision);
        Assert.Single(_changes);
        await using var db = _db.CreateDbContext();
        Assert.Equal("rev-1", (await db.EdgeConfigurationCache.SingleAsync()).Revision);
    }

    [Fact]
    public async Task TheTenantGuard_IsSent_AndAConfigurationOfAnotherOrganisationThanTheSite_IsRefused()
    {
        var organisation = Guid.NewGuid();
        var source = Source(tenantId: organisation.ToString(), siteTenantId: organisation.ToString());
        var own = Configuration("rev-1");
        own.TenantId = Core.Acquisition.EdgeIds.ToByteString(organisation);
        _http.Responses.Enqueue(_ => TestConfigurations.Protobuf(own));
        _http.Responses.Enqueue(_ => TestConfigurations.Protobuf(Configuration("rev-2")));

        await source.SyncAsync();
        await source.SyncAsync();

        Assert.Equal(organisation.ToString(), _http.Requests[0].Headers.GetValues("X-Edge-Tenant-Id").Single());
        Assert.Equal("rev-1", source.Current!.Revision);
        Assert.Single(_changes);
    }

    [Fact]
    public async Task APlatformAgent_SendsNoTenantGuard()
    {
        var source = Source(siteTenantId: Guid.NewGuid().ToString());
        _http.Responses.Enqueue(_ => new HttpResponseMessage(HttpStatusCode.NotModified));

        await source.SyncAsync();

        Assert.False(Assert.Single(_http.Requests).Headers.Contains("X-Edge-Tenant-Id"));
    }

    [Fact]
    public async Task AReloadForTheRunningRevision_IsSkipped_AndAnotherRevisionIsFetched()
    {
        var source = Source();
        _http.Responses.Enqueue(_ => TestConfigurations.Protobuf(Configuration("rev-1")));
        await source.SyncAsync();

        await source.ReloadAsync("rev-1");
        Assert.Single(_http.Requests);

        _http.Responses.Enqueue(_ => TestConfigurations.Protobuf(Configuration("rev-2")));
        await source.ReloadAsync("rev-2");
        Assert.Equal(["rev-1", "rev-2"], _changes.Select(c => c.Revision));
    }

    [Fact]
    public async Task OfflineAtStart_RunsTheCachedConfiguration_WithinTheOfflineWindow()
    {
        _http.Responses.Enqueue(_ => TestConfigurations.Protobuf(Configuration("rev-1")));
        await Source().SyncAsync();
        _time.Now = _time.Now.AddHours(71);
        _changes.Clear();

        var restarted = Source();
        await restarted.SyncAsync();

        Assert.Equal("rev-1", restarted.Current!.Revision);
        Assert.Equal("\"rev-1\"", _http.Requests[1].Headers.IfNoneMatch.Single().Tag);
        _lifetime.Verify(l => l.StopApplication(), Times.Never);
    }

    [Theory]
    [InlineData(73)]
    [InlineData(-1)]
    public async Task OfflineWithAnExpiredCacheOrAClockRollback_StopsTheAgent(int hoursLater)
    {
        _http.Responses.Enqueue(_ => TestConfigurations.Protobuf(Configuration("rev-1")));
        await Source().SyncAsync();
        _time.Now = _time.Now.AddHours(hoursLater);

        var restarted = Source();
        await restarted.SyncAsync();

        Assert.Null(restarted.Current);
        _lifetime.Verify(l => l.StopApplication(), Times.Once);
    }

    [Theory]
    [InlineData(HttpStatusCode.Unauthorized, "EDGE_KEY_REVOKED")]
    [InlineData(HttpStatusCode.Unauthorized, null)]
    [InlineData(HttpStatusCode.Forbidden, "ERRORS.TENANT_SUSPENDED")]
    [InlineData(HttpStatusCode.Forbidden, null)]
    public async Task ARefusal_KeepsTheSiteOnItsCachedConfiguration(HttpStatusCode status, string? code)
    {
        _http.Responses.Enqueue(_ => TestConfigurations.Protobuf(Configuration("rev-1")));
        await Source().SyncAsync();

        var restarted = Source();
        _http.Responses.Enqueue(_ => TestConfigurations.Refusal(status, code));
        await restarted.SyncAsync();

        Assert.Equal("rev-1", restarted.Current!.Revision);
        _lifetime.Verify(l => l.StopApplication(), Times.Never);
    }

    [Fact]
    public async Task ASiteTheAgentNoLongerServes_Stops()
    {
        var source = Source();
        _http.Responses.Enqueue(_ => TestConfigurations.Refusal(HttpStatusCode.Forbidden, "ERRORS.FORBIDDEN_EDGE_SITE_MISMATCH"));

        await source.SyncAsync();

        Assert.Null(source.Current);
        _lifetime.Verify(l => l.StopApplication(), Times.Once);
    }
}
