using System.Net;
using System.Net.Sockets;
using Google.Protobuf;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Interfaces;
using Votech.Edge.Ingestion.Services;
using Votech.Edge.Mqtt;
using lib60870.CS104;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Moq;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Tests.Contract;

public class ProbeTests
{
    private static readonly Guid Root = Guid.NewGuid();
    private static readonly Guid Station = Guid.NewGuid();
    private static readonly DateTimeOffset Now = new(2026, 10, 19, 10, 0, 0, TimeSpan.Zero);

    private readonly Mock<IEdgeConfigurationSource> _source = new();
    private readonly Mock<IConnectionManager> _manager = new();
    private readonly List<(V2.Connection Connection, V2.Station? Station)> _oneShots = [];

    public ProbeTests()
    {
        _source.SetupGet(s => s.Current).Returns(TestConfigurations.Iec104("rev", (Root, 7, []), (Station, 11, [])));
        _manager.SetupGet(m => m.Connections).Returns([]);
        _manager
            .Setup(m => m.ProbeIfIdleAsync(It.IsAny<Guid>(), It.IsAny<Func<CancellationToken, Task<ProbeOutcome>>>(), It.IsAny<CancellationToken>()))
            .Returns((Guid _, Func<CancellationToken, Task<ProbeOutcome>> probe, CancellationToken ct) => probe(ct)!);
    }

    private EndpointProbeService Service() =>
        new(_source.Object, _manager.Object, NullLogger<EndpointProbeService>.Instance, (connection, station, _) =>
        {
            _oneShots.Add((connection, station));
            return Task.FromResult(new ProbeOutcome(true, "STARTDT_CON", null));
        });

    private static V2.ProbeCommand Command(Guid endpointId, long expiresAtMs = 0) =>
        new() { CommandId = EdgeIds.ToByteString(Guid.NewGuid()), EndpointId = EdgeIds.ToByteString(endpointId), ExpiresAtMs = expiresAtMs };

    [Fact]
    public async Task AnEndpointOutsideTheConfiguration_IsRefusedWithoutContactingIt()
    {
        var command = Command(Guid.NewGuid());

        var ack = await Service().ProbeAsync(command, Now, default);

        Assert.Equal((false, EndpointProbeService.NotConfigured), (ack.Success, ack.ProtocolResponse));
        Assert.Equal((command.CommandId, command.EndpointId), (ack.CommandId, ack.EndpointId));
        Assert.Empty(_oneShots);
    }

    [Fact]
    public async Task AnExpiredCommand_IsRefused()
    {
        var ack = await Service().ProbeAsync(Command(Root, Now.AddSeconds(-1).ToUnixTimeMilliseconds()), Now, default);

        Assert.Equal((false, EndpointProbeService.Expired), (ack.Success, ack.ProtocolResponse));
        Assert.Empty(_oneShots);
    }

    [Fact]
    public async Task AStationOfARunningConnection_IsAnsweredFromItsHealth_WithoutASecondSocket()
    {
        var poller = new Mock<IConnectionPoller>();
        poller.SetupGet(p => p.EndpointId).Returns(Root);
        poller.SetupGet(p => p.Health).Returns([
            new EndpointHealth(Root, true, null, DeviceDiagnosticReason.ConnectedHealthy, null),
            new EndpointHealth(Station, false, null, DeviceDiagnosticReason.ConfigurationMismatch, "No data from common address 11"),
        ]);
        _manager.SetupGet(m => m.Connections).Returns([poller.Object]);

        var root = await Service().ProbeAsync(Command(Root, Now.AddSeconds(30).ToUnixTimeMilliseconds()), Now, default);
        var station = await Service().ProbeAsync(Command(Station), Now, default);

        Assert.Equal((true, "CONNECTED_HEALTHY", ""), (root.Success, root.ProtocolResponse, root.Error));
        Assert.Equal((false, "CONFIGURATION_MISMATCH", "No data from common address 11"), (station.Success, station.ProtocolResponse, station.Error));
        Assert.Empty(_oneShots);
    }

    [Fact]
    public async Task AConfiguredEndpointWithoutARunningConnection_IsProbedOnceWithItsSettings()
    {
        var ack = await Service().ProbeAsync(Command(Station), Now, default);

        Assert.True(ack.Success);
        var (connection, station) = Assert.Single(_oneShots);
        Assert.Equal((Root, Station), (EdgeIds.ToGuid(connection.EndpointId), EdgeIds.ToGuid(station!.EndpointId)));
    }

    [Fact]
    public async Task AProbeThatWaitedForARevision_IsAnsweredFromTheConnectionItStarted()
    {
        var poller = new Mock<IConnectionPoller>();
        poller.SetupGet(p => p.EndpointId).Returns(Root);
        poller.SetupGet(p => p.Health).Returns([new EndpointHealth(Root, false, null, DeviceDiagnosticReason.Connecting, null)]);
        _manager.SetupSequence(m => m.Connections).Returns([]).Returns([poller.Object]);
        _manager
            .Setup(m => m.ProbeIfIdleAsync(It.IsAny<Guid>(), It.IsAny<Func<CancellationToken, Task<ProbeOutcome>>>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((ProbeOutcome?)null);

        var ack = await Service().ProbeAsync(Command(Root), Now, default);

        Assert.Equal((false, "CONNECTING"), (ack.Success, ack.ProtocolResponse));
        Assert.Empty(_oneShots);
    }

    [Fact]
    public async Task TheOneShotIec104Probe_ExpectsAStartDtConfirmation()
    {
        var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        var port = ((IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop();
        var server = new Server();
        server.SetLocalAddress("127.0.0.1");
        server.SetLocalPort(port);
        server.Start();
        try
        {
            var connection = new V2.Connection { Protocol = V2.Protocol.Iec104, Iec104 = new V2.Iec104Settings { Host = "127.0.0.1", Port = (uint)port } };
            var outcome = await EndpointProbeService.ProbeOnceAsync(connection, null, default);
            Assert.Equal(new ProbeOutcome(true, "STARTDT_CON", null), outcome);
        }
        finally
        {
            server.Stop();
        }
    }

    [Fact]
    public async Task TheSubscriber_ReloadsAndAnswersProbesOnItsSiteTopics()
    {
        var probes = new Mock<IProbeHandler>();
        var ack = new V2.CommandAck { EndpointId = EdgeIds.ToByteString(Root), Success = true };
        probes.Setup(p => p.ProbeAsync(It.IsAny<V2.ProbeCommand>(), It.IsAny<DateTimeOffset>(), It.IsAny<CancellationToken>())).ReturnsAsync(ack);
        var mqtt = new Mock<IMqttPublisher>();
        var options = Options.Create(new EdgeAgentOptions { SiteId = TestConfigurations.SiteId.ToString(), AgentKey = "k", Mqtt = new MqttOptions { ClientId = "agent", BrokerHost = "localhost", TopicPrefix = "edge" } });
        using var subscriber = new V2CommandSubscriber(options, _source.Object, probes.Object, mqtt.Object, NullLogger<V2CommandSubscriber>.Instance);

        Assert.Equal($"edge/v2/commands/{TestConfigurations.SiteId}/reload", subscriber.ReloadTopic);
        Assert.Equal($"edge/v2/commands/{TestConfigurations.SiteId}/probe", subscriber.ProbeTopic);

        await subscriber.HandleAsync(subscriber.ReloadTopic, new V2.ReloadConfig { Revision = "rev-2" }.ToByteArray());
        await subscriber.HandleAsync(subscriber.ProbeTopic, Command(Root).ToByteArray());
        await subscriber.HandleAsync(subscriber.ProbeTopic, [0xff, 0xff, 0xff]);

        _source.Verify(s => s.ReloadAsync("rev-2", It.IsAny<CancellationToken>()), Times.Once);
        probes.Verify(p => p.ProbeAsync(It.IsAny<V2.ProbeCommand>(), It.IsAny<DateTimeOffset>(), It.IsAny<CancellationToken>()), Times.Once);
        mqtt.Verify(m => m.PublishCommandAckAsync(TestConfigurations.SiteId, ack, It.IsAny<CancellationToken>()), Times.Once);
    }
}
