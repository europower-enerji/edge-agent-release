using Votech.Edge.Core.Models;
using Votech.Edge.Ingestion.Iec104;
using lib60870;
using Xunit;

namespace Votech.Edge.Ingestion.Tests.Contract;

public class StationTimeTests
{
    private static TimeZoneInfo Zone(string id) => TimeZoneInfo.FindSystemTimeZoneById(id);

    private static CP56Time2a Cp56(int year, int month, int day, int hour, int minute, bool summerTime = false) =>
        new(new DateTime(year, month, day, hour, minute, 0)) { SummerTime = summerTime };

    [Fact]
    public void NoZone_ReadsAndSetsUtc_AsBefore()
    {
        var utc = new DateTime(2026, 11, 6, 9, 0, 0, DateTimeKind.Utc);

        Assert.Equal(utc, StationTime.ToUtc(new DateTime(2026, 11, 6, 9, 0, 0), summerTime: false, zone: null));
        var cp56 = StationTime.ToCp56(utc, null);
        Assert.Equal((9, false), (cp56.Hour, cp56.SummerTime));
    }

    [Fact]
    public void Istanbul_IsUtcPlus3_AllYear()
    {
        var istanbul = Zone("Europe/Istanbul");

        Assert.Equal(new DateTime(2026, 1, 15, 9, 0, 0, DateTimeKind.Utc), StationTime.ToUtc(new DateTime(2026, 1, 15, 12, 0, 0), false, istanbul));
        Assert.Equal(new DateTime(2026, 7, 15, 9, 0, 0, DateTimeKind.Utc), StationTime.ToUtc(new DateTime(2026, 7, 15, 12, 0, 0), false, istanbul));
        var cp56 = StationTime.ToCp56(new DateTime(2026, 7, 15, 9, 0, 0, DateTimeKind.Utc), istanbul);
        Assert.Equal((12, false), (cp56.Hour, cp56.SummerTime));
    }

    [Fact]
    public void Bucharest_FollowsSummerTime_AndSetsTheSuBit()
    {
        var bucharest = Zone("Europe/Bucharest");

        Assert.Equal(new DateTime(2026, 1, 15, 10, 0, 0, DateTimeKind.Utc), StationTime.ToUtc(new DateTime(2026, 1, 15, 12, 0, 0), false, bucharest));
        Assert.Equal(new DateTime(2026, 7, 15, 9, 0, 0, DateTimeKind.Utc), StationTime.ToUtc(new DateTime(2026, 7, 15, 12, 0, 0), true, bucharest));

        var summer = StationTime.ToCp56(new DateTime(2026, 7, 15, 9, 0, 0, DateTimeKind.Utc), bucharest);
        var winter = StationTime.ToCp56(new DateTime(2026, 1, 15, 10, 0, 0, DateTimeKind.Utc), bucharest);
        Assert.Equal((12, true), (summer.Hour, summer.SummerTime));
        Assert.Equal((12, false), (winter.Hour, winter.SummerTime));
    }

    [Fact]
    public void AFixedOffsetZone_IgnoresSummerTime()
    {
        // Etc/GMT-2 is UTC+2 all year (the sign is reversed in IANA).
        var fixedPlus2 = Zone("Etc/GMT-2");

        Assert.Equal(new DateTime(2026, 7, 15, 10, 0, 0, DateTimeKind.Utc), StationTime.ToUtc(new DateTime(2026, 7, 15, 12, 0, 0), true, fixedPlus2));
        var cp56 = StationTime.ToCp56(new DateTime(2026, 7, 15, 10, 0, 0, DateTimeKind.Utc), fixedPlus2);
        Assert.Equal((12, false), (cp56.Hour, cp56.SummerTime));
    }

    [Fact]
    public void TheRepeatedHour_IsResolvedByTheSuBit()
    {
        // Bucharest leaves summer time on 2026-10-25 at 04:00 local (01:00 UTC): 03:30 local happens twice.
        var bucharest = Zone("Europe/Bucharest");

        Assert.Equal(new DateTime(2026, 10, 25, 0, 30, 0, DateTimeKind.Utc), StationTime.ToUtc(new DateTime(2026, 10, 25, 3, 30, 0), true, bucharest));
        Assert.Equal(new DateTime(2026, 10, 25, 1, 30, 0, DateTimeKind.Utc), StationTime.ToUtc(new DateTime(2026, 10, 25, 3, 30, 0), false, bucharest));
    }

    [Fact]
    public void TheSkippedHour_IsReadWithTheOffsetBeforeTheChange()
    {
        // Bucharest enters summer time on 2026-03-29 at 03:00 local: 03:30 local never happens.
        var bucharest = Zone("Europe/Bucharest");

        Assert.Equal(new DateTime(2026, 3, 29, 1, 30, 0, DateTimeKind.Utc), StationTime.ToUtc(new DateTime(2026, 3, 29, 3, 30, 0), false, bucharest));
    }

    [Fact]
    public void TheMapper_ReadsADeviceTimeInTheStationZone()
    {
        var receivedAt = new DateTime(2026, 11, 6, 9, 0, 5, DateTimeKind.Utc);
        var policy = Iec104SignalMapper.TimePolicy.Default with { Zone = Zone("Europe/Istanbul") };

        var time = Iec104SignalMapper.ResolveTime(Cp56(2026, 11, 6, 12, 0), receivedAt, policy, null);

        Assert.Equal((new DateTime(2026, 11, 6, 9, 0, 0, DateTimeKind.Utc), SampleTimeSource.Device), (time.Timestamp, time.Source));
    }
}
