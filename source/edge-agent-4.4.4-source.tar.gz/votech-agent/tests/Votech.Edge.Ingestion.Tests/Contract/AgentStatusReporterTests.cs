using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Constants;
using Votech.Edge.Core.Interfaces;
using Votech.Edge.Mqtt;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Moq;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Ingestion.Tests.Contract;

public class AgentStatusReporterTests
{
    private static readonly Guid Root = Guid.NewGuid();
    private static readonly Guid Station = Guid.NewGuid();
    private static readonly DateTime SeenAt = new(2026, 10, 19, 9, 59, 0, DateTimeKind.Utc);

    private sealed class FakePoller : IConnectionPoller
    {
        public bool StationUp { get; set; } = true;
        public Guid EndpointId => Root;
        public V2.Protocol Protocol => V2.Protocol.Iec104;
        public bool IsConnected => true;
        public IReadOnlyList<EndpointHealth> Health =>
        [
            new(Root, true, SeenAt, DeviceDiagnosticReason.ConnectedHealthy, null),
            new(Station, StationUp, SeenAt, StationUp ? DeviceDiagnosticReason.ConnectedHealthy : DeviceDiagnosticReason.ConfigurationMismatch, StationUp ? null : "No data from common address 11"),
        ];
        public Task RunAsync(CancellationToken ct) => Task.CompletedTask;
        public void UpdatePoints(V2.Connection connection) { }
        public ValueTask DisposeAsync() => ValueTask.CompletedTask;
    }

    [Fact]
    public void TheStatus_ListsEveryEndpoint_TheRevision_TheProtocols_AndTheBuffer()
    {
        var poller = new FakePoller { StationUp = false };
        var now = new DateTimeOffset(2026, 10, 19, 10, 0, 0, TimeSpan.Zero);

        var status = AgentStatusReporter.Build("agent-1", TestConfigurations.SiteId, "rev-9", poller.Health, new SignalBufferStatus(1200, 1234), false, V2.AgentState.Online, now);

        Assert.Equal(("agent-1", TestConfigurations.SiteId, "rev-9", V2.AgentState.Degraded), (status.ClientId, EdgeIds.ToGuid(status.SiteId), status.ConfigRevision, status.State));
        Assert.Equal([V2.Protocol.Iec104, V2.Protocol.ModbusTcp, V2.Protocol.ModbusRtu], status.SupportedProtocols);
        Assert.Equal(
            [(Root, true, "CONNECTED_HEALTHY", ""), (Station, false, "CONFIGURATION_MISMATCH", "No data from common address 11")],
            status.Endpoints.Select(e => (EdgeIds.ToGuid(e.EndpointId), e.Connected, e.ReasonCode, e.Error)));
        Assert.All(status.Endpoints, e => Assert.Equal(new DateTimeOffset(SeenAt).ToUnixTimeMilliseconds(), e.LastSeenAtMs));
        Assert.Equal((1200ul, 1234L, false), (status.Buffer.UnpublishedCount, status.Buffer.OldestUnpublishedMs, status.Buffer.Evicting));
        Assert.Equal(now.ToUnixTimeMilliseconds(), status.TimestampMs);
    }

    [Fact]
    public void AConnectedStationWithoutPoints_StaysConnected_ButSaysNothingIsRead()
    {
        // The RTUs of a real plant answered every interrogation while none of their signals had an address.
        var configuration = TestConfigurations.Iec104("rev", (Root, 7, []), (Station, 11, [(Guid.NewGuid(), "1001", V2.DataType.Float32)]));
        var withoutPoints = AgentStatusReporter.StationsWithoutPoints(configuration);
        var down = new EndpointHealth(Root, false, SeenAt, DeviceDiagnosticReason.UnreachablePhysicalDevice, "TCP connection failed");

        var marked = AgentStatusReporter.MarkStationsWithoutPoints(new FakePoller().Health, withoutPoints);
        var stillDown = AgentStatusReporter.MarkStationsWithoutPoints([down], withoutPoints);

        Assert.Equal([Root], withoutPoints);
        Assert.Equal(
            [(Root, true, DeviceDiagnosticReason.NoPointsConfigured, AgentStatusReporter.NoPointsError), (Station, true, DeviceDiagnosticReason.ConnectedHealthy, (string?)null)],
            marked.Select(e => (e.EndpointId, e.Connected, e.ReasonCode, e.Error)));
        Assert.Equal(down, Assert.Single(stillDown));
        Assert.Empty(AgentStatusReporter.StationsWithoutPoints(null));
    }

    [Theory]
    [InlineData(true, false, V2.AgentState.Online, V2.AgentState.Online)]
    [InlineData(true, true, V2.AgentState.Online, V2.AgentState.Degraded)]
    [InlineData(false, false, V2.AgentState.Online, V2.AgentState.Degraded)]
    [InlineData(false, false, V2.AgentState.Offline, V2.AgentState.Offline)]
    public void TheState_IsDegradedWhenAnEndpointIsDownOrTheBufferDropsSamples(bool stationUp, bool evicting, V2.AgentState requested, V2.AgentState expected)
    {
        var status = AgentStatusReporter.Build("a", Guid.Empty, "", new FakePoller { StationUp = stationUp }.Health, new SignalBufferStatus(0, 0), evicting, requested, DateTimeOffset.UtcNow);
        Assert.Equal(expected, status.State);
    }

    [Fact]
    public async Task TheReporter_PublishesAtOnce_OnAnEndpointChange_AndOfflineOnStop()
    {
        var poller = new FakePoller();
        var manager = new Mock<IConnectionManager>();
        manager.SetupGet(m => m.Connections).Returns(() => [poller]);
        manager.SetupGet(m => m.RunningRevision).Returns("rev-1");
        var buffer = new Mock<ISignalBuffer>();
        buffer.Setup(b => b.GetStatusAsync(It.IsAny<CancellationToken>())).ReturnsAsync(new SignalBufferStatus(0, 0));
        var sent = new List<V2.AgentStatus>();
        var mqtt = new Mock<IMqttPublisher>();
        mqtt.SetupGet(m => m.IsConnected).Returns(true);
        mqtt.Setup(m => m.PublishAgentStatusAsync(It.IsAny<V2.AgentStatus>(), It.IsAny<CancellationToken>()))
            .Callback<V2.AgentStatus, CancellationToken>((status, _) => { lock (sent) sent.Add(status); })
            .Returns(Task.CompletedTask);
        var options = Options.Create(new EdgeAgentOptions { SiteId = TestConfigurations.SiteId.ToString(), Mqtt = new MqttOptions { ClientId = "agent-1", HeartbeatIntervalSec = 300 } });
        var reporter = new AgentStatusReporter(manager.Object, buffer.Object, mqtt.Object, options, NullLogger<AgentStatusReporter>.Instance);

        await reporter.StartAsync(default);
        await WaitUntil(() => Count() == 1);
        poller.StationUp = false;
        await WaitUntil(() => Count() == 2);
        await reporter.StopAsync(default);

        Assert.Equal([V2.AgentState.Online, V2.AgentState.Degraded, V2.AgentState.Offline], sent.Select(s => s.State));
        Assert.All(sent, s => Assert.Equal("rev-1", s.ConfigRevision));

        int Count()
        {
            lock (sent)
            {
                return sent.Count;
            }
        }
    }

    [Fact]
    public async Task TheStatus_CarriesTheReadingsTheSinkDropped_AndTheSamplesTheBufferEvicted()
    {
        var manager = new Mock<IConnectionManager>();
        manager.SetupGet(m => m.Connections).Returns(() => [new FakePoller()]);
        manager.SetupGet(m => m.RunningRevision).Returns("rev-1");
        var buffer = new Mock<ISignalBuffer>();
        buffer.Setup(b => b.GetStatusAsync(It.IsAny<CancellationToken>())).ReturnsAsync(new SignalBufferStatus(0, 0));
        buffer.SetupGet(b => b.EvictedTotal).Returns(7);
        var sink = new Mock<ISignalSink>();
        sink.SetupGet(s => s.DroppedTotal).Returns(3);
        V2.AgentStatus? sent = null;
        var mqtt = new Mock<IMqttPublisher>();
        mqtt.Setup(m => m.PublishAgentStatusAsync(It.IsAny<V2.AgentStatus>(), It.IsAny<CancellationToken>()))
            .Callback<V2.AgentStatus, CancellationToken>((status, _) => sent = status)
            .Returns(Task.CompletedTask);
        var options = Options.Create(new EdgeAgentOptions { SiteId = TestConfigurations.SiteId.ToString() });
        var reporter = new AgentStatusReporter(manager.Object, buffer.Object, mqtt.Object, options, NullLogger<AgentStatusReporter>.Instance, sink: sink.Object);

        await reporter.PublishAsync(V2.AgentState.Online, default);

        Assert.Equal((3UL, 7UL), (sent!.Buffer.DroppedTotal, sent.Buffer.EvictedTotal));
    }

    [Theory]
    [InlineData("3.1.0+4abc2442c5b720a45a47061f8c7f84e08a11fc33", "3.1.0+4abc244")]
    [InlineData("3.1.0", "3.1.0")]
    [InlineData(null, "3.1.0")]
    public void TheAgentVersion_NamesTheCommitItWasBuiltFrom(string? informational, string expected) =>
        Assert.Equal(expected, AgentCapabilities.FormatVersion(informational, "3.1.0"));

    private static async Task WaitUntil(Func<bool> condition)
    {
        var deadline = DateTime.UtcNow.AddSeconds(10);
        while (!condition())
        {
            Assert.True(DateTime.UtcNow < deadline, "timed out waiting for the reporter");
            await Task.Delay(20);
        }
    }
}
