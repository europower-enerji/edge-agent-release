using System;
using System.IO;
using Votech.Edge.Core.Configuration;
using Microsoft.Extensions.Configuration;
using Xunit;

namespace Votech.Edge.Ingestion.Tests;

public class DotEnvLoaderTests : IDisposable
{
    private readonly string _tempEnvFile;

    public DotEnvLoaderTests()
    {
        _tempEnvFile = Path.Combine(Path.GetTempPath(), $"test_{Guid.NewGuid():N}.env");
    }

    public void Dispose()
    {
        if (File.Exists(_tempEnvFile))
        {
            File.Delete(_tempEnvFile);
        }
    }

    [Fact]
    public void Load_MapsTheTenantGuard()
    {
        File.WriteAllText(_tempEnvFile, "TENANT_ID=1b2c3d4e-0000-4000-8000-000000000001\nAGENT_KEY=gpk_live_key\n");

        var config = DotEnvLoader.Load(_tempEnvFile);

        Assert.Equal("1b2c3d4e-0000-4000-8000-000000000001", config["EdgeAgent:TenantId"]);
        Assert.Equal("gpk_live_key", config["EdgeAgent:AgentKey"]);
    }

    [Fact]
    public void Load_ParsesSiteIdAndAgentKey_AndMapsToEdgeAgentConfig()
    {
        // Arrange
        var content = """
            # Test comment
            SITE_ID=site-uuid-1234
            AGENT_KEY="gpk_test_token_abc"
            API_BASE_URL='http://custom-api:9090'
            EdgeAgent__FlushIntervalMs=3500
            """;
        File.WriteAllText(_tempEnvFile, content);

        // Act
        var config = DotEnvLoader.Load(_tempEnvFile);

        // Assert
        Assert.Equal("site-uuid-1234", config["SITE_ID"]);
        Assert.Equal("site-uuid-1234", config["EdgeAgent:SiteId"]);
        Assert.Equal("gpk_test_token_abc", config["AGENT_KEY"]);
        Assert.Equal("gpk_test_token_abc", config["EdgeAgent:AgentKey"]);
        Assert.Equal("http://custom-api:9090", config["EdgeAgent:ApiBaseUrl"]);
        Assert.Equal("3500", config["EdgeAgent:FlushIntervalMs"]);

        // Verify System.Environment
        Assert.Equal("site-uuid-1234", Environment.GetEnvironmentVariable("SITE_ID"));
        Assert.Equal("gpk_test_token_abc", Environment.GetEnvironmentVariable("AGENT_KEY"));
    }

    /// <summary>EMS-217: the customer's env.example works without docker-compose (the Windows service reads it).</summary>
    [Fact]
    public void Load_MapsTheCustomerSettingNames_AsDockerComposeDoes()
    {
        File.WriteAllText(_tempEnvFile, """
            MQTT_HOST=votech.example.com
            MQTT_PORT=443
            MQTT_USE_TLS=true
            MQTT_WEBSOCKET_PATH=/mqtt
            MQTT_USERNAME=user
            MQTT_PASSWORD='pa$$word'
            MQTT_CA_CERT=C:\ProgramData\EdgeAgent\ca.pem
            API_CA_CERT=C:\ProgramData\EdgeAgent\ca.pem
            DB_PASSWORD=buffer-secret
            LOG_LEVEL=Debug
            """);

        var config = new ConfigurationBuilder().AddInMemoryCollection(DotEnvLoader.Load(_tempEnvFile)).Build();
        var options = config.GetSection("EdgeAgent").Get<EdgeAgentOptions>()!;

        Assert.Equal("votech.example.com", options.Mqtt.BrokerHost);
        Assert.Equal(443, options.Mqtt.BrokerPort);
        Assert.True(options.Mqtt.UseTls);
        Assert.Equal("wss://votech.example.com:443/mqtt", options.Mqtt.BrokerAddress);
        Assert.Equal("user", options.Mqtt.Username);
        Assert.Equal("pa$$word", options.Mqtt.Password);
        Assert.Equal(@"C:\ProgramData\EdgeAgent\ca.pem", options.Mqtt.CaCertificatePath);
        Assert.Equal(@"C:\ProgramData\EdgeAgent\ca.pem", options.ApiCaCertificatePath);
        Assert.Equal("buffer-secret", options.Storage.DbPassword);
        Assert.Equal("Debug", config["Serilog:MinimumLevel:Default"]);
    }

    [Fact]
    public void AddDotEnv_InjectsIntoConfigurationBuilder()
    {
        // Arrange
        var content = """
            SITE_ID=site-builder-test
            AGENT_KEY=gpk_builder_key
            """;
        File.WriteAllText(_tempEnvFile, content);

        var builder = new ConfigurationBuilder();

        // Act
        builder.AddDotEnv(_tempEnvFile);
        var configuration = builder.Build();

        // Assert
        Assert.Equal("site-builder-test", configuration["EdgeAgent:SiteId"]);
        Assert.Equal("gpk_builder_key", configuration["EdgeAgent:AgentKey"]);
    }
}
