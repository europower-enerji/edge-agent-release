using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Entities;
using Votech.Edge.Core.Interfaces;
using Votech.Edge.Mqtt;
using Votech.Edge.Service;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Moq;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Storage.Tests;

public class WorkerTests
{
    private readonly Mock<IConnectionManager> _connections = new();
    private readonly Mock<ISignalSink> _sink = new();
    private readonly Mock<ISignalBuffer> _buffer = new();
    private readonly Mock<IMqttPublisher> _mqtt = new();
    private readonly List<string> _steps = [];
    private readonly IOptions<EdgeAgentOptions> _options = Options.Create(new EdgeAgentOptions
    {
        SiteId = Guid.NewGuid().ToString(),
        FlushIntervalMs = 100,
    });

    public WorkerTests()
    {
        _mqtt.SetupGet(m => m.IsConnected).Returns(true);
        _connections.Setup(c => c.StartAsync(It.IsAny<CancellationToken>())).Callback(() => Step("start pollers")).Returns(Task.CompletedTask);
        _connections.Setup(c => c.StopAsync(It.IsAny<CancellationToken>())).Callback(() => Step("stop pollers")).Returns(Task.CompletedTask);
        _sink.Setup(s => s.DrainAsync(It.IsAny<CancellationToken>())).Callback(() => Step("drain sink")).Returns(Task.CompletedTask);
        _buffer.Setup(b => b.WaitForBatchesAsync(It.IsAny<TimeSpan>(), It.IsAny<CancellationToken>()))
            .Returns<TimeSpan, CancellationToken>((wait, ct) => Task.Delay(wait, ct));
        _buffer.Setup(b => b.GetStatusAsync(It.IsAny<CancellationToken>())).ReturnsAsync(new SignalBufferStatus(0, 0));
    }

    private void Step(string step)
    {
        lock (_steps)
        {
            _steps.Add(step);
        }
    }

    private Worker CreateWorker() =>
        new(
            NullLogger<Worker>.Instance,
            _connections.Object,
            _sink.Object,
            _buffer.Object,
            _mqtt.Object,
            new SignalBatchPublisher(_buffer.Object, _mqtt.Object, _options, NullLogger<SignalBatchPublisher>.Instance),
            _options
        );

    [Fact]
    public async Task Start_ConnectsMqtt_AndStartsThePollers()
    {
        var worker = CreateWorker();

        await worker.StartAsync(CancellationToken.None);
        await Task.Delay(300);
        await worker.StopAsync(CancellationToken.None);

        _mqtt.Verify(m => m.ConnectAsync(It.IsAny<CancellationToken>()), Times.Once);
        _connections.Verify(c => c.StartAsync(It.IsAny<CancellationToken>()), Times.Once);
    }

    [Fact]
    public async Task Stop_StopsThePollersFirst_ThenStoresAndSendsTheLastSamples()
    {
        var batchId = new byte[16];
        var last = new StoredSignalBatch(
            new BufferedSignalBatch { BatchId = batchId, EndpointId = new byte[16], SampleCount = 1 },
            [new BufferedSignalSample { BatchId = batchId, SignalId = new byte[16], Value = 1 }]
        );
        var drained = false;
        _sink.Setup(s => s.DrainAsync(It.IsAny<CancellationToken>())).Callback(() => { drained = true; Step("drain sink"); }).Returns(Task.CompletedTask);
        _buffer.Setup(b => b.NextUnpublishedAsync(It.IsAny<CancellationToken>()))
            .ReturnsAsync(() => drained && !_steps.Contains("publish") ? last : null);
        _mqtt.Setup(m => m.PublishSignalBatchAsync(It.IsAny<V2.SignalBatch>(), It.IsAny<CancellationToken>()))
            .Callback(() => Step("publish"))
            .Returns(Task.CompletedTask);
        var worker = CreateWorker();
        await worker.StartAsync(CancellationToken.None);
        await Task.Delay(200);

        await worker.StopAsync(CancellationToken.None);

        Assert.Equal(["start pollers", "stop pollers", "drain sink", "publish"], _steps);
        _buffer.Verify(b => b.MarkPublishedAsync(batchId, It.IsAny<CancellationToken>()), Times.Once);
    }
}
