using Votech.Edge.Core.Entities;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

namespace Votech.Edge.Storage.Tests;

public class EdgeDatabaseMigratorTests : IDisposable
{
    // The last migration of the 1.8.x agents.
    private const string Agent18Migration = "20260908100000_Phase1CTenantSiteIdentity";

    // The last migration of the 2.0.x agents.
    private const string Agent20Migration = "20261019075845_AddV2SignalSamples";

    private readonly string _directory = Path.Combine(Path.GetTempPath(), $"edge-migrate-{Guid.NewGuid():N}");

    static EdgeDatabaseMigratorTests()
    {
        SQLitePCL.Batteries.Init();
    }

    public EdgeDatabaseMigratorTests() => Directory.CreateDirectory(_directory);

    public void Dispose()
    {
        SqliteConnection.ClearAllPools();
        Directory.Delete(_directory, recursive: true);
    }

    private EdgeDbContext Context(string file) =>
        new(new DbContextOptionsBuilder<EdgeDbContext>().UseSqlite($"Data Source={file}").Options);

    private static async Task<int> CountAsync(EdgeDbContext db, string sql) =>
        (await db.Database.SqlQueryRaw<int>(sql).ToListAsync()).Single();

    private static Task<int> TableCountAsync(EdgeDbContext db, string table) =>
        CountAsync(db, $"SELECT COUNT(*) AS Value FROM sqlite_master WHERE type = 'table' AND name = '{table}'");

    [Fact]
    public async Task An18xDatabaseWithPendingRows_IsCopied_ThenItsLegacyTablesAreDropped()
    {
        var file = Path.Combine(_directory, "edge.db");
        await using (var old = Context(file))
        {
            await old.GetService<IMigrator>().MigrateAsync(Agent18Migration);
            await old.Database.ExecuteSqlRawAsync("PRAGMA journal_mode = WAL;");
            for (var i = 0; i < 3; i++)
            {
                await old.Database.ExecuteSqlInterpolatedAsync(
                    $"INSERT INTO TelemetryPoints (id, tenant_id, site_id, device_id, tag_id, batch_id, quality_status, tag_name, value, timestamp, is_published, quality, data_type, protocol, protocol_address, unit) VALUES ({$"p{i}"}, 't', 's', 'd', 'tag', 'b', 1, 'P', {i}, '2026-10-19 10:00:00', 0, 0, 'Analog', 'IEC104', 'IOA:1', 'kW')"
                );
            }
        }

        string? backup;
        await using (var db = Context(file))
        {
            backup = await EdgeDatabaseMigrator.MigrateAsync(db, "2.1.0", NullLogger.Instance);

            Assert.Empty(await db.Database.GetPendingMigrationsAsync());
            Assert.Equal(0, await TableCountAsync(db, "TelemetryPoints"));
            Assert.Equal(0, await TableCountAsync(db, "CachedDeviceConfigs"));
            Assert.Equal(0, await db.SignalBatches.CountAsync());
            Assert.Null(await db.EdgeConfigurationCache.FirstOrDefaultAsync());
        }

        // The unsent 1.8.x rows survive only in the copy taken before the migration.
        Assert.Equal($"{file}.bak-2.1.0", backup);
        await using var copy = Context(backup!);
        Assert.Equal([Agent18Migration], (await copy.Database.GetAppliedMigrationsAsync()).TakeLast(1));
        Assert.Equal(3, await CountAsync(copy, "SELECT COUNT(*) AS Value FROM TelemetryPoints WHERE is_published = 0"));
    }

    [Fact]
    public async Task A20xDatabase_KeepsItsUnsentBatches_AndLosesOnlyTheLegacyTables()
    {
        var file = Path.Combine(_directory, "edge.db");
        var batchId = Guid.NewGuid().ToByteArray();
        await using (var old = Context(file))
        {
            await old.GetService<IMigrator>().MigrateAsync(Agent20Migration);
            old.SignalBatches.Add(new BufferedSignalBatch { BatchId = batchId, EndpointId = new byte[16], ConfigRevision = "rev" });
            await old.SaveChangesAsync();
        }

        await using var db = Context(file);
        Assert.Equal($"{file}.bak-2.1.0", await EdgeDatabaseMigrator.MigrateAsync(db, "2.1.0", NullLogger.Instance));
        Assert.Equal(0, await TableCountAsync(db, "TelemetryPoints"));
        Assert.Equal(batchId, (await db.SignalBatches.SingleAsync(b => !b.IsPublished)).BatchId);
    }

    [Fact]
    public async Task ANewDatabase_IsCreatedWithoutACopy_AndAnUpToDateOneIsLeftAlone()
    {
        var file = Path.Combine(_directory, "new.db");
        await using (var db = Context(file))
        {
            Assert.Null(await EdgeDatabaseMigrator.MigrateAsync(db, "2.0.0", NullLogger.Instance));
            db.SignalBatches.Add(new BufferedSignalBatch { BatchId = Guid.NewGuid().ToByteArray(), EndpointId = new byte[16] });
            await db.SaveChangesAsync();
        }

        await using (var db = Context(file))
        {
            Assert.Null(await EdgeDatabaseMigrator.MigrateAsync(db, "2.0.1", NullLogger.Instance));
        }

        Assert.Equal(["new.db"], Directory.GetFiles(_directory, "new.db*").Select(Path.GetFileName).Where(f => !f!.EndsWith("-wal") && !f.EndsWith("-shm")));
    }
}
