using Xunit;

namespace Votech.Edge.Storage.Tests;

public class AgentInstanceLockTests : IDisposable
{
    private readonly string _directory = Path.Combine(Path.GetTempPath(), $"votech-lock-{Guid.NewGuid():N}");

    public void Dispose()
    {
        if (Directory.Exists(_directory))
        {
            Directory.Delete(_directory, true);
        }
    }

    [Fact]
    public void ASecondAgentOnTheSameDatabase_FailsToStart_UntilTheFirstStops()
    {
        var database = Path.Combine(_directory, "edge.db");
        string lockFile;
        using (var first = AgentInstanceLock.Acquire(database, TimeSpan.Zero))
        {
            Assert.NotNull(first);
            lockFile = first.Path;
            Assert.Equal(database + "-lock", lockFile);

            var error = Assert.Throws<InvalidOperationException>(() => AgentInstanceLock.Acquire(database, TimeSpan.FromMilliseconds(300)));
            Assert.Contains("Another agent is running", error.Message);
        }

        Assert.Equal(Environment.ProcessId.ToString(), File.ReadAllText(lockFile));
        using var second = AgentInstanceLock.Acquire(database, TimeSpan.Zero);
        Assert.NotNull(second);
    }

    [Theory]
    [InlineData(":memory:")]
    [InlineData("")]
    public void AnInMemoryDatabase_TakesNoLock(string dataSource)
    {
        Assert.Null(AgentInstanceLock.Acquire(dataSource, TimeSpan.Zero));
    }
}
