using Votech.Edge.Service;
using Serilog.Events;
using Serilog.Parsing;
using Xunit;

namespace Votech.Edge.Storage.Tests;

/// <summary>The agent's console lines look like the backend's: colored level, site and component badges.</summary>
public sealed class CleanConsoleFormatterTests
{
    private static readonly DateTimeOffset Timestamp = new(2026, 11, 9, 13, 31, 2, TimeSpan.FromHours(3));

    private static string Format(
        LogEventLevel level,
        string template,
        string? sourceContext,
        bool colors = false,
        Exception? exception = null,
        params LogEventProperty[] properties
    )
    {
        var all = sourceContext is null
            ? properties
            : [new LogEventProperty("SourceContext", new ScalarValue(sourceContext)), .. properties];
        var logEvent = new LogEvent(Timestamp, level, exception, new MessageTemplateParser().Parse(template), all);
        using var writer = new StringWriter();
        new CleanConsoleFormatter(colors).Format(logEvent, writer);
        return writer.ToString();
    }

    [Fact]
    public void Site_line_shows_time_level_site_component_and_message()
    {
        var line = Format(
            LogEventLevel.Information,
            "[IEC104-CONN] Connected to {Host}:{Port}.",
            "Votech.Edge.Ingestion.Iec104.Iec104ConnectionPoller",
            properties:
            [
                new LogEventProperty("Site", new ScalarValue("Plant A")),
                new LogEventProperty("Host", new ScalarValue("10.0.0.5")),
                new LogEventProperty("Port", new ScalarValue(2404)),
            ]
        );

        // {Message:lj}: strings without quotes, as the agent's messages are written
        Assert.Equal($"[13:31:02] [INF] [Plant A] [IEC104] [IEC104-CONN] Connected to 10.0.0.5:2404.{Environment.NewLine}", line);
    }

    [Fact]
    public void Agent_line_without_a_source_context_is_the_agents()
    {
        var line = Format(LogEventLevel.Fatal, "FATAL CONFIGURATION ERROR: the edge agent did not start.", sourceContext: null);

        Assert.Equal($"[13:31:02] [FTL] [Agent] FATAL CONFIGURATION ERROR: the edge agent did not start.{Environment.NewLine}", line);
    }

    [Fact]
    public void Colors_follow_the_backend()
    {
        var line = Format(
            LogEventLevel.Warning,
            "[MQTT] Broker unreachable.",
            "Votech.Edge.Mqtt.MqttPublisher",
            colors: true,
            properties: [new LogEventProperty("Site", new ScalarValue("Plant A"))]
        );

        Assert.StartsWith("\u001b[90m[13:31:02]\u001b[0m \u001b[33m[WRN]\u001b[0m \u001b[35m[Plant A]\u001b[0m \u001b[36m[MQTT]\u001b[0m ", line);
    }

    [Fact]
    public void Exception_is_indented_and_red()
    {
        var line = Format(
            LogEventLevel.Error,
            "[CONNECTIONS] Poller stopped with an error.",
            "Votech.Edge.Ingestion.Services.ConnectionManager",
            colors: true,
            exception: new InvalidOperationException("link lost")
        );

        Assert.Contains($"\u001b[31m  --> System.InvalidOperationException: link lost\u001b[0m{Environment.NewLine}", line);
    }

    [Fact]
    public void Without_colors_no_escape_codes_are_written()
    {
        var line = Format(LogEventLevel.Error, "Failed.", "Votech.Edge.Service.Worker", exception: new InvalidOperationException("x"));

        Assert.DoesNotContain('\u001b', line);
        Assert.Contains("  --> System.InvalidOperationException: x", line);
    }

    [Theory]
    [InlineData("Votech.Edge.Ingestion.Iec104.Iec104ConnectionPoller", "IEC104")]
    [InlineData("Votech.Edge.Ingestion.Modbus.ModbusConnectionPoller", "Modbus")]
    [InlineData("Votech.Edge.Mqtt.MqttPublisher", "MQTT")]
    [InlineData("Votech.Edge.Mqtt.SignalBatchPublisher", "MQTT")]
    [InlineData("Votech.Edge.Mqtt.V2CommandSubscriber", "Commands")]
    [InlineData("Votech.Edge.Mqtt.AgentStatusReporter", "Status")]
    [InlineData("Votech.Edge.Ingestion.Services.SignalSampleSink", "Sink")]
    [InlineData("Votech.Edge.Ingestion.Services.EndpointProbeService", "Probe")]
    [InlineData("Votech.Edge.Ingestion.Services.EdgeConfigurationSource", "Config")]
    [InlineData("Votech.Edge.Ingestion.Services.ConnectionManager", "Connections")]
    [InlineData("Votech.Edge.Ingestion.Services.ConnectionPollerFactory", "Connections")]
    [InlineData("Votech.Edge.Storage.SqliteSignalBuffer", "Storage")]
    [InlineData("Votech.Edge.Storage.StorageMaintenanceService", "Storage")]
    [InlineData("Votech.Edge.Service.AgentSupervisor", "Agent")]
    [InlineData("Votech.Edge.Ingestion.Services.AgentAssignmentSource", "Agent")]
    [InlineData("Votech.Edge.Service.SiteRuntime", "Agent")]
    [InlineData("Votech.Edge.Api", "API")]
    [InlineData("Votech.Edge.Service.Worker", "Worker")]
    [InlineData("Microsoft.EntityFrameworkCore.Migrations", "Storage")]
    [InlineData("System.Net.Http.HttpClient.EdgeApi.LogicalHandler", "HTTP")]
    [InlineData("Microsoft.Hosting.Lifetime", "Host")]
    [InlineData(null, "Agent")]
    public void Component_badge_of_each_class(string? sourceContext, string badge) =>
        Assert.Equal(badge, CleanConsoleFormatter.ResolveSourceBadge(sourceContext));

    [Theory]
    [InlineData(null, true)]
    [InlineData("", true)]
    [InlineData("true", true)]
    [InlineData("False", false)]
    [InlineData("false", false)]
    [InlineData("no", true)]
    public void Colors_are_on_unless_switched_off(string? setting, bool enabled) =>
        Assert.Equal(enabled, CleanConsoleFormatter.AnsiColorsEnabled(setting));
}
