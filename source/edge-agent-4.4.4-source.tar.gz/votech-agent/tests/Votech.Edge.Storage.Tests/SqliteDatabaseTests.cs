using Votech.Edge.Core.Entities;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

namespace Votech.Edge.Storage.Tests;

/// <summary>The SQLite database under the sample buffer: WAL checkpoints and SQLCipher encryption.</summary>
public class SqliteDatabaseTests : IDisposable
{
    private readonly string _file = Path.Combine(Path.GetTempPath(), $"edge_test_{Guid.NewGuid():N}.db");

    static SqliteDatabaseTests()
    {
        SQLitePCL.Batteries.Init();
    }

    public void Dispose()
    {
        SqliteConnection.ClearAllPools();
        foreach (var file in Directory.GetFiles(Path.GetDirectoryName(_file)!, Path.GetFileName(_file) + "*"))
        {
            File.Delete(file);
        }
    }

    private static TestDbContextFactory Factory(string connectionString) =>
        new(new DbContextOptionsBuilder<EdgeDbContext>().UseSqlite(connectionString).Options);

    [Fact]
    public async Task Checkpoint_RunsOnTheBufferDatabase()
    {
        var factory = Factory($"Data Source={_file}");
        await using (var db = factory.CreateDbContext())
        {
            await db.Database.EnsureCreatedAsync();
            await db.Database.ExecuteSqlRawAsync("PRAGMA journal_mode = WAL;");
        }

        var buffer = new SqliteSignalBuffer(factory, NullLogger<SqliteSignalBuffer>.Instance);

        Assert.Null(await Record.ExceptionAsync(() => buffer.CheckpointDatabaseAsync(CancellationToken.None)));
    }

    [Fact]
    public async Task APassword_EncryptsTheDatabaseOnDisk()
    {
        var encrypted = Factory(new SqliteConnectionStringBuilder($"Data Source={_file}") { Password = "SuperSecretPassword123!" }.ConnectionString);
        var batchId = Guid.NewGuid().ToByteArray();
        await using (var db = encrypted.CreateDbContext())
        {
            await db.Database.EnsureCreatedAsync();
            db.SignalBatches.Add(new BufferedSignalBatch { BatchId = batchId, EndpointId = new byte[16], ConfigRevision = "rev" });
            await db.SaveChangesAsync();
        }

        await using (var db = encrypted.CreateDbContext())
        {
            Assert.Equal(batchId, (await db.SignalBatches.SingleAsync()).BatchId);
        }

        // Without the password the file is not readable.
        await using var plain = Factory($"Data Source={_file}").CreateDbContext();
        var error = await Assert.ThrowsAsync<SqliteException>(() => plain.SignalBatches.ToListAsync());
        Assert.Contains("file is not a database", error.Message, StringComparison.OrdinalIgnoreCase);
    }
}

/// <summary>A minimal <see cref="IDbContextFactory{TContext}"/> for tests.</summary>
internal sealed class TestDbContextFactory(DbContextOptions<EdgeDbContext> options) : IDbContextFactory<EdgeDbContext>
{
    public EdgeDbContext CreateDbContext() => new(options);
}
