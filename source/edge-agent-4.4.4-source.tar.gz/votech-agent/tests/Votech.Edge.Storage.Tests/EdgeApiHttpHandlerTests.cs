using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Ingestion.Tests;
using Votech.Edge.Service;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;

namespace Votech.Edge.Storage.Tests;

/// <summary>A-02: the API client trusts a private CA the same way the broker connection does (API_CA_CERT).</summary>
public sealed class EdgeApiHttpHandlerTests : IDisposable
{
    private readonly TestCertificates _certificates = new();

    public void Dispose() => _certificates.Dispose();

    /// <summary>GET https://broker.test/ against a loopback server presenting <paramref name="serverCertificate"/>.</summary>
    private static async Task<string> GetAsync(SocketsHttpHandler handler, X509Certificate2 serverCertificate)
    {
        using var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        var port = ((IPEndPoint)listener.LocalEndpoint).Port;
        var server = TestCertificates.ServeOnceAsync(listener, serverCertificate, "ok");
        handler.ConnectCallback = async (_, ct) =>
        {
            var socket = new Socket(SocketType.Stream, ProtocolType.Tcp);
            await socket.ConnectAsync(IPAddress.Loopback, port, ct);
            return new NetworkStream(socket, ownsSocket: true);
        };
        using var client = new HttpClient(handler);
        try
        {
            return await client.GetStringAsync($"https://{TestCertificates.Host}:{port}/");
        }
        finally
        {
            await server;
        }
    }

    private EdgeAgentOptions Options(string? apiCa) => new() { ApiBaseUrl = $"https://{TestCertificates.Host}", ApiCaCertificatePath = apiCa };

    [Fact]
    public async Task WithTheApiCa_TheApiIsReached_AndOnlyItsCertificatesForTheHostAreTrusted()
    {
        var ok = await GetAsync(EdgeApiHttpHandler.Create(Options(_certificates.CaPemPath), NullLogger.Instance), _certificates.Server);
        var wrongHost = GetAsync(EdgeApiHttpHandler.Create(Options(_certificates.CaPemPath), NullLogger.Instance), _certificates.WrongHost);
        var otherCa = GetAsync(EdgeApiHttpHandler.Create(Options(_certificates.CaPemPath), NullLogger.Instance), _certificates.OtherCaServer);

        Assert.Equal("ok", ok);
        await Assert.ThrowsAsync<HttpRequestException>(() => wrongHost);
        await Assert.ThrowsAsync<HttpRequestException>(() => otherCa);
    }

    [Fact]
    public async Task WithoutTheApiCa_TheSystemCertificatesDecide_SoAPrivateCaIsNotTrusted()
    {
        await Assert.ThrowsAsync<HttpRequestException>(() => GetAsync(EdgeApiHttpHandler.Create(Options(null), NullLogger.Instance), _certificates.Server));
    }

    [Fact]
    public void AnApiCaFileThatCannotBeRead_Throws()
    {
        Assert.Throws<InvalidOperationException>(() => EdgeApiHttpHandler.Create(Options("missing-ca.pem"), NullLogger.Instance));
    }
}
