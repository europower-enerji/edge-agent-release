using Google.Protobuf;
using Votech.Edge.Core.Acquisition;
using Votech.Edge.Core.Configuration;
using Votech.Edge.Core.Entities;
using Votech.Edge.Service;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using Xunit;
using V2 = Votech.Shared.Protobuf.V2;

namespace Votech.Edge.Storage.Tests;

/// <summary>Agent 3.0: one SQLite file per site, and the sites an agent runs follow its assignment.</summary>
public class SiteDatabaseTests : IDisposable
{
    private static readonly Guid Tenant = Guid.Parse("1b2c3d4e-0000-4000-8000-000000000001");
    private static readonly AgentSite North = new(Tenant, Guid.Parse("5a17e000-0000-4000-8000-0000000000a1"), "North Solar Plant", "North Energy");
    private static readonly AgentSite South = new(Guid.Parse("1b2c3d4e-0000-4000-8000-000000000002"), Guid.Parse("7c6d5e4f-3a2b-4e8f-9b21-3f2b8c1e5a4d"), "South Solar Plant", "South Energy");

    private readonly string _directory = Path.Combine(Path.GetTempPath(), $"votech-sites-{Guid.NewGuid():N}");

    public SiteDatabaseTests() => SQLitePCL.Batteries.Init();

    public void Dispose()
    {
        Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
        if (Directory.Exists(_directory))
        {
            Directory.Delete(_directory, true);
        }
    }

    private string Configured => $"Data Source={Path.Combine(_directory, "edge.db")}";

    [Fact]
    public void EverySite_HasItsOwnFile_UnderItsOrganisation()
    {
        var north = SiteDatabase.ConnectionStringFor(North, Configured, null, NullLogger.Instance);
        var south = SiteDatabase.ConnectionStringFor(South, Configured, null, NullLogger.Instance);

        Assert.Equal(Path.Combine(_directory, North.TenantId.ToString(), $"{North.SiteId}.db"), SiteDatabase.DataSourceOf(north));
        Assert.Equal(Path.Combine(_directory, South.TenantId.ToString(), $"{South.SiteId}.db"), SiteDatabase.DataSourceOf(south));
        Assert.Equal(":memory:", SiteDatabase.DataSourceOf(SiteDatabase.ConnectionStringFor(North, "Data Source=:memory:", null, NullLogger.Instance)));
    }

    [Fact]
    public async Task ADatabaseOfAgent2_KeepsServingTheSiteItCaches_AndNoOther()
    {
        // An agent 2.x database at the configured path, caching the north site's configuration.
        var factory = new TestDbContextFactory(new DbContextOptionsBuilder<EdgeDbContext>().UseSqlite(Configured).Options);
        await SiteDatabase.PrepareAsync(factory, "3.0.0", NullLogger.Instance, CancellationToken.None);
        var configuration = new V2.EdgeConfiguration { SchemaVersion = 2, Revision = "r", SiteId = EdgeIds.ToByteString(North.SiteId) };
        await using (var db = factory.CreateDbContext())
        {
            db.EdgeConfigurationCache.Add(new CachedEdgeConfiguration { Revision = "r", SchemaVersion = 2, Payload = configuration.ToByteArray(), FetchedAt = DateTime.UtcNow });
            await db.SaveChangesAsync();
        }

        Microsoft.Data.Sqlite.SqliteConnection.ClearAllPools();
        var north = SiteDatabase.ConnectionStringFor(North, Configured, null, NullLogger.Instance);
        var south = SiteDatabase.ConnectionStringFor(South, Configured, null, NullLogger.Instance);

        Assert.Equal(Path.Combine(_directory, "edge.db"), SiteDatabase.DataSourceOf(north));
        Assert.Equal(Path.Combine(_directory, South.TenantId.ToString(), $"{South.SiteId}.db"), SiteDatabase.DataSourceOf(south));
    }

    [Fact]
    public void AnAssignmentChange_StartsTheNewSites_AndStopsTheRemovedOnes()
    {
        var third = new AgentSite(Tenant, Guid.NewGuid(), "Third", "North Energy");

        var (start, stop) = AgentSupervisor.Diff([North.SiteId, South.SiteId], [North, third]);

        Assert.Equal([third], start);
        Assert.Equal([South.SiteId], stop);
        var unchanged = AgentSupervisor.Diff([North.SiteId], [North]);
        Assert.Empty(unchanged.Start);
        Assert.Empty(unchanged.Stop);
    }
}
